"""Loads config.toml into typed settings. Every strategy number lives in the config file.

Setting names mirror the inputs of James's Pine Script "My ORB PMT".
"""
from __future__ import annotations

import copy
import tomllib
from dataclasses import dataclass, field, fields
from datetime import datetime, time, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo


@dataclass
class SessionConfig:
    name: str
    enabled: bool = False
    start: time = time(0, 0)  # opening range start, in this session's time zone
    # Time zone for `start`; blank = the main `timezone`. "America/New_York" follows NY daylight saving.
    timezone: str = ""
    window_minutes: int = 15  # opening range length
    rr_first: float = 0.3
    rr_flip: float = 0.3
    allow_flip: bool = True  # one re-entry on the opposite side after the first trade closes
    candle_sl: bool = False  # use the breakout candle's low/high as stop when mostly outside the range
    candle_sl_threshold: float = 50.0  # % of candle outside range that triggers candle SL
    min_close_pct_first: float = 0.0  # min % of candle range closed beyond the range, first trade
    min_close_pct_flip: float = 0.0  # same, flip trade
    breakout_window_hours: float = 2.0  # entries allowed this long after range locks (0 = unlimited)
    body_filter: bool = False
    min_body_pct: float = 50.0
    exhaustion_filter: bool = False
    # Bot-only extra (not in the Pine Script): close any open trade from this session at this time.
    flatten_at: time | None = None

    @property
    def max_trades(self) -> int:
        return 2 if self.allow_flip else 1


@dataclass
class RiskConfig:
    risk_mode: str = "percent"  # "percent" = risk_percent of the balance; "dollars" = risk_dollars per trade
    risk_percent: float = 1.0
    risk_dollars: float = 500.0
    risk_on_starting_balance: bool = False
    account_size: float = 50000.0
    max_contracts: int = 50
    prop_firm_passer: bool = False
    passer_multiplier: float = 2.0
    passer_recovery_wins: int = 6


@dataclass
class SafetyConfig:
    """Bot-only extras. None of these are in the Pine Script; 0 means off."""
    max_daily_loss: float = 0.0
    stop_after_daily_profit: float = 0.0
    min_bracket_ticks: int = 1


@dataclass
class StrategyConfig:
    bar_minutes: int = 15  # the TradingView chart timeframe the strategy runs on


@dataclass
class SimConfig:
    commission_per_side: float = 0.0  # $ per contract per side, used in paper/replay
    slippage_ticks: int = 0  # applied to market entries and stop exits in paper/replay


@dataclass
class BrokerConfig:
    base_url: str = "https://api.topstepx.com"
    symbol: str = "MNQ"
    account_id: int | None = None
    account_name: str = ""  # shown in the app; saved with account_id
    # A non-Practice account (e.g. a Combine) the bot may trade. Only set when you confirm it in the app.
    confirmed_account_id: int | None = None
    confirmed_accounts: list[int] = field(default_factory=list)  # every non-Practice account confirmed in the app
    live_data: bool = False  # False = simulated data feed (Practice/Combine)
    poll_seconds: int = 10
    # Set by `orb-bot bracket-test`. Live order placement is refused until it is set.
    bracket_tick_mode: str | None = None  # "signed" or "unsigned"
    # No longer used: fast bars are always on (kept so older config files still load).
    fast_bars: bool = True
    rtc_url: str = ""  # market hub URL; blank = derived from base_url (rtc.topstepx.com)
    # TopstepX's commission per contract per side, on top of the exchange fees Topstep's trade list gives
    # (TopstepX showed $0.25 for MNQ and MGC on 14 Oct 2026). Used so Performance matches TopstepX's net P&L.
    commission_per_side: float = 0.25


@dataclass
class AlertsConfig:
    """A "TradingView alerts" bot: trades whatever a TradingView script's alerts say (no strategy code here)."""
    secret: str = ""  # must be in every alert message as "key"; made when the bot is added
    symbol: str = ""  # contract this bot trades, e.g. "MGC"; blank = the contract in config.toml
    sizing: str = "tv"  # "tv" = TradingView's contracts x multiplier; "fixed" = always `contracts`
    multiplier: float = 1.0
    contracts: int = 1
    # Every entry goes to Topstep with its stop and target attached (Auto OCO), so exits fill at Topstep with
    # no TradingView delay. Alerts that send "stop"/"target" prices (e.g. from the script's plotted lines)
    # use those; otherwise the stop is stop_ticks from the fill and the target target_rr x the stop
    # (or target_ticks when target_rr is 0).
    stop_ticks: int = 80
    # When an alert has no usable stop price: the script's own $ risk per trade (e.g. 500). The stop is then
    # worked out as risk / (TradingView's contracts x tick value), the way a risk-sized script places it.
    # 0 = off (use stop_ticks).
    script_risk: float = 0.0
    # With script_risk set: the script's opening range, e.g. "15:00" for 15 minutes (main time zone). The bot
    # then tries the two stops a breakout script uses, the range's far edge and the breakout candle's high/low,
    # and takes the one whose distance fits TradingView's size. Blank = use the middle of the sizes' range.
    range_start: str = ""
    range_minutes: int = 15
    chart_minutes: int = 5  # the script's TradingView chart timeframe (the breakout candle's size)
    target_rr: float = 1.0
    target_ticks: int = 80
    # The script's own exit alert: "close" = close the trade if Topstep's stop/target hasn't already,
    # "ignore" = leave the exit to Topstep's stop and target.
    exit_alerts: str = "ignore"
    # When the TradingView alert stops firing (TradingView alerts can expire), e.g. "2026-11-09". The app counts
    # down to it and warns 3 days before. Blank = no reminder.
    alert_expires: str = ""


@dataclass
class ScriptConfig:
    """A "Your own script" bot: a Python file with a Strategy class (see orb_bot/scripting.py)."""
    file: str = ""  # e.g. "strategies/ema_cross.py", relative to the bot folder (where config.toml is)
    params: dict = field(default_factory=dict)  # overrides for the script's own params
    symbol: str = ""  # contract this bot trades, e.g. "MGC"; blank = the script's own, else the one in config.toml


@dataclass
class UpdatesConfig:
    url: str = ""  # where the app looks for new versions (latest.json); blank = the built-in address
    check: bool = True  # look for a new version when the app opens and every few hours


@dataclass
class WebhookConfig:
    """Where the app listens for TradingView alerts (config.toml only)."""
    port: int = 8787
    public_url: str = ""  # your free ngrok static domain, e.g. "james-orb.ngrok-free.app"
    start_ngrok: bool = True  # the app starts ngrok itself when an alerts bot starts


@dataclass
class NotifyConfig:
    """Phone alerts through Telegram (config.toml only). The bot token is kept in the Keychain."""
    telegram_chat_id: str = ""  # blank = phone alerts off
    trades: bool = True  # a message when a trade opens and when it closes
    problems: bool = True  # rejected orders, unprotected trades, TradingView can't reach the app, errors
    paper: bool = False  # also message Paper trades


@dataclass
class Config:
    timezone: ZoneInfo
    sessions: list[SessionConfig]
    risk: RiskConfig
    safety: SafetyConfig
    strategy: StrategyConfig
    broker: BrokerConfig
    sim: SimConfig = field(default_factory=SimConfig)
    log_dir: Path = field(default_factory=lambda: Path("logs"))
    path: Path | None = None
    name: str = ""  # the bot's name in the app, e.g. "ORB M5"; blank = "ORB M<timeframe>"
    kind: str = "orb"  # "orb" = the built-in ORB strategy; "alerts" = trades a TradingView script's alerts
    alerts: AlertsConfig = field(default_factory=AlertsConfig)
    script: ScriptConfig = field(default_factory=ScriptConfig)
    webhook: WebhookConfig = field(default_factory=WebhookConfig)
    updates: UpdatesConfig = field(default_factory=UpdatesConfig)
    notify: NotifyConfig = field(default_factory=NotifyConfig)

    @property
    def bot_name(self) -> str:
        if self.name:
            return self.name
        if self.kind == "script":
            return Path(self.script.file).stem.replace("_", " ").title() or "My strategy"
        return "TV alerts" if self.kind == "alerts" else f"ORB M{self.strategy.bar_minutes}"

    def script_path(self) -> Path:
        p = Path(self.script.file)
        if p.is_absolute():
            return p
        base = self.path.parent if self.path else Path.cwd()
        if base.name == "bots":
            base = base.parent
        return base / p

    @property
    def slug(self) -> str:
        """Short id for order tags and state files: letters and digits only (e.g. "orbm5")."""
        return "".join(ch for ch in self.bot_name.lower() if ch.isalnum()) or "bot"


def session_tz(cfg: Config, s: SessionConfig) -> ZoneInfo:
    return ZoneInfo(s.timezone) if s.timezone else cfg.timezone


def session_window(cfg: Config, s: SessionConfig, now: datetime) -> tuple[datetime, datetime]:
    """Today's range start and end (for the session's own calendar day), in the main time zone."""
    tz = session_tz(cfg, s)
    start = datetime.combine(now.astimezone(tz).date(), s.start, tz)
    return start.astimezone(cfg.timezone), (start + timedelta(minutes=s.window_minutes)).astimezone(cfg.timezone)


def _t(value: str) -> time:
    hh, mm = value.split(":")
    return time(int(hh), int(mm))


def _section(cls, raw: dict, label: str):
    known = {f.name for f in fields(cls)}
    unknown = set(raw) - known
    if unknown:
        raise ValueError(f"unknown setting(s) in [{label}]: {', '.join(sorted(unknown))}")
    return cls(**raw)


def load_config(path: str | Path) -> Config:
    path = Path(path)
    raw = tomllib.loads(path.read_text())
    sessions = []
    for name, s in raw.get("sessions", {}).items():
        s = dict(s)
        s["start"] = _t(s.get("start", "00:00"))
        s["flatten_at"] = _t(s["flatten_at"]) if s.get("flatten_at") else None
        sessions.append(_section(SessionConfig, {"name": name, **s}, f"sessions.{name}"))
        if sessions[-1].timezone:
            ZoneInfo(sessions[-1].timezone)  # fail early on a misspelt zone
    return Config(
        timezone=ZoneInfo(raw.get("timezone", "Australia/Brisbane")),
        sessions=sessions,
        risk=_section(RiskConfig, raw.get("risk", {}), "risk"),
        safety=_section(SafetyConfig, raw.get("safety", {}), "safety"),
        strategy=_section(StrategyConfig, raw.get("strategy", {}), "strategy"),
        broker=_section(BrokerConfig, raw.get("broker", {}), "broker"),
        sim=_section(SimConfig, raw.get("sim", {}), "sim"),
        log_dir=Path(raw.get("log_dir", "logs")),
        path=path,
        name=str(raw.get("name", "")),
        kind=str(raw.get("type", "orb")),
        alerts=_section(AlertsConfig, raw.get("alerts", {}), "alerts"),
        script=_section(ScriptConfig, raw.get("script", {}), "script"),
        webhook=_section(WebhookConfig, raw.get("webhook", {}), "webhook"),
        updates=_section(UpdatesConfig, raw.get("updates", {}), "updates"),
        notify=_section(NotifyConfig, raw.get("notify", {}), "notify"),
    )


def parse_date(text: str):
    """"2026-11-09" or "9/11/2026" (day first) -> date; blank or unreadable -> None."""
    from datetime import datetime as _dt
    text = (text or "").strip()
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%d %b %Y", "%d %B %Y"):
        try:
            return _dt.strptime(text, fmt).date()
        except ValueError:
            continue
    return None


def render_value(value) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, time):
        return f'"{value.strftime("%H:%M")}"'
    if isinstance(value, str):
        return f'"{value}"'
    if isinstance(value, (list, tuple)):
        return "[" + ", ".join(render_value(v) for v in value) + "]"
    return str(value)


def save_broker_setting(path: Path, key: str, value: str | int) -> None:
    save_setting(path, "broker", key, value)


def save_top_setting(path: Path, key: str, value) -> None:
    """Write a top-level key (one above the first [section]), e.g. the bot's name."""
    lines = path.read_text().splitlines()
    rendered = f"{key} = {render_value(value)}"
    first_section = next((i for i, l in enumerate(lines) if l.strip().startswith("[")), len(lines))
    for i in range(first_section):
        s = lines[i].strip()
        if s.startswith(f"{key} ") or s.startswith(f"{key}="):
            lines[i] = rendered
            break
    else:
        lines.insert(first_section, rendered)
        lines.insert(first_section + 1, "")
    path.write_text("\n".join(lines) + "\n")


def save_setting(path: Path, section: str, key: str, value) -> None:
    """Write one key back into config.toml under [section], keeping comments and the rest of the file."""
    lines = path.read_text().splitlines()
    header = f"[{section}]"
    rendered = f"{key} = {render_value(value)}"
    in_broker, inserted = False, False
    out: list[str] = []
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("[") and in_broker and not inserted:
            out.append(rendered)
            inserted = True
        if stripped.startswith("["):
            in_broker = stripped.split("#")[0].strip() == header
        if in_broker and (stripped.startswith(f"{key} ") or stripped.startswith(f"{key}=")
                          or stripped.startswith(f"# {key} ")):
            if not inserted:
                comment = line[line.index("#", len(key)):] if "#" in line[len(key) + 1:] and not stripped.startswith("#") else ""
                out.append(f"{rendered:<32} {comment}".rstrip() if comment else rendered)
                inserted = True
            continue
        out.append(line)
    if not inserted:
        if not any(l.split("#")[0].strip() == header for l in lines):
            out.append(header)
        out.append(rendered)
    path.write_text("\n".join(out) + "\n")


# Per-account settings. Each bot can run on several accounts at once; its risk, daily loss limit and session
# switches can differ per account and live in the bot's file under [accounts.<account id>]. Anything not set
# there comes from the bot's own [risk], [safety] and [sessions] sections.
ACCOUNT_KEYS = {"risk_mode": "risk", "risk_percent": "risk", "risk_dollars": "risk", "max_contracts": "risk",
                "max_daily_loss": "safety", "sizing": "alerts", "multiplier": "alerts", "contracts": "alerts"}


def account_section(account_id: int) -> str:
    return f"accounts.{account_id}"


def _script_symbol(cfg: Config) -> str:
    """The contract a script asks for (its class's `symbol`), or ""."""
    try:
        from .scripting import load_strategy
        return str(getattr(load_strategy(cfg.script_path()), "symbol", "") or "")
    except Exception:  # noqa: BLE001 - a broken script is reported when the bot starts
        return ""


def for_account(cfg: Config, broker: BrokerConfig, account_id: int | None, account_name: str = "") -> Config:
    """A copy of a bot's settings for one account: its own broker settings plus that account's overrides."""
    out = copy.deepcopy(cfg)
    out.broker = copy.deepcopy(broker)
    out.broker.account_id = account_id
    out.broker.account_name = account_name
    if out.kind == "alerts" and out.alerts.symbol:
        out.broker.symbol = out.alerts.symbol
    if out.kind == "script":
        sym = out.script.symbol or _script_symbol(out)
        if sym:
            out.broker.symbol = sym
    if account_id is None or not cfg.path:
        return out
    raw = tomllib.loads(cfg.path.read_text()).get("accounts", {}).get(str(account_id), {})
    for key, value in raw.items():
        if key in ACCOUNT_KEYS:
            setattr(getattr(out, ACCOUNT_KEYS[key]), key, value)
        elif key.endswith("_enabled"):
            for s in out.sessions:
                if s.name == key.removesuffix("_enabled"):
                    s.enabled = bool(value)
    return out


def save_account_setting(path: Path, account_id: int | None, key: str, value) -> None:
    """Save one per-account setting (or the bot's base setting when there's no account)."""
    if account_id is not None:
        save_setting(path, account_section(account_id), key, value)
    elif key.endswith("_enabled"):
        save_setting(path, f"sessions.{key.removesuffix('_enabled')}", "enabled", value)
    else:
        save_setting(path, ACCOUNT_KEYS[key], key, value)
