"""The app window (PySide6). Same engine as the command line; nothing here changes how it trades.

Start it with `orb-bot app`, or double-click the Mac app made by `orb-bot make-app`.

The app can run several bots at once, on several accounts at once. Each bot has its own settings file
(config.toml is the first bot and also holds the login and contract; added bots live in bots/<name>.toml).
Each account shows every bot with its own Start/Stop, risk and session switches, so ORB M5 can run on the
Practice account and the Combine together. The account dropdown only changes which account you're looking at;
bots keep running on the others. Every bot only ever manages its own orders.
"""
from __future__ import annotations

import json
import copy
import logging
import os
import secrets
import shutil
import subprocess
import sys
import threading
from dataclasses import fields
from datetime import datetime, time, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

import html

from PySide6.QtCore import QDate, QObject, QPointF, QRectF, QSize, Qt, QTime, QTimer, Signal
from PySide6.QtGui import QAction, QColor, QFont, QLinearGradient, QPainter, QPen
from PySide6.QtWidgets import (QApplication, QButtonGroup, QCheckBox, QComboBox, QDateEdit, QDialog, QDialogButtonBox, QFileDialog,
                               QDoubleSpinBox, QFormLayout, QFrame, QGridLayout, QGroupBox, QHBoxLayout, QLabel,
                               QLineEdit, QMainWindow, QMenu, QMessageBox, QPlainTextEdit, QPushButton, QScrollArea,
                               QSizePolicy, QSpinBox, QSplitter, QStackedWidget, QTableWidget, QTableWidgetItem, QTabWidget,
                               QTimeEdit, QToolButton, QVBoxLayout, QWidget, QHeaderView, QAbstractItemView)

from . import theme
from .brand import APP_NAME

from .alerts import AlertEngine
from .broker.projectx import ProjectXBroker
from .broker.stream import get_stream
from .live_pnl import OpenPnL
from .layouts import FlowLayout, PageStack
from .cli import (BotNameFilter, attach_fast_bars, describe, get_credentials, save_credentials, session_bar_warnings, set_thread_bot,
                  setup_logging)
from .config import (parse_date, AlertsConfig, BrokerConfig, Config, RiskConfig, SafetyConfig, SessionConfig, SimConfig, StrategyConfig,
                     for_account, load_config, OG_NAME, rename_original_orb, save_account_setting, save_setting, save_top_setting,
                     session_tz, session_window)
from . import notify as phone
from .engine import Engine
from . import updater
from . import licence as lic
from .overview import AllBots, bot_row
from .perf_view import PerformanceWindow
from .help_view import HelpWindow
from .webhook import WebhookServer, find_ngrok
from .tools import (ToolError, bracket_test, check, confirm_account, may_trade, paper_broker, replay,
                    select_account)

# shipped with the app; packaged builds don't show their code on the My bots page
BUILT_IN_SCRIPTS = {"orb_1m.py", "orb_5m.py", "simple_orb.py", "ema_cross.py"}


def _script_risk_section(params: dict) -> str:
    """A new script bot's risk box starts from the script's own risk_dollars / max_contracts (ORB 1M: $535, 2)."""
    if "risk_dollars" in params:
        return (f'[risk]\nrisk_mode = "dollars"\nrisk_dollars = {float(params["risk_dollars"]):g}\n'
                f'max_contracts = {int(params.get("max_contracts", 5))}\n')
    return "[risk]\nmax_contracts = 5\n"

log = logging.getLogger("orb_bot")

GREEN, RED, AMBER, MUTED = theme.UP, theme.DOWN, theme.WARN, theme.TEXT_2

LABELS = {
    "window_minutes": "Range length (min)", "rr_first": "RR first trade", "rr_flip": "RR flip trade",
    "allow_flip": "Allow flip", "candle_sl": "Candle-based SL", "candle_sl_threshold": "Candle SL threshold %",
    "min_close_pct_first": "Min close % beyond range (first)", "min_close_pct_flip": "Min close % (flip)",
    "breakout_window_hours": "Breakout window (h, 0 = no limit)", "body_filter": "Body filter",
    "min_body_pct": "Min body %", "exhaustion_filter": "Exhaustion filter", "start": "Range start",
    "flatten_at": "Close trade at (blank = off)", "risk_on_starting_balance": "% of starting balance (not current)",
    "account_size": "Starting balance $", "prop_firm_passer": "Prop Firm Passer",
    "passer_multiplier": "Passer multiplier", "passer_recovery_wins": "Passer recovery wins",
    "stop_after_daily_profit": "Stop after daily profit $ (0 = off)", "min_bracket_ticks": "Min stop/target ticks",
    "bar_minutes": "Chart timeframe (min)", "symbol": "Contract (MNQ or NQ)",
    "commission_per_side": "Paper commission $/side", "slippage_ticks": "Paper slippage ticks",
    "timezone": "Range start time zone",
    "alerts.symbol": "Contract (blank = same as config.toml)",
    "alerts.stop_ticks": "Stop (ticks from entry)", "alerts.target_rr": "Target RR (× stop; 0 = use ticks)",
    "alerts.target_ticks": "Target (ticks, when RR is 0)",
    "alerts.script_risk": "Script's $ risk per trade (works out a missing stop; 0 = off)",
    "alerts.range_start": "Script's opening range start (e.g. 15:00; finds its stop)",
    "alerts.range_minutes": "Script's opening range length (min)",
    "alerts.chart_minutes": "Script's chart timeframe (min)",
    "alerts.exit_alerts": "Script's exit alerts",
    "alerts.alert_expires": "TradingView alert expires (e.g. 9/11/2026; blank = no reminder)",
}
# Session time zone choices: (label, config value). Blank = the main time zone (Brisbane).
SESSION_ZONES = [("Brisbane", ""), ("New York (follows US daylight saving)", "America/New_York")]
# Settings tab sections: (title, config section name, dataclass, fields shown)
EXTRA_SECTIONS = [
    ("Sizing", "risk", RiskConfig, ["risk_on_starting_balance", "account_size", "prop_firm_passer",
                                    "passer_multiplier", "passer_recovery_wins"]),
    ("Safety", "safety", SafetyConfig, ["stop_after_daily_profit", "min_bracket_ticks"]),
    ("Chart", "strategy", StrategyConfig, ["bar_minutes"]),
    ("Contract", "broker", BrokerConfig, ["symbol"]),
    ("Paper mode", "sim", SimConfig, ["commission_per_side", "slippage_ticks"]),
]
# Settings tab sections for a TradingView alerts bot.
ALERT_SECTIONS = [
    ("Stop and target at Topstep", "alerts", AlertsConfig, ["stop_ticks", "script_risk", "range_start",
                                                            "range_minutes", "chart_minutes", "target_rr",
                                                            "target_ticks", "exit_alerts", "alert_expires", "symbol"]),
    ("Paper mode", "sim", SimConfig, ["commission_per_side", "slippage_ticks"]),
]
EXPIRY_WARN_DAYS = 3  # warn this many days before a TradingView alert expires
TIMEFRAMES = [(1, "1 min"), (2, "2 min"), (3, "3 min"), (5, "5 min"), (10, "10 min"), (15, "15 min"),
              (30, "30 min"), (60, "1 hour")]


def money(v: float | None, signed: bool = False) -> str:
    if v is None:
        return "–"
    s = f"${abs(v):,.2f}"
    if signed:
        return ("+" if v >= 0 else "−") + s
    return s if v >= 0 else "−" + s


def _slug(name: str) -> str:
    return "".join(ch for ch in name.lower() if ch.isalnum())


def short_account(name: str, account_id: int | None = None) -> str:
    """PRAC-V2-105042-46832716 -> PRAC…2716 (for log lines)."""
    if not name:
        return f"account {account_id}" if account_id else "no account"
    parts = name.split("-")
    return f"{parts[0]}…{parts[-1][-4:]}" if len(parts) > 2 else name


class LogBridge(QObject):
    line = Signal(str, int)


class QtLogHandler(logging.Handler):
    def __init__(self, bridge: LogBridge):
        super().__init__()
        self.bridge = bridge
        self.setFormatter(logging.Formatter("%(asctime)s  %(bot)s%(message)s", "%H:%M:%S"))
        self.addFilter(BotNameFilter())

    def emit(self, record):
        try:
            self.bridge.line.emit(self.format(record), record.levelno)
        except RuntimeError:  # window already closed
            pass


def log_html(line: str, level: int = logging.INFO) -> str:
    """One log line for the Activity tab: time faint, bot name in the accent colour, problems in red or amber."""
    when, _, rest = line.partition("  ")
    tag = ""
    if rest.startswith("[") and "] " in rest:
        tag, rest = rest[1:].split("] ", 1)
    color = theme.DOWN_SOFT if level >= logging.ERROR else theme.WARN if level >= logging.WARNING else theme.TEXT_2
    if level < logging.WARNING and ("filled" in rest or rest.startswith("trade closed (target")):
        color = theme.TEXT
    return (f"<span style='color:{theme.TEXT_3}'>{html.escape(when)}</span>&nbsp;&nbsp;"
            + (f"<span style='color:{theme.ACCENT}'>{html.escape(tag)}</span>&nbsp;&nbsp;" if tag else "")
            + f"<span style='color:{color}'>{html.escape(rest)}</span>")


def set_pill(label: QLabel, text: str, kind: str) -> None:
    """A rounded status label: kind is run (green), wait (amber), error (red) or off (grey)."""
    fg, bg = {"run": (theme.UP, "rgba(47,196,137,0.12)"), "wait": (theme.WARN, "rgba(230,162,60,0.13)"),
              "error": (theme.DOWN_SOFT, "rgba(240,93,94,0.14)"),
              "off": (theme.TEXT_2, "rgba(139,147,165,0.12)")}[kind]
    label.setText(f"●&nbsp; {html.escape(text)}")
    label.setStyleSheet(f"color: {fg}; background: {bg};")


class Card(QFrame):
    """One figure in the stat strip under the header."""
    def __init__(self, title: str, last: bool = False):
        super().__init__()
        self.setObjectName("stat")
        self.setProperty("last", last)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(16, 11, 16, 12)
        lay.setSpacing(2)
        t = QLabel(title.upper())
        t.setObjectName("statTitle")
        self.value = QLabel("–")
        self.value.setObjectName("statValue")
        lay.addWidget(t)
        lay.addWidget(self.value)

    def set(self, text: str, color: str | None = None):
        self.value.setText(text)
        self.value.setStyleSheet(f"color: {color};" if color else "")


class Chip(QLabel):
    """One TopstepX-style figure next to the account picker: "BAL: $151,564.11". A filled chip (RP&L) turns
    green or red with the sign of its value."""
    def __init__(self, title: str, filled: bool = False, tip: str = ""):
        super().__init__()
        self.title, self.filled = title, filled
        self.setObjectName("chip")
        self.setTextFormat(Qt.RichText)
        self.setToolTip(tip)
        self.set("–")

    def set(self, text: str, color: str | None = None):
        self.setText(f"<span style='color:{theme.TEXT_2 if not (self.filled and color) else theme.TEXT}'>"
                     f"{self.title}:</span>&nbsp;<b>{text}</b>")
        if self.filled and color:
            self.setStyleSheet(f"background: {color}; border-color: {color}; color: #0b0d12;")
        else:
            self.setStyleSheet(f"color: {color};" if color else "")
        self.setFixedSize(self.sizeHint())  # re-fit to the new figure


class ModeSwitch(QFrame):
    """Paper | Live orders. Same calls as the combo box it replaced: index 0 = paper, 1 = real orders."""
    currentIndexChanged = Signal(int)

    def __init__(self):
        super().__init__()
        self.setObjectName("seg")
        lay = QHBoxLayout(self)
        lay.setContentsMargins(2, 2, 2, 2)
        lay.setSpacing(2)
        self.group = QButtonGroup(self)
        self.buttons = []
        for i, (text, name, tip) in enumerate([
                ("Paper", "paper", "Simulated orders only. Nothing is sent to Topstep."),
                ("Live orders", "live", "Real orders on the Topstep account shown at the top.")]):
            b = QPushButton(text)
            b.setObjectName(name)
            b.setCheckable(True)
            b.setToolTip(tip)
            b.setCursor(Qt.PointingHandCursor)
            self.group.addButton(b, i)
            lay.addWidget(b)
            self.buttons.append(b)
        self.buttons[0].setChecked(True)
        self.group.idToggled.connect(lambda i, on: on and self.currentIndexChanged.emit(i))

    def currentIndex(self) -> int:
        return max(self.group.checkedId(), 0)

    def setCurrentIndex(self, i: int) -> None:
        self.buttons[i].setChecked(True)


class BracketBar(QWidget):
    """The open trade drawn as a bar from stop to target, with the entry marked and a dot at the last price."""

    def __init__(self):
        super().__init__()
        self.trade: dict | None = None
        self.setMinimumHeight(46)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

    def set(self, trade: dict | None) -> None:
        self.trade = trade
        self.update()

    def paintEvent(self, _event):
        t = self.trade
        if not t:
            return
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w = self.width()
        pad, y = 7.0, 12.0
        span = (t["target"] - t["stop"]) or 1.0
        x = lambda v: pad + max(0.0, min(1.0, (v - t["stop"]) / span)) * (w - 2 * pad)  # noqa: E731
        grad = QLinearGradient(pad, 0, w - pad, 0)
        grad.setColorAt(0, QColor(240, 93, 94, 150))
        grad.setColorAt(1, QColor(47, 196, 137, 150))
        p.setPen(Qt.NoPen)
        p.setBrush(grad)
        p.drawRoundedRect(QRectF(pad, y - 2, w - 2 * pad, 4), 2, 2)
        p.setBrush(QColor(theme.TEXT_2))
        p.drawRoundedRect(QRectF(x(t["entry"]) - 1, y - 9, 2, 18), 1, 1)
        if t.get("last") is not None:
            p.setPen(QPen(QColor(theme.PANEL), 3))
            p.setBrush(QColor(theme.TEXT))
            p.drawEllipse(QPointF(x(t["last"]), y), 6, 6)
        f = QFont(self.font())
        f.setPixelSize(11)
        p.setFont(f)
        p.setPen(QColor(theme.TEXT_3))
        r = QRectF(0, y + 14, w, 16)
        p.drawText(r, Qt.AlignLeft | Qt.AlignVCenter, f"Stop {t['stop']:,.2f}")
        p.drawText(r, Qt.AlignHCenter | Qt.AlignVCenter, f"Entry {t['entry']:,.2f}")
        p.drawText(r, Qt.AlignRight | Qt.AlignVCenter, f"Target {t['target']:,.2f}")
        p.end()


def notify(title: str, text: str) -> None:
    """A macOS notification (does nothing elsewhere)."""
    if sys.platform != "darwin":
        return
    q = lambda v: v.replace("\\", "").replace('"', "'")  # noqa: E731
    try:
        subprocess.Popen(["osascript", "-e", f'display notification "{q(text)}" with title "{q(title)}"'],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except OSError:
        pass


def _box(title: str) -> QGroupBox:
    return QGroupBox(title.upper())


class PhoneAlertsDialog(QDialog):
    """Telegram setup: bot token (Keychain), chat id, what to send, and a test message."""
    def __init__(self, cfg: "Config", token: str | None, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Phone alerts (Telegram)")
        self.setMinimumWidth(520)
        form = QFormLayout(self)
        steps = QLabel("1. In Telegram, message <b>@BotFather</b>, send <b>/newbot</b> and follow the steps. "
                       "It gives you a token.<br>2. Paste the token below.<br>3. Open your new bot in Telegram "
                       "and send it any message (e.g. <i>hi</i>).<br>4. Press <b>Find my chat</b>, then "
                       "<b>Send test</b>.<br><br>Then you can text the bot <b>/status</b>, <b>/stop</b> or "
                       "<b>/flatten</b>. Only your chat is listened to. Free, no limits.")
        steps.setWordWrap(True)
        steps.setTextFormat(Qt.RichText)
        form.addRow(steps)
        self.token = QLineEdit(token or "")
        self.token.setEchoMode(QLineEdit.Password)
        self.token.setPlaceholderText("123456789:AA…")
        form.addRow("Bot token", self.token)
        row = QHBoxLayout()
        self.chat = QLineEdit(cfg.notify.telegram_chat_id)
        self.chat.setPlaceholderText("found automatically")
        find = QPushButton("Find my chat")
        find.clicked.connect(self._find)
        row.addWidget(self.chat, 1)
        row.addWidget(find)
        form.addRow("Your chat", row)
        self.trades = QCheckBox("When a trade opens and closes")
        self.trades.setChecked(cfg.notify.trades)
        self.problems = QCheckBox("When something needs attention (rejected order, TradingView can't reach the "
                                  "app, loss limit, errors)")
        self.problems.setChecked(cfg.notify.problems)
        self.paper = QCheckBox("Paper trades too")
        self.paper.setChecked(cfg.notify.paper)
        for b in (self.trades, self.problems, self.paper):
            form.addRow("", b)
        self.result = QLabel("")
        self.result.setObjectName("muted")
        self.result.setWordWrap(True)
        test = QPushButton("Send test")
        test.clicked.connect(self._test)
        tr = QHBoxLayout()
        tr.addWidget(test)
        tr.addWidget(self.result, 1)
        form.addRow(tr)
        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel | QDialogButtonBox.Help)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        buttons.helpRequested.connect(lambda: parent.open_help("phone") if parent else None)
        form.addRow(buttons)

    def _find(self):
        try:
            chat, who = phone.find_chat_id(self.token.text().strip())
        except phone.NotifyError as e:
            self.result.setText(f"Couldn't find your chat: {e}")
            return
        self.chat.setText(chat)
        self.result.setText(f"Found your chat{' with ' + who if who else ''}.")

    def _test(self):
        try:
            phone.send_message(self.token.text().strip(), self.chat.text().strip(),
                                f"✅ {APP_NAME} phone alerts work. Send /status to check your bots.")
        except phone.NotifyError as e:
            self.result.setText(f"Not sent: {e}")
            return
        self.result.setText("Sent. Check Telegram.")


class LoginDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("TopstepX login")
        form = QFormLayout(self)
        form.addRow(QLabel("Saved in your Mac's Keychain. Get the API key from the ProjectX dashboard."))
        self.user = QLineEdit()
        self.key = QLineEdit()
        self.key.setEchoMode(QLineEdit.Password)
        form.addRow("TopstepX username", self.user)
        form.addRow("ProjectX API key", self.key)
        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        form.addRow(buttons)


class AddBotDialog(QDialog):
    def __init__(self, parent, bots: list["BotPanel"]):
        super().__init__(parent)
        self.setWindowTitle("Add a bot")
        form = QFormLayout(self)
        form.addRow(QLabel("The new bot is added on every account. It only manages its own orders, so it can\n"
                           "run alongside your other bots."))
        self.kind = QComboBox()
        self.kind.addItem("ORB (copy of an existing ORB bot)", "orb")
        self.kind.addItem("TradingView alerts (any script, replaces PickMyTrade)", "alerts")
        self.kind.addItem("Your own script (Python file)", "script")
        self.script_file = QLineEdit()
        self.script_file.setPlaceholderText("Choose a .py file")
        pick = QPushButton("Choose…")
        pick.clicked.connect(self._pick_script)
        self.script_row = QWidget()
        sr = QHBoxLayout(self.script_row)
        sr.setContentsMargins(0, 0, 0, 0)
        sr.addWidget(self.script_file, 1)
        sr.addWidget(pick)
        self.source = QComboBox()
        self.orb_bots = [b for b in bots if b.cfg.kind == "orb"]
        for b in self.orb_bots:
            self.source.addItem(b.cfg.bot_name)
        self.symbol = QLineEdit("MNQ")
        self.timeframe = QComboBox()
        for m, label in TIMEFRAMES:
            self.timeframe.addItem(label, m)
        self.timeframe.setCurrentIndex(self.timeframe.findData(60))
        self.name = QLineEdit()
        self.name.setPlaceholderText("e.g. ORB H1")
        self.timeframe.currentIndexChanged.connect(self._suggest)
        self.kind.currentIndexChanged.connect(self._kind_changed)
        form.addRow("Type", self.kind)
        form.addRow("Copy settings from", self.source)
        form.addRow("Chart timeframe", self.timeframe)
        form.addRow("Contract", self.symbol)
        form.addRow("Script", self.script_row)
        form.addRow("Name", self.name)
        self.form = form
        self._kind_changed()
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        form.addRow(buttons)

    def _kind_changed(self):
        kind = self.kind.currentData()
        self.form.setRowVisible(self.source, kind == "orb")
        self.form.setRowVisible(self.timeframe, kind in ("orb", "script"))
        self.form.setRowVisible(self.symbol, kind in ("alerts", "script"))
        self.form.setRowVisible(self.script_row, kind == "script")
        self._suggest()

    def _pick_script(self):
        start = str(Path.cwd() / "strategies")
        path, _ = QFileDialog.getOpenFileName(self, "Choose your strategy script", start, "Python (*.py)")
        if path:
            self.script_file.setText(path)
            self._suggest()

    def _suggest(self):
        if self.name.isModified():
            return
        if self.kind.currentData() == "alerts":
            self.name.setText("TV alerts")
            return
        if self.kind.currentData() == "script":
            stem = Path(self.script_file.text()).stem
            try:
                from .scripting import load_strategy
                st = load_strategy(Path(self.script_file.text()))
                if getattr(st, "symbol", None):
                    self.symbol.setText(st.symbol)
                if getattr(st, "name", "") and st.name != "My strategy":
                    self.name.setText(st.name)
                    return
            except Exception:  # noqa: BLE001 - checked again when the bot is added
                pass
            self.name.setText(stem.replace("_", " ").title() if stem else "My strategy")
            return
        m = self.timeframe.currentData()
        self.name.setText(f"ORB H{m // 60}" if m >= 60 and m % 60 == 0 else f"ORB M{m}")


class BotPanel(QWidget):
    """One bot on one account: its controls, sessions, risk and current trade, plus its Settings and Replay pages.

    The same bot on another account is another BotPanel with the same settings file, so each can be started,
    stopped and sized separately. Risk and session switches are saved per account; strategy settings are shared.
    """
    finished = Signal()

    def __init__(self, win: "MainWindow", cfg_path: Path, account_id: int | None = None, account_name: str = ""):
        super().__init__()
        self.win = win
        self.cfg_path = cfg_path
        self.account_id, self.account_name = account_id, account_name
        self.is_main = cfg_path == win.main_path
        self.cfg: Config = win.load_bot_config(cfg_path, account_id, account_name)
        self.is_alerts = self.cfg.kind == "alerts"
        self.is_script = self.cfg.kind == "script"
        self.engine: Engine | None = None
        self.worker: threading.Thread | None = None
        self.starting = False
        self._build()
        self.settings_page = QWidget()
        self.settings_scroll = QScrollArea()
        self.settings_scroll.setWidgetResizable(True)
        self.settings_scroll.setWidget(self.settings_page)
        self.replay_page = self._build_replay_page() if not self.is_alerts else QLabel(
            "Replay isn't available for a TradingView alerts bot: use TradingView's Strategy Tester for its "
            "history.")
        self._load_risk_panel()
        self._load_settings_tab()
        self.finished.connect(self._on_finished)

    @property
    def name(self) -> str:
        return self.cfg.bot_name

    @property
    def running(self) -> bool:
        return bool(self.worker and self.worker.is_alive())

    @property
    def label(self) -> str:
        """Name on log lines: the bot and the account, e.g. "ORB M5 @ PRAC…2716"."""
        return f"{self.name} @ {short_account(self.account_name, self.account_id)}"

    def refresh_broker(self):
        """Pick up the shared login, contract, bracket test and Fast bars settings (not while running)."""
        if not self.running:
            b = copy.deepcopy(self.win.main_cfg.broker)
            b.account_id, b.account_name = self.account_id, self.account_name
            self.cfg.broker = b

    # --- layout ---------------------------------------------------------------------------
    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 14, 0, 0)
        root.setSpacing(12)
        bar = QHBoxLayout()
        bar.setSpacing(10)
        self.title = QLabel()
        self.title.setObjectName("h2")
        self.status = QLabel()
        self.status.setObjectName("pill")
        self.status.setTextFormat(Qt.RichText)
        # Start always places real orders. Paper is a one-off "Test run" in the ••• menu, so a restart never
        # leaves a bot quietly trading on paper.
        self.mode = ModeSwitch()
        self.mode.setCurrentIndex(1)
        self.mode.hide()
        self.start_btn = QPushButton("▶  Start")
        self.start_btn.setObjectName("start")
        self.stop_btn = QPushButton("■  Stop")
        self.stop_btn.setObjectName("stop")
        for b in (self.start_btn, self.stop_btn):
            b.setCursor(Qt.PointingHandCursor)
        self.start_btn.clicked.connect(self.start)
        self.stop_btn.clicked.connect(self.stop)
        more = QToolButton()
        more.setText("•••")
        more.setToolTip("Test run, rename or remove this bot")
        more.setPopupMode(QToolButton.InstantPopup)
        menu = QMenu(more)
        self.test_btn = menu.addAction("Test run (paper, no real orders)")
        self.test_btn.setToolTip("Runs the bot with simulated orders until you press Stop. The next Start places "
                                 "real orders again.")
        self.test_btn.triggered.connect(self.test_run)
        menu.addSeparator()
        self.rename_btn = menu.addAction("Rename…")
        self.rename_btn.triggered.connect(self.rename)
        self.remove_btn = menu.addAction("Remove bot…")
        self.remove_btn.triggered.connect(self.remove)
        self.remove_btn.setVisible(not self.is_main)
        more.setMenu(menu)
        bar.addWidget(self.title)
        bar.addWidget(self.status)
        bar.addStretch(1)
        for w in (self.start_btn, self.stop_btn, more):
            bar.addWidget(w)
        root.addLayout(bar)

        mid = QHBoxLayout()
        mid.setSpacing(12)
        self.sess_box = _box("Sessions")
        sl = QVBoxLayout(self.sess_box)
        sl.setContentsMargins(0, 0, 0, 0)
        if self.is_alerts:
            self._build_alerts_box(sl)
        if self.is_script:
            self.script_info = QLabel()
            self.script_info.setWordWrap(True)
            self.script_info.setTextFormat(Qt.RichText)
            self.script_info.setOpenExternalLinks(True)
            self._show_script_info()
            sl.addWidget(self.script_info)
            self.switch_row = QHBoxLayout()
            self.switch_row.setSpacing(16)
            self.switch_boxes: dict[str, QCheckBox] = {}
            self._build_switches()
            sl.addLayout(self.switch_row)
            sl.addStretch(1)
        self.sessions = QTableWidget(0, 7)
        self.sessions.setHorizontalHeaderLabels(["", "SESSION", "RANGE", "HIGH", "LOW", "STATUS", "TODAY"])
        self.sessions.verticalHeader().setVisible(False)
        self.sessions.setShowGrid(False)
        self.sessions.setFocusPolicy(Qt.NoFocus)
        self.sessions.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.sessions.setSelectionMode(QAbstractItemView.NoSelection)
        hh = self.sessions.horizontalHeader()
        hh.setSectionResizeMode(QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(5, QHeaderView.Stretch)
        hh.setSectionResizeMode(0, QHeaderView.Fixed)
        self.sessions.setColumnWidth(0, 52)
        hh.setDefaultAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.sessions.verticalHeader().setDefaultSectionSize(38)
        self.sessions.itemChanged.connect(self._session_toggled)
        self.sessions.setMinimumHeight(150)
        self.sessions.setToolTip("Switch a session on or off. Applies straight away, even while the bot runs.")
        sl.addWidget(self.sessions)
        self.sessions.setVisible(not self.is_alerts and not self.is_script)
        mid.addWidget(self.sess_box, 3)

        right = QVBoxLayout()
        right.setSpacing(12)
        trade = self.trade_box = _box("Position")
        tg = QVBoxLayout(trade)
        tg.setSpacing(8)
        top = QHBoxLayout()
        self.t_labels = {k: QLabel("–") for k in ("what", "unreal", "last", "risk", "reward", "since", "entry",
                                                   "stop", "target")}
        for k in ("what", "unreal"):
            self.t_labels[k].setObjectName("huge" if self.is_alerts else "big")
        top.addWidget(self.t_labels["what"])
        top.addStretch(1)
        top.addWidget(self.t_labels["unreal"])
        tg.addLayout(top)
        self.bracket = BracketBar()
        tg.addWidget(self.bracket)
        kv = QGridLayout()
        kv.setHorizontalSpacing(12)
        kv.setVerticalSpacing(1)
        kv.setVerticalSpacing(2)
        for n, (k, name) in enumerate([("entry", "ENTRY"), ("stop", "STOP"), ("target", "TARGET"),
                                       ("last", "LAST"), ("risk", "RISK"), ("reward", "REWARD")]):
            row, col = divmod(n, 3)
            t = QLabel(name)
            t.setObjectName("lbl")
            kv.addWidget(t, row * 2, col)
            v = self.t_labels[k]
            v.setTextInteractionFlags(Qt.TextSelectableByMouse)
            v.setObjectName("value")
            kv.addWidget(v, row * 2 + 1, col)
            if row == 0:
                kv.setRowMinimumHeight(1, 30)
        self.kv_widget = QWidget()
        self.kv_widget.setLayout(kv)
        tg.addWidget(self.kv_widget)
        self.flat_note = QLabel()
        self.flat_note.setObjectName("muted")
        self.flat_note.setWordWrap(True)
        tg.addWidget(self.flat_note)
        self.close_btn = QPushButton("Close this position now")
        self.close_btn.setObjectName("close")
        self.close_btn.clicked.connect(self.close_trade)
        self.be_btn = QPushButton("Move stop to break-even")
        self.be_btn.setToolTip("Moves this bot's stop to its entry price. Available once the price has moved past "
                               "the entry, so the stop isn't hit straight away.")
        self.be_btn.clicked.connect(self.breakeven)
        acts = QHBoxLayout()
        acts.addWidget(self.be_btn, 1)
        acts.addWidget(self.close_btn, 1)
        tg.addLayout(acts)
        right.addWidget(trade)

        risk = _box("Size on this account" if self.is_alerts else "Risk on this account")
        risk.setToolTip("Applies from the next trade, even while the bot runs.")
        rf = QFormLayout(risk)
        rf.setHorizontalSpacing(14)
        rf.setVerticalSpacing(8)
        rf.setLabelAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.risk_mode = QComboBox()
        self.risk_mode.addItems(["Same as TradingView ×", "Fixed contracts"] if self.is_alerts else
                                ["% of balance", "Fixed $ per trade"])
        self.risk_amount = QDoubleSpinBox()
        self.risk_amount.setRange(0.01, 1_000_000)
        self.max_contracts = QSpinBox()
        self.max_contracts.setRange(1, 1000)
        self.daily_loss = QSpinBox()
        self.daily_loss.setRange(0, 1_000_000)
        self.daily_loss.setSingleStep(100)
        self.daily_loss.setPrefix("$")
        self.daily_loss.setSpecialValueText("Off")
        rf.addRow(self._muted("Contracts" if self.is_alerts else "Risk per trade"), self.risk_mode)
        rf.addRow(self._muted("Amount"), self.risk_amount)
        rf.addRow(self._muted("Max contracts"), self.max_contracts)
        rf.addRow(self._muted("Daily loss limit"), self.daily_loss)
        note = QLabel("Applies from the next trade.")
        note.setObjectName("lbl")
        rf.addRow(note)
        self.risk_mode.currentIndexChanged.connect(self._risk_mode_changed)
        for w in (self.risk_amount, self.max_contracts, self.daily_loss):
            w.editingFinished.connect(self._risk_changed)
        right.addWidget(risk)
        right.addStretch(1)
        if self.is_alerts:  # the live position is what matters once it's set up: give it the room
            mid.removeWidget(self.sess_box)
            right.removeWidget(trade)
            right.removeWidget(risk)
            row = QHBoxLayout()
            row.setSpacing(12)
            root.addLayout(row)  # in place first, so the boxes get their parent straight away
            row.addWidget(trade, 3)
            row.addWidget(risk, 2)
            root.addWidget(self.sess_box, 1)
        else:
            mid.addLayout(right, 2)
            root.addLayout(mid, 1)
        self._update_titles()

    @staticmethod
    def _muted(text: str) -> QLabel:
        lab = QLabel(text)
        lab.setObjectName("muted")
        return lab

    def _update_titles(self):
        self.title.setText(self.name)
        if self.is_alerts:
            self.sess_box.setTitle("TRADINGVIEW CONNECTION")
            self._fill_alert_info()
        elif self.is_script:
            self.sess_box.setTitle("YOUR SCRIPT")
            self._show_script_info()
        else:
            self.sess_box.setTitle("SESSIONS")

    # --- TradingView alerts bot -------------------------------------------------------------
    def _build_alerts_box(self, lay: QVBoxLayout):
        lay.setSpacing(8)
        grid = QGridLayout()
        grid.setHorizontalSpacing(10)
        grid.setVerticalSpacing(6)
        self.al_url = QLabel()
        self.al_url.setObjectName("code")
        self.al_url.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.al_url.setWordWrap(True)
        copy_url = QPushButton("Copy URL")
        copy_url.clicked.connect(lambda: QApplication.clipboard().setText(self.win.webhook.address or ""))
        self.al_msg = QLabel()
        self.al_msg.setObjectName("code")
        self.al_msg.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.al_msg.setWordWrap(True)
        copy_msg = QPushButton("Copy message")
        copy_msg.clicked.connect(lambda: QApplication.clipboard().setText(self.alert_message()))
        self.al_pos = QLabel("TradingView position: –")
        self.al_pos.setTextFormat(Qt.RichText)
        for row, (name, value, btn) in enumerate([("WEBHOOK URL", self.al_url, copy_url),
                                                  ("ALERT MESSAGE", self.al_msg, copy_msg)]):
            t = QLabel(name)
            t.setObjectName("lbl")
            grid.addWidget(t, row * 2, 0, 1, 2)
            grid.addWidget(value, row * 2 + 1, 0)
            grid.addWidget(btn, row * 2 + 1, 1, Qt.AlignTop)
        grid.setColumnStretch(0, 1)
        # once it's set up the webhook URL and message are rarely needed: one line, opened with "Show setup"
        head = QHBoxLayout()
        head.addWidget(self.al_pos, 1)
        self.al_toggle = QPushButton()
        self.al_toggle.setObjectName("link")
        self.al_toggle.clicked.connect(lambda: self._show_setup(not self.al_setup.isVisible()))
        head.addWidget(self.al_toggle)
        lay.addLayout(head)
        self.al_setup = QWidget()
        self.al_setup.setLayout(grid)
        grid.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(self.al_setup)
        self._show_setup(not self.win.webhook.address)
        t = QLabel("RECENT ALERTS")
        t.setObjectName("lbl")
        lay.addWidget(t)
        self.al_table = QTableWidget(0, 3)
        self.al_table.setHorizontalHeaderLabels(["TIME", "ALERT", "WHAT THE BOT DID"])
        self.al_table.verticalHeader().setVisible(False)
        self.al_table.setShowGrid(False)
        self.al_table.setFocusPolicy(Qt.NoFocus)
        self.al_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.al_table.setSelectionMode(QAbstractItemView.NoSelection)
        hh = self.al_table.horizontalHeader()
        hh.setSectionResizeMode(QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(2, QHeaderView.Stretch)
        hh.setDefaultAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.al_table.verticalHeader().setDefaultSectionSize(34)
        self.al_table.setMinimumHeight(120)
        lay.addWidget(self.al_table)

    def _show_setup(self, show: bool) -> None:
        self.al_setup.setVisible(show)
        self.al_toggle.setText("Hide setup ▴" if show else "Show setup ▾")

    def alert_message(self) -> str:
        """What goes in the TradingView alert's Message box (strategy alerts)."""
        return ('{"bot": "%s", "key": "%s", "action": "{{strategy.order.action}}", '
                '"contracts": "{{strategy.order.contracts}}", "position": "{{strategy.market_position}}", '
                '"position_size": "{{strategy.market_position_size}}", "price": "{{close}}", '
                '"ticker": "{{ticker}}"}') % (self.cfg.slug, self.cfg.alerts.secret)

    def _fill_alert_info(self):
        if not self.is_alerts:
            return
        url = self.win.webhook.address
        self.al_url.setText(f"{url}\nIf the script's own alert message can't be changed, use this URL instead:\n"
                            f"{url}/{self.cfg.slug}/{self.cfg.alerts.secret}"
                            if url else "Not set up yet: Bots → TradingView alerts setup…")
        self.al_msg.setText(self.alert_message())
        self.al_msg.setToolTip('For an indicator (not a strategy), make one alert per signal with "action": "buy", '
                               '"sell" or "exit" and leave out the other fields.')

    def _fill_alerts(self, snap: dict | None):
        rows = list(reversed(snap.get("alerts", []))) if snap else []
        self.al_table.setRowCount(len(rows))
        for i, r in enumerate(rows):
            for j, v in enumerate((r["time"], r["alert"], r["result"])):
                it = QTableWidgetItem(v)
                if j == 2 and (v.startswith("error") or v.startswith("ignored") or v.startswith("skipped")
                               or "rejected" in v):
                    it.setForeground(QColor(RED))
                self.al_table.setItem(i, j, it)
        pos = snap.get("tv_position") if snap else None
        text = "TradingView position: " + ("–" if pos is None else
                                           "flat" if not pos else f"{'long' if pos > 0 else 'short'} {abs(pos):g}")
        wh = self.win.webhook
        if self.running and wh.running and wh.public_url:
            when = datetime.fromtimestamp(wh.checked_at).strftime("%H:%M") if wh.checked_at else ""
            if wh.reachable:
                text += f"&nbsp;&nbsp;·&nbsp;&nbsp;<span style='color:{GREEN}'>● TradingView can reach the app</span>" \
                        f"<span style='color:{MUTED}'> (checked {when})</span>"
            elif wh.reachable is False:
                text += (f"&nbsp;&nbsp;·&nbsp;&nbsp;<span style='color:{RED}'>● TradingView can't reach the app: "
                         f"{wh.ngrok_error or 'no answer'}</span>")
            else:
                text += f"&nbsp;&nbsp;·&nbsp;&nbsp;<span style='color:{AMBER}'>● checking the connection…</span>"
        expiry = self.expiry_status()
        if expiry:
            msg, kind = expiry
            color = {"ok": theme.TEXT_3, "warn": theme.WARN, "error": theme.DOWN_SOFT}[kind]
            text += f"&nbsp;&nbsp;·&nbsp;&nbsp;<span style='color:{color}'>{html.escape(msg)}</span>"
        self.al_pos.setText(text)

    def expiry_status(self) -> tuple[str, str] | None:
        """("TradingView alert expires in 29 days (9 Nov)", "ok" | "warn" | "error"), or None when not set."""
        if not self.is_alerts or not self.cfg.alerts.alert_expires.strip():
            return None
        d = parse_date(self.cfg.alerts.alert_expires)
        if d is None:
            return "Alert expiry date not understood: use e.g. 9/11/2026", "warn"
        days = (d - datetime.now(self.cfg.timezone).date()).days
        when = d.strftime("%-d %b") if sys.platform != "win32" else d.strftime("%d %b").lstrip("0")
        if days < 0:
            return f"TradingView alert expired {when}: renew it in TradingView, then update the date", "error"
        if days == 0:
            return "TradingView alert expires TODAY: renew it in TradingView", "error"
        if days <= EXPIRY_WARN_DAYS:
            return f"TradingView alert expires in {days} day{'s' if days != 1 else ''} ({when}): renew it soon", "warn"
        return f"Alert expires {when} ({days} days)", "ok"

    def new_secret(self):
        if self.win.file_running(self.cfg_path):
            QMessageBox.information(self, "New key", f"Stop {self.name} on every account first.")
            return
        save_setting(self.cfg_path, "alerts", "secret", secrets.token_urlsafe(12))
        self.win.reload_bot(self.cfg_path)
        QMessageBox.information(self, "New key", "Done. Paste the new alert message into your TradingView alerts; "
                                "alerts with the old key are now refused.")

    def _build_replay_page(self) -> QWidget:
        page = QWidget()
        lay = QVBoxLayout(page)
        row = QHBoxLayout()
        today = QDate.currentDate()
        self.rp_from, self.rp_to = QDateEdit(today.addDays(-21)), QDateEdit(today)
        for d in (self.rp_from, self.rp_to):
            d.setCalendarPopup(True)
            d.setDisplayFormat("d MMM yyyy")
        self.rp_run = QPushButton("Run replay")
        self.rp_run.clicked.connect(self.run_replay)
        self.rp_title = QLabel()
        self.rp_summary = QLabel("Replays the strategy over past bars with this bot's current settings, filled like "
                                 "TradingView's strategy tester. Topstep keeps about 1-3 months of history.")
        self.rp_summary.setWordWrap(True)
        for w in (self.rp_title, QLabel("From"), self.rp_from, QLabel("to"), self.rp_to, self.rp_run):
            row.addWidget(w)
        row.addStretch(1)
        lay.addLayout(row)
        lay.addWidget(self.rp_summary)
        self.rp_table = QTableWidget(0, 9)
        self.rp_table.setHorizontalHeaderLabels(["Session", "Entry time", "Side", "Size", "Entry", "Stop", "Target",
                                                 "Exit", "P&L"])
        self.rp_table.verticalHeader().setVisible(False)
        self.rp_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.rp_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        lay.addWidget(self.rp_table, 1)
        return page

    # --- replay ------------------------------------------------------------------------------
    def run_replay(self):
        b = self.win._broker()
        if not b:
            return
        start, end = self.rp_from.date().toPython(), self.rp_to.date().toPython()
        if end < start:
            QMessageBox.warning(self, "Replay", "The end date is before the start date.")
            return
        self.rp_run.setEnabled(False)
        self.rp_summary.setText("Replaying…")
        out = self.win.root / f"replay-trades-{self.cfg.slug}.csv"
        self.win._job(lambda: replay(b, self.cfg, start, end, out), self._replay_done, bot=self.label)

    def _replay_done(self, trades, err):
        self.rp_run.setEnabled(True)
        if err:
            self.rp_summary.setText(f"Replay failed: {err}")
            return
        closed = [t for t in trades if t.exit_time]
        wins = sum(1 for t in closed if t.pnl > 0)
        net = sum(t.pnl for t in closed)
        rate = f"{wins / len(closed):.0%}" if closed else "–"
        self.rp_summary.setText(f"{self.name}: {len(closed)} trades, {wins} winners ({rate}), net {money(net, True)} "
                                f"(hypothetical, {self.cfg.broker.symbol}). Saved to "
                                f"replay-trades-{self.cfg.slug}.csv.")
        self.rp_table.setRowCount(len(trades))
        tz = self.cfg.timezone
        for i, t in enumerate(trades):
            vals = [t.tag.split("-")[-2].upper() if t.tag else "", f"{t.entry_time.astimezone(tz):%a %d %b %H:%M}",
                    "Long" if t.side.value == "buy" else "Short", str(t.size), f"{t.entry_price:.2f}",
                    f"{t.stop_price:.2f}", f"{t.target_price:.2f}",
                    f"{t.exit_price:.2f} ({t.exit_reason})" if t.exit_time else "open",
                    money(t.pnl, True) if t.exit_time else ""]
            for j, v in enumerate(vals):
                it = QTableWidgetItem(v)
                if j == 8 and t.exit_time:
                    it.setForeground(QColor(GREEN if t.pnl > 0 else RED))
                self.rp_table.setItem(i, j, it)

    # --- risk panel (live) ------------------------------------------------------------------
    def _second_mode(self) -> bool:
        """Fixed $ (ORB) or fixed contracts (alerts)."""
        if self.is_alerts:
            return self.cfg.alerts.sizing == "fixed"
        return self.cfg.risk.risk_mode == "dollars"

    def _amount(self) -> float:
        if self.is_alerts:
            a = self.cfg.alerts
            return float(a.contracts) if a.sizing == "fixed" else a.multiplier
        r = self.cfg.risk
        return r.risk_dollars if r.risk_mode == "dollars" else r.risk_percent

    def _load_risk_panel(self):
        r, s = self.cfg.risk, self.cfg.safety
        for w in (self.risk_mode, self.risk_amount, self.max_contracts, self.daily_loss):
            w.blockSignals(True)
        self.risk_mode.setCurrentIndex(1 if self._second_mode() else 0)
        self._format_amount()
        self.risk_amount.setValue(self._amount())
        self.max_contracts.setValue(r.max_contracts)
        self.daily_loss.setValue(int(s.max_daily_loss))
        for w in (self.risk_mode, self.risk_amount, self.max_contracts, self.daily_loss):
            w.blockSignals(False)

    def _format_amount(self):
        if self.is_alerts:
            fixed = self.risk_mode.currentIndex() == 1
            self.risk_amount.setPrefix("")
            self.risk_amount.setSuffix(" contracts" if fixed else " ×")
            self.risk_amount.setDecimals(0 if fixed else 2)
            self.risk_amount.setSingleStep(1 if fixed else 0.5)
            return
        dollars = self.risk_mode.currentIndex() == 1
        self.risk_amount.setPrefix("$" if dollars else "")
        self.risk_amount.setSuffix("" if dollars else " %")
        self.risk_amount.setDecimals(0 if dollars else 2)
        self.risk_amount.setSingleStep(50 if dollars else 0.25)

    def _risk_mode_changed(self):
        if self.is_alerts:
            a = self.cfg.alerts
            a.sizing = "fixed" if self.risk_mode.currentIndex() == 1 else "tv"
            self._format_amount()
            self.risk_amount.blockSignals(True)
            self.risk_amount.setValue(self._amount())
            self.risk_amount.blockSignals(False)
            save_account_setting(self.cfg_path, self.account_id, "sizing", a.sizing)
            log.info("%s size set to %s", self.label, self._risk_text())
            return
        r = self.cfg.risk
        r.risk_mode = "dollars" if self.risk_mode.currentIndex() == 1 else "percent"
        self._format_amount()
        self.risk_amount.blockSignals(True)
        self.risk_amount.setValue(r.risk_dollars if r.risk_mode == "dollars" else r.risk_percent)
        self.risk_amount.blockSignals(False)
        save_account_setting(self.cfg_path, self.account_id, "risk_mode", r.risk_mode)
        log.info("%s risk set to %s", self.label, self._risk_text())

    def _risk_changed(self):
        r, s = self.cfg.risk, self.cfg.safety
        if self.is_alerts:
            a = self.cfg.alerts
            if a.sizing == "fixed":
                a.contracts = int(self.risk_amount.value())
                save_account_setting(self.cfg_path, self.account_id, "contracts", a.contracts)
            else:
                a.multiplier = float(self.risk_amount.value())
                save_account_setting(self.cfg_path, self.account_id, "multiplier", a.multiplier)
        elif r.risk_mode == "dollars":
            r.risk_dollars = float(self.risk_amount.value())
            save_account_setting(self.cfg_path, self.account_id, "risk_dollars", r.risk_dollars)
        else:
            r.risk_percent = float(self.risk_amount.value())
            save_account_setting(self.cfg_path, self.account_id, "risk_percent", r.risk_percent)
        if r.max_contracts != self.max_contracts.value():
            r.max_contracts = self.max_contracts.value()
            save_account_setting(self.cfg_path, self.account_id, "max_contracts", r.max_contracts)
        if s.max_daily_loss != self.daily_loss.value():
            s.max_daily_loss = float(self.daily_loss.value())
            save_account_setting(self.cfg_path, self.account_id, "max_daily_loss", int(s.max_daily_loss))
        log.info("%s %s set to %s", self.label, "size" if self.is_alerts else "risk", self._risk_text())

    def _risk_text(self) -> str:
        r, s = self.cfg.risk, self.cfg.safety
        if self.is_alerts:
            a = self.cfg.alerts
            size = (f"{a.contracts} contracts per trade" if a.sizing == "fixed"
                    else f"TradingView's contracts × {a.multiplier:g}")
        else:
            size = (f"${r.risk_dollars:,.0f} per trade" if r.risk_mode == "dollars"
                    else f"{r.risk_percent:g}% of balance")
        loss = f"daily loss limit ${s.max_daily_loss:,.0f}" if s.max_daily_loss else "no daily loss limit"
        return f"{size}, max {r.max_contracts} contracts, {loss}"

    # --- sessions table -----------------------------------------------------------------------
    def _session_toggled(self, item: QTableWidgetItem):
        if item.column() != 0:
            return
        name = item.data(Qt.UserRole)
        cfg = next((s for s in self.cfg.sessions if s.name == name), None)
        if not cfg:
            return
        on = item.checkState() == Qt.Checked
        if cfg.enabled != on:
            cfg.enabled = on
            save_account_setting(self.cfg_path, self.account_id, f"{name}_enabled", on)
            log.info("%s %s switched %s", self.label, name.upper(), "ON" if on else "OFF")

    def _fill_sessions(self, rows: list[dict]):
        self.sessions.blockSignals(True)
        self.sessions.setRowCount(len(rows))
        for i, r in enumerate(rows):
            on = QTableWidgetItem()
            on.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled)
            on.setCheckState(Qt.Checked if r["enabled"] else Qt.Unchecked)
            on.setData(Qt.UserRole, r["name"])
            self.sessions.setItem(i, 0, on)
            vals = [r["name"].upper(), r["window"],
                    f"{r['high']:.2f}" if r["high"] is not None else "–",
                    f"{r['low']:.2f}" if r["low"] is not None else "–", r["status"],
                    money(r["pnl"], True) if r["trades"] else ""]
            for j, v in enumerate(vals, start=1):
                it = QTableWidgetItem(v)
                if j == 5:
                    color = {"Building range": AMBER, "Watching for breakout": GREEN, "In trade": GREEN,
                             "Off": MUTED}.get(r["status"])
                    if color:
                        it.setForeground(QColor(color))
                if j == 6 and r["trades"]:
                    it.setForeground(QColor(GREEN if r["pnl"] >= 0 else RED))
                self.sessions.setItem(i, j, it)
        self.sessions.blockSignals(False)

    def _idle_rows(self) -> list[dict]:
        rows = []
        for s in self.cfg.sessions:
            start, end = session_window(self.cfg, s, datetime.now(self.cfg.timezone))
            rows.append({"name": s.name, "enabled": s.enabled,
                         "window": f"{start.strftime('%H:%M')}-{end.strftime('%H:%M')}", "high": None,
                         "low": None, "status": "Off" if not s.enabled else "Bot stopped", "pnl": 0, "trades": 0})
        return rows

    # --- settings tab ---------------------------------------------------------------------------
    def _editor(self, value, ftype):
        if isinstance(value, bool):
            w = QCheckBox()
            w.setChecked(value)
        elif isinstance(value, time) or ftype == "time":
            w = QTimeEdit()
            w.setDisplayFormat("HH:mm")
            w.setTime(QTime(value.hour, value.minute))
        elif isinstance(value, int) and not isinstance(value, bool):
            w = QSpinBox()
            w.setRange(0, 1_000_000)
            w.setValue(value)
        elif isinstance(value, float):
            w = QDoubleSpinBox()
            w.setRange(0, 10_000_000)
            w.setDecimals(2)
            w.setValue(value)
        else:
            w = QLineEdit("" if value is None else str(value))
        return w

    def _zone_editor(self, value: str, start_edit: QTimeEdit) -> QComboBox:
        """Time zone picker; switching it converts the range start so the session stays at the same moment."""
        w = QComboBox()
        for label, zone in SESSION_ZONES:
            w.addItem(label, zone)
        if value not in [z for _, z in SESSION_ZONES]:
            w.addItem(value, value)
        w.setCurrentIndex(w.findData(value))
        w.setProperty("prev", value)

        def changed():
            old, new = w.property("prev") or "", w.currentData() or ""
            zone = lambda z: ZoneInfo(z) if z else self.cfg.timezone  # noqa: E731
            t = start_edit.time()
            moment = datetime.combine(datetime.now(zone(old)).date(), time(t.hour(), t.minute()), zone(old))
            local = moment.astimezone(zone(new))
            start_edit.setTime(QTime(local.hour, local.minute))
            w.setProperty("prev", new)
        w.currentIndexChanged.connect(changed)
        return w

    @staticmethod
    def _read(w):
        if isinstance(w, QComboBox):
            return w.currentData() or ""
        if isinstance(w, QCheckBox):
            return w.isChecked()
        if isinstance(w, QTimeEdit):
            t = w.time()
            return time(t.hour(), t.minute())
        if isinstance(w, QSpinBox):
            return w.value()
        if isinstance(w, QDoubleSpinBox):
            return round(w.value(), 4)
        return w.text().strip()

    def _load_settings_tab(self):
        old = self.settings_page.layout()
        if old:
            QWidget().setLayout(old)  # discard the previous layout and its widgets
        lay = QVBoxLayout(self.settings_page)
        top = QHBoxLayout()
        self.settings_title = QLabel(f"<b>{self.name}</b>")
        self.settings_note = QLabel("Shared by every account. Stop this bot on all accounts to change them. "
                                    "Risk and session on/off are set per account above.")
        self.settings_note.setStyleSheet(f"color: {MUTED};")
        self.save_btn = QPushButton("Save settings")
        self.save_btn.clicked.connect(self.save_settings)
        top.addWidget(self.settings_title)
        top.addWidget(self.settings_note)
        top.addStretch(1)
        top.addWidget(self.save_btn)
        lay.addLayout(top)
        grid = QGridLayout()
        self.editors: list[tuple[str, str, QWidget]] = []
        col = 0
        for s in self.cfg.sessions:
            box = _box(f"Session {s.name[1:]}")
            form = QFormLayout(box)
            for f in fields(SessionConfig):
                if f.name in ("name", "enabled"):
                    continue
                value = getattr(s, f.name)
                if f.name == "flatten_at":
                    w = QLineEdit(value.strftime("%H:%M") if value else "")
                    w.setPlaceholderText("HH:MM")
                elif f.name == "timezone":
                    w = self._zone_editor(value, start_edit)
                else:
                    w = self._editor(value, "time" if f.name == "start" else None)
                if f.name == "start":
                    start_edit = w
                form.addRow(LABELS.get(f.name, f.name), w)
                self.editors.append((f"sessions.{s.name}", f.name, w))
            grid.addWidget(box, 0, col)
            col += 1
        columns = [QVBoxLayout() for _ in range(max(col, 1))]
        placement = {"risk": 0, "safety": 1, "strategy": 1, "broker": 2, "sim": 2, "alerts": 0}
        for title, section, _cls, names in (ALERT_SECTIONS if self.is_alerts else EXTRA_SECTIONS):
            if section == "broker" and not self.is_main:
                continue  # the contract is shared and set on the first bot
            box = _box(title)
            form = QFormLayout(box)
            obj = getattr(self.cfg, section)
            for n in names:
                if (section, n) == ("alerts", "exit_alerts"):
                    w = QComboBox()
                    w.addItem("Close the trade if it's still open", "close")
                    w.addItem("Ignore (Topstep's stop and target only)", "ignore")
                    w.setCurrentIndex(max(w.findData(getattr(obj, n)), 0))
                else:
                    w = self._editor(getattr(obj, n), None)
                form.addRow(LABELS.get(f"{section}.{n}", LABELS.get(n, n)), w)
                self.editors.append((section, n, w))
            columns[min(placement[section], len(columns) - 1)].addWidget(box)
        for i, c in enumerate(columns):
            c.addStretch(1)
            holder = QWidget()
            holder.setLayout(c)
            grid.addWidget(holder, 1, i)
        lay.addLayout(grid)
        if self.is_script:
            from .scripting import ScriptError, load_strategy
            box = _box("Script settings (params)")
            form = QFormLayout(box)
            form.addRow(LABELS.get("script.file", "Script file"), QLabel(f"<code>{self.cfg.script.file}</code>"))
            w = self._editor(self.cfg.script.symbol, None)
            form.addRow("Contract (e.g. MNQ, MGC; blank = the script's own or the main one)", w)
            self.editors.append(("script", "symbol", w))
            try:
                st = load_strategy(self.cfg.script_path(), self.cfg.script.params)
                for k, v in st.params.items():
                    if k in st.switches:
                        continue  # on the bot's screen, per account
                    w = self._editor(v, None)
                    form.addRow(k, w)
                    self.editors.append(("script.params", k, w))
            except ScriptError as e:
                form.addRow(QLabel(str(e)))
            lay.addWidget(box)
        if self.is_alerts:
            row = QHBoxLayout()
            note = QLabel("Every entry goes to Topstep with this stop and target attached, so exits fill at "
                          "Topstep straight away. If your script plots its stop and target lines, the alert "
                          "message can send them as \"stop\" and \"target\" (TradingView's plot placeholders) "
                          "and those exact prices are used instead.")
            note.setWordWrap(True)
            note.setStyleSheet(f"color: {MUTED};")
            self.secret_btn = QPushButton("New secret key…")
            self.secret_btn.clicked.connect(self.new_secret)
            row.addWidget(note, 1)
            row.addWidget(self.secret_btn)
            lay.addLayout(row)
        lay.addStretch(1)

    def _script_switches(self) -> dict:
        from .scripting import ScriptError, load_strategy
        try:
            return dict(load_strategy(self.cfg.script_path(), self.cfg.script.params).switches)
        except ScriptError:
            return {}

    def _build_switches(self) -> None:
        """The script's on/off switches (e.g. London / NY AM): this account's own, live even while running."""
        for k, label in self._script_switches().items():
            box = QCheckBox(label)
            box.setToolTip(f"Switch {label} on or off on this account. Applies straight away, even while the bot runs.")
            box.setChecked(bool(self.cfg.script.params.get(k, True)))
            box.toggled.connect(lambda on, k=k, label=label: self._switch_toggled(k, label, on))
            self.switch_boxes[k] = box
            self.switch_row.addWidget(box)
        self.switch_row.addStretch(1)

    def _load_switches(self) -> None:
        from .scripting import load_strategy
        try:
            params = load_strategy(self.cfg.script_path(), self.cfg.script.params).params
        except Exception:  # noqa: BLE001
            return
        for k, box in getattr(self, "switch_boxes", {}).items():
            box.blockSignals(True)
            box.setChecked(bool(params.get(k, True)))
            box.blockSignals(False)

    def _switch_toggled(self, key: str, label: str, on: bool) -> None:
        self.cfg.script.params = {**self.cfg.script.params, key: on}
        save_account_setting(self.cfg_path, self.account_id, f"switch_{key}", on)
        script = getattr(getattr(self.engine, "strategy", None), "script", None) if self.engine else None
        if script is not None:
            setattr(script.p, key, on)
            script.params[key] = on
        log.info("%s %s switched %s", self.label, label, "ON" if on else "OFF")

    def _show_script_info(self) -> None:
        from .scripting import ScriptError, load_strategy
        path = self.cfg.script_path()
        try:
            st = load_strategy(path, self.cfg.script.params)
            params = ", ".join(f"{k} = {v}" for k, v in st.params.items() if k not in st.switches) or "none"
            text = (f"<b>{st.name}</b> from <code>{path.name}</code><br>"
                    f"<span style='color:{MUTED}'>Settings: {params}</span><br><br>"
                    f"<span style='color:{MUTED}'>The script decides when to buy, sell or close; this bot sizes "
                    "each trade from the risk on the right and sends it to Topstep with its stop and target. "
                    "Edit the file, then Settings → Save to reload it. Test it in the Replay tab first.</span>")
        except ScriptError as e:
            text = f"<span style='color:{theme.DOWN}'>{e}</span><br><code>{path}</code>"
        self.script_info.setText(text)

    def save_settings(self):
        try:
            for section, key, w in self.editors:
                value = self._read(w)
                if key == "flatten_at":
                    if value:
                        hh, mm = value.split(":")
                        value = time(int(hh), int(mm))
                    else:
                        value = ""
                save_setting(self.cfg_path, section, key, value)
            self._strip_empty_flatten()
            self.win.reload_bot(self.cfg_path)
        except Exception as e:  # noqa: BLE001
            QMessageBox.warning(self, "Settings not saved", f"Check the values: {e}")
            return
        warn = session_bar_warnings(self.cfg)
        if warn:
            QMessageBox.warning(self, "Sessions don't fit the timeframe", "\n\n".join(warn))
        log.info("%s settings saved", self.name)

    def reload(self):
        """Re-read the settings file (only while this panel isn't running; risk edits apply live instead)."""
        self.cfg = self.win.load_bot_config(self.cfg_path, self.account_id, self.account_name)
        self._load_risk_panel()
        self._load_switches()
        self._load_settings_tab()
        self._update_titles()
        self.refresh()

    def _strip_empty_flatten(self):
        text = self.cfg_path.read_text().splitlines()
        self.cfg_path.write_text("\n".join(l for l in text if l.strip() != 'flatten_at = ""') + "\n")

    # --- name ------------------------------------------------------------------------------------
    def rename(self):
        if self.win.file_running(self.cfg_path):
            QMessageBox.information(self, "Rename", f"Stop {self.name} on every account first.")
            return
        dlg = QDialog(self)
        dlg.setWindowTitle("Rename bot")
        form = QFormLayout(dlg)
        edit = QLineEdit(self.name)
        form.addRow("Name", edit)
        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.accepted.connect(dlg.accept)
        buttons.rejected.connect(dlg.reject)
        form.addRow(buttons)
        if not dlg.exec():
            return
        new = edit.text().strip()
        problem = self.win.name_problem(new, exclude=self)
        if problem:
            QMessageBox.warning(self, "Rename", problem)
            return
        old = self.name
        save_top_setting(self.cfg_path, "name", new)
        self.win.reload_bot(self.cfg_path)
        log.info("bot %s renamed to %s", old, new)

    def remove(self):
        if self.is_main:
            return
        if self.win.file_running(self.cfg_path):
            QMessageBox.information(self, "Remove bot", f"Stop {self.name} on every account first.")
            return
        if any(p.engine and p.engine.trade for p in self.win.panels_for(self.cfg_path)):
            QMessageBox.information(self, "Remove bot", f"{self.name} still has an open trade.")
            return
        ok = QMessageBox.question(self, f"Remove {self.name}?",
                                  f"Remove {self.name} from the app, on every account? Its settings file is kept as "
                                  f"{self.cfg_path.name}.removed in the bots folder.")
        if ok == QMessageBox.Yes:
            self.cfg_path.rename(self.cfg_path.with_name(self.cfg_path.name + ".removed"))
            self.win.remove_bot(self.cfg_path)
            log.info("bot %s removed", self.name)

    # --- start / stop -----------------------------------------------------------------------------
    def test_run(self) -> None:
        """Start once with simulated orders; the next Start is real orders again."""
        if self.running or self.starting:
            return
        self.mode.setCurrentIndex(0)
        try:
            self.start()
        finally:
            self.mode.setCurrentIndex(1)

    def start(self, confirmed: bool = False):
        if self.running:
            return
        st = self.win.licence.status()
        if not st.may_trade:
            QMessageBox.information(self, "Start", f"{st.message}\n\nSettings → Licence.")
            return
        if self.account_id is None:
            QMessageBox.information(self, "Start", "Choose an account first: Account → Check connection and "
                                    "choose account.")
            return
        creds = self.win._credentials()
        if not creds:
            return
        self.refresh_broker()
        warn = session_bar_warnings(self.cfg)
        if warn and not confirmed:
            QMessageBox.warning(self, "Sessions don't fit the timeframe", "\n\n".join(warn))
        mode = "practice" if self.mode.currentIndex() == 1 else "paper"
        if mode == "practice" and not confirmed:
            if not self.cfg.broker.bracket_tick_mode:
                QMessageBox.warning(self, "Bracket test needed",
                                    "Run Account → Run bracket test… once before trading an account.")
                return
            acct = self.account_name or f"account {self.account_id}"
            allowed = self.win.account_allowed(self.account_id, self.account_name)
            text = (f"{self.name} will place real orders on {acct}.\n\n"
                    "It only manages its own orders; other bots and manual trades are left alone.")
            if not allowed:
                text += (f"\n\n{acct} isn't a Practice account. Topstep's rules for it (daily loss limit, trailing "
                         "drawdown, consistency) apply to every trade. Check this bot's Daily loss limit is below "
                         "Topstep's. Saying Yes also allows bots to trade this account from now on.")
            ok = QMessageBox.question(self, f"Start {self.name} on {acct}?", text)
            if ok != QMessageBox.Yes:
                return
            if not allowed:
                confirm_account(self.win.main_cfg, self.account_id)
                self.refresh_broker()
                log.info("%s confirmed for real orders", acct)
        if self.is_alerts and not self.win.ensure_webhook():
            return
        self.starting = True
        self.mode.setEnabled(False)
        self.worker = threading.Thread(target=self._run, args=(mode, creds), daemon=True)
        self.worker.start()
        self.win.bot_started()

    def _run(self, mode: str, creds: tuple[str, str]):
        set_thread_bot(self.label)
        try:
            cfg = self.cfg
            broker = ProjectXBroker(cfg.broker, *creds)
            broker.connect()
            if mode == "practice":
                acct = broker.get_account_state()
                if not may_trade(cfg, acct):
                    log.error("account %s is not a Practice account and hasn't been confirmed in Account → Check "
                              "connection; not starting", acct.name)
                    return
                log.info("trading account %s, balance %s", acct.name, money(acct.balance))
                orders = broker
            else:
                orders, paper_label = paper_broker(broker, cfg)
            if self.is_alerts:
                al = cfg.alerts
                stop = f"the alert's stop, else {al.stop_ticks} ticks"
                if al.script_risk:
                    stop = (f"the alert's stop, else worked out from ${al.script_risk:,.0f} script risk"
                            + (f" and the {al.range_start} range" if al.range_start else ""))
                target = f"{al.target_rr:g} × the stop" if al.target_rr else f"{al.target_ticks} ticks"
                log.info("size: %s; stop: %s; target: %s", self._risk_text(), stop, target)
                engine = AlertEngine(cfg, broker, orders, mode)
            else:
                describe(cfg)
                log.info("risk: %s", self._risk_text())
                engine = Engine(cfg, broker, orders, mode)
                attach_fast_bars(engine, cfg, broker)
            if mode == "paper":
                engine.account_name = paper_label
            self.engine = engine
            self.starting = False
            engine.run_live()
        except Exception as e:  # noqa: BLE001
            log.exception("could not run: %s", e)
        finally:
            self.starting = False
            self.finished.emit()

    def stop(self):
        if self.engine and self.running:
            log.info("stopping %s…", self.label)
            self.engine.request_stop()

    def _on_finished(self):
        self.mode.setEnabled(True)
        self.win.bot_stopped()
        self.refresh()

    def close_trade(self):
        if not (self.engine and self.engine.trade):
            return
        t = self.engine.trade
        ok = QMessageBox.question(self, "Close now?",
                                  f"Close {self.name}'s {t.side.value} {t.size} at market and cancel its stop and "
                                  "target?\n\nOther positions on the account (other bots, manual trades) are not "
                                  "touched.")
        if ok == QMessageBox.Yes:
            self.engine.request_close()

    def breakeven(self):
        if not (self.engine and self.engine.trade):
            return
        t = self.engine.trade
        ok = QMessageBox.question(self, "Move stop to break-even?",
                                  f"Move {self.name}'s stop to its entry price, {t.entry:,.2f}?\n\nIf the price comes "
                                  "back to the entry, the trade closes at about $0 (fees aside). The target stays "
                                  "where it is.")
        if ok == QMessageBox.Yes:
            self.engine.request_breakeven()

    # --- refresh -----------------------------------------------------------------------------------
    def snapshot(self) -> dict | None:
        if not self.engine:
            return None
        try:
            return self.engine.snapshot()
        except Exception as e:  # noqa: BLE001 - engine mid-update; try again next second
            log.debug("snapshot failed: %s", e)
            return None

    def refresh(self, snap: dict | None = None):
        running = self.running
        snap = snap if snap is not None else self.snapshot()
        self.start_btn.setVisible(not running)
        self.stop_btn.setVisible(running)
        self.start_btn.setEnabled(not running)
        self.stop_btn.setEnabled(running and not self.starting)
        anywhere = self.win.file_running(self.cfg_path)
        self.save_btn.setEnabled(not anywhere)
        self.rename_btn.setEnabled(not anywhere)
        self.remove_btn.setEnabled(not anywhere)
        for _s, _k, w in getattr(self, "editors", []):
            w.setEnabled(not anywhere)
        if running and self.starting:
            set_pill(self.status, "Starting…", "wait")
            self.status.setToolTip("")
        elif running and snap:
            if self.is_alerts:
                what = "listening for alerts"
            elif snap["last_bar"]:
                lag = f" ({snap['last_lag']:.1f}s)" if snap["last_lag"] is not None else ""
                what = f"last bar {snap['last_bar'].strftime('%H:%M')}{lag}"
            else:
                what = f"{self.cfg.strategy.bar_minutes}-min bars"
            mode = "live orders" if snap["mode"] == "practice" else "paper"
            set_pill(self.status, f"Running · {mode} · {snap['contract']} · {what}", "run")
            fast = snap.get("fast") or {}
            tip = ""
            if fast.get("on"):
                tip = (f"Fast bars {'connected' if fast['connected'] else 'reconnecting'}: built from Topstep's live "
                       f"trade stream and acted on about 0.5s after the close ({fast['matched']} matched Topstep's "
                       f"bar, {fast['differed']} differed).")
            self.status.setToolTip(tip)
        else:
            set_pill(self.status, "Stopped", "off")
            self.status.setToolTip("")
        if self.is_alerts:
            self._fill_alerts(snap)
        if snap:
            self._fill_sessions(snap["sessions"])
            self._fill_trade(snap["trade"], running)
        else:
            self._fill_sessions(self._idle_rows())
            self._fill_trade(None, False)

    def _fill_trade(self, t: dict | None, running: bool):
        L = self.t_labels
        has = bool(t)
        for w in (self.bracket, self.kv_widget, self.close_btn, self.be_btn):
            w.setVisible(has)
        self.flat_note.setVisible(not has)
        L["unreal"].setVisible(has)
        if not t:
            self.trade_box.setTitle("POSITION")
            L["what"].setText("Flat" if running else "–")
            L["what"].setStyleSheet(f"color: {theme.TEXT_2};")
            self.flat_note.setText("Waiting for the next signal." if running else
                                   "The bot is stopped on this account.")
            self.bracket.set(None)
            self.close_btn.setEnabled(False)
            return
        long = t["side"] == "buy"
        sess = "TRADINGVIEW" if self.is_alerts else t["session"].upper()
        self.trade_box.setTitle(f"POSITION · {sess} · SINCE {t['time']}")
        L["what"].setText(f"{'LONG' if long else 'SHORT'} {t['size']} {self.contract_root()}"
                          + ("" if t["filled"] else "  · waiting for fill"))
        L["what"].setStyleSheet(f"color: {GREEN if long else RED};")
        u = t["unrealized"]
        L["unreal"].setText(money(u, True) if u is not None else "–")
        L["unreal"].setStyleSheet("" if u is None else f"color: {GREEN if u >= 0 else RED};")
        L["last"].setText(f"{t['last']:,.2f}" if t["last"] is not None else "–")
        L["entry"].setText(f"{t['entry']:,.2f}")
        L["stop"].setText(f"{t['stop']:,.2f}" if t.get("stop") is not None else "–")
        L["stop"].setStyleSheet(f"color: {RED};")
        L["target"].setText(f"{t['target']:,.2f}" if t.get("target") is not None else "–")
        L["target"].setStyleSheet(f"color: {GREEN};")
        pv = self.point_value()
        if pv:
            L["risk"].setText(money(abs(t["entry"] - t["stop"]) * pv * t["size"]))
            L["reward"].setText(money(abs(t["target"] - t["entry"]) * pv * t["size"]))
        else:
            L["risk"].setText(f"{t['stop']:,.2f}")
            L["reward"].setText(f"{t['target']:,.2f}")
        self.bracket.set(t)
        self.close_btn.setEnabled(running)
        at_be = t.get("stop") is not None and t["stop"] == t["entry"]
        self.be_btn.setText("Stop is at break-even" if at_be else "Move stop to break-even")
        self.be_btn.setEnabled(running and t["filled"] and not at_be and (u or 0) > 0)

    def contract_root(self) -> str:
        sym = (self.cfg.alerts.symbol if self.is_alerts and self.cfg.alerts.symbol else
               self.cfg.script.symbol if self.is_script and self.cfg.script.symbol else self.cfg.broker.symbol) or ""
        return sym.upper()[:3] if sym.upper().startswith(("MNQ", "MES", "MGC", "MYM", "M2K")) else sym.upper()[:2]

    def point_value(self) -> float | None:
        """Dollars per point per contract, from the running engine's contract."""
        c = getattr(self.engine, "contract", None)
        if c and c.tick_size:
            return c.tick_value / c.tick_size
        return {"MNQ": 2.0, "NQ": 20.0, "MES": 5.0, "ES": 50.0, "MGC": 10.0, "GC": 100.0}.get(self.contract_root())


class MainWindow(QMainWindow):
    """Every account gets its own set of bot tabs. The account dropdown switches which set you see; bots keep
    running on the accounts you're not looking at."""
    job_done = Signal(object, object, object)  # callback, result, error
    remote_command = Signal(str)  # a command texted to the Telegram bot

    def __init__(self, root: Path):
        super().__init__()
        self.root = root
        self.main_path = root / "config.toml"
        self.bots_dir = root / "bots"
        if not self.main_path.exists() and (root / "config.example.toml").exists():
            shutil.copy(root / "config.example.toml", self.main_path)
        for p in [self.main_path, *(sorted(self.bots_dir.glob("*.toml")) if self.bots_dir.exists() else [])]:
            try:
                if rename_original_orb(p):
                    log.info("bot ORB M5 renamed to %s", OG_NAME)
            except Exception as e:  # noqa: BLE001 - keep the old name rather than stop the app
                log.warning("couldn't rename ORB M5 in %s: %s", p.name, e)
        # Login, contract, bracket test, Fast bars, confirmed accounts and the account last viewed.
        self.main_cfg: Config = load_config(self.main_path)
        wh = self.main_cfg.webhook
        self.webhook = WebhookServer(wh.port, wh.public_url, wh.start_ngrok)
        self.bot_files: list[Path] = [self.main_path]
        for p in sorted(self.bots_dir.glob("*.toml")) if self.bots_dir.exists() else []:
            try:
                load_config(p)
                self.bot_files.append(p)
            except Exception as e:  # noqa: BLE001 - a broken file shouldn't stop the app
                log.error("could not load bot %s: %s", p.name, e)
        self.views: dict[int | None, QTabWidget] = {}
        self.panels: dict[int | None, list[BotPanel]] = {}
        self.view_id: int | None = None
        self._accounts: list = []
        self.keep_awake: subprocess.Popen | None = None
        self.bridge = LogBridge()
        theme.apply()
        self.setWindowTitle(APP_NAME)
        self.resize(1150, 820)
        self._build()
        b = self.main_cfg.broker
        self.view_account(b.account_id, b.account_name, remember=False)
        self.bridge.line.connect(self._append_log)
        handler = QtLogHandler(self.bridge)
        handler.setLevel(logging.INFO)
        logging.getLogger().addHandler(handler)
        self.problem_handler = phone.ProblemHandler()
        self.problem_handler.addFilter(BotNameFilter())
        logging.getLogger().addHandler(self.problem_handler)
        self.listener: phone.CommandListener | None = None
        self.remote_command.connect(self.remote)
        self.setup_phone_alerts()
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh)
        self.timer.start(1000)
        self.open_pnl = OpenPnL(self._pnl_broker, get_stream)
        self.upl_timer = QTimer(self)  # UP&L moves with the market, like TopstepX's
        self.upl_timer.timeout.connect(self._show_upl)
        self.upl_timer.start(250)
        self._fill_account_combo([])
        self.load_accounts()
        self.refresh()

    # --- the bots on the account being viewed (used by the tests too) ---------------------------
    @property
    def bots(self) -> list[BotPanel]:
        return self.panels.get(self.view_id, [])

    @property
    def main(self) -> BotPanel:
        return self.bots[0]

    @property
    def cfg(self) -> Config:
        """The first bot's settings on the account being viewed."""
        return self.main.cfg

    @property
    def bot_tabs(self) -> QTabWidget:
        return self.views[self.view_id]

    def all_panels(self) -> list[BotPanel]:
        return [p for ps in self.panels.values() for p in ps]

    def panels_for(self, path: Path) -> list[BotPanel]:
        return [p for p in self.all_panels() if p.cfg_path == path]

    def file_running(self, path: Path) -> bool:
        return any(p.running for p in self.panels_for(path))

    def running_on(self, account_id: int | None) -> list[BotPanel]:
        return [p for p in self.panels.get(account_id, []) if p.running]

    def account_allowed(self, account_id: int, name: str) -> bool:
        b = self.main_cfg.broker
        return name.upper().startswith("PRAC") or account_id == b.confirmed_account_id \
            or account_id in b.confirmed_accounts

    def load_bot_config(self, path: Path, account_id: int | None = None, account_name: str = "") -> Config:
        return for_account(load_config(path), self.main_cfg.broker, account_id, account_name)


    # --- accounts ---------------------------------------------------------------------------------
    def load_accounts(self):
        """Fetch the account list in the background if a login is saved (never asks for one at startup)."""
        try:
            creds = get_credentials()
        except Exception:  # noqa: BLE001 - no Keychain access: the Account menu still works
            creds = None
        if not creds:
            return
        b = ProjectXBroker(self.main_cfg.broker, *creds)

        def fetch():
            b.connect()
            return b.list_accounts()
        self._job(fetch, lambda accts, err: self._fill_account_combo(accts) if not err else
                  log.warning("could not list accounts: %s", err))

    def _fill_account_combo(self, accounts: list):
        if accounts:
            self._accounts = list(accounts)
            if self.view_id is not None:
                acct = next((a for a in accounts if a.id == self.view_id), None)
                if acct and acct.name != self.main_cfg.broker.account_name:
                    self.view_account(acct.id, acct.name)
        self.account_combo.blockSignals(True)
        self.account_combo.clear()
        for text, acct_id in self._combo_entries():
            self.account_combo.addItem(text, acct_id)
        i = self.account_combo.findData(self.view_id)
        self.account_combo.setCurrentIndex(max(i, 0))
        self.account_combo.blockSignals(False)

    def _combo_entries(self) -> list[tuple[str, int | None]]:
        entries = [(a.id, a.name, "") for a in self._accounts]  # balance is in the BAL figure next to it
        for acct_id, ps in self.panels.items():  # accounts with bots but missing from the list
            if acct_id is not None and all(e[0] != acct_id for e in entries) and ps:
                entries.append((acct_id, ps[0].account_name or f"Account {acct_id}", ""))
        out = []
        for acct_id, name, bal in entries:
            n = len(self.running_on(acct_id))
            run = f"   ● {n} running" if n else ""
            tag = "" if self.account_allowed(acct_id, name) else "   (asks to confirm before real orders)"
            out.append((f"{name}{bal}{run}{tag}", acct_id))
        return out or [("No account yet: Account → Check connection", None)]

    def _account_picked(self, index: int):
        acct_id = self.account_combo.itemData(index)
        if acct_id is None or acct_id == self.view_id:
            return
        acct = next((a for a in self._accounts if a.id == acct_id), None)
        name = acct.name if acct else (self.panels[acct_id][0].account_name if self.panels.get(acct_id) else "")
        self.view_account(acct_id, name)

    def _ensure_panels(self, account_id: int | None, name: str = "") -> None:
        """This account's bot tabs, made the first time they're needed (viewing it, or deploying a bot to it)."""
        if account_id not in self.views:
            tabs = QTabWidget()
            tabs.setDocumentMode(True)
            tabs.tabBar().setDrawBase(False)
            tabs.currentChanged.connect(self._bot_tab_changed)
            self.views[account_id] = tabs
            self.panels[account_id] = []
            self.view_stack.addWidget(tabs)
            for path in self.bot_files:
                self._add_panel(account_id, name, path)
        else:
            for p in self.panels[account_id]:
                if name and p.account_name != name and not p.running:
                    p.account_name = name
                    p.refresh_broker()
                    p._update_titles()

    def view_account(self, account_id: int | None, name: str = "", remember: bool = True):
        """Show this account's bots (creating them the first time). Never stops or changes a running bot."""
        self._ensure_panels(account_id, name)
        self.view_id = account_id
        if getattr(self, "chart", None) is not None:
            self.chart.set_account(account_id)
        self.view_stack.setCurrentWidget(self.views[account_id])
        if remember and account_id is not None:
            # Remembered for the next launch and used by Check connection, the bracket test and the command line.
            select_account(self.main_cfg, None, account_id, name)
        self._bot_tab_changed()
        self._fill_account_combo([])
        self._show_account_cards()
        if remember:
            running = self.running_on(account_id)
            log.info("viewing %s%s", name or f"account {account_id}",
                     f" ({', '.join(p.name for p in running)} running)" if running else "")

    # --- bots -----------------------------------------------------------------------------------
    def _add_panel(self, account_id: int | None, account_name: str, path: Path) -> BotPanel:
        panel = BotPanel(self, path, account_id, account_name)
        self.panels[account_id].append(panel)
        self.settings_stack.addWidget(panel.settings_scroll)
        self.replay_stack.addWidget(panel.replay_page)
        self.views[account_id].addTab(panel, panel.name)
        panel.refresh()
        return panel

    def reload_bot(self, path: Path):
        """After a settings file changed: re-read it in every account's copy of that bot."""
        if path == self.main_path:
            fresh = load_config(self.main_path)
            self.main_cfg.broker.symbol = fresh.broker.symbol
            for p in self.all_panels():
                p.refresh_broker()
        for p in self.panels_for(path):
            p.reload()
            tabs = self.views[p.account_id]
            tabs.setTabText(tabs.indexOf(p), p.name)
        self._bot_tab_changed()

    def remove_bot(self, path: Path):
        for p in self.panels_for(path):
            self.panels[p.account_id].remove(p)
            tabs = self.views[p.account_id]
            tabs.removeTab(tabs.indexOf(p))
            self.settings_stack.removeWidget(p.settings_scroll)
            self.replay_stack.removeWidget(p.replay_page)
            p.deleteLater()
        self.bot_files.remove(path)
        self._bot_tab_changed()

    def name_problem(self, name: str, exclude: BotPanel | None = None) -> str | None:
        if not name:
            return "Give the bot a name."
        if not _slug(name):
            return "Use at least one letter or number in the name."
        for b in self.bots:
            if (exclude is None or b.cfg_path != exclude.cfg_path) and b.cfg.slug == _slug(name):
                return f"{b.name} already uses that name."
        return None

    def add_bot(self):
        dlg = AddBotDialog(self, self.bots)
        if not dlg.exec():
            return
        name = dlg.name.text().strip()
        problem = self.name_problem(name)
        if problem:
            QMessageBox.warning(self, "Add bot", problem)
            return
        self.bots_dir.mkdir(exist_ok=True)
        path = self.bots_dir / f"{_slug(name)}.toml"
        if path.exists():
            path.rename(path.with_name(path.name + f".old-{datetime.now():%Y%m%d%H%M%S}"))
        if dlg.kind.currentData() == "alerts":
            self._add_alerts_bot(path, name, dlg.symbol.text().strip().upper() or self.main_cfg.broker.symbol)
            return
        if dlg.kind.currentData() == "script":
            self._add_script_bot(path, name, Path(dlg.script_file.text().strip()), dlg.timeframe.currentData(),
                                 dlg.symbol.text().strip().upper())
            return
        if not dlg.orb_bots:
            QMessageBox.warning(self, "Add bot", "There's no ORB bot to copy.")
            return
        source = dlg.orb_bots[dlg.source.currentIndex()]
        minutes = dlg.timeframe.currentData()
        text = source.cfg_path.read_text()
        cut = text.find("\n[accounts.")  # per-account risk stays with the source bot
        path.write_text(f"# {name}: added in the app, copied from {source.name}. Login and contract settings "
                        "come from config.toml.\n" + (text[:cut + 1] if cut >= 0 else text))
        save_top_setting(path, "name", name)
        save_top_setting(path, "id", _slug(name))  # its own order tags and state, never the copied bot's
        save_setting(path, "strategy", "bar_minutes", minutes)
        self.bot_files.append(path)
        for acct_id in self.views:
            ps = self.panels[acct_id]
            self._add_panel(acct_id, ps[0].account_name if ps else "", path)
        panel = self.bots[-1]
        self.bot_tabs.setCurrentWidget(panel)
        log.info("added bot %s (%d-minute bars, settings copied from %s)", name, minutes, source.name)
        msg = (f"{name} is set up on every account with {source.name}'s settings on {minutes}-minute bars. Its "
               "sessions start switched on as they were in the copy.\n\nOpen the Settings tab to set its sessions, "
               "then press Save.")
        warn = session_bar_warnings(panel.cfg)
        if warn:
            msg += "\n\nThese sessions need changing for this timeframe:\n• " + "\n• ".join(warn)
        QMessageBox.information(self, "Bot added", msg)
        self.bottom.setCurrentIndex(2)

    def _add_alerts_bot(self, path: Path, name: str, symbol: str):
        main = self.main_cfg
        path.write_text(
            f"# {name}: trades a TradingView script's alerts (added in the app). Login comes from config.toml.\n"
            f'name = "{name}"\ntype = "alerts"\ntimezone = "{main.timezone.key}"\nlog_dir = "{main.log_dir}"\n\n'
            f'[alerts]\nsecret = "{secrets.token_urlsafe(12)}"\nsymbol = "{symbol}"\nsizing = "tv"\n'
            "multiplier = 1.0\ncontracts = 1\nstop_ticks = 80\ntarget_rr = 1.0\ntarget_ticks = 80\n"
            'exit_alerts = "ignore"\n\n[risk]\nmax_contracts = 10\n\n[safety]\nmax_daily_loss = 1000\n\n'
            "[strategy]\n\n[broker]\n\n[sim]\nslippage_ticks = 1\n")
        self.bot_files.append(path)
        for acct_id in self.views:
            ps = self.panels[acct_id]
            self._add_panel(acct_id, ps[0].account_name if ps else "", path)
        self.bot_tabs.setCurrentWidget(self.bots[-1])
        log.info("added TradingView alerts bot %s (%s)", name, symbol)
        QMessageBox.information(
            self, "Bot added",
            f"{name} is added on every account.\n\n1. Set its stop and target in its Settings tab and press Save.\n"
            "2. Bots → TradingView alerts setup… (once) gives the app its public web address.\n"
            "3. In TradingView, edit the script's alert: Webhook URL and Message are shown on the bot's tab "
            "(Copy buttons).\n4. Try it with ••• → Test run first if you like.")
        self.bottom.setCurrentIndex(2)

    # --- TradingView webhook ----------------------------------------------------------------
    def ensure_webhook(self) -> bool:
        """Start listening for alerts (and the ngrok tunnel) before an alerts bot starts."""
        if not self.webhook.public_url:
            ok = QMessageBox.question(
                self, "TradingView can't reach the app yet",
                "The app has no public web address yet, so TradingView's alerts can't reach it. Set it up in "
                "Bots → TradingView alerts setup….\n\nStart anyway (you can still test locally)?")
            if ok != QMessageBox.Yes:
                return False
        try:
            self.webhook.start()
        except OSError as e:
            port = self.webhook.port
            if e.errno in (48, 98):  # address already in use (macOS, Linux)
                if self.webhook.port_owner() == "app":
                    msg = (f"Another copy of {APP_NAME} is already open and receiving TradingView alerts on port "
                           f"{port}. Only one copy can receive them.\n\nQuit the other copy (click it, then Cmd+Q) "
                           "and press Start here again. Run the TV alerts bot on several accounts from this one "
                           "window: the alert reaches every account it's started on.")
                else:
                    msg = (f"Another program on this Mac is using port {port}, so TradingView alerts can't be "
                           "received.\n\nQuit that program, or pick another port in Bots → TradingView alerts "
                           "setup… (and use the same port in ngrok).")
            else:
                msg = f"Could not listen on port {port}: {e}"
            log.error("TradingView alerts: %s", msg.split("\n")[0])
            QMessageBox.warning(self, "TradingView alerts", msg)
            return False
        return True

    def webhook_setup(self):
        dlg = QDialog(self)
        dlg.setWindowTitle("TradingView alerts setup")
        form = QFormLayout(dlg)
        steps = QLabel(
            "TradingView sends alerts to a public web address. A free ngrok account gives this Mac a fixed one,\n"
            "and the app starts ngrok for you whenever a TradingView alerts bot is running. Once only:\n\n"
            "1. Sign up free at ngrok.com, then in Terminal:  brew install ngrok\n"
            "2. Copy your authtoken from the ngrok dashboard and run:  ngrok config add-authtoken <token>\n"
            "3. In the ngrok dashboard open Domains, copy your free domain (…ngrok-free.app) and paste it below.\n\n"
            "TradingView needs two-factor authentication turned on before it sends webhooks.\n"
            "Only alerts come in through ngrok; orders still go from this Mac straight to Topstep.")
        steps.setTextInteractionFlags(Qt.TextSelectableByMouse)
        form.addRow(steps)
        domain = QLineEdit(self.main_cfg.webhook.public_url)
        domain.setPlaceholderText("e.g. james-orb.ngrok-free.app")
        port = QSpinBox()
        port.setRange(1024, 65535)
        port.setValue(self.main_cfg.webhook.port)
        auto = QCheckBox("Start ngrok automatically")
        auto.setChecked(self.main_cfg.webhook.start_ngrok)
        form.addRow("ngrok domain", domain)
        form.addRow("Local port", port)
        form.addRow("", auto)
        exe = find_ngrok()
        status = ("ngrok found: " + exe) if exe else "ngrok not found yet (step 1)"
        if self.webhook.running:
            status += f"\nListening now. Webhook URL: {self.webhook.address or '(no domain yet)'}"
        if self.webhook.ngrok_error:
            status += f"\nngrok said: {self.webhook.ngrok_error}"
        form.addRow(QLabel(status))
        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.accepted.connect(dlg.accept)
        buttons.rejected.connect(dlg.reject)
        form.addRow(buttons)
        if not dlg.exec():
            return
        self.set_webhook(domain.text(), port.value(), auto.isChecked())

    def set_webhook(self, domain: str, port: int, start_ngrok: bool):
        host = domain.strip().removeprefix("https://").removeprefix("http://").rstrip("/").removesuffix("/tv")
        wh = self.main_cfg.webhook
        wh.public_url, wh.port, wh.start_ngrok = host, port, start_ngrok
        for k, v in (("public_url", host), ("port", port), ("start_ngrok", start_ngrok)):
            save_setting(self.main_path, "webhook", k, v)
        restart = self.webhook.running
        self.webhook.stop()
        self.webhook = WebhookServer(wh.port, wh.public_url, wh.start_ngrok)
        if restart:
            self.webhook.start()
        for p in self.all_panels():
            p._fill_alert_info()
        log.info("TradingView alerts address set: %s", self.webhook.address or "none")

    # --- layout ---------------------------------------------------------------------------
    def _build(self):
        # No menu bar: Settings (cog), Help and the header buttons hold all of these. The menus are kept, unattached,
        # for the Account button and tests.
        self.menuBar().setNativeMenuBar(False)
        self.menuBar().hide()
        menu = self.account_menu = QMenu("Account", self)
        for text, fn in [("Check connection and choose account…", self.check_connection),
                         ("Run bracket test…", self.run_bracket_test),
                         ("Change TopstepX login…", self.change_login),
                         ("Phone alerts (Telegram)…", self.phone_alerts)]:
            act = QAction(text, self)
            act.triggered.connect(fn)
            menu.addAction(act)
        bots_menu = QMenu("Bots", self)
        act = QAction("Add a bot…", self)
        act.triggered.connect(self.add_bot)
        bots_menu.addAction(act)
        act = QAction("TradingView alerts setup…", self)
        act.triggered.connect(self.webhook_setup)
        bots_menu.addAction(act)
        act = QAction("Performance…", self)
        act.triggered.connect(self.open_performance)
        bots_menu.addAction(act)
        act = QAction("Show or hide chart", self)
        act.triggered.connect(self.open_chart)
        bots_menu.addAction(act)
        help_menu = QMenu("Help", self)
        for text, tid in [(f"{APP_NAME} Help", "start"), ("TopstepX login and API key", "login"),
                          ("Accounts", "accounts"), ("TradingView alerts", "tv"), ("Phone alerts (Telegram)", "phone"),
                          ("Troubleshooting", "trouble"), ("FAQ", "faq")]:
            act = QAction(text, self)
            act.triggered.connect(lambda _c=False, t=tid: self.open_help(t))
            help_menu.addAction(act)
        bots_menu.addSeparator()
        act = QAction("Stop all bots", self)
        act.triggered.connect(lambda: self.stop_all(ask=True))
        bots_menu.addAction(act)
        act = QAction("Flatten all and stop…", self)
        act.triggered.connect(lambda: self.flatten_all(ask=True))
        bots_menu.addAction(act)
        self.job_done.connect(lambda cb, res, err: cb(res, err))

        # TopstepX-style: an icon bar down the left (Chart, Performance, Settings, Help), pages on the right.
        central = QWidget()
        outer = QHBoxLayout(central)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        outer.addWidget(self._build_rail())
        main = QWidget()
        root = QVBoxLayout(main)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        outer.addWidget(main, 1)

        header = QFrame()
        header.setObjectName("topbar")
        hl = QVBoxLayout(header)
        hl.setContentsMargins(0, 0, 0, 0)
        # wraps onto a second line when the window is narrow (e.g. half the screen next to another app)
        bar = FlowLayout(spacing=10, v_spacing=8)
        bar.setContentsMargins(16, 10, 16, 10)
        hl.addLayout(bar)
        brand = QLabel(theme.wordmark_html(15))
        brand.setTextFormat(Qt.RichText)
        brand.setToolTip(theme.TAGLINE)
        # The same Account menu as in the Mac menu bar, inside the window where it's easy to find.
        self.account_btn = QPushButton("Account  ▾")
        self.account_btn.setMenu(self.account_menu)
        self.flatten_btn = QPushButton("Flatten all")
        self.flatten_btn.setObjectName("close")
        self.flatten_btn.setToolTip("Close every bot's open trade at market, on every account, and stop all bots. "
                                    "Trades the bots didn't place are not touched.")
        self.flatten_btn.clicked.connect(lambda: self.flatten_all(ask=True))
        self.add_btn = QPushButton("＋  Add bot")
        self.add_btn.clicked.connect(self.add_bot)
        self.status = QLabel()
        self.status.setObjectName("pill")
        self.status.setTextFormat(Qt.RichText)
        self.account_combo = QComboBox()
        self.account_combo.setMinimumWidth(220)
        self.account_combo.setSizeAdjustPolicy(QComboBox.AdjustToContents)
        # The account's figures, as TopstepX shows them across its top bar.
        self.c_balance = Chip("BAL", tip="The account's balance at Topstep")
        self.c_mll = Chip("MLL", tip="Maximum loss limit: the balance the account must stay above (Topstep's "
                                     "trailing drawdown, worked out from the account's daily balances)")
        self.c_pnl = Chip("RP&L", filled=True, tip="Realised P&L today, the whole account (every bot and manual "
                                                   "trades), after fees")
        self.c_upl = Chip("UP&L", tip="Open P&L of every position on this account (bots' and manual), "
                                      "updating with each trade")
        self.account_combo.setToolTip("Which account's bots you're looking at. Switching never stops a bot: bots "
                                      "keep running on every account they were started on.")
        self.account_combo.activated.connect(self._account_picked)
        bar.addWidget(brand)
        bar.addWidget(self.account_combo)
        for c in (self.c_balance, self.c_mll, self.c_pnl, self.c_upl):
            bar.addWidget(c)
        self.status.hide()  # the account picker already says how many bots are running
        bar.add_stretch()
        bar.addWidget(self.flatten_btn)
        bar.addWidget(self.add_btn)
        self.account_btn.hide()  # the Settings page (left bar) has the same items
        root.addWidget(header)
        root.addWidget(self._build_update_banner())
        self.pages = PageStack()
        root.addWidget(self.pages, 1)
        trade_page = QWidget()
        root = QVBoxLayout(trade_page)  # the Chart page: stats, chart, bots, Activity
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        self.pages.addWidget(trade_page)
        self.bots_page = AllBots()
        self.bots_page.open_bot.connect(self._open_bot)
        self.bots_page.pick_bot.connect(self._show_bot_detail)
        self.bots_page.deploy.connect(self._deploy)
        self.bots_page.close_bot.connect(lambda i: self._row_bot(i, "close_trade"))
        self.bots_page.be_bot.connect(lambda i: self._row_bot(i, "breakeven"))
        self.pages.addWidget(self.bots_page)
        self.perf_page = QWidget()  # the Performance and Help pages are built the first time they're opened
        QVBoxLayout(self.perf_page).setContentsMargins(0, 0, 0, 0)
        self.pages.addWidget(self.perf_page)
        self.pages.addWidget(self._build_settings_page())
        self.help_page = QWidget()
        QVBoxLayout(self.help_page).setContentsMargins(0, 0, 0, 0)
        self.pages.addWidget(self.help_page)

        self.c_account = Card("Account")  # kept for the account name; shown in the dropdown

        body = QWidget()
        bl = QVBoxLayout(body)
        bl.setContentsMargins(16, 8, 16, 14)
        bl.setSpacing(0)
        self.view_stack = QStackedWidget()  # one tab set per account
        bl.addWidget(self.view_stack, 1)
        # Chart on top, the bots in the middle, Activity/trades/settings below; drag the dividers to resize.
        self.split = theme.GripSplitter(Qt.Vertical)
        self.split.setChildrenCollapsible(True)
        self.chart = self._make_chart()
        if self.chart is not None:
            self.split.addWidget(self.chart)
        body_scroll = QScrollArea()  # lets the bots area shrink when the chart is made bigger
        body_scroll.setWidget(body)
        body_scroll.setWidgetResizable(True)
        body_scroll.setFrameShape(QFrame.NoFrame)
        body_scroll.setMinimumHeight(120)
        self.split.addWidget(body_scroll)
        root.addWidget(self.split, 1)

        self.bottom = QTabWidget()
        self.bottom.setDocumentMode(True)
        self.bottom.setMinimumHeight(80)
        self.log_view = QPlainTextEdit()
        self.log_view.setReadOnly(True)
        self.log_view.setMaximumBlockCount(5000)
        self.log_view.setFont(theme.mono_font())
        self.bottom.addTab(self.log_view, "Activity")
        self.trades = QTableWidget(0, 8)
        self.trades.setHorizontalHeaderLabels(["BOT", "IN", "OUT", "SIDE", "SIZE", "ENTRY", "EXIT", "P&L"])
        self.trades.verticalHeader().setVisible(False)
        self.trades.setShowGrid(False)
        self.trades.setFocusPolicy(Qt.NoFocus)
        self.trades.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.trades.setSelectionMode(QAbstractItemView.NoSelection)
        self.trades.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.trades.horizontalHeader().setDefaultAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.bottom.addTab(self.trades, "Today's trades")
        self.settings_stack = QStackedWidget()
        self.bottom.addTab(self.settings_stack, "Settings")
        self.replay_stack = QStackedWidget()
        self.bottom.addTab(self.replay_stack, "Replay")
        self.split.addWidget(self.bottom)
        for i in range(self.split.count()):
            self.split.setStretchFactor(i, 3 if i == 0 and self.chart is not None else 1)
        self._split_sized = False

        self.setCentralWidget(central)
        theme.apply()

    PAGES = [("chart", "Chart and bots"), ("bots", "My bots"), ("performance", "Performance"), ("settings", "Settings"),
             ("help", "Help")]

    def _build_rail(self) -> QFrame:
        rail = QFrame()
        rail.setObjectName("rail")
        rail.setFixedWidth(60)
        lay = QVBoxLayout(rail)
        lay.setContentsMargins(8, 12, 8, 12)
        lay.setSpacing(8)
        logo = QLabel()
        logo.setPixmap(theme.logo_pixmap(30))
        logo.setAlignment(Qt.AlignCenter)
        logo.setToolTip(f"{APP_NAME}: {theme.TAGLINE}")
        lay.addWidget(logo)
        lay.addSpacing(10)
        self.nav = QButtonGroup(self)
        self.nav.setExclusive(True)
        self.nav_buttons = {}
        for i, (name, tip) in enumerate(self.PAGES):
            b = QToolButton()
            b.setObjectName("nav")
            b.setIcon(theme.nav_icon(name))
            b.setIconSize(QSize(22, 22))
            b.setFixedSize(44, 44)
            b.setCheckable(True)
            b.setToolTip(tip)
            b.setCursor(Qt.PointingHandCursor)
            self.nav.addButton(b, i)
            self.nav_buttons[name] = b
            lay.addWidget(b, 0, Qt.AlignHCenter)
        lay.addStretch(1)
        self.nav_buttons["chart"].setChecked(True)
        self.nav.idClicked.connect(lambda i: self.show_page(self.PAGES[i][0]))
        return rail

    def show_page(self, name: str) -> None:
        if name == "bots":
            self._select_page("bots")
            return self.refresh()  # fill it now, not on the next tick
        if name == "performance":
            return self.open_performance()
        if name == "help":
            return self.open_help()
        self._select_page(name)

    def _select_page(self, name: str) -> None:
        i = [n for n, _t in self.PAGES].index(name)
        self.pages.setCurrentIndex(i)
        self.nav_buttons[name].setChecked(True)

    def _build_settings_page(self) -> QWidget:
        """Everything from the Account and Bots menus, as buttons on one page."""
        page = QScrollArea()
        page.setWidgetResizable(True)
        page.setFrameShape(QFrame.NoFrame)
        inner = QWidget()
        lay = QVBoxLayout(inner)
        lay.setContentsMargins(24, 20, 24, 20)
        lay.setSpacing(14)
        title = QLabel("Settings")
        title.setObjectName("h2")
        lay.addWidget(title)
        groups = [
            ("TOPSTEPX ACCOUNT", [
                ("Check connection and choose account…", "Log in to TopstepX and pick the account to view.",
                 self.check_connection),
                ("Change TopstepX login…", "Your username and API key, kept in the Mac's Keychain.",
                 self.change_login),
                ("Run bracket test…", "Places and cancels a tiny bracket on a Practice account to check orders work.",
                 self.run_bracket_test)]),
            ("BOTS", [
                ("Add a bot…", "Another ORB bot, a TradingView alerts bot, or your own Python script.", self.add_bot),
                ("TradingView alerts setup…", "The webhook URL and alert message for TradingView.",
                 self.webhook_setup),
                ("Stop all bots", "Stops every bot on every account. Open trades keep their stop and target.",
                 lambda: self.stop_all(ask=True))]),
            ("NOTIFICATIONS", [
                ("Phone alerts (Telegram)…", "Trade and problem alerts on your phone, and phone commands.",
                 self.phone_alerts)]),
        ]
        if self.licence.enforce:
            box = QGroupBox("LICENCE")
            g = QGridLayout(box)
            self.licence_key = QLineEdit(self.licence.key)
            self.licence_key.setPlaceholderText("Licence key from your Whop receipt")
            g.addWidget(self.licence_key, 0, 0, 1, 3)
            for i, (text, fn) in enumerate([("Activate", self.licence_activate),
                                            ("Check licence", lambda: self.licence_check()),
                                            ("Deactivate this computer", self.licence_deactivate)]):
                b = QPushButton(text)
                b.clicked.connect(lambda _c=False, f=fn: f())
                g.addWidget(b, 1, i)
            self.licence_status = QLabel(self.licence.status().message)
            self.licence_status.setWordWrap(True)
            g.addWidget(self.licence_status, 2, 0, 1, 3)
            lay.addWidget(box)
        for head, rows in groups:
            box = QGroupBox(head)
            g = QGridLayout(box)
            g.setHorizontalSpacing(16)
            g.setVerticalSpacing(10)
            for r, (text, help_text, fn) in enumerate(rows):
                b = QPushButton(text.rstrip("…"))
                b.setMinimumWidth(260)
                b.clicked.connect(lambda _c=False, f=fn: f())
                note = QLabel(help_text)
                note.setStyleSheet(f"color: {theme.TEXT_2};")
                note.setWordWrap(True)
                g.addWidget(b, r, 0)
                g.addWidget(note, r, 1)
            g.setColumnStretch(1, 1)
            lay.addWidget(box)
        lay.addStretch(1)
        page.setWidget(inner)
        return page

    def _open_bot(self, _i: int = 0) -> None:
        """My bots → Open on chart: the bot shown, on its tab of the Chart page, on its account."""
        p = getattr(self, "_detail_bot", None)
        if p is None or p not in self.all_panels():
            return
        if p.account_id != self.view_id:
            self.view_account(p.account_id, p.account_name)
        self.views[p.account_id].setCurrentWidget(p)
        self._select_page("chart")

    def _show_bot_detail(self, i: int) -> None:
        rows = self._bot_list()
        if 0 <= i < len(rows):
            self._detail_bot = rows[i]
            self.bots_page.show_detail(i, self._bot_detail(rows[i]))

    def _bot_detail(self, p: BotPanel) -> dict:
        """My bots → a bot: what it is, its settings, and its code (or its TradingView alert) to copy."""
        c = p.cfg
        kind = "TradingView alerts" if p.is_alerts else "Your Python script" if p.is_script else "ORB (built in)"
        market = (c.alerts.symbol if p.is_alerts and c.alerts.symbol else c.broker.symbol) or "–"
        on = [q.account_name or str(q.account_id) for q in self.panels_for(p.cfg_path) if q.running]
        facts = [("Type", kind), ("Market", market), ("Running on", ", ".join(on) or "nothing right now")]
        r = c.risk
        if p.is_alerts:
            a = c.alerts
            facts += [("Size", f"TradingView's contracts × {a.multiplier:g}" if a.sizing == "tv"
                       else f"{a.contracts} contract{'s' if a.contracts != 1 else ''}"),
                      ("Stop", f"the alert's stop, else {a.stop_ticks} ticks"),
                      ("Target", f"{a.target_rr:g} R" if a.target_rr else f"{a.target_ticks} ticks"),
                      ("Script's exit alerts", a.exit_alerts)]
        else:
            facts += [("Timeframe", f"{c.strategy.bar_minutes} min"),
                      ("Risk per trade", f"{r.risk_percent:g}% of the balance" if r.risk_mode == "percent"
                       else f"${r.risk_dollars:,.0f}")]
            if not p.is_script:
                facts += [(s.name, f"{s.start:%H:%M} for {s.window_minutes} min · {s.rr_first:g} R"
                           + ("" if s.enabled else " · off")) for s in c.sessions]
        facts += [("Max contracts", str(r.max_contracts)),
                  ("Daily loss limit", f"${c.safety.max_daily_loss:,.0f}" if c.safety.max_daily_loss else "none"),
                  ("Settings file", str(p.cfg_path.relative_to(self.root) if p.cfg_path.is_relative_to(self.root)
                                        else p.cfg_path))]
        if p.is_alerts:
            url = self.webhook.address
            code_title = "TradingView alert message (paste into the alert's Message box)"
            code = p.alert_message() + ("\n\nWebhook URL:\n" + url if url else "")
        else:
            src = (self.root / c.script.file) if p.is_script else Path(__file__).parent / "strategy" / "orb.py"
            code_title = f"Python code · {src.name}"
        if not p.is_alerts and lic.ENFORCE and (not p.is_script or src.name in BUILT_IN_SCRIPTS):
            code_title, code = "Python code", "A built-in Traders Helm bot: its code isn't shown."
        elif not p.is_alerts:
            try:
                code = src.read_text(encoding="utf-8")
            except OSError as e:
                code = f"Couldn't read {src}: {e}"
        names = {a.id: a.name for a in self._accounts}
        names.update({a: (ps[0].account_name if ps else "") or names.get(a, "") for a, ps in self.panels.items()
                      if a is not None and a not in names})
        accounts = [(a, n, any(q.running for q in self.panels.get(a, []) if q.cfg_path == p.cfg_path))
                    for a, n in names.items()]
        return {"title": p.name, "sub": f"{kind} · {market}", "facts": facts, "code_title": code_title,
                "code": code, "accounts": accounts, "account": p.account_id}

    def _deploy(self, account_id: int) -> None:
        """My bots → Deploy: start the bot shown on that account (or stop it there). Start asks first, as on the
        bot's own tab: real orders, and an extra confirmation for an account that isn't Practice."""
        p = getattr(self, "_detail_bot", None)
        if p is None:
            return
        name = next((a.name for a in self._accounts if a.id == account_id), "")
        self._ensure_panels(account_id, name)
        q = next((q for q in self.panels[account_id] if q.cfg_path == p.cfg_path), None)
        if q is None:
            return
        if q.running:
            q.stop()
        else:
            q.start()
        QTimer.singleShot(800, lambda: self.bots_page.isVisible() and self.bots_page.shown is not None
                          and self.bots_page.show_detail(self.bots_page.shown, self._bot_detail(p), scroll=False))

    def _row_bot(self, i: int, action: str) -> None:
        bots = self._bot_list()
        if 0 <= i < len(bots):
            getattr(bots[i], action)()  # each asks to confirm first

    def _bot_list(self) -> list[BotPanel]:
        """My bots: the account being viewed first, then the others the app has open; running ones first."""
        order = [self.view_id] + [a for a in self.panels if a != self.view_id]
        return [p for a in order for p in sorted(self.panels.get(a, []), key=lambda p: not p.running)]

    def current_bot(self) -> BotPanel | None:
        """The bot whose tab is showing (None on the All bots tab)."""
        if self.view_id not in self.views:
            return None
        w = self.bot_tabs.currentWidget()
        return w if isinstance(w, BotPanel) else None

    def _bot_tab_changed(self, _i: int = 0):
        p = self.current_bot()
        if p is not None:
            self.settings_stack.setCurrentWidget(p.settings_scroll)
            self.replay_stack.setCurrentWidget(p.replay_page)
            self.bottom.setTabText(2, f"Settings · {p.name}")
            self.bottom.setTabText(3, f"Replay · {p.name}")

    # --- background jobs (check, bracket test, replay) ---------------------------------------
    def _job(self, fn, callback, bot: str | None = None):
        def work():
            set_thread_bot(bot)
            try:
                res, err = fn(), None
            except Exception as e:  # noqa: BLE001 - shown to the user
                res, err = None, e
                if not isinstance(e, ToolError):
                    log.exception("job failed: %s", e)
            self.job_done.emit(callback, res, err)
        threading.Thread(target=work, daemon=True).start()

    def _credentials(self) -> tuple[str, str] | None:
        try:
            creds = get_credentials()
        except Exception as e:  # noqa: BLE001
            QMessageBox.critical(self, "Keychain", f"Could not read the Keychain: {e}")
            return None
        if not creds:
            self.change_login()
            creds = get_credentials()
        return creds

    # --- stop / flatten everything, and phone alerts -------------------------------------------
    def stop_all(self, ask: bool = False) -> list[BotPanel]:
        running = [p for p in self.all_panels() if p.running]
        if ask and running and QMessageBox.question(
                self, "Stop all bots?", f"Stop {len(running)} running bot{'s' if len(running) != 1 else ''}?\n\n"
                "Open trades keep their stop and target at Topstep.") != QMessageBox.Yes:
            return []
        for p in running:
            p.stop()
        if running:
            log.warning("all bots stopped (%d)", len(running))
        return running

    def flatten_all(self, ask: bool = False) -> tuple[list[str], int]:
        """Close every bot's own open trade at market and stop every bot. Returns (closed trades, bots stopped)."""
        running = [p for p in self.all_panels() if p.running]
        open_trades = [p for p in running if p.engine and p.engine.trade]
        if ask:
            if not running:
                QMessageBox.information(self, "Flatten all", "No bots are running.")
                return [], 0
            lines = "\n".join(f"• {p.label}: {p.engine.trade.side.value} {p.engine.trade.size}" for p in open_trades)
            ok = QMessageBox.question(
                self, "Flatten all and stop?",
                (f"Close these trades at market:\n{lines}\n\n" if open_trades else "No bot has an open trade.\n\n")
                + f"Then stop all {len(running)} running bot{'s' if len(running) != 1 else ''}. Trades the bots "
                "didn't place (other bots, manual trades) are not touched.",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)  # Enter / a stray click = No
            if ok != QMessageBox.Yes:
                return [], 0
        closed = []
        for p in open_trades:
            t = p.engine.trade
            closed.append(f"{p.label}: {t.side.value} {t.size}")
            p.engine.request_close()
        for p in running:
            p.stop()
        log.warning("FLATTEN ALL: closing %d trade(s), stopping %d bot(s)", len(closed), len(running))
        return closed, len(running)

    def status_text(self) -> str:
        running = [p for p in self.all_panels() if p.running]
        if not running:
            return f"{APP_NAME}: no bots running."
        lines = [f"{APP_NAME}: {len(running)} bot{'s' if len(running) != 1 else ''} running"]
        for p in running:
            snap = p.snapshot() or {}
            t = p.engine.trade if p.engine else None
            pos = f"{'long' if t.side.value == 'buy' else 'short'} {t.size} @ {t.entry:,.2f}" if t else "flat"
            day = snap.get("day_pnl")
            lines.append(f"• {p.label} ({p.account_name or '?'}, {'real orders' if p.engine.mode == 'practice' else 'paper'}): "
                         f"{pos}" + (f", account today {'-' if day < 0 else '+'}${abs(day):,.2f}" if day is not None else ""))
        return "\n".join(lines)

    def remote(self, cmd: str):
        """A command texted to the Telegram bot (runs on the window's thread)."""
        n = phone.current()
        log.info("phone command: %s", cmd)
        if cmd == "status":
            n.reply(self.status_text())
        elif cmd == "stop":
            stopped = self.stop_all()
            n.reply(f"⏹ Stopped {len(stopped)} bot{'s' if len(stopped) != 1 else ''}. Open trades keep their "
                    "stop and target at Topstep." if stopped else "No bots were running.")
        elif cmd == "confirm_flatten":
            running = [p for p in self.all_panels() if p.running]
            trades = [f"• {p.label}: {p.engine.trade.side.value} {p.engine.trade.size}" for p in running
                      if p.engine and p.engine.trade]
            n.reply(("Close these at market and stop all bots?\n" + "\n".join(trades) if trades else
                     f"No bot has an open trade. Stop all {len(running)} running bots?") +
                    f"\n\nReply YES within {phone.CONFIRM_SECONDS} seconds.")
        elif cmd == "flatten":
            closed, stopped = self.flatten_all()
            n.reply(f"🛑 Flatten sent: closing {len(closed)} trade{'s' if len(closed) != 1 else ''}, stopped "
                    f"{stopped} bot{'s' if stopped != 1 else ''}. You'll get a message as each trade closes.")
        else:
            n.reply(phone.HELP)

    def setup_phone_alerts(self):
        """(Re)start Telegram alerts and commands from config.toml and the Keychain."""
        if self.listener:
            self.listener.stop()
            self.listener = None
        nc = self.main_cfg.notify
        token = phone.get_token()
        phone.configure(phone.Notifier(token, nc.telegram_chat_id, nc.trades, nc.problems, nc.paper))
        if token and nc.telegram_chat_id:
            self.listener = phone.CommandListener(token, nc.telegram_chat_id, self.remote_command.emit)
            self.listener.start()

    def phone_alerts(self):
        dlg = PhoneAlertsDialog(self.main_cfg, phone.get_token(), self)
        if not dlg.exec():
            return
        try:
            phone.save_token(dlg.token.text().strip())
        except Exception as e:  # noqa: BLE001
            QMessageBox.critical(self, "Keychain", f"Could not save the token: {e}")
            return
        nc = self.main_cfg.notify
        nc.telegram_chat_id = dlg.chat.text().strip()
        nc.trades, nc.problems, nc.paper = (dlg.trades.isChecked(), dlg.problems.isChecked(),
                                            dlg.paper.isChecked())
        for key in ("telegram_chat_id", "trades", "problems", "paper"):
            save_setting(self.main_path, "notify", key, getattr(nc, key))
        self.setup_phone_alerts()
        log.info("phone alerts %s", "on" if phone.current().enabled else "off")

    def open_help(self, topic: str | None = None):
        w = getattr(self, "help_window", None)
        if w is None:
            self.help_window = w = HelpWindow(self.help_page)  # a page in the main window
            self.help_page.layout().addWidget(w)
            self.version_label = QLabel(f"{APP_NAME} v{updater.app_version()}")
            self.version_label.setObjectName("muted")
            self.update_btn = QPushButton("Check for updates")
            self.update_btn.clicked.connect(lambda: self.check_updates(manual=True))
            w.footer.addWidget(self.version_label)
            w.footer.addWidget(self.update_btn)
            self._show_update_state()
        if topic:
            w.show_topic(topic)
        self._select_page("help")

    # --- app updates ----------------------------------------------------------------------------
    def _build_update_banner(self) -> QFrame:
        self.release = None
        bar = QFrame()
        bar.setObjectName("box")
        bar.setStyleSheet(f"QFrame#box {{ background: rgba(111,155,255,0.10); border: 1px solid {theme.ACCENT}; "
                          "border-radius: 10px; }")
        lay = QHBoxLayout(bar)
        lay.setContentsMargins(14, 8, 10, 8)
        self.update_text = QLabel()
        self.update_text.setWordWrap(True)
        now = QPushButton("Update now")
        now.setObjectName("start")
        now.clicked.connect(self.update_now)
        later = QPushButton("Later")
        later.setObjectName("flat")
        lay.addWidget(self.update_text, 1)
        lay.addWidget(now)
        lay.addWidget(later)
        wrap = QWidget()
        wl = QVBoxLayout(wrap)
        wl.setContentsMargins(16, 8, 16, 0)
        wl.addWidget(bar)
        wrap.hide()
        self.update_banner = wrap
        later.clicked.connect(wrap.hide)
        return wrap

    # --- licence ----------------------------------------------------------------------------------------
    @property
    def licence(self) -> "lic.Licence":
        if getattr(self, "_licence", None) is None:
            self._licence = lic.Licence(self.root / "licence.json")
            import orb_bot.engine as eng
            eng.ENTRY_GATE = self._licence.may_trade
        return self._licence

    def _start_licence_checks(self) -> None:
        """At start-up, then whenever the daily check is due (looked at hourly). Only in packaged builds."""
        if not self.licence.enforce:
            return
        QTimer.singleShot(5_000, lambda: self.licence_check(quiet=True))
        self.licence_timer = QTimer(self)
        self.licence_timer.timeout.connect(lambda: self.licence.check_due() and self.licence_check(quiet=True))
        self.licence_timer.start(3600 * 1000)

    def _licence_text(self) -> None:
        if getattr(self, "licence_status", None) is not None:
            self.licence_status.setText(self.licence.status().message)

    def licence_check(self, quiet: bool = False) -> None:
        def done(st, err):
            self._licence_text()
            if st is not None and not st.may_trade:
                log.warning("licence: %s", st.message)
            if not quiet:
                QMessageBox.information(self, "Licence", (st.message if st else str(err)))
        self._job(lambda: self.licence.check(updater.app_version()), done)

    def licence_activate(self) -> None:
        key = self.licence_key.text().strip()
        if not key:
            QMessageBox.information(self, "Licence", "Paste the licence key from your Whop receipt first.")
            return

        def done(st, err):
            self._licence_text()
            if err is not None:
                QMessageBox.warning(self, "Licence", str(err) if isinstance(err, lic.LicenceError)
                                    else f"Couldn't reach the licence server: {err}")
            else:
                QMessageBox.information(self, "Licence", st.message)
        self._job(lambda: self.licence.activate(key, updater.app_version()), done)

    def licence_deactivate(self) -> None:
        if QMessageBox.question(self, "Deactivate this computer",
                                "Free your licence key so you can use it on another computer? Bots here stop "
                                "taking new trades until a key is entered again.",
                                QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
            return

        def done(_r, err):
            self._licence_text()
            QMessageBox.information(self, "Licence", f"Not deactivated: {err}" if err is not None else
                                    "This computer is deactivated. You can enter the key on another one.")
        self._job(self.licence.deactivate, done)

    def _update_url(self) -> str:
        return self.main_cfg.updates.url or updater.DEFAULT_URL

    def _start_update_checks(self) -> None:
        if not self.main_cfg.updates.check or not self._update_url():
            return
        QTimer.singleShot(10_000, self.check_updates)
        self.update_timer = QTimer(self)
        self.update_timer.timeout.connect(self.check_updates)
        self.update_timer.start(6 * 3600 * 1000)

    def check_updates(self, manual: bool = False) -> None:
        """Ask the release address for a newer version. Quiet unless there is one (or you asked)."""
        if manual and not self._update_url():
            QMessageBox.information(self, "Updates", "Updates aren't switched on for this copy yet (no update "
                                    "address). New versions come as a zip for now.")
            return
        current = updater.app_version()

        def done(rel, err):
            if err:
                log.info("update check failed: %s", err)
                if manual:
                    QMessageBox.warning(self, "Updates", f"Couldn't check for updates:\n\n{err}")
            elif rel is None:
                if manual:
                    QMessageBox.information(self, "Updates", f"You're on the latest version (v{current}).")
            else:
                self.release = rel
                log.info("update available: v%s", rel.version)
                self.update_text.setText(f"<b>{APP_NAME} v{rel.version}</b> is ready (you have v{current})."
                                         + (f"  {rel.notes}" if rel.notes else ""))
                self.update_banner.show()
                if manual:
                    self.update_now()
            self._show_update_state()

        self._job(lambda: updater.check(self._update_url(), current), done)

    def _show_update_state(self) -> None:
        if getattr(self, "update_btn", None) is None:
            return
        rel = self.release
        self.update_btn.setText(f"Update to v{rel.version}" if rel else "Check for updates")
        self.version_label.setText(f"{APP_NAME} v{updater.app_version()}")

    def update_now(self) -> None:
        rel = self.release
        if rel is None:
            return self.check_updates(manual=True)
        if not updater.can_update():
            QMessageBox.information(self, "Update", "This copy of the app can't update itself. Download "
                                    f"v{rel.version} from your account page and install it.")
            return
        running = [p for p in self.all_panels() if p.running]
        if running:
            QMessageBox.information(
                self, "Update", f"Stop your bots first ({', '.join(p.label for p in running)}), then press "
                "Update now. Updating restarts the app, so it never happens while a bot is trading.")
            return
        ok = QMessageBox.question(self, "Update", f"Update to v{rel.version} now? {APP_NAME} downloads it, "
                                  "checks it's a genuine release, installs it and restarts (about a minute). "
                                  "Your settings, bots and logs stay as they are.")
        if ok != QMessageBox.Yes:
            return
        self.update_text.setText(f"Downloading and installing v{rel.version}…")

        def work():
            data = updater.download(rel)
            files = updater.install(data, updater.APP_ROOT)
            updater.refresh_packages(updater.APP_ROOT)
            return files

        def done(files, err):
            if err:
                QMessageBox.warning(self, "Update", f"The update didn't install:\n\n{err}\n\nNothing was changed "
                                    "if the download didn't check out; you can keep using this version.")
                self.update_text.setText(f"<b>{APP_NAME} v{rel.version}</b> is ready.")
                return
            log.info("updated to v%s (%d files); restarting", rel.version, len(files))
            QMessageBox.information(self, "Update", f"Updated to v{rel.version}. {APP_NAME} will now restart.")
            updater.restart()
            QApplication.quit()

        self._job(work, done)

    # --- performance ----------------------------------------------------------------------------
    def _build_performance(self) -> None:
        """Built once, as a page of the main window (the first switch to it used to flash while it was made)."""
        if getattr(self, "perf_window", None) is not None:
            return
        self.perf_window = PerformanceWindow(
            self._perf_accounts, self._perf_fetch, self._job, self.main_cfg.log_dir / "fills.csv",
            self.main_cfg.timezone, self.view_id, parent=self.perf_page, balance=self._account_balance,
            bars=self._trade_bars, layout_file=self.main_cfg.log_dir / "performance-layout.json")
        self.perf_page.layout().addWidget(self.perf_window)

    def open_performance(self):
        """The Performance page, on the account being viewed."""
        if getattr(self, "perf_window", None) is None:
            self._build_performance()
        else:
            self.perf_window.reload_accounts(self.view_id)
        self._select_page("performance")

    def _add_script_bot(self, path: Path, name: str, script: Path, minutes: int, symbol: str = "") -> None:
        """A bot that runs the user's own Python strategy. The file is copied into strategies/."""
        from .scripting import ScriptError, load_strategy
        try:
            st = load_strategy(script)
            minutes = st.bar_minutes or minutes  # a script that needs a timeframe gets it
        except ScriptError as e:
            QMessageBox.warning(self, "Add bot", f"That script can't be used yet:\n\n{e}")
            path.unlink(missing_ok=True)
            return
        folder = self.root / "strategies"
        folder.mkdir(exist_ok=True)
        dest = folder / script.name
        if script.resolve() != dest.resolve():
            shutil.copy(script, dest)
        path.write_text(f'# {name}: your own Python strategy, added in the app.\nname = "{name}"\ntype = "script"\n\n'
                        f'[script]\nfile = "strategies/{dest.name}"\nsymbol = "{symbol}"\n\n[strategy]\nbar_minutes = {minutes}\n\n'
                        + _script_risk_section(st.params) + "\n[safety]\nmax_daily_loss = 1000\n")
        self.bot_files.append(path)
        for acct_id in self.views:
            ps = self.panels[acct_id]
            self._add_panel(acct_id, ps[0].account_name if ps else "", path)
        self.bot_tabs.setCurrentWidget(self.bots[-1])
        log.info("added script bot %s (%s, %s, %d-minute bars)", name, dest.name, symbol or "main contract", minutes)
        QMessageBox.information(
            self, "Bot added",
            f"{name} runs strategies/{dest.name} on {minutes}-minute bars, on every account.\n\n"
            "1. Set its risk on the right (max 5 contracts and a $1,000 daily loss limit to start).\n"
            "2. Try it in the Replay tab on past days.\n3. Then ••• → Test run, or Start for real orders.")

    def _make_chart(self):
        """The chart pane: TradingView's Lightweight Charts in a web view, or, where the Mac stops that (or the
        web engine isn't set up), the same chart drawn by the app. Once the web one fails it isn't tried again."""
        native = (not QApplication.testAttribute(Qt.AA_ShareOpenGLContexts)
                  or bool(self._ui_state().get("native_chart")) or os.environ.get("HELM_NATIVE_CHART") == "1")
        try:
            from .chart_view import ChartPanel
            return ChartPanel(self._perf_accounts, self._chart_symbols, self._chart_fetch, self._chart_lines,
                              self._job, self.main_cfg.log_dir / "fills.csv", self.main_cfg.timezone,
                              self.main_cfg.broker.account_id, native=native,
                              use_native=lambda: self._save_ui_state(native_chart=True), ranges=self._chart_ranges,
                              open_trades=self._chart_open_trades)
        except Exception as e:  # noqa: BLE001
            log.warning("chart not available: %s", e)
            return None

    def open_chart(self):
        """Bots → Show or hide chart: goes to the Chart page and shows or hides the chart pane."""
        if self.chart is None:
            QMessageBox.information(self, "Chart", "The chart needs Qt's web engine, which isn't installed. "
                                    "In Terminal: cd ~/orb-bot && source .venv/bin/activate && pip install PySide6")
            return
        on_page = self.pages.currentIndex() == 0
        self._select_page("chart")
        if on_page or not self.chart.isVisible():
            self.chart.setVisible(not self.chart.isVisible())

    def _chart_symbols(self) -> list[str]:
        seen = [self.main_cfg.broker.symbol]
        for p in self.all_panels():
            sym = (p.cfg.alerts.symbol if p.is_alerts else "") or p.cfg.broker.symbol
            if sym and sym not in seen:
                seen.append(sym)
        return seen

    def _chart_open_trades(self, account_id: int | None, contract_name: str) -> list[dict]:
        """Running bots' open trades on this contract, for the chart's live trade boxes."""
        out = []
        for p in self.panels.get(account_id, []):
            snap = p.snapshot() if p.running else None
            t = snap.get("trade") if snap and snap.get("contract") == contract_name else None
            if t and t.get("filled") and t.get("at") is not None:
                out.append(dict(t, bot=p.name))
        return out

    def _chart_ranges(self, account_id: int | None, contract_name: str, days) -> list[tuple]:
        """Each ORB bot's switched-on sessions, and TV alerts bots with a range start set, for the chart's days:
        (label, range start, range end, how long the range stays drawn)."""
        out = []
        for p in self.panels.get(account_id, []):
            c = p.cfg
            sym = (c.alerts.symbol if p.is_alerts else "") or c.broker.symbol
            if not sym or not contract_name.startswith(sym) or len(contract_name) - len(sym) > 3:
                continue
            for day in days:
                if p.is_alerts:
                    if not c.alerts.range_start:
                        continue
                    try:
                        hh, mm = (int(x) for x in c.alerts.range_start.split(":"))
                    except ValueError:
                        continue
                    start = datetime.combine(day, time(hh, mm), c.timezone)
                    end = start + timedelta(minutes=c.alerts.range_minutes)
                    out.append((p.name, start, end, end + timedelta(hours=2)))
                elif not p.is_script:
                    for s in c.sessions:
                        if s.enabled:
                            start, end = session_window(c, s, datetime.combine(day, time(12, 0), session_tz(c, s)))
                            hours = s.breakout_window_hours or 4.0
                            out.append((f"{p.name} {s.name.upper()}", start, end, end + timedelta(hours=hours)))
        return sorted(set(out), key=lambda w: w[1])

    def _chart_fetch(self, account_id: int, symbol: str, minutes: int, start, end, with_fills: bool, fills_from):
        """Runs in the background: (contract, bars, fills or None) from Topstep."""
        creds = get_credentials()
        if not creds:
            raise ToolError("No TopstepX login saved. Use Account → Change TopstepX login.")
        cfg = copy.deepcopy(self.main_cfg.broker)
        cfg.symbol = symbol
        b = ProjectXBroker(cfg, *creds)
        b.account_id = account_id
        contract = b.get_contract()
        bars = b.get_historical_bars(start, end, minutes, partial=True)
        fills = b.get_fills(fills_from) if with_fills else None
        return contract, bars, fills

    def _chart_lines(self, account_id: int | None, contract_name: str) -> list[dict]:
        """The open trades' entry, stop and target, and opening ranges being built or watched."""
        out = []
        for p in self.panels.get(account_id, []):
            snap = p.snapshot() if p.running else None
            if not snap or snap.get("contract") != contract_name:
                continue
            t = snap.get("trade")
            if t and t.get("filled"):
                who = p.name
                out += [{"price": t["entry"], "color": theme.TEXT_2, "title": f"{who} entry", "style": 0},
                        {"price": t["stop"], "color": theme.DOWN, "title": f"{who} stop", "width": 2},
                        {"price": t["target"], "color": theme.UP, "title": f"{who} target", "width": 2}]
            for r in snap.get("sessions", []):
                if r.get("high") is not None and r.get("low") is not None:
                    out += [{"price": r["high"], "color": theme.WARN, "title": f"{r['name']} high"},
                            {"price": r["low"], "color": theme.WARN, "title": f"{r['name']} low"}]
        return out

    def _perf_accounts(self) -> list[tuple[int, str]]:
        if self._accounts:
            return [(a.id, a.name) for a in self._accounts]
        b = self.main_cfg.broker
        return [(b.account_id, b.account_name or f"Account {b.account_id}")] if b.account_id else []

    def _account_balance(self, account_id: int) -> float | None:
        """Now: a running bot's last look at the balance, else the account list's."""
        for p in self.panels.get(account_id, []):
            snap = p.snapshot() if p.running else None
            if snap and snap.get("balance") is not None:
                return snap["balance"]
        return next((a.balance for a in self._accounts if a.id == account_id), None)

    def _trade_bars(self, contract_id: str, start, end, minutes: int):
        """Runs in the background: the candles around one trade, for its detail window."""
        creds = get_credentials()
        if not creds:
            raise ToolError("No TopstepX login saved.")
        b = ProjectXBroker(copy.deepcopy(self.main_cfg.broker), *creds)
        b.contract = b.contract_by_id(contract_id)
        return b.get_historical_bars(start, end, minutes, partial=True)

    def _perf_fetch(self, account_id: int, since):
        """Runs in the background: this account's fills from Topstep."""
        creds = get_credentials()
        if not creds:
            raise ToolError("No TopstepX login saved. Use Account → Change TopstepX login.")
        b = ProjectXBroker(copy.deepcopy(self.main_cfg.broker), *creds)
        b.account_id = account_id
        return b.get_fills(since)

    def _broker(self) -> ProjectXBroker | None:
        """A connection for one-off jobs, on the account being viewed."""
        creds = self._credentials()
        return ProjectXBroker(self.main_cfg.broker, *creds) if creds else None

    def check_connection(self):
        b = self._broker()
        if not b:
            return
        log.info("checking the TopstepX connection…")
        self._job(lambda: (b, check(b, self.main_cfg)), self._check_done)

    def _check_done(self, res, err):
        if err:
            QMessageBox.warning(self, "Connection check", str(err))
            return
        b, r = res
        tz = self.main_cfg.timezone
        lines = [f"Logged in. Contract {r.contract.name}, tick {r.contract.tick_size} = ${r.contract.tick_value}.",
                 f"{r.recent_bars} one-minute bars in the last 3 days"
                 + (f", latest close {r.latest_close} at {r.latest.astimezone(tz):%a %H:%M}." if r.latest else "."),
                 f"Bracket test: {'passed (' + r.bracket_mode + ')' if r.bracket_mode else 'not run yet'}."]
        for line in lines:
            log.info(line)
        self._fill_account_combo(r.accounts)
        if self.view_id is None and r.selected:  # first check picked the Practice account
            self.view_account(r.selected.id, r.selected.name)
        dlg = QDialog(self)
        dlg.setWindowTitle("TopstepX connection")
        form = QFormLayout(dlg)
        form.addRow(QLabel("\n".join(lines)))
        combo = QComboBox()
        for a in r.accounts:
            combo.addItem(f"{a.name}   ${a.balance:,.2f}" + ("" if a.can_trade else "   (can't trade)"), a.id)
            if a.id == self.view_id:
                combo.setCurrentIndex(combo.count() - 1)
        form.addRow("Show account", combo)
        form.addRow(QLabel("Each account has its own Start/Stop and risk for every bot, and bots keep running\n"
                           "when you switch to another account. Practice accounts are always allowed; starting a\n"
                           "bot with real orders on any other account (e.g. a Combine) asks you to confirm it."))
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Close)
        buttons.accepted.connect(dlg.accept)
        buttons.rejected.connect(dlg.reject)
        form.addRow(buttons)
        if dlg.exec() and r.accounts:
            acct = r.accounts[combo.currentIndex()]
            if acct.id != self.view_id:
                self.view_account(acct.id, acct.name)
        self._show_account_cards()

    def _show_account_cards(self):
        """Account and Balance cards from the account list while no bot on this account is running."""
        if any(p.engine for p in self.bots):
            return
        acct = next((a for a in self._accounts if a.id == self.view_id), None)
        self.c_account.set(acct.name if acct else (self.main_cfg.broker.account_name or "–"))
        self.c_balance.set(money(acct.balance) if acct else "–")
        self.c_pnl.set("–")


    def run_bracket_test(self):
        if self.running_on(self.view_id):
            QMessageBox.information(self, "Bracket test", "Stop the bots on this account first.")
            return
        ok = QMessageBox.question(self, "Run bracket test?",
                                  "This BUYS 1 contract at market on the Practice account shown with a 40-tick stop "
                                  "and target, checks they landed on the right sides, then closes it.\n\n"
                                  "The contract must be flat on that account.")
        if ok != QMessageBox.Yes:
            return
        b = self._broker()
        if not b:
            return
        self._job(lambda: bracket_test(b, self.main_cfg), self._bracket_done)

    def _bracket_done(self, mode, err):
        if err:
            QMessageBox.warning(self, "Bracket test", str(err))
        else:
            for p in self.all_panels():
                p.refresh_broker()
            QMessageBox.information(self, "Bracket test", f"Passed ('{mode}' ticks). Real orders are unlocked.")

    def change_login(self):
        dlg = LoginDialog(self)
        if dlg.exec() and dlg.user.text().strip() and dlg.key.text().strip():
            save_credentials(dlg.user.text().strip(), dlg.key.text().strip())
            log.info("TopstepX login saved")

    # --- keep the Mac awake while any bot runs -------------------------------------------------------
    def bot_started(self):
        if sys.platform == "darwin" and self.keep_awake is None:
            self.keep_awake = subprocess.Popen(["caffeinate", "-i", "-w", str(os.getpid())])

    def bot_stopped(self):
        if self.keep_awake and not any(p.running for p in self.all_panels()):
            self.keep_awake.terminate()
            self.keep_awake = None
        self.refresh()

    def showEvent(self, event):
        super().showEvent(event)
        if not self._split_sized:  # first show: chart about half, bots a third, Activity the rest
            self._split_sized = True
            QTimer.singleShot(0, self._size_split)
            QTimer.singleShot(1500, self._build_performance)  # ready before the first switch to it
            self._start_update_checks()
            self._start_licence_checks()

    def _size_split(self) -> None:
        """The sizes you last dragged the dividers to (logs/ui-state.json), else chart half, bots a third."""
        saved = self._ui_state().get("split")
        if isinstance(saved, list) and len(saved) == self.split.count() and sum(saved) > 0:
            self.split.setSizes([int(x) for x in saved])
        else:
            h = max(self.split.height(), 600)
            parts = [0.5, 0.33, 0.17] if self.chart is not None else [0.66, 0.34]
            self.split.setSizes([int(h * f) for f in parts])
        self.split.splitterMoved.connect(lambda _pos, _i: self._save_ui_state(split=self.split.sizes()))

    def _ui_state(self) -> dict:
        try:
            return json.loads((self.main_cfg.log_dir / "ui-state.json").read_text())
        except (OSError, ValueError):
            return {}

    def _save_ui_state(self, **changes) -> None:
        state = self._ui_state()
        state.update(changes)
        try:
            self.main_cfg.log_dir.mkdir(parents=True, exist_ok=True)
            (self.main_cfg.log_dir / "ui-state.json").write_text(json.dumps(state))
        except OSError as e:
            log.debug("couldn't save window layout: %s", e)

    def closeEvent(self, event):
        running = [p for p in self.all_panels() if p.running]
        if running:
            names = ", ".join(p.label for p in running)
            ok = QMessageBox.question(self, f"Quit {APP_NAME}?",
                                      f"{names} {'is' if len(running) == 1 else 'are'} running. Quit and stop?\n\n"
                                      "Open trades keep their stop and target at Topstep.")
            if ok != QMessageBox.Yes:
                event.ignore()
                return
            for p in running:
                p.stop()
            for p in running:
                p.worker.join(timeout=8)
        if self.keep_awake:
            self.keep_awake.terminate()
        self.webhook.stop()
        if self.listener:
            self.listener.stop()
        logging.getLogger().removeHandler(self.problem_handler)
        event.accept()

    # --- refresh -----------------------------------------------------------------------------------
    def _append_log(self, line: str, level: int = logging.INFO):
        self.log_view.appendHtml(log_html(line, level))

    def refresh(self):
        snaps = {}
        for acct_id, ps in self.panels.items():
            tabs = self.views[acct_id]
            for p in ps:
                snap = p.snapshot()
                snaps[p] = snap
                if acct_id == self.view_id or p.running:
                    p.refresh(snap)
                i = tabs.indexOf(p)
                if tabs.tabText(i) != p.name:
                    tabs.setTabText(i, p.name)
                tabs.setTabIcon(i, theme.dot_icon(GREEN if p.running else theme.TEXT_3))

        if self.pages.currentWidget() is self.bots_page:
            self.bots_page.set_rows([
                bot_row(p.name, "TV alerts" if p.is_alerts else "Script" if p.is_script else "ORB",
                        (p.cfg.alerts.symbol if p.is_alerts and p.cfg.alerts.symbol else p.cfg.broker.symbol),
                        p.running, snaps.get(p), p.account_name or "–") for p in self._bot_list()])
        running = [p for p in self.all_panels() if p.running]
        accounts = {p.account_id for p in running}
        if any(p.is_alerts for p in running):
            self.webhook.tick()
        self._expiry_reminders()
        if running:
            set_pill(self.status, f"{len(running)} bot{'s' if len(running) != 1 else ''} running on "
                     f"{len(accounts)} account{'s' if len(accounts) != 1 else ''}", "run")
        else:
            set_pill(self.status, "No bots running", "off")
        # Keep the dropdown's "● n bots running" marks current (only rebuilt when they change).
        shown = [(self.account_combo.itemText(i), self.account_combo.itemData(i))
                 for i in range(self.account_combo.count())]
        if shown != self._combo_entries():
            self._fill_account_combo([])

        # Account cards for the account being viewed: a bot placing real orders wins, else the selected bot.
        view = self.bots
        live = [snaps[p] for p in view if snaps.get(p) and snaps[p]["mode"] == "practice"]
        current = self.current_bot() or (view[0] if view else None)
        acct = live[0] if live else (snaps.get(current) if current else None)
        if acct:
            self.c_account.set(acct["account"] or "–")
            self.c_balance.set(money(acct["balance"]))
            pnl = acct["day_pnl"]
            self.c_pnl.set(money(pnl, True) if pnl is not None else "–",
                           None if pnl is None else (GREEN if pnl >= 0 else RED))
        closed = [dict(t, bot=p.name) for p in view if snaps.get(p) for t in snaps[p]["closed"]]
        closed.sort(key=lambda t: t["time"])
        self._fill_trades(closed)

    def _pnl_broker(self):
        creds = get_credentials()
        return ProjectXBroker(copy.deepcopy(self.main_cfg.broker), *creds) if creds else None

    def _show_upl(self) -> None:
        if self.open_pnl.account_id != self.view_id:
            self.open_pnl.set_account(self.view_id)
        v = self.open_pnl.value()
        self.c_upl.set("–" if v is None else money(v), None if not v else (GREEN if v > 0 else RED))
        if not any(p.engine for p in self.bots):  # a running bot fills RP&L itself
            r = self.open_pnl.realised
            self.c_pnl.set("–" if r is None else money(r, True), None if r is None else (GREEN if r >= 0 else RED))

    def _expiry_reminders(self):
        """Once a day per bot: a log line and a Mac notification when its TradingView alert is about to expire."""
        today = datetime.now().date()
        seen = getattr(self, "_reminded", {})
        self._reminded = seen
        for p in self.all_panels():
            st = p.expiry_status()
            if not st or st[1] == "ok" or seen.get(p.cfg_path) == today:
                continue
            seen[p.cfg_path] = today
            log.warning("%s: %s", p.name, st[0])
            notify(APP_NAME, f"{p.name}: {st[0]}")

    def _fill_trades(self, closed: list[dict]):
        self.trades.setRowCount(len(closed))
        for i, t in enumerate(closed):
            vals = [t["bot"], t["time"], t.get("out") or "–", "Long" if t["side"] == "buy" else "Short",
                    str(t["size"]), f"{t['entry']:.2f}" if t["entry"] is not None else "–",
                    f"{t['exit']:.2f}" if t["exit"] is not None else "–", money(t["pnl"], True)]
            for j, v in enumerate(vals):
                it = QTableWidgetItem(v)
                if t.get("reason"):
                    it.setToolTip(f"Closed by {t['reason']}")
                if j == 7 and t["pnl"] is not None:
                    it.setForeground(QColor(GREEN if t["pnl"] >= 0 else RED))
                self.trades.setItem(i, j, it)


def main(argv: list[str] | None = None) -> None:
    root = Path.cwd()
    # The chart's web view needs these set before the app exists, or it can stay blank on a Mac.
    if sys.platform == "darwin":
        os.environ.setdefault("QTWEBENGINE_CHROMIUM_FLAGS", "--disable-gpu")
    QApplication.setAttribute(Qt.AA_ShareOpenGLContexts)
    try:
        import PySide6.QtWebEngineWidgets  # noqa: F401
    except ImportError:
        pass
    app = QApplication(sys.argv if argv is None else argv)
    app.setApplicationName(APP_NAME)
    app.setWindowIcon(theme.app_icon())
    theme.apply(app)
    cfg_path = root / "config.toml"
    log_dir = load_config(cfg_path).log_dir if cfg_path.exists() else Path("logs")
    setup_logging(log_dir, False)
    win = MainWindow(root)
    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
