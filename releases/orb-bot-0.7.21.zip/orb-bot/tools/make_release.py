"""Make a signed release: the zip users download and latest.json, the file the app checks.

    python tools/make_release.py --key /path/to/signing.key --base-url https://…/download --out ../releases
                                 --notes "What's new in one line"

Upload both files to the base URL's folder (the zip's URL is <base-url>/<zip name>). The key never leaves
the release machine; the app only knows its public half (orb_bot/updater.py PUBLIC_KEY)."""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import tomllib
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from orb_bot import ed25519, updater  # noqa: E402

SKIP_DIRS = {"__pycache__", ".pytest_cache", ".venv", "bots", "logs", ".git"}
SKIP_TOP = {"config.toml", "licence.json"}


def files(root: Path):
    for p in sorted(root.rglob("*")):
        rel = p.relative_to(root)
        if p.is_dir() or any(part in SKIP_DIRS or part.endswith(".egg-info") for part in rel.parts):
            continue
        if p.suffix == ".pyc" or (len(rel.parts) == 1 and (rel.name in SKIP_TOP or rel.suffix == ".csv")):
            continue
        yield p, rel


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--key", required=True)
    ap.add_argument("--base-url", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--notes", default="")
    a = ap.parse_args()
    version = tomllib.loads((ROOT / "pyproject.toml").read_text())["project"]["version"]
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    name = f"orb-bot-{version}.zip"
    zpath = out / name
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for p, rel in files(ROOT):
            z.write(p, f"{updater.TOP}/{rel.as_posix()}")
    data = zpath.read_bytes()
    sha = hashlib.sha256(data).hexdigest()
    secret = bytes.fromhex(Path(a.key).read_text().strip())
    if ed25519.public_key(secret) != updater.PUBLIC_KEY:
        sys.exit("that key doesn't match the app's PUBLIC_KEY")
    sig = ed25519.sign(secret, updater.signed_message(version, sha)).hex()
    manifest = {"version": version, "url": f"{a.base_url.rstrip('/')}/{name}", "sha256": sha, "notes": a.notes,
                "signature": sig}
    updater.parse_manifest(manifest)  # the app's own check, before anything is uploaded
    (out / "latest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(f"{zpath} ({len(data):,} bytes)\n{out / 'latest.json'}")


if __name__ == "__main__":
    main()
