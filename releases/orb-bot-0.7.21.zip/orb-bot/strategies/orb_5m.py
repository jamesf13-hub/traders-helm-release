"""ORB 5M: opening range breakout on five-minute bars, ASIA and NY AM sessions. For James's own use only.

MNQ five-minute bars, New York times:
  ASIA:  range 01:00-01:15, entries until 03:45, anything still open is closed at 06:05.
  NY AM: range 09:15-09:30, entries until 12:00, closed at 12:05.
  A bar that closes beyond the range in its own colour is the signal (with filters: ASIA needs
  a trending DMI and a close under 45% of the range beyond it; NY AM checks the bar's body against VWAP
  momentum, skips the 09:45 bar and closes 40-60% of the range beyond).
  Stop: ASIA at the other side of the range, NY AM at the signal bar's low/high. Target 0.3 x the risk.
  Size: risk $ / (stop points x $2), rounded down, at most max contracts. Two trades a session at most.

session = "ASIA", "NYAM" or "BOTH". The logic is in orb_bot/orb_5m.py.
"""
import logging
from datetime import timezone

from orb_bot import orb_5m as ac
from orb_bot.scripting import Strategy

log = logging.getLogger("orb_5m")


class Orb5M(Strategy):
    name = "ORB 5M"
    symbol = "MNQ"
    bar_minutes = 5
    history = 30
    params = {"session": "BOTH", "risk_dollars": 500.0, "reward_risk": 0.3, "max_contracts": 20}

    def on_start(self):
        which = str(self.p.session).upper().replace(" ", "")
        sessions = (ac.ASIA, ac.NYAM) if which == "BOTH" else ((ac.NYAM,) if which in ("NYAM", "NY") else (ac.ASIA,))
        rr = float(self.p.reward_risk)
        self.core = ac.Orb5M(ac.Settings(sessions=sessions, risk_dollars=float(self.p.risk_dollars), ny_rr=rr,
                                             asia_rr=rr, max_contracts=int(self.p.max_contracts)), log=log.info)
        self._forced = False
        self._closed_seen = 0

    def on_bar(self, bar):
        core = self.core
        # what happened at Topstep since the last bar
        if core.pending is not None:
            a = core.pending
            if self.position * a.side > 0:
                core.filled(a.side, abs(self.position))
            elif self.trades_closed > self._closed_seen:
                core.filled(a.side, a.qty)  # filled and already out by its stop or target within the bar
            else:
                core.entry_failed()
        self._closed_seen = self.trades_closed
        if core.position != 0 and self.position == 0:
            core.closed(by_bracket=not self._forced)
            self._forced = False
        open_et = bar.time.astimezone(ac_tz()).replace(tzinfo=None)
        a = core.on_bar(ac.Bar(open_et, bar.open, bar.high, bar.low, bar.close, bar.volume))
        if a is None or not self.live:
            if a is not None and a.kind == "enter":
                core.entry_failed()  # catching up on past bars: nothing was traded
            return
        if a.kind == "flatten":
            if self.position != 0:
                self._forced = True
                self.close(a.reason)
            return
        if a.reversal or self.position != 0:
            # NinjaTrader reverses in one order; here the open trade is closed and the new one skipped
            log.info("ORB 5M: %s signal while in a trade: closing the trade, not reversing", a.reason)
            self._forced = True
            self.close(a.reason)
            core.entry_failed()
            return
        order = self.buy if a.side > 0 else self.sell
        order(stop=a.stop, target=a.target, contracts=a.qty, reason=f"ORB 5M {a.reason}")


def ac_tz():
    from zoneinfo import ZoneInfo
    return ZoneInfo("America/New_York")
