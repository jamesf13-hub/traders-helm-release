# Traders Helm (formerly ORB Bot; personal use, Mac)

*Automated trading, you at the helm.*

Connects straight to your TopstepX account, builds the NQ/MNQ opening range, and places each entry with its stop and target attached at Topstep. No TradingView, no PickMyTrade.

The strategy is a port of your Pine Script **"My ORB PMT"**, rule for rule:
- Sessions 1, 2 and 3 with their start times in Brisbane time, except Session 3, which follows New York time (09:15 NY), so it moves with US daylight saving.
- Range lock, breakout window, first trade plus one opposite-side flip.
- Min % close beyond the range, candle-based stop, body and exhaustion filters.
- RR first/flip, risk % sizing (at least 1 contract, capped at max contracts), Prop Firm Passer.
- Bot-only extras: fixed $ risk per trade, and a daily loss limit that also cuts size so one stop-out can't breach it.

All the inputs from the script are in `config.toml` under the same names.

**Known differences from TradingView**
- A trade whose stop or target would be less than 1 tick from entry is skipped, because Topstep can't hold a 0-tick bracket. TradingView would take it.
- On live trades the stop and target are placed in whole ticks from the actual fill price. TradingView uses the exact signal-bar close.
- Replay and paper mode fill exactly like TradingView's strategy tester (entry at bar close; if the stop and target are both inside one bar, the end nearer the open is assumed to hit first).

## The app

The window uses the dark "Desk" look (orb_bot/theme.py, fonts: IBM Plex, SIL Open Font License, bundled in orb_bot/assets/fonts). The product name is set once in orb_bot/brand.py.

`orb-bot app` opens a window with:
- Start/Stop (Start always places real orders; ••• → Test run runs once on paper)
- account, balance and today's P&L
- each session's on/off switch, range and status
- the current trade with a **Close now** button
- the live log, today's trades (in and out time to the second, side, size, prices, P&L), and a Settings tab with every script input
- a **Replay** tab: pick dates, press Run replay, see the trade list and totals (also saved to replay-trades.csv)
- an **Account** menu: check the connection and choose the account, run the bracket test, change the TopstepX login

**Several bots.** Press **Add bot** to run another bot, for example a 1-hour version with different settings. It starts as a copy of an existing bot; pick its chart timeframe and name, then set its sessions in its Settings tab. Each bot has its own tab, sessions, risk and Start/Stop, its name on every log line and trade, and only manages its own orders. The first bot's settings are in config.toml; added bots are in the bots folder.

**Several accounts.** The **Account** dropdown at the top picks which account you're looking at. Every account has its own copy of every bot, with its own Start/Stop, risk, daily loss limit and session switches. Switching the dropdown never stops anything: bots keep running on the other accounts, and the dropdown shows "● 2 bots running" next to each account. So ORB M5 can risk 1% on the Practice account and $500 on the Combine at the same time. The strategy settings (Settings tab) are shared by all accounts and can only be changed while that bot is stopped everywhere. Starting real orders on an account that isn't Practice (e.g. a Combine) asks you to confirm once.

**TradingView alerts (replaces PickMyTrade).** Add bot → Type "TradingView alerts" makes a bot that trades whatever a TradingView script's alerts say, including invite-only scripts you don't have the code for. When the entry alert arrives, the bot places the order at Topstep with its stop and target already attached, so exits fill at Topstep with no TradingView delay. The script's later exit alert is then ignored by default (Settings → Script's exit alerts can switch that to "close if still open").
- Stop and target: set in the bot's Settings tab (stop in ticks, target as RR × stop or in ticks). If the script plots its stop and target lines, the alert message can send their exact prices as `"stop"` and `"target"` instead. For a script that sizes each trade to a fixed $ risk (e.g. $500), set "Script's $ risk per trade" and an alert without a stop price gets a stop in the middle of the range that fits TradingView's size: between risk ÷ (contracts + 1) and risk ÷ contracts per contract. (Use it for a script whose entry alert sends "null" for its stop.) Set "Script's opening range start" (e.g. 15:00, 15 minutes, 5-minute chart) and the bot first tries the range edge and the breakout candle's high/low, using whichever fits TradingView's size; it waits up to 4 s for TopstepX's copy of the breakout candle. The bot's alert list says where each stop came from.
- Size per account: TradingView's contracts × a multiplier, or a fixed number of contracts, plus max contracts and the daily loss limit (a trade is cut so one stop-out can't breach it).
- Setup once: Bots → TradingView alerts setup… (free ngrok account for the public web address; TradingView needs two-factor authentication on to send webhooks). Then in TradingView edit the alert: paste the Webhook URL and the Alert message shown on the bot's tab (Copy buttons). Only alerts come in through ngrok; orders go from your Mac straight to Topstep.
- While the bot runs, the app re-checks every 5 minutes that TradingView can reach it (shown next to "TradingView position") and restarts ngrok if it stops.
- Each alert and what the bot did is listed on the bot's tab.
- Every closed trade (any bot, Paper or real orders) adds a row to `logs/fills.csv`: signal price and time, how long until the order went out, the fill price, and how many ticks better or worse each entry and exit filled. Open it in Excel or Numbers to compare against PickMyTrade. Alerts with the wrong key, for another market, or more than 60 s old are refused.
- **Left icon bar** (like TopstepX): Chart and bots, Performance, Settings (account, login, bracket test, add bot, TradingView setup, phone alerts) and Help at the bottom.
- **Performance** (left bar, or Bots → Performance…): TopstepX-style stats for one account or all of them, from Topstep's own fills after fees, with charts, a month calendar, P&L by bot and a trade list. Trades are tagged with the bot that placed them (via the entry order id in `logs/fills.csv`); anything else shows as "Manual / other".
- **Phone alerts (Telegram)** (Account → Phone alerts…): messages when trades open and close and when something needs attention; text the bot /status, /stop or /flatten. The token is kept in the Keychain; settings are under [notify] in config.toml. Only your own chat is obeyed.
- **Flatten all** (top bar): closes every bot's own open trade at market on every account and stops all bots. Bots → Stop all bots stops them and leaves trades with their brackets.
- **Chart**: on the main screen above the bots (drag the dividers to resize; Bots → Show or hide chart). Topstep's own bars drawn with TradingView's free Lightweight Charts library (bundled in orb_bot/assets/chart, Apache 2.0). Entries and exits from Topstep's fills are marked with the bot and P&L; running bots' open trade entry/stop/target and opening ranges are drawn as lines. Updates every 5 s; scroll left to load older candles back to the start of Topstep's history.
- **Your own strategy (Python)**: ＋ Add bot → Your own script. A .py file with a `Strategy` class (see strategies/template.py, ema_cross.py, simple_orb.py and orb_bot/scripting.py) decides when to buy, sell or close; the app sizes, limits and places the trades like any other bot. Test it in its Replay tab.
- **Help** (? button, Help menu): setup, accounts, TradingView, Telegram, safety, troubleshooting and FAQ, with search. Pages live in orb_bot/help_content.py.

**Fast bars (always on).** The app builds each bar from Topstep's live trade stream and acts about 0.5 s after the close, instead of waiting 1-3 s for Topstep's bar. If the stream wasn't connected for the whole bar, the bot uses Topstep's bar as before. Every live bar is checked against Topstep's own bar afterwards; differences are logged and counted in the bot's status line.

After the one-time `orb-bot setup` (login into the Keychain), you don't need Terminal: check, bracket test and replay are all in the app. The commands below still work.

Risk (% of balance or a fixed $ per trade), max contracts, the daily loss limit and the session switches can be changed while it runs. They apply from the next trade. The app keeps the Mac awake while the bot is running.

To get a double-click app, run this once:
```bash
cd ~/orb-bot && source .venv/bin/activate
orb-bot make-app
```
That creates **ORB Bot** in your home folder's Applications. Drag it to the Dock.

**Running alongside other bots.** The bot only manages its own orders. It tracks its entry and its own stop and target by order ID. Close now and the safety checks close only its own contracts and cancel only its own stop and target. With Auto OCO Brackets on, every entry gets its own stop and target, so another bot's contracts on the same instrument keep running when this bot's target fills. The daily loss limit counts the whole account, like Topstep's.

## Modes, safest first

| Command | What it does | Real orders? |
|---|---|---|
| `orb-bot check` | Logs in, lists accounts, finds the contract, tests market data and history depth | No |
| `orb-bot replay` | Runs the strategy over past days and writes a trade list (CSV) | No |
| `orb-bot run` | Runs live on real prices, **simulated** orders (paper) | No |
| `orb-bot bracket-test` | Buys 1 contract on **Practice**, checks the stop and target landed on the right sides, closes it | Practice only |
| `orb-bot run --mode practice` | Runs live on your **Practice** account | Practice only |

The bot refuses to place orders unless the bracket test has passed and the account is a Practice account (name starts with `PRAC`), or another account such as a Combine that you confirmed in the app when you first started a bot on it with real orders.

## One-time setup

**1. TopstepX side**
- Subscribe to API access: ProjectX dashboard → Subscriptions → ProjectX API Access, code `topstep` ($14.50/mo).
- Create an API key there and keep it in your password manager.
- In TopstepX, on your Practice account: **Settings → Risk Settings → Auto OCO Brackets → On** (you must be flat to change it). Without this, TopstepX rejects orders that carry a stop and target.

**2. Python** (skip if you did Phase 0 step 5)
```bash
brew install python@3.12
```

**3. Install the bot.** Unzip `orb-bot.zip` into your home folder, then:
```bash
cd ~/orb-bot
python3.12 -m venv .venv
source .venv/bin/activate
pip install -e .
```

**4. Save your login.** This puts your username and API key in the Mac Keychain and creates `config.toml`.
```bash
orb-bot setup
```

**5. Test the connection**
```bash
orb-bot check
```
It picks your first Practice account and writes its id into `config.toml`. Paste the output into the thread (it contains no secrets).

## Try it

Replay last month and compare with TradingView's List of Trades:
```bash
orb-bot replay --start 2026-09-01 --end 2026-10-08
open replay-trades.csv
```

Paper trade live (no orders):
```bash
orb-bot run
```

Practice account:
```bash
orb-bot bracket-test
caffeinate -i orb-bot run --mode practice
```
`caffeinate -i` stops your Mac sleeping while the bot runs. Stop the bot with **Ctrl+C**. If a trade is open when you stop, its stop and target stay active at Topstep.

## Every day after setup
```bash
cd ~/orb-bot && source .venv/bin/activate
caffeinate -i orb-bot run --mode practice
```

## Settings

Everything is in `config.toml`, using the same names as your Pine Script inputs:
- `[strategy] bar_minutes`: the chart timeframe (5, matching your 5m script).
- `[sessions.s1/s2/s3]`: each session's times and filters.
- `[risk]`: sizing and the Prop Firm Passer.
- `[safety]`: optional bot-only limits, all off by default so results match the script.
- `symbol`: the contract (`MNQ` by default; change to `NQ` when you're ready).

## Safety built in
- On start, it checks for open positions and orders. Stray orders with no position are cancelled. An existing position is adopted.
- Every poll, an open position must have a stop at Topstep. If it doesn't for two checks in a row, the bot closes the position.
- Breakouts that happened while the bot was off are logged, not traded.
- Optional extras in `[safety]` and `flatten_at` (all off by default): max daily loss, stop after daily profit, close at a set time.
- Leftover bracket orders are cancelled after a position closes.
- Logs are in `logs/orb-bot.log` (rotating). Send that file if something looks wrong.

## Tests
```bash
pip install -e '.[dev]' && pytest
```
