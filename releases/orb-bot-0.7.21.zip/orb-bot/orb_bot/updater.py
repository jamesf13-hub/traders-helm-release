"""App updates: Help → Check for updates / Update now, and a banner when a new version is out.

A release is a zip of the app plus a small manifest (latest.json) published at one web address:
    {"version": "0.7.14", "url": "https://…/orb-bot-0.7.14.zip", "sha256": "…", "notes": "…",
     "signature": "<hex>"}
The signature is Ed25519 over "traders-helm|<version>|<sha256>", made with our release key; the app only has
the public half (PUBLIC_KEY) and refuses anything that doesn't verify, so only our own releases install.

Installing copies the zip's files over the app folder. Your settings (config.toml), bots/, logs/ and your own
strategy files are never in a release zip, so they're left as they are. The app then restarts itself."""
from __future__ import annotations

import hashlib
import io
import logging
import subprocess
import sys
import zipfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath

from . import ed25519

log = logging.getLogger(__name__)

PUBLIC_KEY = bytes.fromhex("4ac22344e6cd1d7b04e8966425235fec96c2d578f264bcd7f7d04ace11a77751")
# Where releases are published. Set once hosting is chosen; [updates] url in config.toml overrides it.
DEFAULT_URL = "https://raw.githubusercontent.com/jamesf13-hub/traders-helm-release/main/latest.json"
APP_ROOT = Path(__file__).resolve().parent.parent  # the folder with pyproject.toml (~/orb-bot)
TOP = "orb-bot"  # the folder inside each release zip
KEEP = {"config.toml", "licence.json"}  # never replaced, even if a zip carried one
KEEP_DIRS = {"bots", "logs", ".venv"}
# files earlier versions shipped that have since been renamed or dropped (deleted on update)
REMOVED = ("strategies/agent_orb.py", "strategies/agent_orb_c.py", "orb_bot/agent_orb.py", "orb_bot/agent_orb_c.py",
           "orb_bot/assets/agent_orb_state.json")


class UpdateError(Exception):
    pass


@dataclass
class Release:
    version: str
    url: str
    sha256: str
    notes: str
    signature: str


def app_version(root: Path = APP_ROOT) -> str:
    """This copy's version, from pyproject.toml (right after an update, before pip has caught up)."""
    try:
        import tomllib
        return tomllib.loads((root / "pyproject.toml").read_text())["project"]["version"]
    except Exception:  # noqa: BLE001
        try:
            from importlib.metadata import version
            return version("orb-bot")
        except Exception:  # noqa: BLE001
            return "0"


def can_update(root: Path = APP_ROOT) -> bool:
    """Only a copy installed from the zip (with its pyproject.toml) updates itself; a packaged app downloads
    the new installer instead."""
    return (root / "pyproject.toml").exists() and (root / "orb_bot").is_dir()


def version_tuple(v: str) -> tuple[int, ...]:
    out = []
    for part in v.strip().lstrip("v").split("."):
        digits = "".join(ch for ch in part if ch.isdigit())
        out.append(int(digits or 0))
    return tuple(out)


def signed_message(version: str, sha256: str) -> bytes:
    return f"traders-helm|{version}|{sha256.lower()}".encode()


def parse_manifest(data: dict) -> Release:
    try:
        r = Release(str(data["version"]), str(data["url"]), str(data["sha256"]).lower(),
                    str(data.get("notes", "")), str(data["signature"]))
    except KeyError as e:
        raise UpdateError(f"the update information is missing {e}") from None
    try:
        sig = bytes.fromhex(r.signature)
    except ValueError:
        sig = b""
    if not ed25519.verify(PUBLIC_KEY, signed_message(r.version, r.sha256), sig):
        raise UpdateError("the update isn't signed by Traders Helm, so it won't be installed")
    return r


def check(manifest_url: str, current: str, get=None) -> Release | None:
    """The newer release, or None when this is the latest. get(url) -> requests-style response."""
    if not manifest_url:
        raise UpdateError("no update address is set yet")
    if get is None:
        import requests
        get = lambda u: requests.get(u, timeout=15)  # noqa: E731
    resp = get(manifest_url)
    resp.raise_for_status()
    r = parse_manifest(resp.json())
    return r if version_tuple(r.version) > version_tuple(current) else None


def download(r: Release, get=None) -> bytes:
    if get is None:
        import requests
        get = lambda u: requests.get(u, timeout=120)  # noqa: E731
    resp = get(r.url)
    resp.raise_for_status()
    data = resp.content
    if hashlib.sha256(data).hexdigest() != r.sha256:
        raise UpdateError("the download didn't match the signed release (damaged or changed); nothing was installed")
    return data


def install(data: bytes, root: Path) -> list[str]:
    """Copy the release over the app folder. Returns the files written."""
    root = root.resolve()
    written = []
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        members = [m for m in z.infolist() if not m.is_dir()]
        for m in members:  # check every path first, so a bad zip writes nothing
            p = PurePosixPath(m.filename)
            if p.is_absolute() or ".." in p.parts or not p.parts or p.parts[0] != TOP:
                raise UpdateError(f"the update has an unexpected file ({m.filename}); nothing was installed")
        for m in members:
            rel = PurePosixPath(m.filename).parts[1:]
            if not rel or rel[0] in KEEP_DIRS or (len(rel) == 1 and rel[0] in KEEP):
                continue
            dest = root.joinpath(*rel)
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(z.read(m))
            written.append("/".join(rel))
    for rel in REMOVED:
        (root / rel).unlink(missing_ok=True)
    return written


def refresh_packages(root: Path) -> None:
    """New versions can need new Python packages: reinstall the app into its own environment (quick when
    nothing changed). A failure is logged, not fatal."""
    try:
        subprocess.run([sys.executable, "-m", "pip", "install", "-q", "-e", str(root)], check=True, timeout=600,
                       capture_output=True)
    except Exception as e:  # noqa: BLE001
        log.warning("update: couldn't refresh Python packages (%s); the app may still work", e)


def restart() -> None:
    """Start the app again (same command it was started with); the caller then quits this copy."""
    from PySide6.QtCore import QProcess
    QProcess.startDetached(sys.executable, sys.argv)
