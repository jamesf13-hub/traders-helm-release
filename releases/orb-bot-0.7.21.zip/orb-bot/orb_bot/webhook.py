"""Receives TradingView alerts and hands them to the running TradingView alerts bots.

TradingView can only send webhooks to a public https address, so the app runs this small server on the Mac
(http://127.0.0.1:8787, not reachable from outside) and ngrok's free tunnel gives it a fixed public address:
    https://<your-domain>.ngrok-free.app/tv  ->  http://127.0.0.1:8787/tv
Only inbound alerts go through the tunnel. Orders still go from this Mac straight to Topstep.

Every alert must carry the bot's secret key; anything else is refused and logged.
"""
from __future__ import annotations

import hashlib
import hmac
import logging
import shutil
import subprocess
import threading
import time as _time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from .alerts import AlertError, parse_alert
from .brand import APP_NAME

log = logging.getLogger(__name__)

MAX_BODY = 16_384
DUPLICATE_WINDOW = 3.0
SELF_TEST_SECONDS = 300.0  # how often the app checks TradingView can still reach it
NGROK_RETRY_SECONDS = 30.0  # the same message twice within this many seconds is ignored
# TradingView sends webhooks from these addresses (https://www.tradingview.com/support/solutions/43000529348/)
TRADINGVIEW_IPS = {"52.89.214.238", "34.212.75.30", "54.218.53.128", "52.32.178.7"}

_ENGINES: dict[str, list] = {}  # bot slug -> running AlertEngines (one per account)
_LOCK = threading.Lock()
_recent: dict[str, float] = {}
received: list[dict] = []  # every request, for the app's "last alert" display


def register(engine) -> None:
    with _LOCK:
        _ENGINES.setdefault(engine.cfg.slug, []).append(engine)


def unregister(engine) -> None:
    with _LOCK:
        lst = _ENGINES.get(engine.cfg.slug, [])
        if engine in lst:
            lst.remove(engine)


def dispatch(body: str, path: str = "/tv", source: str = "") -> tuple[int, str]:
    """Check an alert and give it to every running copy of its bot. Returns (HTTP status, message)."""
    parts = [p for p in path.split("?")[0].split("/") if p]
    url_bot = parts[1].lower() if len(parts) > 1 else ""
    url_key = parts[2] if len(parts) > 2 else ""
    try:
        a = parse_alert(body, url_bot, url_key)
    except AlertError as e:
        log.warning("alert refused: %s", e)
        return 400, str(e)
    with _LOCK:
        engines = list(_ENGINES.get(a.bot, []))
    if not a.bot:
        log.warning("alert refused: no \"bot\" in the message")
        return 400, 'no "bot" in the message'
    if not engines:
        log.warning("alert for %s received, but that bot isn't running on any account: %s", a.bot, a.describe())
        return 404, f"bot {a.bot} is not running"
    secret = engines[0].cfg.alerts.secret
    if not secret or not hmac.compare_digest(a.key.encode(), secret.encode()):
        log.warning("alert for %s refused: wrong key (from %s)", a.bot, source or "?")
        return 403, "wrong key"
    digest = hashlib.sha256(f"{a.bot}|{body}".encode()).hexdigest()
    now = _time.monotonic()
    with _LOCK:
        for k in [k for k, t in _recent.items() if now - t > DUPLICATE_WINDOW]:
            del _recent[k]
        if digest in _recent:
            log.info("duplicate alert for %s ignored", a.bot)
            return 200, "duplicate ignored"
        _recent[digest] = now
    if source and source not in TRADINGVIEW_IPS and source not in ("127.0.0.1", "::1"):
        log.info("alert for %s came from %s (not a TradingView address); accepted because the key matched",
                 a.bot, source)
    for e in engines:
        e.submit(a)
    return 200, f"ok: {len(engines)} account(s)"


class _Handler(BaseHTTPRequestHandler):
    server_version = "ORBBot"

    def log_message(self, *args):  # noqa: D102 - our own logging below
        pass

    def _reply(self, status: int, text: str) -> None:
        body = text.encode()
        self.send_response(status)
        self.send_header("Content-Type", "text/plain")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        self._reply(200, f"{APP_NAME} is listening for TradingView alerts.")

    def do_POST(self):
        size = int(self.headers.get("Content-Length") or 0)
        if size > MAX_BODY:
            self._reply(413, "too large")
            return
        body = self.rfile.read(size).decode("utf-8", "replace")
        source = (self.headers.get("X-Forwarded-For") or self.client_address[0]).split(",")[0].strip()
        status, text = dispatch(body, self.path, source)
        received.append({"time": _time.time(), "status": status, "text": text})
        del received[:-50]
        self._reply(status, text)


class WebhookServer:
    """The local server plus (optionally) the ngrok tunnel in front of it."""

    def __init__(self, port: int, public_url: str = "", start_ngrok: bool = True):
        self.port, self.public_url, self.start_ngrok = port, public_url.strip(), start_ngrok
        self.httpd: ThreadingHTTPServer | None = None
        self.ngrok: subprocess.Popen | None = None
        self.ngrok_error = ""
        self.reachable: bool | None = None  # last self-test result (None = not checked yet)
        self.checked_at = 0.0  # wall-clock time of the last self-test
        self._next_test = 0.0
        self._last_ngrok_start = 0.0
        self._testing = False

    @property
    def running(self) -> bool:
        return self.httpd is not None

    @property
    def address(self) -> str:
        """The URL to paste into TradingView's Webhook URL box."""
        host = self.public_url.removeprefix("https://").removeprefix("http://").rstrip("/")
        return f"https://{host}/tv" if host else ""

    def port_owner(self) -> str:
        """Who holds our port when we can't listen on it: "app" (another copy of this app) or "other"."""
        import urllib.request
        try:
            with urllib.request.urlopen(f"http://127.0.0.1:{self.port}/", timeout=2) as r:
                text = r.read(500).decode("utf-8", "replace")
        except Exception:  # noqa: BLE001 - anything unexpected means it isn't us
            return "other"
        return "app" if "listening for TradingView alerts" in text else "other"

    def start(self) -> None:
        if self.httpd is None:
            self.httpd = ThreadingHTTPServer(("127.0.0.1", self.port), _Handler)
            threading.Thread(target=self.httpd.serve_forever, name="webhook", daemon=True).start()
            log.info("listening for TradingView alerts on http://127.0.0.1:%d/tv", self.port)
        if self.start_ngrok and self.public_url and (self.ngrok is None or self.ngrok.poll() is not None):
            self._start_ngrok()

    def tick(self) -> None:
        """Called about once a second while a TradingView alerts bot runs: restarts ngrok if it died and
        re-checks every few minutes that TradingView can still reach the app (e.g. after the Mac's Wi-Fi drops)."""
        if not self.running:
            return
        now = _time.monotonic()
        if (self.start_ngrok and self.public_url and (self.ngrok is None or self.ngrok.poll() is not None)
                and now - self._last_ngrok_start > (SELF_TEST_SECONDS if "already using" in self.ngrok_error
                                                    else NGROK_RETRY_SECONDS) and find_ngrok()):
            log.warning("the ngrok tunnel isn't running; starting it again")
            self.reachable = False
            self._start_ngrok()
            return
        if self.public_url and not self._testing and now >= self._next_test:
            self._next_test = now + SELF_TEST_SECONDS
            self._testing = True
            threading.Thread(target=self._background_test, daemon=True).start()

    def _background_test(self) -> None:
        try:
            ok, was = self.self_test(quiet=True), self.reachable
        finally:
            self._testing = False
        if ok and was is False:
            log.info("TradingView alerts can reach the app again")

    def _start_ngrok(self) -> None:
        self._last_ngrok_start = _time.monotonic()
        self._next_test = self._last_ngrok_start + 15  # give the tunnel time to come up before checking
        exe = find_ngrok()
        if not exe:
            self.ngrok_error = "ngrok isn't installed (brew install ngrok)"
            log.error("%s; TradingView can't reach the app", self.ngrok_error)
            return
        host = self.public_url.removeprefix("https://").removeprefix("http://").rstrip("/")
        cmd = [exe, "http", f"--url={host}", str(self.port), "--log=stdout", "--log-format=logfmt"]
        try:
            self.ngrok = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        except OSError as e:
            self.ngrok_error = f"could not start ngrok: {e}"
            log.error(self.ngrok_error)
            return
        self.ngrok_error = ""
        threading.Thread(target=self._watch_ngrok, args=(self.ngrok,), daemon=True).start()
        log.info("starting the ngrok tunnel: %s -> port %d", self.address, self.port)

    def _watch_ngrok(self, proc: subprocess.Popen) -> None:
        for line in proc.stdout or []:
            if "started tunnel" in line:
                log.info("ngrok tunnel up, checking %s answers from this app", self.address)
                threading.Thread(target=self._first_check, daemon=True).start()
            elif "lvl=eror" in line or "lvl=crit" in line or "ERR_NGROK" in line:
                msg = line.split("err=", 1)[-1].strip()[:300]
                if "ERR_NGROK_334" in line or "already online" in line:
                    msg = ("another ngrok (older project or another computer) is already using this address; "
                           "stop it, or stop its endpoint on dashboard.ngrok.com > Endpoints, then Stop/Start the bot")
                self.ngrok_error = msg
                log.error("ngrok: %s", msg)
        if self.ngrok is proc:
            log.warning("the ngrok tunnel stopped (exit code %s); TradingView alerts can't reach the app",
                        proc.wait())

    def _first_check(self, tries: int = 4, gap: float = 3.0) -> None:
        """ngrok answers 404 for a few seconds after "started tunnel"; only report a failure that lasts."""
        for _ in range(tries - 1):
            if self.self_test(quiet=True):
                log.info("ngrok check passed: TradingView alerts can reach %s", self.address)
                return
            _time.sleep(gap)
        self.self_test()

    def self_test(self, quiet: bool = False) -> bool:
        """Ask the public address who answers. True only if it is this app (not another tunnel's server)."""
        import urllib.request
        host = self.public_url.removeprefix("https://").removeprefix("http://").rstrip("/")
        try:
            req = urllib.request.Request(f"https://{host}/", headers={"ngrok-skip-browser-warning": "1"})
            with urllib.request.urlopen(req, timeout=10) as r:
                text = r.read(300).decode("utf-8", "replace")
        except Exception as e:  # noqa: BLE001 - any failure means TradingView can't reach us either
            text = f"no answer ({e})"
        self.checked_at = _time.time()
        if "is listening for TradingView alerts" in text:
            self.ngrok_error = ""
            if not quiet:
                log.info("ngrok check passed: TradingView alerts can reach %s", self.address)
            self.reachable = True
            return True
        was, self.reachable = self.reachable, False
        self.ngrok_error = "the public address didn't answer" if text.startswith("no answer") else (
                            "the address answered, but not from this app, so another ngrok is probably using "
                            "it; stop that one (dashboard.ngrok.com > Endpoints) and Stop/Start the bot")
        if not quiet or was is not False:  # say it once, not every few minutes
            log.error("ngrok check failed: %s. It answered: %s", self.ngrok_error, text[:120].replace("\n", " "))
        return False

    def stop(self) -> None:
        if self.ngrok and self.ngrok.poll() is None:
            self.ngrok.terminate()
        self.ngrok = None
        if self.httpd:
            self.httpd.shutdown()
            self.httpd.server_close()
            self.httpd = None


def find_ngrok() -> str | None:
    for p in (shutil.which("ngrok"), "/opt/homebrew/bin/ngrok", "/usr/local/bin/ngrok"):
        if p and Path(p).exists():
            return p
    return None
