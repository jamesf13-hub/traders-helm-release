"""The UP&L figure in the top bar: open P&L of every position on the account being viewed (the bots' and
manual ones), moving with each trade like TopstepX's.

Positions are checked every few seconds; prices come from the live trade stream, so the figure updates as
the market trades. It also keeps the account's realised P&L for the trading day (from 18:00 New York, Topstep's
trade list less fees), shown as RP&L while no bot is running on the account."""
from __future__ import annotations

import logging
import threading
import time
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo
from typing import Callable

from .models import Contract, Position

log = logging.getLogger(__name__)

CHECK_SECONDS = 3.0
REALISED_SECONDS = 30.0
NEW_YORK = ZoneInfo("America/New_York")


def trading_day_start(now: datetime) -> datetime:
    """18:00 New York on the evening the current Topstep trading day began."""
    ny = now.astimezone(NEW_YORK)
    start = ny.replace(hour=18, minute=0, second=0, microsecond=0)
    return start if ny >= start else start - timedelta(days=1)


def open_pnl(positions: list[Position], contracts: dict[str, Contract], prices: dict[str, float | None]) -> float | None:
    """Sum of (price − average) × direction × size × $ per point. None if any price is still unknown."""
    total = 0.0
    for p in positions:
        c, price = contracts.get(p.contract_id), prices.get(p.contract_id)
        if c is None or price is None:
            return None
        total += (price - p.average_price) * p.side.sign * p.size * c.tick_value / c.tick_size
    return total


class OpenPnL:
    """make_broker() -> a ProjectXBroker (or None without a login); stream_for(broker, contract_id) -> a stream
    with .last_price."""

    def __init__(self, make_broker: Callable, stream_for: Callable):
        self.make_broker, self.stream_for = make_broker, stream_for
        self.account_id: int | None = None
        self.positions: list[Position] | None = None  # None = not known yet
        self.realised: float | None = None  # today's closed-trade P&L after fees; None = not known yet
        self._realised_at = 0.0
        self.contracts: dict[str, Contract] = {}
        self.fallback: dict[str, float | None] = {}
        self.streams: dict[str, object] = {}
        self._broker = None
        self._wake = threading.Event()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def set_account(self, account_id: int | None) -> None:
        if account_id != self.account_id:
            self.account_id, self.positions, self.realised, self._realised_at = account_id, None, None, 0.0
            self._wake.set()
        if self._thread is None:
            self._thread = threading.Thread(target=self._run, name="open-pnl", daemon=True)
            self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        self._wake.set()

    def value(self) -> float | None:
        """The live figure: 0.0 when flat, None when not known yet."""
        pos = self.positions
        if pos is None:
            return None
        prices = {}
        for p in pos:
            s = self.streams.get(p.contract_id)
            live = getattr(s, "last_price", None)
            prices[p.contract_id] = live if live is not None else self.fallback.get(p.contract_id)
        return open_pnl(pos, self.contracts, prices)

    def check(self) -> None:
        """One look at the account's positions (runs in the background thread)."""
        aid = self.account_id
        if aid is None:
            return
        if self._broker is None:
            self._broker = self.make_broker()
            if self._broker is None:
                return
        b = self._broker
        b.account_id = aid
        pos = b.get_all_positions()
        for p in pos:
            if p.contract_id not in self.contracts:
                self.contracts[p.contract_id] = b.contract_by_id(p.contract_id)
            if p.contract_id not in self.streams:
                try:
                    self.streams[p.contract_id] = self.stream_for(b, p.contract_id)
                except Exception as e:  # noqa: BLE001 - falls back to 1-minute closes
                    log.debug("no live stream for %s: %s", p.contract_id, e)
            if getattr(self.streams.get(p.contract_id), "last_price", None) is None:
                self.fallback[p.contract_id] = b.last_price_of(p.contract_id)
        if aid == self.account_id:
            self.positions = pos
        if time.monotonic() - self._realised_at >= REALISED_SECONDS:
            start = trading_day_start(datetime.now(timezone.utc))
            fills = b.get_fills(start)
            if aid == self.account_id:
                self.realised = sum((f.pnl or 0.0) - f.fees for f in fills if f.time >= start)
                self._realised_at = time.monotonic()

    def _run(self) -> None:
        while not self._stop.is_set():
            try:
                self.check()
            except Exception as e:  # noqa: BLE001 - display only; try again next time
                log.debug("open P&L check failed: %s", e)
                self._broker = None
            self._wake.wait(CHECK_SECONDS)
            self._wake.clear()
