"""ORB 5M: five-minute MNQ opening range breakout, ASIA and NY AM sessions. For James's own use.

Feed it completed five-minute MNQ bars with ``on_bar``; it returns what to do (enter / flatten). The caller
tells it when its trade fills (``filled``) and when the stop or target closes it (``closed``).

Rules, from the strategy source (New York times, bar open times):
  ASIA:  range 01:00-01:15 (three 5-min bars), entries on bars 01:15 to 03:40, force close at 06:05.
  NY AM: range 09:15-09:30, entries on bars 09:30 to 11:50, force close at 12:05.
  Signal: a bar closes beyond the range in its own direction (green bar for longs, red for shorts).
  ASIA filter: |DI+ - DI-| (14) > 5.5 and the close no more than 45% of the range beyond it; a breakout close
    that fails this rules that direction out for the rest of the session.
  NY filter: not the 09:45 bar; close not 40-60% of the range beyond; body >= 30% of the bar when VWAP moved
    >= 0.18 ATR over the last 5 bars, else >= 50%.
  Stop: ASIA = the other side of the range, NY = the signal bar's low/high. Target = close +/- RR x risk.
  Size: floor(risk $ / (risk points x $2)), at most max contracts (and 40). Market order on the next bar.
  Two trades a session at most, one per direction: the second is the opposite way, either after the first
  is stopped / hits its target, or as a reversal while the first is still open.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import date, datetime, time, timedelta

TICK = 0.25
POINT_VALUE = 2.0
ABS_MAX_CONTRACTS = 40

ASIA, NYAM = "ASIA", "NYAM"
ORB = {ASIA: (time(1, 0), time(1, 14, 29)), NYAM: (time(9, 15), time(9, 29, 29))}
TRADE_START = {ASIA: time(1, 15), NYAM: time(9, 30)}
ENTRY_END = {ASIA: time(3, 45), NYAM: time(12, 0)}   # signal bar must close before this
FORCE_CLOSE = {ASIA: time(6, 0), NYAM: time(12, 0)}  # bar opening at this time closes the trade

NY_IMPULSE, NY_IMPULSIVE_BODY, NY_TRANSITION_BODY = 0.18, 30.0, 50.0
ASIA_MIN_DI_SEP, ASIA_MAX_BREAKOUT = 5.5, 45.0


def round_tick(p: float) -> float:
    return round(p / TICK) * TICK


@dataclass
class Settings:
    sessions: tuple = (ASIA,)
    risk_dollars: float = 1000.0
    ny_rr: float = 0.3
    asia_rr: float = 0.3
    max_contracts: int = 20


@dataclass
class Bar:
    open_et: datetime  # bar open time, New York, naive
    open: float
    high: float
    low: float
    close: float
    volume: float = 0.0


@dataclass
class Action:
    kind: str                # "enter" or "flatten"
    side: int = 0            # +1 long, -1 short
    qty: int = 0
    stop: float = math.nan
    target: float = math.nan
    reversal: bool = False
    session: str = ""
    reason: str = ""


@dataclass
class _Session:
    kind: str = ""
    day: date | None = None
    high: float = math.nan
    low: float = math.nan
    ready: bool = False
    trades: int = 0
    long_taken: bool = False
    short_taken: bool = False
    long_rejected: bool = False
    short_rejected: bool = False
    first_dir: int = 0
    second_unlocked: bool = False


class Orb5M:
    def __init__(self, settings: Settings | None = None, log=None):
        self.s = settings or Settings()
        self.log = log or (lambda msg: None)
        self.sess = _Session()
        self.position = 0          # signed contracts the strategy believes it holds
        self.pending: Action | None = None
        self.closed_today: dict = {}
        self.prev_in_orb = False
        # indicators
        self.prev: Bar | None = None
        self.atr_n, self.atr_sum, self.atr = 0, 0.0, math.nan
        self.vwap_pv = self.vwap_v = 0.0
        self.vwap_hist: list[float] = []
        self.dm_n = 0
        self.sum_tr = self.sum_dmp = self.sum_dmm = 0.0
        self.di_plus = self.di_minus = math.nan
        self.bars_seen = 0
        self.closed_this_bar = False

    # ---------- indicators ----------
    def _indicators(self, b: Bar) -> None:
        p = self.prev
        tr = b.high - b.low if p is None else max(b.high - b.low, abs(b.high - p.close), abs(b.low - p.close))
        if self.atr_n < 14:
            self.atr_sum += tr
            self.atr_n += 1
            self.atr = self.atr_sum / 14 if self.atr_n == 14 else math.nan
        else:
            self.atr = (self.atr * 13 + tr) / 14
        # session VWAP (CME session starts 18:00 New York)
        if p is None or _session_key(b.open_et) != _session_key(p.open_et):
            self.vwap_pv = self.vwap_v = 0.0
        self.vwap_pv += (b.high + b.low + b.close) / 3 * b.volume
        self.vwap_v += b.volume
        self.vwap_hist.append(self.vwap_pv / self.vwap_v if self.vwap_v > 0 else math.nan)
        del self.vwap_hist[:-6]
        # NinjaTrader DM(14)
        if p is None:
            self.sum_tr, self.sum_dmp, self.sum_dmm = b.high - b.low, 0.0, 0.0
        else:
            up, down = b.high - p.high, p.low - b.low
            dmp = max(up, 0.0) if up > down else 0.0
            dmm = max(down, 0.0) if down > up else 0.0
            if self.dm_n < 14:
                self.sum_tr += tr; self.sum_dmp += dmp; self.sum_dmm += dmm
            else:
                self.sum_tr += tr - self.sum_tr / 14
                self.sum_dmp += dmp - self.sum_dmp / 14
                self.sum_dmm += dmm - self.sum_dmm / 14
        self.dm_n += 1
        self.di_plus = 100 * self.sum_dmp / self.sum_tr if self.sum_tr else 0.0
        self.di_minus = 100 * self.sum_dmm / self.sum_tr if self.sum_tr else 0.0
        self.prev = b

    # ---------- fills reported by the caller ----------
    def filled(self, side: int, qty: int) -> None:
        """The entry filled (for a reversal: the old trade is closed and the new one is on)."""
        self.position = side * qty
        self.pending = None

    def entry_failed(self) -> None:
        a = self.pending
        self.pending = None
        if a is None:
            return
        s = self.sess
        if a.side > 0:
            s.long_taken = False
        else:
            s.short_taken = False
        s.trades = max(0, s.trades - 1)
        if s.trades == 0:
            s.first_dir, s.second_unlocked = 0, False

    def closed(self, by_bracket: bool) -> None:
        """The trade is flat: by its stop/target (unlocks the second trade) or by a forced close."""
        self.position = 0
        self.closed_this_bar = True
        if by_bracket and self.sess.trades == 1:
            self.sess.second_unlocked = True

    # ---------- per bar ----------
    def on_bar(self, b: Bar) -> Action | None:
        self._indicators(b)
        self.bars_seen += 1
        # like the TradingView version: the bar a trade closed in can't be the second trade's signal bar
        just_closed, self.closed_this_bar = self.closed_this_bar, False
        if self.bars_seen < 20:
            return None
        t, d = b.open_et.time(), b.open_et.date()
        close_et = b.open_et + timedelta(minutes=5)
        on = self.s.sessions
        in_ny = NYAM in on and ORB[NYAM][0] <= t <= ORB[NYAM][1]
        in_asia = ASIA in on and ORB[ASIA][0] <= t <= ORB[ASIA][1]
        in_orb = in_ny or in_asia
        starting = in_orb and not self.prev_in_orb
        s = self.sess
        if starting:
            self.sess = s = _Session(kind=ASIA if in_asia else NYAM, day=d, high=b.high, low=b.low)
            self.pending = None
        if not starting and s.ready and s.day != d:
            s.ready = False
        if in_orb:
            s.high, s.low = max(s.high, b.high), min(s.low, b.low)
        ct = close_et.time()
        if ((in_asia and ct > ORB[ASIA][1]) or (in_ny and ct > ORB[NYAM][1])) and not math.isnan(s.high):
            s.ready = True
        self.prev_in_orb = in_orb

        for kind in (ASIA, NYAM):
            if kind in on and t == FORCE_CLOSE[kind] and self.closed_today.get(kind) != d:
                self.closed_today[kind] = d
                self.pending = None
                if self.position != 0:
                    return Action("flatten", session=kind, reason=f"{'6:00 AM' if kind == ASIA else '12 PM'} Force Close")
                return None

        if not s.ready or not s.kind or s.day != d or s.kind not in on or not self._entry_bar(b.open_et, s):
            return None
        if self.pending is not None:
            return None
        asia = s.kind == ASIA
        c, o, h, l = b.close, b.open, b.high, b.low
        up, down = c > s.high, c < s.low
        rng = h - l
        body = abs(c - o) / rng * 100 if rng > 0 else math.nan
        vw = self.vwap_hist
        move = vw[-1] - vw[0] if len(vw) == 6 and not math.isnan(vw[0]) else math.nan
        impulse = abs(move) / self.atr if not math.isnan(self.atr) and self.atr > 0 and not math.isnan(move) else math.nan
        need_body = NY_IMPULSIVE_BODY if not math.isnan(impulse) and impulse >= NY_IMPULSE else NY_TRANSITION_BODY
        body_ok = asia or (not math.isnan(impulse) and not math.isnan(body) and body >= need_body)
        can = s.trades < 2
        first = s.trades == 0
        second_long = s.trades == 1 and s.second_unlocked and not just_closed and s.first_dir == -1
        second_short = s.trades == 1 and s.second_unlocked and not just_closed and s.first_dir == 1
        stop_long = round_tick(s.low if asia else l)
        stop_short = round_tick(s.high if asia else h)
        risk_long, risk_short = c - stop_long, stop_short - c
        rr = self.s.asia_rr if asia else self.s.ny_rr
        tgt_long, tgt_short = round_tick(c + risk_long * rr), round_tick(c - risk_short * rr)
        q_long, q_short = self._contracts(risk_long), self._contracts(risk_short)
        not_945 = asia or t != time(9, 45)
        width = s.high - s.low
        bo_up = (c - s.high) / width * 100 if width > 0 else math.nan
        bo_down = (s.low - c) / width * 100 if width > 0 else math.nan
        mid_up = asia or math.isnan(bo_up) or bo_up < 40 or bo_up > 60
        mid_down = asia or math.isnan(bo_down) or bo_down < 40 or bo_down > 60
        sep = abs(self.di_plus - self.di_minus)
        quant_long = sep > ASIA_MIN_DI_SEP and not math.isnan(bo_up) and bo_up < ASIA_MAX_BREAKOUT
        quant_short = sep > ASIA_MIN_DI_SEP and not math.isnan(bo_down) and bo_down < ASIA_MAX_BREAKOUT
        if asia:
            if up and not quant_long:
                s.long_rejected = True
            if down and not quant_short:
                s.short_rejected = True
        ok_long = not_945 and mid_up and body_ok and (not asia or (quant_long and not s.long_rejected))
        ok_short = not_945 and mid_down and body_ok and (not asia or (quant_short and not s.short_rejected))
        flat = self.position == 0
        go_long = flat and not s.long_taken and up and ok_long and (first or second_long) and q_long >= 1
        go_short = flat and not s.short_taken and down and ok_short and (first or second_short) and q_short >= 1
        rev_long = self.position < 0 and s.trades == 1 and can and not s.long_taken and up and ok_long and q_long >= 1
        rev_short = self.position > 0 and s.trades == 1 and can and not s.short_taken and down and ok_short and q_short >= 1
        if (go_long or rev_long) and c > o:
            return self._prepare(1, q_long, stop_long, tgt_long, rev_long, b, s)
        if (go_short or rev_short) and c < o:
            return self._prepare(-1, q_short, stop_short, tgt_short, rev_short, b, s)
        return None

    def _entry_bar(self, open_et: datetime, s: _Session) -> bool:
        d = s.day
        close_et = open_et + timedelta(minutes=5)
        return (open_et.date() == d and close_et.date() == d and open_et.time() >= TRADE_START[s.kind]
                and close_et < datetime.combine(d, ENTRY_END[s.kind]))

    def _contracts(self, risk_points: float) -> int:
        if risk_points <= 0:
            return 0
        n = math.floor(self.s.risk_dollars / (risk_points * POINT_VALUE))
        return 0 if n < 1 else min(n, self.s.max_contracts, ABS_MAX_CONTRACTS)

    def _prepare(self, side, qty, stop, target, reversal, b: Bar, s: _Session) -> Action:
        if side > 0:
            s.long_taken = True
        else:
            s.short_taken = True
        s.trades += 1
        if s.first_dir == 0:
            s.first_dir = side
        a = Action("enter", side, qty, stop, target, reversal, s.kind,
                   f"{s.kind} {'reversal' if reversal else 'breakout'} {'long' if side > 0 else 'short'}")
        self.pending = a
        self.log(f"{a.reason} x{qty} at the {b.open_et:%H:%M} close {b.close:.2f}, range {s.low:.2f}-{s.high:.2f}, "
                 f"stop {stop:.2f}, target {target:.2f}")
        return a

    def entry_window_open(self, now_et: datetime) -> bool:
        """The fill bar must still be inside the session's entry window (as NinjaTrader checks on historical bars)."""
        s = self.sess
        if not s.kind or s.day != now_et.date():
            return False
        return datetime.combine(s.day, TRADE_START[s.kind]) <= now_et < datetime.combine(s.day, ENTRY_END[s.kind])


def _session_key(open_et: datetime) -> date:
    """CME session date: a bar from 18:00 New York belongs to the next day's session."""
    return (open_et + timedelta(hours=6)).date()


def simulate(bars_1m, settings: Settings | None = None):
    """Backtest on one-minute bars (New York open time, o, h, l, c, v), trading on five-minute closes like
    NinjaTrader: market entries at the next 5-minute bar's open (no slippage), the stop and target as resting
    orders checked minute by minute (stop first if both are touched in the same minute)."""
    core = Orb5M(settings)
    trades, pos = [], None
    pending: Action | None = None
    flatten: Action | None = None
    bucket: list = []

    def close_pos(when, price, why, bracket):
        nonlocal pos
        pos.update(exit_time=when, exit=price, reason=why)
        pos["pnl"] = (price - pos["entry"]) * pos["side"] * pos["qty"] * POINT_VALUE
        trades.append(pos)
        pos = None
        core.closed(bracket)

    def five_min_close():
        nonlocal pending, flatten
        o = bucket[0]
        b = Bar(o[0].replace(minute=o[0].minute - o[0].minute % 5), o[1], max(x[2] for x in bucket),
                min(x[3] for x in bucket), bucket[-1][4], sum(x[5] for x in bucket))
        a = core.on_bar(b)
        if a is None:
            return
        if a.kind == "flatten":
            flatten = a
        elif a.kind == "enter":
            pending = a

    for row in bars_1m:
        t = row[0]
        start5 = t.replace(minute=t.minute - t.minute % 5, second=0)
        if bucket and bucket[0][0].replace(minute=bucket[0][0].minute - bucket[0][0].minute % 5) != start5:
            five_min_close()
            bucket = []
            # orders from that close fill at this bar's open
            if flatten is not None:
                if pos is not None:
                    close_pos(t, row[1], flatten.reason, False)
                flatten = None
            if pending is not None:
                a, pending = pending, None
                if not core.entry_window_open(start5) or not (core.sess.day == start5.date()):
                    core.entry_failed()
                else:
                    if pos is not None:
                        close_pos(t, row[1], "Reversal", False)
                    fill = row[1]
                    risk = (fill - a.stop) * a.side
                    pos = dict(side=a.side, qty=a.qty, entry=fill, entry_time=t, stop=a.stop, target=a.target,
                               session=a.session, reversal=a.reversal)
                    core.filled(a.side, a.qty)
                    if risk <= 0:
                        close_pos(t, fill, "Invalid Gap Entry", False)
        bucket.append(row)
        if pos is not None and pos["entry_time"] <= t:
            _, o, h, l, c = row[:5]
            sd = pos["side"]
            hit_stop = l <= pos["stop"] if sd > 0 else h >= pos["stop"]
            hit_tgt = h >= pos["target"] if sd > 0 else l <= pos["target"]
            if hit_stop:
                px = min(o, pos["stop"]) if sd > 0 else max(o, pos["stop"])
                close_pos(t, px, "Stop Loss", True)
            elif hit_tgt:
                px = max(o, pos["target"]) if sd > 0 else min(o, pos["target"])
                close_pos(t, px, "Take Profit", True)
    return trades
