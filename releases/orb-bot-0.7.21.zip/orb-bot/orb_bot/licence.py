"""Licence check for the packaged app (goes in as orb_bot/licence.py).

A buyer enters their Whop licence key once. The app ties it to this computer through the licence server and
keeps the signed pass it gets back in licence.json. The pass lasts GRACE (7 days) and is renewed by a check
every day, so:
  * no internet, or our server down: bots keep trading until the pass runs out, with a warning after a day;
  * subscription cancelled or ended: the next daily check says so and the licence stops;
  * never closes or touches an open trade: a lapsed licence only stops bots taking new trades (the caller's
    job: may_trade() is the one question the app asks).

Only enforced in packaged builds (ENFORCE, set by the build); James's own copy from the zip runs as before.
The pass is checked with the public half of our licence key (PUBLIC_KEY), so it can't be edited or made up
without the private half, which only the licence server has."""
from __future__ import annotations

import base64
import hashlib
import json
import logging
import platform
import re
import subprocess
import sys
import time
import uuid
from dataclasses import dataclass
from pathlib import Path

from . import ed25519

log = logging.getLogger(__name__)

ENFORCE = False  # the packaged build sets this True
PUBLIC_KEY_HEX = "__LICENCE_PUBLIC_KEY__"  # from tools/make_licence_key.py; the build refuses the placeholder
PUBLIC_KEY = bytes.fromhex(PUBLIC_KEY_HEX) if not PUBLIC_KEY_HEX.startswith("__") else b""
SERVER_URL = "__LICENCE_SERVER_URL__"
PASS_PREFIX = b"traders-helm-licence|"
CHECK_EVERY = 24 * 3600
WARN_AFTER = 26 * 3600  # a missed daily check (plus slack) before the app says it can't reach us
_SALT = b"traders-helm-machine-v1|"


class LicenceError(Exception):
    """The server said no (bad key, cancelled, other computer...). str() is a message for the user."""

    def __init__(self, reason: str, message: str):
        super().__init__(message)
        self.reason = reason


class Offline(Exception):
    """The licence server couldn't be reached or is having trouble. Not the user's fault."""


# --- this computer ---------------------------------------------------------------------------------------------

def _raw_machine_id() -> str:
    try:
        if sys.platform == "darwin":
            out = subprocess.run(["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"], capture_output=True,
                                 text=True, timeout=10).stdout
            m = re.search(r'"IOPlatformUUID"\s*=\s*"([^"]+)"', out)
            if m:
                return m.group(1)
        elif sys.platform == "win32":
            import winreg
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography", 0,
                                winreg.KEY_READ | winreg.KEY_WOW64_64KEY) as k:
                return str(winreg.QueryValueEx(k, "MachineGuid")[0])
        else:
            for p in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
                if Path(p).exists() and Path(p).read_text().strip():
                    return Path(p).read_text().strip()
    except Exception as e:  # noqa: BLE001
        log.warning("licence: couldn't read this computer's id (%s); using the network card", e)
    return f"node-{uuid.getnode():012x}"


def machine_id() -> str:
    """A stable id for this computer. Hashed, so the hardware id itself never leaves it."""
    return hashlib.sha256(_SALT + _raw_machine_id().encode()).hexdigest()[:32]


def machine_name() -> str:
    name = platform.node().split(".")[0] or "this computer"
    return name[:60]


# --- passes ----------------------------------------------------------------------------------------------------

def key_fingerprint(licence_key: str) -> str:
    return hashlib.sha256(licence_key.strip().encode()).hexdigest()[:16]


def read_pass(token: str, public_key: bytes | None = None) -> dict | None:
    """The pass's contents if our signature checks out, else None."""
    try:
        payload, sig = token.split(".", 1)
        if not ed25519.verify(public_key or PUBLIC_KEY, PASS_PREFIX + payload.encode(), bytes.fromhex(sig)):
            return None
        return json.loads(base64.urlsafe_b64decode(payload.encode()))
    except Exception:  # noqa: BLE001
        return None


# --- state -----------------------------------------------------------------------------------------------------

@dataclass
class Status:
    state: str          # "ok", "offline" (pass still good, server not reached lately), "none", "expired"
    message: str        # one line for the app
    days_left: float = 0.0  # until the pass runs out

    @property
    def may_trade(self) -> bool:
        return self.state in ("ok", "offline")


class Licence:
    """licence.json in the app's data folder: {key, pass, checked (last good check), seen (latest clock seen),
    reason/message (the server's last no)}."""

    def __init__(self, path: Path, server_url: str = SERVER_URL, public_key: bytes | None = None, post=None,
                 clock=time.time, machine: str | None = None, enforce: bool | None = None):
        self.enforce = ENFORCE if enforce is None else enforce
        self.path = Path(path)
        self.server = server_url.rstrip("/")
        self.public_key = public_key or PUBLIC_KEY
        self._post = post
        self.clock = clock
        self.machine = machine or machine_id()
        self.data = self._load()

    # storage
    def _load(self) -> dict:
        try:
            return json.loads(self.path.read_text())
        except Exception:  # noqa: BLE001
            return {}

    def _save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.data, indent=1))
        tmp.replace(self.path)

    def _now(self) -> float:
        """The clock, but never earlier than one we've already seen: winding the clock back can't stretch the
        offline days."""
        now = self.clock()
        seen = float(self.data.get("seen") or 0)
        if now > seen:
            self.data["seen"] = now
            try:
                self._save()
            except OSError:
                pass
        return max(now, seen)

    @property
    def key(self) -> str:
        return self.data.get("key") or ""

    # server
    def _call(self, path: str, body: dict) -> dict:
        if not self.server or self.server.startswith("__"):
            raise Offline("no licence server address is set")
        post = self._post
        if post is None:
            import requests
            post = lambda url, json: requests.post(url, json=json, timeout=30)  # noqa: E731
        try:
            r = post(self.server + path, json=body)
        except Exception as e:  # noqa: BLE001
            raise Offline(str(e)) from None
        if r.status_code != 200:
            raise Offline(f"licence server answered {r.status_code}")
        try:
            d = r.json()
        except ValueError:
            raise Offline("licence server sent something unreadable") from None
        if not d.get("ok"):
            raise LicenceError(str(d.get("reason") or "refused"), str(d.get("message") or "Licence refused."))
        return d

    def _take(self, key: str, d: dict) -> None:
        info = read_pass(d.get("pass") or "", self.public_key)
        if not info or info.get("machine") != self.machine or info.get("key") != key_fingerprint(key):
            raise Offline("the licence server's answer didn't check out")
        self.data.update({"key": key.strip(), "pass": d["pass"], "checked": self._now()})
        self.data.pop("reason", None)
        self.data.pop("message", None)
        self._save()

    def _refused(self, e: LicenceError) -> None:
        self.data.pop("pass", None)
        self.data.update({"reason": e.reason, "message": str(e)})
        self._save()

    def activate(self, licence_key: str, app_version: str = "") -> Status:
        """Enter a key on this computer. Raises LicenceError (message for the user) or Offline."""
        key = licence_key.strip()
        try:
            d = self._call("/v1/activate", {"licence_key": key, "machine_id": self.machine,
                                            "machine_name": machine_name(), "app_version": app_version})
        except LicenceError as e:
            if not self.key or self.key == key:
                self._refused(e)
            raise
        self._take(key, d)
        return self.status()

    def check(self, app_version: str = "") -> Status:
        """The daily check. Never raises: offline keeps the current pass, a refusal ends it."""
        if not self.key:
            return self.status()
        try:
            d = self._call("/v1/check", {"licence_key": self.key, "machine_id": self.machine,
                                         "app_version": app_version})
            self._take(self.key, d)
        except LicenceError as e:
            log.warning("licence: %s", e)
            self._refused(e)
        except Offline as e:
            log.info("licence: check skipped, server not reached (%s)", e)
        return self.status()

    def check_due(self) -> bool:
        return bool(self.key) and self._now() - float(self.data.get("checked") or 0) >= CHECK_EVERY

    def deactivate(self) -> None:
        """Free the key so it can go on another computer. Raises LicenceError/Offline (needs the server, or
        the key would still be tied here)."""
        if self.key:
            self._call("/v1/deactivate", {"licence_key": self.key, "machine_id": self.machine})
        self.data = {"seen": self.data.get("seen")}
        self._save()

    def status(self) -> Status:
        if not self.enforce:
            return Status("ok", "Licence not needed for this copy.", 9999)
        if not self.key:
            return Status("none", "Enter your licence key to start trading.")
        info = read_pass(self.data.get("pass") or "", self.public_key)
        if not info or info.get("machine") != self.machine or info.get("key") != key_fingerprint(self.key):
            return Status("none", self.data.get("message") or "Enter your licence key to start trading.")
        now = self._now()
        left = (float(info.get("exp") or 0) - now) / 86400
        if left <= 0:
            return Status("expired", "Couldn't reach the licence server for 7 days, so bots can't take new "
                                     "trades. Connect to the internet and choose Check licence.")
        if now - float(self.data.get("checked") or 0) > WARN_AFTER:
            return Status("offline", f"Couldn't reach the licence server. Bots keep trading for "
                                     f"{_days(left)} more.", left)
        return Status("ok", "Licence active.", left)

    def may_trade(self) -> bool:
        return self.status().may_trade


def _days(d: float) -> str:
    if d >= 1.5:
        return f"{round(d)} days"
    hours = max(1, round(d * 24))
    return f"{hours} hour" + ("s" if hours != 1 else "")
