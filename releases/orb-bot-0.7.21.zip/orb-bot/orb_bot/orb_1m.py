"""ORB 1M: one-minute MNQ opening range breakout, bar for bar. For James's own use.

Feed it completed one-minute MNQ bars in time order with ``on_bar``. It keeps
the same state the NinjaScript strategy keeps (opening range, session history,
shadow breakout/fade pairs, quarterly nearest-neighbour model) and simulates
fills the way NinjaTrader's historical engine does (market orders at the next
bar's open with 1 tick slippage, stop/target from the average fill price).

Live, the same simulation keeps the books and ``hooks`` (enter / move_stop / exit) send the real orders on
bars marked live. Checked against James's NinjaTrader trades on 28 Sep, 5, 7 and 14 Oct 2026.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo

NEW_YORK = ZoneInfo("America/New_York")
TICK = 0.25
POINT_VALUE = 2.0

ORB_START = 570          # 09:30 ET
ORB_END = 585            # 09:45 ET
CASH_CLOSE = 960         # 16:00 ET
COND_EXIT = 930          # 15:30 ET

STOP_ORB_MULTIPLE = 1.25
MIN_STOP, MAX_STOP = 2.0, 100.0
BASE_TARGET_R, HIGH_ORB_TARGET_R = 3.0, 1.25
ORB_LOOKBACK, ORB_Q = 120, 0.75
ADM_BODY, ADM_CLOSE_LOC, ADM_TOUCHES = 0.15, 0.6, 3
TREND_CLOSES = 21
PRIOR_DAY_BPS = 300.0
NEIGHBORS, MIN_ROWS, FLIP_P = 15, 100, 0.65
TRAIN_START, PREDICT_START = date(2021, 1, 1), date(2023, 1, 1)
WEAK_BODY = 0.2
HIGHVOL_TOUCHES, HIGHVOL_BARS = 3, 3
INTRADAY_BPS, INTRADAY_EXT = 25.0, 0.25
PRIOR_SESSION_BPS = 100.0
DIRECT_ELAPSED, DIRECT_VWAP_BPS = 1.0, 20.0
LABEL_COST = 2.5

ROLL_EXCLUDE = {20200311, 20200610, 20200909, 20210609, 20210908, 20220608, 20220907, 20260611}
DEGRADED_EXCLUDE = {20200227, 20200228, 20200630, 20200701, 20200702, 20211206, 20220103, 20240918,
                    20240919, 20250917, 20250918, 20250924, 20250925, 20251128, 20260316, 20260317,
                    20260410, 20260525, 20260730, 20260731}


# CME equity index futures days that close before 16:00 ET (NinjaTrader's "CME US Index Futures ETH" hours skip
# them). Backtests work this out from the data; live trading needs to know in the morning.
EARLY_CLOSE = {date(2026, 11, 27), date(2026, 12, 24), date(2026, 12, 31), date(2027, 1, 18), date(2027, 2, 15),
               date(2027, 5, 31), date(2027, 6, 18), date(2027, 7, 2), date(2027, 7, 5), date(2027, 9, 6),
               date(2027, 11, 26), date(2027, 12, 23), date(2027, 12, 24), date(2027, 12, 31)}


def bundled_state() -> dict:
    """History built from 2020-2026 one-minute data, shipped with the app."""
    import json
    from importlib import resources
    return json.loads(resources.files("orb_bot").joinpath("assets/orb_1m_state.json").read_text())


def cash_date_of(open_et: datetime) -> date:
    """The CME trading day a one-minute bar belongs to (sessions run 18:00 ET to 17:00 ET; weekend -> Monday)."""
    close = open_et + timedelta(minutes=1)
    d = close.date()
    if close.hour * 60 + close.minute > 1020:
        d += timedelta(days=1)
    if d.weekday() == 5:
        d += timedelta(days=2)
    elif d.weekday() == 6:
        d += timedelta(days=1)
    return d


def dkey(d: date) -> int:
    return d.year * 10000 + d.month * 100 + d.day


def round_tick(p: float) -> float:
    return round(p / TICK) * TICK


def offset_ticks(points: float, price_below_entry: bool) -> int:
    n = points / TICK
    return math.ceil(n - 0.5) if price_below_entry else math.floor(n + 0.5)


def ret_bps(num: float, den: float) -> float:
    return 0.0 if den == 0 else (num / den - 1.0) * 10000.0


def lag_bps(values: list, periods: int) -> float:
    if len(values) <= periods or values[-1 - periods] == 0:
        return 0.0
    return ret_bps(values[-1], values[-1 - periods])


def percentile(values: list, q: float) -> float:
    a = sorted(values)
    pos = (len(a) - 1) * q
    lo, hi = math.floor(pos), math.ceil(pos)
    return a[lo] if lo == hi else a[lo] + (a[hi] - a[lo]) * (pos - lo)


@dataclass
class Bar:
    open_utc: datetime   # bar open, UTC
    open_et: datetime    # bar open, New York (naive)
    cash_date: date      # CME trading day the bar belongs to
    o: float
    h: float
    l: float
    c: float
    v: float


@dataclass
class Shadow:
    side: int
    entry: float
    stop: float
    target: float
    risk: float
    trig: float
    lock: float
    pending_exit: bool = False
    done: bool = False
    exit: float = 0.0


@dataclass
class Trade:
    cash_date: date
    side: int
    qty: int
    signal_time: datetime | None
    entry_time: datetime | None = None
    entry: float = 0.0
    stop: float = 0.0
    target: float = 0.0
    stop_ticks: int = 0
    exit_time: datetime | None = None
    exit: float = 0.0
    reason: str = ""
    source: str = ""
    path: str = ""
    regime: str = ""
    managed: bool = False
    target_ticks: int = 0
    trig: float = 0.0
    lock: float = 0.0
    cond_done: bool = False
    real: bool = False  # sent to the broker (live), not just simulated

    @property
    def points(self) -> float:
        return self.side * (self.exit - self.entry)

    @property
    def r(self) -> float:
        risk = self.stop_ticks * TICK
        return self.points / risk if risk else 0.0


@dataclass
class Settings:
    fixed_risk: float = 535.0
    max_contracts: int = 2
    round_turn_cost: float = 2.5
    stop_slip_ticks: int = 1
    slippage_ticks: int = 1
    trading_start: date = date(2021, 1, 1)


class Orb1M:
    """``hooks`` (live only) has enter(trade), move_stop(price, trade) and exit(reason); ``live`` is set per bar."""

    def __init__(self, settings: Settings | None = None, log=None, hooks=None):
        self.s = settings or Settings()
        self.log = log or (lambda msg: None)
        self.hooks = hooks
        self.live = False
        self.on_day_done = None  # called after a day's history is recorded (to save the state)
        self._recent: list[Bar] = []
        # rolling history
        self.orb_hist: list[float] = []
        self.close_hist: list[float] = []
        self.session_ret_hist: list[float] = []
        self.rows: list[tuple[date, list[float], bool, int]] = []
        self.seq = 0
        self.model = None
        self.model_key = 0
        self.trades: list[Trade] = []
        self.decisions: list[dict] = []
        self.cash_date: date | None = None
        self.prev_bar: Bar | None = None
        # position / orders
        self.pos: Trade | None = None
        self.pending_entry: Trade | None = None   # market entry, fills next open
        self.pending_exit: str = ""                 # market exit reason, fills next open
        self.new_day_reset(None)

    # ---------- session ----------
    def new_day_reset(self, d):
        self.eligible = False
        self.ref_open = 0.0
        self.ref_captured = False
        self.day_blocked = True
        self.session_ending = False
        self.orb_final = False
        self.consumed = False
        self.cash_exit = False
        self.integrity = False
        self.hist_recorded = False
        self.orb_n = 0
        self.orb_next = ORB_START
        self.orb_h = self.orb_l = self.orb_o = self.orb_c = 0.0
        self.orb_bps = 0.0
        self.q75 = 0.0
        self.q75_ok = False
        self.trend_ok, self.trend_bps = False, 0.0
        self.rth_closes: list[float] = []
        self.tpv = 0.0
        self.vol = 0.0
        self.last_cash_close: datetime | None = None
        self.pend1 = None
        self.pend2 = None
        self.shadow = None

    def begin_cash_date(self, d: date, full_window: bool):
        exposure = self.pos is not None or self.pending_entry is not None
        if self.shadow or self.pend1 or self.pend2:
            self.log(f"{d}: new day before prior state completed")
        self.new_day_reset(d)
        self.cash_date = d
        self.eligible = True
        self.day_blocked = exposure
        self.session_ending = exposure
        self.consumed = exposure
        if len(self.close_hist) >= TREND_CLOSES and self.close_hist[0] > 0 and self.close_hist[-1] > 0:
            self.trend_ok, self.trend_bps = True, (self.close_hist[-1] / self.close_hist[0] - 1) * 10000
        if exposure:
            self.pending_entry = None
            self.request_exit("OvernightExposure")
            return
        if d.weekday() >= 5:
            self.eligible = False
            self.day_blocked = True
            return
        k = dkey(d)
        if k in DEGRADED_EXCLUDE or k in ROLL_EXCLUDE or not full_window:
            self.eligible = False
            self.day_blocked = True
        else:
            self.integrity = True

    def block(self, why: str):
        self.integrity = False
        self.day_blocked = True
        self.consumed = True
        self.log(f"{self.cash_date} blocked: {why}")

    def invalidate(self):
        self.pend1 = self.pend2 = self.shadow = None

    # ---------- orders ----------
    def request_exit(self, reason: str):
        if self.pos is not None and not self.pending_exit:
            self.pending_exit = reason
            if self.pos.real and self.live and self.hooks:
                self.hooks.exit(reason)

    def fill_orders(self, b: Bar):
        """Fills that happen during bar b (before its close is processed)."""
        slip = self.s.slippage_ticks * TICK
        if self.pending_entry is not None:
            t = self.pending_entry
            self.pending_entry = None
            t.entry = b.o + t.side * slip
            t.entry_time = b.open_et
            t.stop = round_tick(t.entry - t.side * t.stop_ticks * TICK)
            t.target = round_tick(t.entry + t.side * t.target_ticks * TICK)
            self.pos = t
            self.trades.append(t)
        if self.pos is None:
            self.pending_exit = ""
            return
        t = self.pos
        if self.pending_exit:
            self.close_pos(b.o - t.side * slip, b.open_et, self.pending_exit)
            return
        hit_stop = b.l <= t.stop if t.side == 1 else b.h >= t.stop
        hit_tgt = b.h >= t.target if t.side == 1 else b.l <= t.target
        if hit_stop:
            px = min(t.stop, b.o) if t.side == 1 else max(t.stop, b.o)
            self.close_pos(px - t.side * slip, b.open_et, "Stop" if not t.managed else "Managed stop")
        elif hit_tgt:
            px = max(t.target, b.o) if t.side == 1 else min(t.target, b.o)
            self.close_pos(px, b.open_et, "Target")

    def close_pos(self, px, when, reason):
        t = self.pos
        t.exit, t.exit_time, t.reason = px, when, reason
        self.pos = None
        self.pending_exit = ""

    # ---------- main ----------
    def on_bar(self, b: Bar, full_window: bool | None = None):
        """One completed bar. ``full_window``: the day's session runs to 16:00 ET (None = use EARLY_CLOSE)."""
        if full_window is None:
            full_window = b.cash_date not in EARLY_CLOSE
        self.fill_orders(b)
        self._recent.append(b)
        del self._recent[:-15]
        close_et = b.open_et + timedelta(minutes=1)
        if self.cash_date != b.cash_date:
            self.begin_cash_date(b.cash_date, full_window)
        # 23:00 UTC reference open on the prior calendar day
        if (self.eligible and not self.ref_captured and b.open_utc.hour == 23 and b.open_utc.minute == 0
                and b.open_utc.date() == self.cash_date - timedelta(days=1)):
            self.ref_open, self.ref_captured = b.o, True
        om = b.open_et.hour * 60 + b.open_et.minute
        cm = close_et.hour * 60 + close_et.minute
        if close_et.date() != b.open_et.date():
            cm += 1440
        on_day = b.open_et.date() == self.cash_date and close_et.date() == self.cash_date
        if self.session_ending:
            self.invalidate()
            self.pending_entry = None
            self.request_exit("SessionEnding")
            return
        if on_day and om >= ORB_START and cm <= CASH_CLOSE:
            if self.last_cash_close is not None and b.open_et != self.last_cash_close:
                self.block("data gap in cash window")
                self.invalidate()
                self.session_ending = True
                self.request_exit("CashDataGap")
                return
            self.last_cash_close = close_et
            if self.eligible and self.integrity and not self.day_blocked and om == ORB_START and not self.ref_captured:
                self.block("missing 23:00 UTC reference open")
                self.invalidate()
                return
            if not self.day_blocked:
                self.rth_closes.append(b.c)
                self.tpv += (b.h + b.l + b.c) / 3.0 * b.v
                self.vol += b.v
        if on_day and self.shadow is not None:
            self.process_shadow(b, cm)
        if on_day and self.pend1 is not None and not self.day_blocked:
            self.process_pend1(b, close_et)
        if on_day and self.pend2 is not None and not self.day_blocked:
            self.process_pend2(b, close_et)
        if on_day and cm >= CASH_CLOSE:
            if self.last_cash_close != datetime.combine(self.cash_date, datetime.min.time()) + timedelta(minutes=CASH_CLOSE):
                self.block("cash close bar missing")
                self.invalidate()
                self.session_ending = True
                self.pending_entry = None
                self.request_exit("CashDataGapAtClose")
                return
            self.finalize_shadow(b.c)
            self.record_history(b.c)
            if not self.cash_exit:
                self.cash_exit = True
                self.day_blocked = True
                self.pending_entry = None
            self.request_exit("CashClose1600ET")
            return
        if self.cash_exit:
            self.request_exit("CashExitFollowup")
            return
        quarter = on_day and 600 <= cm < CASH_CLOSE and cm % 15 == 0
        if self.pos is not None:
            if quarter:
                self.manage_stop(b)
            if on_day and cm == COND_EXIT:
                self.conditional_exit(b)
        else:
            if self.day_blocked or self.cash_date.weekday() >= 5:
                return
            self.capture_orb(b, om, cm, on_day)
            if (not self.day_blocked and self.orb_final and not self.consumed and quarter
                    and self.pos is None and self.pending_entry is None):
                up = b.c >= round_tick(self.orb_h + TICK)
                dn = b.c <= round_tick(self.orb_l - TICK)
                if up or dn:
                    self.evaluate(1 if up else -1, b, close_et)
            return

    def capture_orb(self, b: Bar, om: int, cm: int, on_day: bool):
        if self.orb_final or self.day_blocked:
            return
        if on_day and ORB_START <= om < ORB_END:
            if om != self.orb_next or cm != om + 1:
                self.block("opening range bars missing")
                return
            if self.orb_n == 0:
                self.orb_o, self.orb_h, self.orb_l = b.o, b.h, b.l
            else:
                self.orb_h, self.orb_l = max(self.orb_h, b.h), min(self.orb_l, b.l)
            self.orb_c = b.c
            self.orb_n += 1
            self.orb_next += 1
            if cm != ORB_END:
                return
            if self.orb_n != 15 or self.orb_h < self.orb_l:
                self.block("opening range incomplete")
                return
            self.orb_final = True
            mid = (self.orb_h + self.orb_l) / 2
            self.orb_bps = (self.orb_h - self.orb_l) / mid * 10000 if mid > 0 else 0.0
            self.q75_ok = len(self.orb_hist) == ORB_LOOKBACK
            if self.q75_ok:
                self.q75 = percentile(self.orb_hist, ORB_Q)
        elif on_day and cm > ORB_END and not self.orb_final:
            self.block("opening range not available")

    # ---------- signal ----------
    def signal_window(self, close_et: datetime):
        rb = self._recent
        if len(rb) < 15:
            return None
        win = rb[-15:]
        for i, bar in enumerate(reversed(win)):
            if bar.open_et + timedelta(minutes=1) != close_et - timedelta(minutes=i):
                return None
        hi = max(x.h for x in win)
        lo = min(x.l for x in win)
        if not hi > lo:
            return None
        return win, win[0].o, hi, lo, win[-1].c

    def touches(self, win, side, level):
        return sum(1 for x in win if (side == 1 and x.h >= level) or (side == -1 and x.l <= level))

    def evaluate(self, base: int, b: Bar, close_et: datetime):
        sw = self.signal_window(close_et)
        if sw is None:
            self.consumed = True
            self.block("signal window not exact")
            self.invalidate()
            return
        win, so, sh, sl, sc = sw
        rng = sh - sl
        body = base * (sc - so) / rng
        loc = (sc - sl) / rng if base == 1 else (sh - sc) / rng
        dec = {"date": self.cash_date, "time": close_et, "base": base, "body": body, "loc": loc}
        if body < ADM_BODY or loc < ADM_CLOSE_LOC:
            dec["result"] = "geometry_reject"
            self.decisions.append(dec)
            return
        level = self.orb_h + TICK if base == 1 else self.orb_l - TICK
        n_touch = self.touches(win, base, level)
        dec["touches"] = n_touch
        if n_touch < ADM_TOUCHES:
            self.consumed = True
            dec["result"] = "touch_veto"
            self.decisions.append(dec)
            return
        feats = self.features(base, n_touch, close_et, sc)
        if feats is None:
            self.consumed = True
            self.block("features failed")
            self.invalidate()
            return
        self.consumed = True
        prior = self.session_ret_hist[-1] if self.session_ret_hist else 0.0
        prior_flip = base * prior < -PRIOR_DAY_BPS
        ok, p, nflip, nrows = self.predict(self.cash_date, feats)
        knn_flip = ok and p > FLIP_P
        side = -base if (prior_flip or knn_flip) else base
        source = ("prior_session_and_quarterly_knn" if prior_flip and knn_flip else
                  "prior_session" if prior_flip else "quarterly_knn" if knn_flip else "breakout")
        dec.update(features=feats, prior_bps=prior, prior_flip=prior_flip, knn_ok=ok, knn_p=p,
                   knn_rows=nrows, knn_flip=knn_flip, side=side, source=source)
        self.start_shadow(base, feats, close_et)
        if self.day_blocked:
            return
        live = self.cash_date >= self.s.trading_start
        ctx = self.q75_ok and self.trend_ok
        submit = live and ctx
        dec["submit_allowed"] = submit
        if feats[7] == DIRECT_ELAPSED and feats[4] <= DIRECT_VWAP_BPS:
            dec["result"] = "direct"
            self.decisions.append(dec)
            if submit:
                self.submit(base, b, "rc1_breakout_shadow", "direct_first_signal_near_vwap", close_et)
            return
        weak = side * (sc - so) / rng <= WEAK_BODY
        high = self.q75_ok and self.orb_bps > self.q75
        lvl2 = self.orb_h + TICK if side == 1 else self.orb_l - TICK
        dir_touch = self.touches(win, side, lvl2)
        hv = high and dir_touch <= HIGHVOL_TOUCHES
        dec["result"] = "weak_delay" if weak else ("high_vol_vote" if hv else "refine")
        self.decisions.append(dec)
        if weak or hv:
            self.pend1 = dict(expect=close_et, side=side, need=1 if weak else HIGHVOL_BARS, seen=0, first=0.0,
                              submit=submit, branch="weak_signal_delay_keep" if weak else "high_vol_touch_vote",
                              source=source, base=base, feats=feats, sc=sc)
        else:
            self.final_refine(side, close_et, source, "condition_not_met", submit, base, feats, sc, b)

    def features(self, base, n_touch, close_et, sc):
        if not (self.orb_o > 0 and self.orb_c > 0 and self.vol > 0) or not self.rth_closes:
            return None
        den = self.close_hist[-1] if self.close_hist else self.orb_o
        prior = self.session_ret_hist[-1] if self.session_ret_hist else 0.0
        r5 = lag_bps(self.close_hist, 5)
        r20 = lag_bps(self.close_hist, 20)
        vwap = self.tpv / self.vol
        d30 = self.rth_closes[-31] if len(self.rth_closes) > 30 else self.orb_c
        gap = ret_bps(self.orb_o, den)
        vw = ret_bps(sc, vwap)
        r30 = ret_bps(sc, d30)
        elapsed = (close_et.hour * 60 + close_et.minute - ORB_END) / 15.0
        wd = self.cash_date.weekday()
        mo = self.cash_date.month
        f = [base * gap, base * prior, base * r5, base * r20, base * vw, base * r30, float(base), elapsed,
             self.orb_bps, float(n_touch),
             math.sin(2 * math.pi * wd / 5), math.cos(2 * math.pi * wd / 5),
             math.sin(2 * math.pi * (mo - 1) / 12), math.cos(2 * math.pi * (mo - 1) / 12)]
        if any(math.isnan(x) or math.isinf(x) for x in f):
            return None
        return f

    # ---------- kNN ----------
    def predict(self, d: date, feats):
        if d < PREDICT_START:
            return False, 0.0, 0, 0
        qm = (d.month - 1) // 3 * 3 + 1
        q = date(d.year, qm, 1)
        key = q.year * 10 + (qm - 1) // 3 + 1
        if self.model_key != key:
            self.model = self.fit(q)
            self.model_key = key
        if self.model is None:
            return False, 0.0, 0, 0
        rows, means, scales = self.model
        z = [(feats[j] - means[j]) / scales[j] for j in range(14)]
        dists = []
        for (sess, f, flip, seq) in rows:
            s = 0.0
            for j in range(14):
                dd = (f[j] - means[j]) / scales[j] - z[j]
                s += dd * dd
            dists.append((math.sqrt(s), seq, flip))
        dists.sort(key=lambda x: (x[0], x[1]))
        n = sum(1 for x in dists[:NEIGHBORS] if x[2])
        return True, (n + 2.0) / 19.0, n, len(rows)

    def fit(self, q: date):
        cutoff = q - timedelta(days=1)
        rows = [r for r in self.rows if r[0] >= TRAIN_START and r[0] <= cutoff]
        if len(rows) < max(MIN_ROWS, NEIGHBORS):
            return None
        means, scales = [], []
        for j in range(14):
            m = sum(r[1][j] for r in rows) / len(rows)
            sd = math.sqrt(sum((r[1][j] - m) ** 2 for r in rows) / len(rows))
            means.append(m)
            scales.append(sd if sd > 0 else 1.0)
        return rows, means, scales

    # ---------- shadow pair ----------
    def plan(self, side, trend_ok, trend_bps):
        if self.q75_ok and self.orb_bps > self.q75:
            return HIGH_ORB_TARGET_R, 1.25, 0.0, "high_orb_short_target"
        if trend_ok and side * trend_bps < 0:
            return BASE_TARGET_R, 0.75, 0.1, "countertrend_early_guard"
        return BASE_TARGET_R, 1.25, 0.0, "baseline"

    def start_shadow(self, base, feats, close_et):
        if self.cash_date < TRAIN_START:
            return
        if self.shadow is not None:
            self.invalidate()
            self.day_blocked = True
            return
        self.shadow = dict(session=self.cash_date, expect=close_et, base=base, feats=list(feats),
                           trend_ok=self.trend_ok, trend=self.trend_bps, init=False, invalid=False,
                           bo=None, fa=None)

    def make_shadow(self, side, fill_open, trend_ok, trend):
        e = fill_open + side * TICK
        sp = max(MIN_STOP, min(MAX_STOP, (self.orb_h - self.orb_l) * STOP_ORB_MULTIPLE))
        st = round_tick(e - side * sp)
        risk = side * (e - st)
        tr, trig, lock, _ = self.plan(side, trend_ok, trend)
        sh = Shadow(side, e, st, round_tick(e + side * sp * tr), risk, trig, lock)
        if not risk > 0:
            sh.done, sh.exit = True, e
        return sh

    def process_shadow(self, b: Bar, cm: int):
        s = self.shadow
        if s["invalid"]:
            return
        if not s["init"]:
            if b.open_et < s["expect"]:
                return
            if b.open_et != s["expect"]:
                s["invalid"] = True
                return
            s["bo"] = self.make_shadow(s["base"], b.o, s["trend_ok"], s["trend"])
            s["fa"] = self.make_shadow(-s["base"], b.o, s["trend_ok"], s["trend"])
            s["init"] = True
        self.shadow_bar(s["bo"], b, cm)
        self.shadow_bar(s["fa"], b, cm)
        self.try_label()

    def shadow_bar(self, t: Shadow, b: Bar, cm: int):
        if t.done:
            return
        if t.pending_exit:
            t.exit, t.done = b.o - t.side * TICK, True
            return
        hit_stop = b.l <= t.stop if t.side == 1 else b.h >= t.stop
        hit_tgt = b.h >= t.target if t.side == 1 else b.l <= t.target
        if hit_stop:
            px = min(t.stop, b.o) if t.side == 1 else max(t.stop, b.o)
            t.exit, t.done = px - t.side * TICK, True
        elif hit_tgt:
            t.exit, t.done = (max(t.target, b.o) if t.side == 1 else min(t.target, b.o)), True
        elif cm < CASH_CLOSE and cm % 15 == 0:
            r = t.side * (b.c - t.entry) / t.risk
            if r >= t.trig:
                v = round_tick(t.entry + t.side * t.risk * t.lock)
                t.stop = max(t.stop, v) if t.side == 1 else min(t.stop, v)
            if cm == COND_EXIT and (r < 0 or r >= 1):
                t.pending_exit = True

    def finalize_shadow(self, close_px):
        s = self.shadow
        if s is None:
            return
        if s["invalid"] or not s["init"]:
            self.shadow = None
            return
        for t in (s["bo"], s["fa"]):
            if not t.done:
                t.exit, t.done = close_px - t.side * TICK, True
        self.try_label()

    def try_label(self):
        s = self.shadow
        if s is None or s["invalid"] or not s["init"] or not (s["bo"].done and s["fa"].done):
            return
        bo = s["bo"].side * (s["bo"].exit - s["bo"].entry) * POINT_VALUE - LABEL_COST
        fa = s["fa"].side * (s["fa"].exit - s["fa"].entry) * POINT_VALUE - LABEL_COST
        if (bo > 0) != (fa > 0):
            self.rows.append((s["session"], s["feats"], fa > 0, self.seq))
            self.seq += 1
        self.shadow = None

    # ---------- refinement ----------
    def process_pend1(self, b: Bar, close_et):
        p = self.pend1
        if b.open_et < p["expect"]:
            return
        if b.open_et != p["expect"]:
            self.pend1 = None
            self.day_blocked = True
            return
        if p["seen"] == 0:
            p["first"] = b.o
        p["seen"] += 1
        p["expect"] = close_et
        if p["seen"] < p["need"]:
            return
        side, path = p["side"], p["branch"]
        if p["branch"] == "high_vol_touch_vote":
            move = side * (b.c - p["first"])
            frac = move / (self.orb_h - self.orb_l) if self.orb_h - self.orb_l > 0 else 0.0
            if frac <= 0:
                side, path = -side, "high_vol_vote_flip"
            else:
                path = "high_vol_vote_keep"
        self.pend1 = None
        self.final_refine(side, close_et, p["source"], path, p["submit"], p["base"], p["feats"], p["sc"], b)

    def final_refine(self, side, fill_open_et, source, path, submit, base, feats, sc, b):
        rng = self.orb_h - self.orb_l
        if not rng > 0:
            self.day_blocked = True
            return
        agree = side * base
        aprior = agree * feats[1]
        a30 = agree * feats[5]
        orb_body = side * (self.orb_c - self.orb_o) / rng
        edge = self.orb_h if side == 1 else self.orb_l
        ext = side * (sc - edge) / rng
        c1 = aprior > PRIOR_SESSION_BPS and orb_body <= 0
        c2 = a30 > INTRADAY_BPS and ext <= INTRADAY_EXT
        branch = "prior_session_disagreement" if c1 else ("intraday_continuation" if c2 else "none")
        if branch == "none":
            if submit:
                self.submit(side, b, source, path + "->entry_condition_not_met", fill_open_et)
            return
        self.pend2 = dict(expect=fill_open_et, side=side, need=2 if c1 else 1, seen=0, first=0.0,
                          submit=submit, branch=branch, source=source, path=path)

    def process_pend2(self, b: Bar, close_et):
        p = self.pend2
        if b.open_et < p["expect"]:
            return
        if b.open_et != p["expect"]:
            self.pend2 = None
            self.day_blocked = True
            return
        if p["seen"] == 0:
            p["first"] = b.o
        p["seen"] += 1
        p["expect"] = close_et
        if p["seen"] < p["need"]:
            return
        side = p["side"]
        move = side * (b.c - p["first"])
        if p["branch"] == "prior_session_disagreement":
            final, how = -side, "prior_session_disagreement_reverse"
        elif move > 0:
            final, how = -side, "intraday_continuation_reverse"
        else:
            final, how = side, "intraday_continuation_keep"
        self.pend2 = None
        if p["submit"]:
            self.submit(final, b, p["source"] + "+" + p["branch"], p["path"] + "->" + how, close_et)

    # ---------- entry / management ----------
    def submit(self, side, b: Bar, source, path, when):
        is_long = side == 1
        sp = max(MIN_STOP, min(MAX_STOP, (self.orb_h - self.orb_l) * STOP_ORB_MULTIPLE))
        st = offset_ticks(sp, is_long)
        tr, trig, lock, regime = self.plan(side, self.trend_ok, self.trend_bps)
        tt = offset_ticks(sp * tr, not is_long)
        counter = self.trend_ok and side * self.trend_bps < 0
        high = self.q75_ok and self.orb_bps > self.q75
        cap = self.s.max_contracts
        if high or counter:
            cap = min(cap, 1)
        if st < 1 or tt < 1:
            return
        stop_px = round_tick(b.c - side * st * TICK)
        dist = side * (b.c - stop_px)
        per = dist * POINT_VALUE + max(self.s.stop_slip_ticks, self.s.slippage_ticks) * TICK * POINT_VALUE + self.s.round_turn_cost
        qty = min(cap, int(math.floor(self.s.fixed_risk / per)) if per > 0 else 0)
        if qty < 1:
            self.log(f"{self.cash_date}: sizing skip")
            return
        t = Trade(self.cash_date, side, qty, when, stop_ticks=st, source=source, path=path, regime=regime,
                  target_ticks=tt, trig=trig, lock=lock)
        if self.live and self.hooks:
            t.real = bool(self.hooks.enter(t))
        self.pending_entry = t

    def manage_stop(self, b: Bar):
        t = self.pos
        if t.managed:
            return
        risk = t.stop_ticks * TICK
        r = t.side * (b.c - t.entry) / risk
        if r >= t.trig:
            t.stop = round_tick(t.entry + t.side * risk * t.lock)
            t.managed = True
            if t.real and self.live and self.hooks:
                self.hooks.move_stop(t.stop, t)

    def conditional_exit(self, b: Bar):
        t = self.pos
        if t.cond_done:
            return
        r = t.side * (b.c - t.entry) / (t.stop_ticks * TICK)
        if not (0 <= r < 1):
            t.cond_done = True
            self.request_exit("Conditional1530ET")

    # ---------- history ----------
    def record_history(self, close_px):
        if self.hist_recorded or not (self.eligible and self.integrity and self.orb_final and self.ref_captured):
            return
        self.orb_hist.append(self.orb_bps)
        del self.orb_hist[:-ORB_LOOKBACK]
        self.close_hist.append(close_px)
        del self.close_hist[:-TREND_CLOSES]
        self.session_ret_hist = [ret_bps(close_px, self.ref_open)]
        self.hist_recorded = True
        if self.on_day_done:
            self.on_day_done(self)

    # ---------- saved state (between days) ----------
    def to_state(self) -> dict:
        """Everything a later day needs: ranges, closes, last session return and the model's training rows."""
        return {"v": 1, "cash_date": self.cash_date.isoformat() if self.cash_date else None,
                "orb_hist": [float(x) for x in self.orb_hist], "close_hist": [float(x) for x in self.close_hist],
                "session_ret_hist": [float(x) for x in self.session_ret_hist], "seq": int(self.seq),
                "rows": [[r[0].isoformat(), [float(x) for x in r[1]], bool(r[2]), int(r[3])] for r in self.rows]}

    def load_state(self, st: dict) -> None:
        self.orb_hist = list(st["orb_hist"])
        self.close_hist = list(st["close_hist"])
        self.session_ret_hist = list(st["session_ret_hist"])
        self.seq = int(st["seq"])
        self.rows = [(date.fromisoformat(r[0]), list(r[1]), bool(r[2]), int(r[3])) for r in st["rows"]]
        self.cash_date = date.fromisoformat(st["cash_date"]) if st.get("cash_date") else None
        self.model, self.model_key = None, 0

    def shift_prices(self, offset: float) -> None:
        """Contract roll: NinjaTrader's back-adjusted chart moves older prices onto the new contract."""
        self.close_hist = [c + offset for c in self.close_hist]
