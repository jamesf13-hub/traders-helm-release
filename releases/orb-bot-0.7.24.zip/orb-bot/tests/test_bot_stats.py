"""My bots → Bot stats: the figures, the periods, live trades matched to a bot, and the bundled backtests."""
from datetime import date, datetime, timedelta

import pytest
from zoneinfo import ZoneInfo

from orb_bot import bot_stats as bs
from orb_bot import performance as pf
from orb_bot.models import Side

NY = ZoneInfo("America/New_York")


def _t(day: int, net: float, side: int = 1, session: str = "", risk: float | None = None, month: int = 9):
    a = datetime(2026, month, day, 10, tzinfo=NY)
    return bs.StatTrade(a, a + timedelta(minutes=30), side, 1, net, session, risk)


def test_compute_figures():
    s = bs.compute([_t(1, 100, session="NY AM", risk=50), _t(2, -50, -1, "London", 50), _t(2, -25, 1, "NY AM", 50),
                    _t(3, 200, -1, "London", 100), _t(4, 50, 1, "NY AM", 50, month=10)])
    assert (s.trades, s.wins, s.losses) == (5, 3, 2)
    assert s.net == 275 and s.win_rate == 0.6
    assert s.profit_factor == 350 / 75
    assert s.max_drawdown == -75 and s.drawdown_date == date(2026, 9, 2)
    assert (s.win_streak, s.loss_streak) == (2, 2)
    assert s.best == 200 and s.worst == -50
    assert s.avg_r == (2 - 1 - 0.5 + 2 + 1) / 5
    assert [g.name for g in s.sessions] == ["London", "NY AM"]
    assert s.sessions[1].trades == 3 and s.sessions[1].net == 125
    assert s.months == {(2026, 9): 225, (2026, 10): 50}
    assert s.curve == [(date(2026, 9, 1), 100), (date(2026, 9, 2), 25), (date(2026, 9, 3), 225),
                       (date(2026, 10, 4), 275)]
    empty = bs.compute([])
    assert empty.trades == 0 and empty.win_rate is None and empty.profit_factor is None


def test_periods():
    trades = [_t(1, 1), _t(20, 1), _t(4, 1, month=10)]
    today = date(2026, 10, 16)
    assert len(bs.in_period(trades, None, today)) == 3
    assert len(bs.in_period(trades, 30, today)) == 2
    assert len(bs.in_period(trades, ("year", 2026), today)) == 3
    assert len(bs.in_period(trades, ("year", 2025), today)) == 0


def test_live_trades_matched_to_the_bot():
    tz = ZoneInfo("Australia/Brisbane")

    def trip(bot, hour, session=""):
        a = datetime(2026, 10, 15, hour, 5, tzinfo=NY)
        t = pf.RoundTrip("PRAC", "CON.F.US.MNQ.Z26", Side.SELL, 2, a, a + timedelta(minutes=9), 100.0, 99.0, 4.0, 1.0)
        t.bot, t.log = bot, {"session": session, "stop": "101.0"}
        return t
    trips = [trip("ORB 5M", 1, "ORB 5M"), trip("ORB 5M", 9, "ORB 5M"), trip("Other", 9), trip("ORB M5", 3, "S1")]
    mine = bs.from_round_trips(trips, "ORB 5M", tz, "strategies/orb_5m.py")
    assert [t.session for t in mine] == ["London", "NY AM"]
    assert mine[0].net == 3.0 and mine[0].side == -1 and mine[0].risk == 4.0  # 1 point x 2 contracts x $2
    og = bs.from_round_trips(trips, "ORB M5 O.G", tz)  # trades logged under its old name still count
    assert len(og) == 1 and og[0].session == "S1"


def test_bundled_backtests_load():
    for script in ("strategies/orb_1m.py", "orb_5m.py"):
        trades, note = bs.bundled_backtest(script)
        assert len(trades) > 1000 and "Backtest of ORB" in note
        assert all(t.exit_time >= t.entry_time for t in trades)
    assert {t.session for t in bs.bundled_backtest("orb_5m.py")[0]} == {"London", "NY AM"}
    assert bs.bundled_backtest("my_strategy.py") == ([], "")


def test_panel_renders(qapp=None):
    from PySide6.QtWidgets import QApplication
    QApplication.instance() or QApplication([])
    p = bs.BotStatsPanel()
    assert p.range.text() == "No trades yet"
    p.set_trades("backtest", [_t(1, 100, session="A"), _t(2, -50, session="B")], "note")
    p.set_source("backtest")
    assert "2 trades" in p.range.text() and p.tiles["Win rate"].value.text() == "50.0%"
    assert p.period.findText("2026") >= 0 and p.groups.rowCount() == 3  # two sessions, longs
    p.period.setCurrentIndex(p.period.findText("2026"))
    assert p.period_range(date(2026, 10, 16)) == (date(2026, 1, 1), date(2026, 10, 16))
    p.set_can_run(False)
    assert p.run.isHidden()


def test_eval_odds_pass_blow_and_consistency():
    # +600 a day: a 50K ($3,000 target) passes on day 5 from every start that has 5 days left
    wins = [_t(d, 600) for d in range(1, 31) if date(2026, 9, d).weekday() < 5]
    o = bs.eval_odds(wins, 3000, 2000)
    assert o.passed and not o.blown and set(o.pass_days) == {5}
    # one big day: best day / 0.55 raises the target, so the pass waits
    big = [_t(1, 2900), _t(2, 100), _t(3, 100)]
    o = bs.eval_odds(big, 3000, 2000)
    assert o.passed == 0
    # -700 a day: the $2,000 max loss is hit on day 3
    o = bs.eval_odds([_t(d, -700) for d in (1, 2, 3, 4, 7)], 3000, 2000)
    assert o.blown and o.blow_days[0] == 3
    # the limit trails the end-of-day high: up 1,500 then down 2,100 blows it, though the account is only -600
    o = bs.eval_odds([_t(1, 1500), _t(2, -2100), _t(3, 5000)], 3000, 2000)
    assert o.blow_days[:1] == [2]
    assert bs.eval_odds([_t(1, 1500), _t(2, -2100)], 3000, 2000, scale=0.5).blown == 0


def test_bot_mix_maths():
    from orb_bot import bot_mix as bm
    a = [_t(1, 100), _t(2, -50), _t(3, 100)]
    b = [_t(1, -40), _t(2, 80), _t(3, -40)]
    days = [date(2026, 9, d) for d in (1, 2, 3)]
    assert bm.curve(a, days) == [100, 50, 150]
    assert bm.curve(a + b, days) == [60, 90, 150]
    assert bm.correlation(bm.daily(a), bm.daily(b), days) is None  # too few days to say
    days = [date(2026, 9, 1) + timedelta(days=i) for i in range(12)]
    a = [_t(d.day, 100 if d.day % 2 else -100) for d in days]
    b = [_t(d.day, -100 if d.day % 2 else 100) for d in days]
    assert bm.correlation(bm.daily(a), bm.daily(b), days) == pytest.approx(-1)
    assert bm.scaled(a, 2)[0].net == 200 and bm.scaled(a, 1) is a


def test_bot_mix_panel():
    from PySide6.QtWidgets import QApplication
    from orb_bot.bot_mix import BotMixPanel, MixBot
    QApplication.instance() or QApplication([])
    p = BotMixPanel()
    one, _ = bs.bundled_backtest("orb_1m.py")
    five, _ = bs.bundled_backtest("orb_5m.py")
    p.set_bots("backtest", [MixBot("ORB 1M", one, 535), MixBot("ORB 5M", five, 500), MixBot("ORB M5 O.G", [], None, "x")])
    assert p._ticked == {"ORB 1M", "ORB 5M"}
    assert p.table.rowCount() == 3 and p.tiles["Drawdown saved"].value.text() != "–"
    p._risk["ORB 5M"] = 250
    p._render()
    assert p.table.item(1, 2).text() != ""
