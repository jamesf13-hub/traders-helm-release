"""Bot mix (My bots): tick bots to see each one's running P&L next to all of them together, and whether running
them side by side smooths the curve (a smaller drawdown than they have on their own) and helps a Combine."""
from __future__ import annotations

import math
from dataclasses import dataclass
from datetime import date, timedelta

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QColor, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import (QButtonGroup, QCheckBox, QComboBox, QDoubleSpinBox, QFrame, QGridLayout, QHBoxLayout,
                               QLabel, QPushButton, QSizePolicy, QToolTip, QVBoxLayout, QWidget)

from . import theme
from .bot_stats import (COMBINES, PERIODS, StatTrade, _q, _table, compute, eval_odds, in_period)
from .perf_view import Tile, _fill, money, pct

COLOURS = ["#6f9bff", "#e6a23c", "#c77dff", "#3fc1c9", "#ff8b8b", "#9bd65b", "#f4d35e", "#ff9f68"]
TOTAL = "#e6e9ef"


@dataclass
class MixBot:
    name: str
    trades: list[StatTrade]
    base_risk: float | None = None  # $ risk the trades were made at, so they can be resized
    note: str = ""  # why there are no trades


def scaled(trades: list[StatTrade], k: float) -> list[StatTrade]:
    if k == 1:
        return trades
    return [StatTrade(t.entry_time, t.exit_time, t.side, t.size, t.net * k, t.session, t.risk and t.risk * k,
                      t.fees * k, t.account) for t in trades]


def daily(trades: list[StatTrade]) -> dict[date, float]:
    out: dict[date, float] = {}
    for t in trades:
        d = t.exit_time.date()
        out[d] = out.get(d, 0.0) + t.net
    return out


def correlation(a: dict[date, float], b: dict[date, float], days: list[date]) -> float | None:
    """Of two bots' daily P&L over the same days (0 on days without a trade): +1 move together, 0 unrelated,
    -1 opposite. Unrelated or opposite is what flattens a combined curve."""
    if len(days) < 10:
        return None
    xs = [a.get(d, 0.0) for d in days]
    ys = [b.get(d, 0.0) for d in days]
    mx, my = sum(xs) / len(xs), sum(ys) / len(ys)
    sx = math.sqrt(sum((x - mx) ** 2 for x in xs))
    sy = math.sqrt(sum((y - my) ** 2 for y in ys))
    if not sx or not sy:
        return None
    return sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / (sx * sy)


def curve(trades: list[StatTrade], days: list[date]) -> list[float]:
    d = daily(trades)
    run, out = 0.0, []
    for day in days:
        run += d.get(day, 0.0)
        out.append(run)
    return out


class MultiCurve(QWidget):
    """Several running P&L lines on one chart; the combined one drawn thicker."""

    def __init__(self):
        super().__init__()
        self.days: list[date] = []
        self.series: list[tuple[str, str, list[float], bool]] = []  # name, colour, values, is total
        self.setMinimumHeight(260)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setMouseTracking(True)
        self._r = QRectF()

    def set_series(self, days: list[date], series) -> None:
        self.days, self.series = days, series
        self.update()

    def mouseMoveEvent(self, e):
        if not self.days or self._r.width() <= 0:
            return
        i = round((e.position().x() - self._r.left()) / self._r.width() * (len(self.days) - 1))
        i = min(max(i, 0), len(self.days) - 1)
        lines = [f"{self.days[i]:%a %d %b %Y}"] + [f"{n}: {money(v[i], True)}" for n, _c, v, _t in self.series]
        QToolTip.showText(e.globalPosition().toPoint(), "\n".join(lines), self)

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        r = self._r = QRectF(self.rect()).adjusted(62, 12, -12, -26)
        f = theme.mono_font()
        f.setPixelSize(10)
        p.setFont(f)
        if not self.series or len(self.days) < 2:
            p.setPen(QColor(theme.TEXT_3))
            p.drawText(QRectF(self.rect()), Qt.AlignCenter, "Tick two or more bots that have trades")
            return
        vals = [v for _n, _c, vs, _t in self.series for v in vs]
        lo, hi = min(0.0, *vals), max(0.0, *vals)
        pad = (hi - lo) * 0.08 or 1
        lo, hi = lo - pad, hi + pad
        n = len(self.days)

        def x(i):
            return r.left() + r.width() * i / (n - 1)

        def y(v):
            return r.bottom() - (v - lo) / (hi - lo) * r.height()
        for k in range(5):
            v = lo + (hi - lo) * k / 4
            p.setPen(QPen(QColor(theme.LINE), 1))
            p.drawLine(QPointF(r.left(), y(v)), QPointF(r.right(), y(v)))
            p.setPen(QColor(theme.TEXT_3))
            p.drawText(QRectF(0, y(v) - 8, r.left() - 6, 16), Qt.AlignRight | Qt.AlignVCenter, f"{v:,.0f}")
        p.setPen(QPen(QColor(theme.LINE_2), 1))
        p.drawLine(QPointF(r.left(), y(0)), QPointF(r.right(), y(0)))
        long_span = (self.days[-1] - self.days[0]).days > 300
        every = max(1, n // 6)
        p.setPen(QColor(theme.TEXT_3))
        for i in range(0, n, every):
            if n - 1 - i >= every / 2 or i == 0:
                p.drawText(QRectF(min(max(x(i) - 30, r.left() - 10), r.right() - 50), r.bottom() + 6, 60, 16),
                           Qt.AlignCenter, self.days[i].strftime("%b %y" if long_span else "%d/%m"))
        step = max(1, n // 1200)  # long ranges: about one point per pixel
        for name, colour, vs, total in sorted(self.series, key=lambda s: s[3]):  # the total on top
            path = QPainterPath()
            path.moveTo(x(0), y(vs[0]))
            for i in range(step, n, step):
                path.lineTo(x(i), y(vs[i]))
            path.lineTo(x(n - 1), y(vs[-1]))
            p.setPen(QPen(QColor(colour), 2.4 if total else 1.3))
            p.setBrush(Qt.NoBrush)
            p.drawPath(path)


class BotMixPanel(QFrame):
    """Pick bots and their risk; see their curves alone and together, and the Combine odds of running them all."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("box")
        self.bots: dict[str, dict[str, MixBot]] = {"backtest": {}, "live": {}}
        self.source = "backtest"
        self._ticked: set[str] = set()
        self._risk: dict[str, float] = {}
        lay = QVBoxLayout(self)
        lay.setContentsMargins(16, 14, 16, 16)
        lay.setSpacing(12)
        head = QHBoxLayout()
        t = QLabel("BOT MIX")
        t.setObjectName("statTitle")
        head.addWidget(t)
        head.addSpacing(12)
        seg = QFrame()
        seg.setObjectName("seg")
        sl = QHBoxLayout(seg)
        sl.setContentsMargins(2, 2, 2, 2)
        sl.setSpacing(2)
        self.seg = QButtonGroup(self)
        for key, label in (("backtest", "Backtest"), ("live", "Live trades")):
            b = QPushButton(label)
            b.setCheckable(True)
            b.setChecked(key == "backtest")
            b.clicked.connect(lambda _c=False, k=key: self.set_source(k))
            self.seg.addButton(b)
            sl.addWidget(b)
        head.addWidget(seg)
        head.addSpacing(12)
        self.period = QComboBox()
        for label, v in PERIODS:
            self.period.addItem(label, v)
        self.period.currentIndexChanged.connect(lambda _i: self._render())
        head.addWidget(self.period)
        head.addSpacing(10)
        self.range = QLabel("")
        self.range.setObjectName("muted")
        head.addWidget(self.range)
        head.addStretch(1)
        lay.addLayout(head)
        intro = QLabel("Tick the bots you'd run together on one account. Bots that don't win and lose on the same "
                       "days smooth each other out: the combined drawdown is smaller than theirs added up.")
        intro.setObjectName("muted")
        intro.setWordWrap(True)
        lay.addWidget(intro)
        self.picks = QGridLayout()
        self.picks.setHorizontalSpacing(14)
        self.picks.setVerticalSpacing(6)
        lay.addLayout(self.picks)
        self.chart = MultiCurve()
        lay.addWidget(self.chart)
        tiles = QGridLayout()
        tiles.setHorizontalSpacing(10)
        tiles.setVerticalSpacing(10)
        names = ["Combined net", "Max drawdown", "Drawdown saved", "Net ÷ drawdown",
                 "Worst day", "Losing months", "Days the bots agree", "Pass chance"]
        self.tiles = {n: Tile(n) for n in names}
        for i, n in enumerate(names):
            self.tiles[n].setMinimumHeight(84)
            tiles.addWidget(self.tiles[n], i // 4, i % 4)
        lay.addLayout(tiles)
        ct = QHBoxLayout()
        l2 = QLabel("EACH BOT AND TOGETHER")
        l2.setObjectName("statTitle")
        ct.addWidget(l2)
        ct.addStretch(1)
        self.combine = QComboBox()
        for k, (tgt, mll) in COMBINES.items():
            self.combine.addItem(f"Combine {k}: target ${tgt:,.0f}, max loss ${mll:,.0f}", k)
        self.combine.setCurrentIndex(0)  # 50K
        self.combine.currentIndexChanged.connect(lambda _i: self._render())
        ct.addWidget(self.combine)
        lay.addLayout(ct)
        self.table = _table(["", "TRADES", "NET", "MAX DRAWDOWN", "NET ÷ DD", "WORST DAY", "PASS", "BLOW UP",
                             "DAYS TO PASS"])
        lay.addWidget(self.table)
        self.note = QLabel("")
        self.note.setObjectName("muted")
        self.note.setWordWrap(True)
        lay.addWidget(self.note)
        self._render()

    # --- data -------------------------------------------------------------------------------------
    def set_bots(self, source: str, bots: list[MixBot]) -> None:
        self.bots[source] = {b.name: b for b in bots}
        if not self._ticked:  # first time: tick everything that has trades
            self._ticked = {b.name for b in bots if b.trades}
        if source == self.source:
            self._build_picks()
            self._render()

    def set_source(self, source: str) -> None:
        self.source = source
        for b in self.seg.buttons():
            b.setChecked(b.text().lower().startswith(source[:4]))
        self._build_picks()
        self._render()

    def _build_picks(self) -> None:
        while self.picks.count():
            w = self.picks.takeAt(0).widget()
            if w:
                w.deleteLater()
        for r, (name, b) in enumerate(self.bots[self.source].items()):
            colour = COLOURS[r % len(COLOURS)]
            box = QCheckBox(name)
            box.setChecked(name in self._ticked and bool(b.trades))
            box.setEnabled(bool(b.trades))
            box.setStyleSheet(f"QCheckBox {{ color: {colour if b.trades else theme.TEXT_3}; font-weight: 600; }}")
            box.toggled.connect(lambda on, n=name: (self._ticked.add(n) if on else self._ticked.discard(n),
                                                    self._render()))
            self.picks.addWidget(box, r, 0)
            if b.trades and b.base_risk:
                lab = QLabel("risk a trade")
                lab.setObjectName("muted")
                spin = QDoubleSpinBox()
                spin.setRange(25, 100000)
                spin.setDecimals(0)
                spin.setSingleStep(25)
                spin.setPrefix("$")
                spin.setValue(self._risk.get(name, b.base_risk))
                spin.valueChanged.connect(lambda v, n=name: (self._risk.__setitem__(n, v), self._render()))
                self.picks.addWidget(lab, r, 1)
                self.picks.addWidget(spin, r, 2)
            info = QLabel(b.note if not b.trades else f"{len(b.trades):,} trades")
            info.setObjectName("muted")
            self.picks.addWidget(info, r, 3)
        self.picks.setColumnStretch(3, 1)

    def _chosen(self) -> list[tuple[str, str, list[StatTrade]]]:
        out = []
        for r, (name, b) in enumerate(self.bots[self.source].items()):
            if name not in self._ticked or not b.trades:
                continue
            k = self._risk.get(name, b.base_risk) / b.base_risk if b.base_risk else 1.0
            trades = in_period(scaled(b.trades, k), self.period.currentData(), date.today())
            out.append((name, COLOURS[r % len(COLOURS)], trades))
        return out

    # --- drawing ----------------------------------------------------------------------------------
    def _render(self) -> None:
        chosen = [c for c in self._chosen() if c[2]]
        T = self.tiles
        if not chosen:
            self.chart.set_series([], [])
            for tile in T.values():
                tile.set("–", "")
            _fill(self.table, [])
            self.range.setText("")
            self.note.setText("")
            return
        if len(chosen) > 1:  # compare over the dates they all have trades for
            start = max(min(t.exit_time.date() for t in c[2]) for c in chosen)
            end = min(max(t.exit_time.date() for t in c[2]) for c in chosen)
            chosen = [(n, col, [t for t in tr if start <= t.exit_time.date() <= end]) for n, col, tr in chosen]
        allt = [t for _n, _c, tr in chosen for t in tr]
        if not allt:
            self.chart.set_series([], [])
            return
        first = min(t.exit_time.date() for t in allt)
        last = max(t.exit_time.date() for t in allt)
        days = [first + timedelta(days=i) for i in range((last - first).days + 1)
                if (first + timedelta(days=i)).weekday() < 5]
        self.range.setText(f"{first:%d %b %Y} – {last:%d %b %Y}")
        series = [(n, col, curve(tr, days), False) for n, col, tr in chosen]
        if len(chosen) > 1:
            series.append(("All together", TOTAL, curve(allt, days), True))
        self.chart.set_series(days, series)

        target, mll = COMBINES[self.combine.currentData()]
        rows = []
        own_dd = 0.0
        for n, col, tr in chosen + ([("All together", TOTAL, allt)] if len(chosen) > 1 else []):
            s = compute(tr)
            o = eval_odds(tr, target, mll)
            worst = min(daily(tr).values(), default=0.0)
            if n != "All together":
                own_dd += s.max_drawdown
            d = _q(o.pass_days, 0.5)
            rows.append([(n, col), (f"{s.trades:,}", theme.TEXT_2), (money(s.net, True), theme.UP if s.net > 0 else theme.DOWN),
                         (money(s.max_drawdown), theme.DOWN if s.max_drawdown else None),
                         (f"{s.recovery:.1f}" if s.recovery and s.net > 0 else "–", None), (money(worst), None),
                         (pct(o.pass_rate), None), (pct(o.blow_rate), None), (f"{d}" if d else "–", None)])
        _fill(self.table, rows)

        s = compute(allt)
        o = eval_odds(allt, target, mll)
        dd = s.max_drawdown
        T["Combined net"].set(money(s.net, True), f"{s.trades:,} trades from {len(chosen)} bot{'s' if len(chosen) > 1 else ''}",
                              theme.UP if s.net > 0 else theme.DOWN)
        T["Max drawdown"].set(money(dd), f"{s.drawdown_date:%d %b %Y}" if s.drawdown_date else "", theme.DOWN if dd else None)
        if len(chosen) > 1 and own_dd:
            saved = 1 - dd / own_dd
            T["Drawdown saved"].set(pct(saved), f"vs {money(own_dd)} if their worst dips lined up",
                                    theme.UP if saved > 0.15 else None)
        else:
            T["Drawdown saved"].set("–", "tick two or more bots")
        T["Net ÷ drawdown"].set(f"{s.recovery:.1f}" if s.recovery and s.net > 0 else "–", "higher is smoother")
        dly = daily(allt)
        worst = min(dly.values(), default=0.0)
        T["Worst day"].set(money(worst), f"{min(dly, key=dly.get):%d %b %Y}" if dly else "", theme.DOWN if worst < 0 else None)
        neg = sum(v < 0 for v in s.months.values())
        T["Losing months"].set(f"{neg} of {len(s.months)}", "", theme.UP if s.months and neg / len(s.months) < 0.2 else None)
        if len(chosen) == 2:
            c = correlation(daily(chosen[0][2]), daily(chosen[1][2]), days)
            T["Days the bots agree"].set("–" if c is None else f"{c:+.2f}",
                                         "daily P&L correlation: near 0 or below smooths the curve")
        elif len(chosen) > 2:
            cs = [correlation(daily(a[2]), daily(b[2]), days) for i, a in enumerate(chosen) for b in chosen[i + 1:]]
            cs = [c for c in cs if c is not None]
            T["Days the bots agree"].set(f"{sum(cs) / len(cs):+.2f}" if cs else "–", "average daily P&L correlation")
        else:
            T["Days the bots agree"].set("–", "tick two or more bots")
        d = _q(o.pass_days, 0.5)
        T["Pass chance"].set(pct(o.pass_rate), (f"{self.combine.currentData()} Combine · usually {d} trading days"
                                                 if d else f"{self.combine.currentData()} Combine"),
                             None if o.pass_rate is None else theme.UP if o.pass_rate >= 0.5 else theme.DOWN)
        self.note.setText("All the bots on one account, each at the risk set above. "
                          + ("Compared only over the dates every ticked bot has trades for. " if len(chosen) > 1 else "")
                          + "Pass / blow up: a Combine started on every trading day and played forward (see Bot stats "
                          "for the rules used). Past results, not a promise of future ones.")
