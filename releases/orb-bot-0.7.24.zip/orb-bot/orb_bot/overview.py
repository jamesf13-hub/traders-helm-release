"""The My bots page (robot icon in the left bar): one row per bot on each account the app has open, with its
status, position, open and today's P&L. Click a row for that bot's details: its settings, its stats (live trades
and backtest) and its code."""
from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QComboBox, QFrame, QGridLayout, QHBoxLayout, QHeaderView,
                               QLabel, QPlainTextEdit, QPushButton, QScrollArea, QTableWidget, QTableWidgetItem,
                               QVBoxLayout, QWidget)

from . import theme
from .bot_check import BotCheckPanel, ReviewBanner
from .bot_mix import BotMixPanel
from .bot_stats import BotStatsPanel

COLUMNS = ["BOT", "ACCOUNT", "TYPE", "MARKET", "STATUS", "POSITION", "OPEN P&L", "P&L TODAY", "TRADES", ""]


def _money(v: float | None) -> str:
    if v is None:
        return "–"
    return ("+" if v >= 0 else "−") + f"${abs(v):,.2f}"


def _colour(v: float | None) -> str | None:
    return None if v is None else (theme.UP if v >= 0 else theme.DOWN)


def bot_row(name: str, kind: str, market: str, running: bool, snap: dict | None, account: str = "–") -> dict:
    """What one bot's row shows, from its engine's snapshot (None while stopped)."""
    snap = snap or {}
    trade = snap.get("trade")
    position, upl, can_be, at_be = "–", None, False, False
    if trade:
        side = "Long" if trade["side"] == "buy" else "Short"
        if trade.get("filled"):
            position, upl = f"{side} {trade['size']} @ {trade['entry']:,.2f}", trade.get("unrealized")
            at_be = trade.get("stop") is not None and trade["stop"] == trade["entry"]
            can_be = running and not at_be and (upl or 0) > 0
        else:
            position = f"{side} {trade['size']}, order sent"
    closed = snap.get("closed") or []
    status = ("Test run" if snap.get("mode") == "paper" else "Running") if running else "Stopped"
    return {"name": name, "account": account, "kind": kind, "market": market or "–", "running": running, "status": status,
            "position": position, "upl": upl, "pnl": sum(t.get("pnl") or 0 for t in closed) if closed else None,
            "trades": len(closed), "can_close": running and bool(trade and trade.get("filled")),
            "can_be": can_be, "at_be": at_be}


class AllBots(QScrollArea):
    pick_bot = Signal(int)  # a row was clicked: show that bot's details
    open_bot = Signal(int)  # "Open on chart" for the bot shown
    deploy = Signal(int)  # start (or stop) the bot shown on this account id
    close_bot = Signal(int)  # Close on a row: close that bot's open trade
    be_bot = Signal(int)  # BE on a row: move that bot's stop to its entry

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWidgetResizable(True)
        self.setFrameShape(QFrame.NoFrame)
        inner = QWidget()
        self.setWidget(inner)
        lay = QVBoxLayout(inner)
        lay.setContentsMargins(24, 20, 24, 20)
        lay.setSpacing(14)
        heading = QLabel("My bots")
        heading.setObjectName("h2")
        lay.addWidget(heading)
        self.reviews = QVBoxLayout()  # monthly checks waiting for a look, one banner per bot
        self.reviews.setSpacing(8)
        lay.addLayout(self.reviews)
        box = QFrame()
        box.setObjectName("box")
        bl = QVBoxLayout(box)
        bl.setContentsMargins(14, 10, 14, 12)
        bl.setSpacing(6)
        title = QLabel("EVERY BOT, EVERY ACCOUNT   ·   click a bot to open it")
        title.setObjectName("statTitle")
        bl.addWidget(title)
        self.table = QTableWidget(0, len(COLUMNS))
        self.table.setHorizontalHeaderLabels(COLUMNS)
        self.table.verticalHeader().setVisible(False)
        self.table.setShowGrid(False)
        self.table.setFocusPolicy(Qt.NoFocus)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionMode(QAbstractItemView.NoSelection)
        self.table.setMouseTracking(True)
        self.table.setCursor(Qt.PointingHandCursor)
        head = self.table.horizontalHeader()
        head.setSectionResizeMode(QHeaderView.Stretch)
        head.setSectionResizeMode(1, QHeaderView.ResizeToContents)
        head.setSectionResizeMode(5, QHeaderView.ResizeToContents)
        head.setSectionResizeMode(len(COLUMNS) - 1, QHeaderView.Fixed)
        self.table.setColumnWidth(len(COLUMNS) - 1, 150)
        head.setDefaultAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.table.cellClicked.connect(lambda r, c: r < self._bots and c < len(COLUMNS) - 1 and self.pick_bot.emit(r))
        bl.addWidget(self.table)
        lay.addWidget(box)
        lay.addWidget(self._build_detail())
        self.mix = BotMixPanel()  # filled by the main window when the page opens
        lay.addWidget(self.mix)
        lay.addStretch(1)
        self._bots = 0
        self._last: list | None = None
        self.shown: int | None = None

    # --- one bot's details ------------------------------------------------------------------------
    def _build_detail(self) -> QFrame:
        self.detail = box = QFrame()
        box.setObjectName("box")
        box.hide()
        lay = QVBoxLayout(box)
        lay.setContentsMargins(16, 14, 16, 16)
        lay.setSpacing(12)
        head = QHBoxLayout()
        self.d_title = QLabel()
        self.d_title.setObjectName("h2")
        self.d_sub = QLabel()
        self.d_sub.setObjectName("muted")
        head.addWidget(self.d_title)
        head.addSpacing(10)
        head.addWidget(self.d_sub)
        head.addStretch(1)
        go = QPushButton("Open on chart")
        go.clicked.connect(lambda: self.shown is not None and self.open_bot.emit(self.shown))
        head.addWidget(go)
        lay.addLayout(head)
        dep = QHBoxLayout()
        t = QLabel("DEPLOY TO")
        t.setObjectName("statTitle")
        self.d_account = QComboBox()
        self.d_account.setMinimumWidth(300)
        self.d_account.currentIndexChanged.connect(self._deploy_label)
        self.d_deploy = QPushButton("Deploy")
        self.d_deploy.setObjectName("start")
        self.d_deploy.clicked.connect(lambda: self.d_account.currentData() is not None
                                      and self.deploy.emit(self.d_account.currentData()))
        dep.addWidget(t)
        dep.addSpacing(8)
        dep.addWidget(self.d_account)
        dep.addWidget(self.d_deploy)
        dep.addStretch(1)
        lay.addLayout(dep)
        self.d_facts = QGridLayout()
        self.d_facts.setHorizontalSpacing(18)
        self.d_facts.setVerticalSpacing(6)
        lay.addLayout(self.d_facts)
        self.stats = BotStatsPanel()  # filled by the main window (live trades from Topstep, backtests)
        lay.addWidget(self.stats)
        self.check = BotCheckPanel()
        lay.addWidget(self.check)
        code_head = QHBoxLayout()
        self.d_code_title = QLabel()
        self.d_code_title.setObjectName("statTitle")
        self.d_copy = QPushButton("Copy")
        self.d_copy.clicked.connect(self._copy)
        code_head.addWidget(self.d_code_title)
        code_head.addStretch(1)
        code_head.addWidget(self.d_copy)
        lay.addLayout(code_head)
        self.d_code = QPlainTextEdit()
        self.d_code.setReadOnly(True)
        self.d_code.setLineWrapMode(QPlainTextEdit.NoWrap)
        self.d_code.setFont(theme.mono_font())
        self.d_code.setMinimumHeight(360)
        self.d_code.setStyleSheet(f"QPlainTextEdit {{ background: {theme.BG}; border: 1px solid {theme.LINE}; "
                                  "border-radius: 8px; }")
        lay.addWidget(self.d_code)
        return box

    def set_reviews(self, banners: list[ReviewBanner]) -> None:
        """The banners to show at the top (the main window owns them and wires their buttons)."""
        while self.reviews.count():
            w = self.reviews.takeAt(0).widget()
            if w and w not in banners:
                w.setParent(None)
        for b in banners:
            self.reviews.addWidget(b)

    def _deploy_label(self, _i: int = 0) -> None:
        running = self.d_account.currentData(Qt.UserRole + 1)
        has = self.d_account.currentData() is not None
        self.d_deploy.setEnabled(has)
        self.d_deploy.setObjectName("stop" if running else "start")
        self.d_deploy.setText("Stop on this account" if running else "Deploy")
        self.d_deploy.style().unpolish(self.d_deploy)
        self.d_deploy.style().polish(self.d_deploy)

    def show_detail(self, i: int, d: dict, scroll: bool = True) -> None:
        """d: title, sub, facts [(label, value)], code_title, code, accounts [(id, name, running)], account."""
        self.shown = i
        keep = self.d_account.currentData() if not scroll else d.get("account")
        self.d_account.blockSignals(True)
        self.d_account.clear()
        for acct_id, name, running in d.get("accounts", []):
            self.d_account.addItem(f"{name or acct_id}{'   ● running' if running else ''}", acct_id)
            self.d_account.setItemData(self.d_account.count() - 1, running, Qt.UserRole + 1)
        if not self.d_account.count():
            self.d_account.addItem("No accounts yet: Settings → Check connection", None)
        k = self.d_account.findData(keep)
        self.d_account.setCurrentIndex(max(k, 0))
        self.d_account.blockSignals(False)
        self._deploy_label()
        self.d_title.setText(d["title"])
        self.d_sub.setText(d.get("sub", ""))
        while self.d_facts.count():
            w = self.d_facts.takeAt(0).widget()
            if w:
                w.deleteLater()
        facts = d.get("facts", [])
        per_col = (len(facts) + 1) // 2 or 1
        for k, (label, value) in enumerate(facts):
            col, r = divmod(k, per_col)
            t = QLabel(label.upper())
            t.setObjectName("statTitle")
            v = QLabel(value)
            v.setTextInteractionFlags(Qt.TextSelectableByMouse)
            self.d_facts.addWidget(t, r, col * 2)
            self.d_facts.addWidget(v, r, col * 2 + 1)
        self.d_facts.setColumnStretch(1, 1)
        self.d_facts.setColumnStretch(3, 1)
        self.d_code_title.setText(d.get("code_title", "").upper())
        self.d_code.setPlainText(d.get("code", ""))
        self.d_copy.setText("Copy")
        self.detail.show()
        if scroll:
            QApplication.processEvents()
            self.ensureWidgetVisible(self.detail, 0, 0)

    def _copy(self) -> None:
        QApplication.clipboard().setText(self.d_code.toPlainText())
        self.d_copy.setText("Copied")

    def _actions(self, i: int, r: dict) -> QWidget:
        """BE and Close for a bot with an open trade."""
        w = QWidget()
        lay = QHBoxLayout(w)
        lay.setContentsMargins(0, 0, 4, 0)
        lay.setSpacing(6)
        be = QPushButton("At BE" if r.get("at_be") else "BE")
        be.setToolTip("Move this bot's stop to its entry price (once the price is past the entry)")
        be.setEnabled(bool(r.get("can_be")))
        be.clicked.connect(lambda: self.be_bot.emit(i))
        close = QPushButton("Close")
        close.setObjectName("close")
        close.setToolTip("Close this bot's trade at market (other positions aren't touched)")
        close.clicked.connect(lambda: self.close_bot.emit(i))
        for b in (be, close):
            b.setFixedHeight(28)
            b.setStyleSheet("padding: 0 10px;")
            lay.addWidget(b)
        return w

    def set_rows(self, rows: list[dict]) -> None:
        if rows == self._last:
            return
        self._last = rows
        self._bots = len(rows)
        total_pnl = [r["pnl"] for r in rows if r["pnl"] is not None]
        total_upl = [r["upl"] for r in rows if r["upl"] is not None]
        rows_in = rows
        lines = [[(r["name"], None, True), (r["account"], theme.TEXT_2, False), (r["kind"], theme.TEXT_2, False), (r["market"], None, False),
                  ("● " + r["status"], theme.UP if r["running"] else theme.TEXT_3, False),
                  (r["position"], None, False), (_money(r["upl"]), _colour(r["upl"]), False),
                  (_money(r["pnl"]), _colour(r["pnl"]), False), (str(r["trades"]) if r["trades"] else "–", None, False),
                  ("", None, False)]
                 for r in rows]
        if len(rows) > 1:
            up, pnl = (sum(total_upl) if total_upl else None), (sum(total_pnl) if total_pnl else None)
            lines.append([("Total", theme.TEXT_2, True), ("", None, False), ("", None, False), ("", None, False),
                          (f"{sum(r['running'] for r in rows)} of {len(rows)} running", theme.TEXT_2, False),
                          ("", None, False), (_money(up), _colour(up), False), (_money(pnl), _colour(pnl), False),
                          (str(sum(r["trades"] for r in rows)) or "–", theme.TEXT_2, False), ("", None, False)])
        self.table.setRowCount(len(lines))
        for i, line in enumerate(lines):
            for c, (text, colour, bold) in enumerate(line):
                item = QTableWidgetItem(text)
                if colour:
                    item.setForeground(QColor(colour))
                if bold:
                    f = item.font()
                    f.setBold(True)
                    item.setFont(f)
                self.table.setItem(i, c, item)
            self.table.setRowHeight(i, 38)
            self.table.removeCellWidget(i, len(COLUMNS) - 1)
            if i < len(rows_in) and rows_in[i].get("can_close"):
                self.table.setCellWidget(i, len(COLUMNS) - 1, self._actions(i, rows_in[i]))
        self.table.setFixedHeight(self.table.horizontalHeader().height() + 38 * len(lines) + 4)
