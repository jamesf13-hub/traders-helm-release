"""Template for your own Traders Helm strategy. Copy this file, rename it, and change on_bar.

How it works
  - Traders Helm calls on_bar once for every closed bar (the bot's chart timeframe, e.g. 5 minutes).
  - Call self.buy(...) or self.sell(...) to enter, or self.close() to exit early. Do nothing to wait.
  - Every entry needs a stop and a target. Give each as a price, in ticks, or the target as a multiple of the stop:
        self.buy(stop=21450.25, target=21500)
        self.sell(stop_ticks=40, target_rr=2)          # stop 40 ticks away, target twice as far
  - Size comes from the bot's risk settings in the app (% or $ per trade, max contracts), not from the script.
    The daily loss limit, Topstep's stop and target orders, phone alerts and Performance are handled for you.
  - While a trade is open, new buy/sell calls are ignored (one trade at a time per bot).

What you can use inside on_bar
  bar                      the bar just closed: bar.open, bar.high, bar.low, bar.close, bar.volume, bar.time
  self.bars                every closed bar so far, oldest first (self.bars[-1] is this bar)
  self.closes / highs / lows / opens / volumes     the same as lists of numbers
  self.time                this bar's close time in your time zone (self.time.hour, .minute, .weekday())
  self.position            +size if long, -size if short, 0 if flat
  self.p.<name>            your params below (change them in the bot's Settings tab without editing the file)
  self.tick                tick size (0.25 for NQ / MNQ)
  self.sma(n) self.ema(n) self.rsi(n) self.atr(n)  -> lists like the closes (None until there's enough data)
  self.highest(n) self.lowest(n)                   -> highest high / lowest low of the last n bars
  self.crossed_above(a, b) self.crossed_below(a, b) -> True on the bar a crosses b (b can be a list or a number)

Test it in the bot's Replay tab on past days before starting it for real.
"""
from orb_bot.scripting import Strategy


class MyStrategy(Strategy):
    name = "My strategy"
    params = {
        "stop_ticks": 40,
        "target_rr": 2.0,
    }

    def on_start(self):
        pass  # anything to set up once

    def on_bar(self, bar):
        # Example rule: buy when this bar closes above the highest high of the 20 bars before it.
        if len(self.bars) < 21 or self.position != 0:
            return
        prior_high = max(b.high for b in self.bars[-21:-1])
        if bar.close > prior_high:
            self.buy(stop_ticks=self.p.stop_ticks, target_rr=self.p.target_rr, reason="20-bar breakout")
