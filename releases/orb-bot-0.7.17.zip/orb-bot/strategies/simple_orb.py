"""Example: a simple opening range breakout. Builds the range from the first bars after the open, then takes
the first close outside it, with the stop at the other side of the range."""
from datetime import timedelta

from orb_bot.scripting import Strategy


class SimpleORB(Strategy):
    name = "Simple ORB"
    params = {
        "open_hour": 23,        # range start, your time zone (23:30 Brisbane = 09:30 New York in AEST)
        "open_minute": 30,
        "range_minutes": 15,
        "target_rr": 1.0,
        "last_entry_hour": 2,   # no new entries from this hour
    }

    def on_start(self):
        self.high = self.low = None
        self.traded = False

    def on_bar(self, bar):
        t = self.time  # this bar's close time
        start = t.replace(hour=self.p.open_hour, minute=self.p.open_minute, second=0, microsecond=0)
        if start > t:
            start -= timedelta(days=1)  # after midnight: the range started the evening before
        minutes = (t - start).total_seconds() / 60
        if 0 < minutes <= self.p.range_minutes:                     # bar inside the range window
            if minutes <= self._step():
                self.high, self.low, self.traded = bar.high, bar.low, False
            else:
                self.high, self.low = max(self.high, bar.high), min(self.low, bar.low)
            return
        if self.high is None or self.traded or self.position != 0 or t.hour == self.p.last_entry_hour:
            return
        if bar.close > self.high:
            self.buy(stop=self.low, target_rr=self.p.target_rr, reason="close above the opening range")
            self.traded = True
        elif bar.close < self.low:
            self.sell(stop=self.high, target_rr=self.p.target_rr, reason="close below the opening range")
            self.traded = True

    def _step(self) -> float:
        if len(self.bars) < 2:
            return 5
        return (self.bars[-1].time - self.bars[-2].time).total_seconds() / 60
