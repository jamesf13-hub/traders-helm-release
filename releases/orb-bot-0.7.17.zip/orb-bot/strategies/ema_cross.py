"""Example: trade fast/slow EMA crosses during New York hours, stop beyond the recent swing."""
from orb_bot.scripting import Strategy


class EmaCross(Strategy):
    name = "EMA cross"
    params = {
        "fast": 9,
        "slow": 21,
        "swing_bars": 5,        # stop goes beyond the lowest low / highest high of this many bars
        "target_rr": 1.5,
        "start_hour": 23,       # only enter between these hours (your time zone; 23-02 = New York morning)
        "end_hour": 2,
    }

    def in_hours(self) -> bool:
        h = self.time.hour
        a, b = self.p.start_hour, self.p.end_hour
        return a <= h or h < b if a > b else a <= h < b

    def on_bar(self, bar):
        fast, slow = self.ema(self.p.fast), self.ema(self.p.slow)
        if self.position != 0 or not self.in_hours():
            return
        if self.crossed_above(fast, slow):
            self.buy(stop=self.lowest(self.p.swing_bars) - self.tick, target_rr=self.p.target_rr,
                     reason=f"EMA {self.p.fast} crossed above {self.p.slow}")
        elif self.crossed_below(fast, slow):
            self.sell(stop=self.highest(self.p.swing_bars) + self.tick, target_rr=self.p.target_rr,
                      reason=f"EMA {self.p.fast} crossed below {self.p.slow}")
