"""Qt's web engine (the chart) has to be set up before any QApplication exists, as the app does in gui.main."""
try:
    from PySide6.QtCore import QCoreApplication, Qt
    QCoreApplication.setAttribute(Qt.AA_ShareOpenGLContexts)
    import PySide6.QtWebEngineWidgets  # noqa: F401
except ImportError:
    pass
