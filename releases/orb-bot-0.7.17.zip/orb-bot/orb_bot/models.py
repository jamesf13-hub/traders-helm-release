"""Plain data types shared by every layer. No broker-specific code here."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from enum import Enum


class Side(Enum):
    BUY = "buy"
    SELL = "sell"

    @property
    def sign(self) -> int:
        return 1 if self is Side.BUY else -1


@dataclass(frozen=True)
class Bar:
    time: datetime  # bar open time, timezone-aware
    open: float
    high: float
    low: float
    close: float
    volume: float = 0.0


@dataclass(frozen=True)
class Contract:
    id: str
    name: str
    tick_size: float
    tick_value: float


@dataclass(frozen=True)
class Account:
    id: int
    name: str
    balance: float
    can_trade: bool


@dataclass(frozen=True)
class Signal:
    """What the strategy wants to do. Prices are absolute; the engine turns them into ticks."""
    session: str
    side: Side
    entry_price: float  # reference price (breakout bar close)
    stop_price: float
    target_price: float
    contracts: int
    reason: str


@dataclass
class Position:
    contract_id: str
    side: Side
    size: int
    average_price: float


@dataclass
class OpenOrder:
    id: int
    contract_id: str
    side: Side
    size: int
    type: int
    limit_price: float | None
    stop_price: float | None


@dataclass
class OrderResult:
    ok: bool
    order_id: int | None
    error: str | None = None


@dataclass
class Fill:
    order_id: int
    contract_id: str
    side: Side
    size: int
    price: float
    pnl: float | None  # None on an opening fill
    fees: float
    time: datetime
