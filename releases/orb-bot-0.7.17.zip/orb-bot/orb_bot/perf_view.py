"""The Performance window: TopstepX-style stats for one account (or all of them), from Topstep's own fills,
split by bot."""
from __future__ import annotations

import calendar
import json
import logging
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Callable
from zoneinfo import ZoneInfo

from PySide6.QtCore import QDate, QEvent, QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QColor, QLinearGradient, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import (QAbstractItemView, QCheckBox, QComboBox, QDateEdit, QDialog, QDialogButtonBox,
                               QFrame, QGridLayout, QHBoxLayout, QHeaderView, QLabel, QPushButton, QScrollArea,
                               QSizePolicy, QTableWidget, QTableWidgetItem, QToolTip, QVBoxLayout, QWidget)

from . import performance as pf
from . import theme
from .models import Side
from .layouts import FlowLayout

log = logging.getLogger("orb_bot")

HISTORY_DAYS = 365  # how far back "All time" reaches
ALL_ACCOUNTS = -1


def money(v: float | None, sign: bool = False) -> str:
    if v is None:
        return "–"
    s = f"${abs(v):,.2f}"
    return f"-{s}" if v < 0 else (f"+{s}" if sign and v > 0 else s)


def pct(v: float | None) -> str:
    return "–" if v is None else f"{v * 100:.1f}%"


def pnl_color(v: float | None) -> str | None:
    if not v:
        return None
    return theme.UP if v > 0 else theme.DOWN


class Tile(QFrame):
    """One figure: a small caps title, a big value and an optional note under it."""
    def __init__(self, title: str):
        super().__init__()
        self.setObjectName("box")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(14, 10, 14, 12)
        lay.setSpacing(2)
        t = QLabel(title.upper())
        t.setObjectName("statTitle")
        self.value = QLabel("–")
        self.value.setObjectName("statValue")
        self.note = QLabel("")
        self.note.setObjectName("muted")
        self.note.setWordWrap(True)
        lay.addWidget(t)
        lay.addWidget(self.value)
        lay.addWidget(self.note)

    def set(self, value: str, note: str = "", color: str | None = None):
        self.value.setText(value)
        self.value.setStyleSheet(f"color: {color};" if color else "")
        self.note.setText(note)


class Chart(QWidget):
    """Running P&L as a line with a soft fill ("curve"), daily P&L as green and red bars ("bars"), or the
    account's end-of-day balance ("balance"). Hovering shows the day and its value; clicking a day emits it."""
    day_clicked = Signal(object)

    def __init__(self, kind: str):
        super().__init__()
        self.kind = kind
        self.points: list[tuple[date, float]] = []
        self.hover: int | None = None
        self._xs: list[float] = []
        self.setMinimumHeight(200)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setMouseTracking(True)

    def set_points(self, points: list[tuple[date, float]]):
        self.points = points
        self.hover = None
        self.update()

    def mouseMoveEvent(self, e):
        if not self._xs:
            return
        x = e.position().x()
        i = min(range(len(self._xs)), key=lambda k: abs(self._xs[k] - x))
        if i != self.hover:
            self.hover = i
            self.update()
        d, v = self.points[i]
        label = "Balance" if self.kind == "balance" else "Day" if self.kind == "bars" else "Total"
        QToolTip.showText(e.globalPosition().toPoint(), f"{d:%a %d %b %Y}\n{label}: {money(v)}\nClick for the day's trades",
                          self)
        self.setCursor(Qt.PointingHandCursor)

    def leaveEvent(self, e):
        self.hover = None
        self.update()
        super().leaveEvent(e)

    def mousePressEvent(self, e):
        if self._xs and e.button() == Qt.LeftButton:
            x = e.position().x()
            i = min(range(len(self._xs)), key=lambda k: abs(self._xs[k] - x))
            self.day_clicked.emit(self.points[i][0])

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(self.rect()).adjusted(58, 12, -12, -26)
        f = theme.mono_font()
        f.setPixelSize(10)
        p.setFont(f)
        if not self.points:
            p.setPen(QColor(theme.TEXT_3))
            p.drawText(QRectF(self.rect()), Qt.AlignCenter, "No trades in this period")
            return
        vals = [v for _, v in self.points]
        lo, hi = (min(vals), max(vals)) if self.kind == "balance" else (min(0.0, *vals), max(0.0, *vals))
        if hi == lo:
            hi, lo = hi + 1, lo - 1
        pad = (hi - lo) * 0.08
        lo, hi = lo - pad, hi + pad

        def y(v: float) -> float:
            return r.bottom() - (v - lo) / (hi - lo) * r.height()

        # grid and value labels
        for i in range(5):
            v = lo + (hi - lo) * i / 4
            yy = y(v)
            p.setPen(QPen(QColor(theme.LINE), 1))
            p.drawLine(QPointF(r.left(), yy), QPointF(r.right(), yy))
            p.setPen(QColor(theme.TEXT_3))
            p.drawText(QRectF(0, yy - 8, r.left() - 6, 16), Qt.AlignRight | Qt.AlignVCenter, f"{v:,.0f}")
        if self.kind != "balance":
            p.setPen(QPen(QColor(theme.LINE_2), 1))
            p.drawLine(QPointF(r.left(), y(0)), QPointF(r.right(), y(0)))
        n = len(self.points)
        step = r.width() / max(n, 1)

        def x(i: int) -> float:
            return r.left() + step * (i + 0.5)
        self._xs = [x(i) for i in range(n)]
        if self.hover is not None and self.hover < n:  # a guide line on the hovered day
            p.setPen(QPen(QColor(theme.LINE_2), 1, Qt.DashLine))
            p.drawLine(QPointF(x(self.hover), r.top()), QPointF(x(self.hover), r.bottom()))

        # date labels, at most about six
        p.setPen(QColor(theme.TEXT_3))
        every = max(1, n // 6)
        for i, (d, _) in enumerate(self.points):
            if i % every == 0 or i == n - 1:
                p.drawText(QRectF(x(i) - 30, r.bottom() + 6, 60, 16), Qt.AlignCenter, d.strftime("%d/%m"))

        if self.kind == "balance":
            pts = [QPointF(x(i), y(v)) for i, (_, v) in enumerate(self.points)]
            line = QPainterPath()
            line.moveTo(pts[0])
            for a, b in zip(pts, pts[1:]):  # smooth, like TopstepX's balance line
                mid = (a.x() + b.x()) / 2
                line.cubicTo(QPointF(mid, a.y()), QPointF(mid, b.y()), b)
            area = QPainterPath(line)
            area.lineTo(QPointF(pts[-1].x(), r.bottom()))
            area.lineTo(QPointF(pts[0].x(), r.bottom()))
            area.closeSubpath()
            g = QLinearGradient(0, r.top(), 0, r.bottom())
            g.setColorAt(0, QColor(255, 255, 255, 28))
            g.setColorAt(1, QColor(255, 255, 255, 0))
            p.fillPath(area, g)
            p.setPen(QPen(QColor(theme.TEXT), 1.6))
            p.drawPath(line)
            p.setPen(QPen(QColor(theme.TEXT_2), 1))
            p.setBrush(QColor(theme.BG))
            for i, pt in enumerate(pts):
                rad = 4.5 if i == self.hover else 2.5
                p.drawEllipse(pt, rad, rad)
            return

        if self.kind == "bars":
            w = max(2.0, min(26.0, step * 0.6))
            for i, (_, v) in enumerate(self.points):
                c = QColor(theme.UP if v >= 0 else theme.DOWN)
                top, bottom = sorted((y(v), y(0)))
                p.fillRect(QRectF(x(i) - w / 2, top, w, max(1.0, bottom - top)), c)
            return

        line = QPainterPath()
        pts = [QPointF(r.left(), y(0))] + [QPointF(x(i), y(v)) for i, (_, v) in enumerate(self.points)]
        line.moveTo(pts[0])
        for pt in pts[1:]:
            line.lineTo(pt)
        area = QPainterPath(line)
        area.lineTo(QPointF(pts[-1].x(), y(0)))
        area.closeSubpath()
        up = vals[-1] >= 0
        c = QColor(theme.UP if up else theme.DOWN)
        g = QLinearGradient(0, r.top(), 0, r.bottom())
        top = QColor(c)
        top.setAlpha(70)
        bottom = QColor(c)
        bottom.setAlpha(5)
        g.setColorAt(0, top)
        g.setColorAt(1, bottom)
        p.fillPath(area, g)
        p.setPen(QPen(c, 2))
        p.drawPath(line)
        p.setBrush(c)
        p.drawEllipse(pts[-1], 3.5, 3.5)


class MonthCalendar(QFrame):
    """A month of daily net P&L with weekly totals, like TopstepX's calendar. Clicking a day emits it."""
    day_clicked = Signal(object)

    def __init__(self):
        super().__init__()
        self.cell_days: dict[QLabel, date] = {}
        self.setObjectName("box")
        self.days: dict[date, pf.Group] = {}
        today = date.today()
        self.month = date(today.year, today.month, 1)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(14, 10, 14, 14)
        lay.setSpacing(8)
        head = QHBoxLayout()
        self.prev_btn, self.next_btn = QPushButton("‹"), QPushButton("›")
        for b in (self.prev_btn, self.next_btn):
            b.setObjectName("flat")
        self.prev_btn.clicked.connect(lambda: self.shift(-1))
        self.next_btn.clicked.connect(lambda: self.shift(1))
        self.title = QLabel()
        self.title.setObjectName("h2")
        self.total = QLabel()
        head.addWidget(self.prev_btn)
        head.addWidget(self.title)
        head.addWidget(self.next_btn)
        head.addStretch(1)
        head.addWidget(self.total)
        lay.addLayout(head)
        self.grid = QGridLayout()
        self.grid.setSpacing(4)
        for c, name in enumerate(["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun", "Week"]):
            l = QLabel(name.upper())
            l.setObjectName("lbl")
            l.setAlignment(Qt.AlignCenter)
            self.grid.addWidget(l, 0, c)
        self.cells: list[list[QLabel]] = []
        for row in range(6):
            cells = []
            for c in range(8):
                l = QLabel()
                l.setTextFormat(Qt.RichText)
                l.setAlignment(Qt.AlignCenter)
                l.setMinimumHeight(54)
                l.installEventFilter(self)
                self.grid.addWidget(l, row + 1, c)
                cells.append(l)
            self.cells.append(cells)
        lay.addLayout(self.grid)
        self.render()

    def eventFilter(self, obj, e):
        if e.type() == QEvent.MouseButtonPress and obj in self.cell_days and self.days.get(self.cell_days[obj]):
            self.day_clicked.emit(self.cell_days[obj])
            return True
        return super().eventFilter(obj, e)

    def set_days(self, days: dict[date, pf.Group]):
        self.days = days
        self.render()

    def shift(self, months: int):
        m = self.month.month - 1 + months
        self.month = date(self.month.year + m // 12, m % 12 + 1, 1)
        self.render()

    @staticmethod
    def _cell(top: str, g: pf.Group | None, faded: bool = False) -> tuple[str, str]:
        if not g or not g.trades:
            colour = theme.TEXT_3
            return (f"<span style='color:{colour}'>{top}</span>",
                    f"background:{theme.PANEL_2 if not faded else 'transparent'}; border-radius:6px;")
        c = theme.UP if g.net > 0 else theme.DOWN if g.net < 0 else theme.TEXT_2
        bg = "rgba(47,196,137,0.13)" if g.net > 0 else "rgba(240,93,94,0.13)" if g.net < 0 else theme.PANEL_2
        html = (f"<span style='color:{theme.TEXT_3}; font-size:10px'>{top}</span><br>"
                f"<b style='color:{c}'>{money(g.net)}</b><br>"
                f"<span style='color:{theme.TEXT_2}; font-size:10px'>{g.trades} trade{'s' if g.trades != 1 else ''}</span>")
        return html, f"background:{bg}; border-radius:6px;"

    def render(self):
        y, m = self.month.year, self.month.month
        self.title.setText(self.month.strftime("%B %Y"))
        weeks = calendar.Calendar(0).monthdatescalendar(y, m)
        month_net = 0.0
        for row in range(6):
            week = weeks[row] if row < len(weeks) else None
            for cell in self.cells[row]:
                cell.setVisible(week is not None)
            wk = pf.Group("week")
            for c in range(7):
                cell = self.cells[row][c]
                if week is None:
                    cell.setText("")
                    cell.setStyleSheet("")
                    continue
                d = week[c]
                g = self.days.get(d)
                self.cell_days[cell] = d
                cell.setCursor(Qt.PointingHandCursor if g and d.month == m else Qt.ArrowCursor)
                if d.month == m and g:
                    wk.trades += g.trades
                    wk.net += g.net
                    month_net += g.net
                html, style = self._cell(str(d.day), g if d.month == m else None, d.month != m)
                cell.setText(html)
                cell.setStyleSheet(style)
            wcell = self.cells[row][7]
            if week is None:
                wcell.setText("")
                wcell.setStyleSheet("")
            else:
                html, style = self._cell(f"Week {row + 1}", wk)
                wcell.setText(html)
                wcell.setStyleSheet(style + f" border: 1px solid {theme.LINE};")
        self.total.setText(f"Month: <b style='color:{pnl_color(month_net) or theme.TEXT}'>{money(month_net)}</b>")


def _table(headers: list[str]) -> QTableWidget:
    t = QTableWidget(0, len(headers))
    t.setHorizontalHeaderLabels(headers)
    t.verticalHeader().setVisible(False)
    t.setShowGrid(False)
    t.setFocusPolicy(Qt.NoFocus)
    t.setEditTriggers(QAbstractItemView.NoEditTriggers)
    t.setSelectionMode(QAbstractItemView.NoSelection)
    t.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
    t.horizontalHeader().setDefaultAlignment(Qt.AlignLeft | Qt.AlignVCenter)
    return t


def _fill(t: QTableWidget, rows: list[list[tuple[str, str | None]]], max_height: int | None = None):
    t.setRowCount(len(rows))
    for r, row in enumerate(rows):
        for c, (text, colour) in enumerate(row):
            it = QTableWidgetItem(text)
            it.setForeground(QColor(colour or theme.TEXT))
            t.setItem(r, c, it)
    h = t.horizontalHeader().height() + sum(t.rowHeight(i) for i in range(len(rows))) + 6
    t.setFixedHeight(min(h, max_height) if max_height else h)


class PerformanceWindow(QWidget):
    """`accounts()` gives [(id, name)], `fetch(account_id, since)` gives that account's Topstep fills, and
    `run(fn, callback)` runs fn in the background then calls callback(result, error) on the main thread."""

    def __init__(self, accounts: Callable[[], list[tuple[int, str]]], fetch: Callable, run: Callable,
                 bot_log: Path, tz: ZoneInfo, account_id: int | None = None, parent=None,
                 balance: Callable[[int], float | None] | None = None, bars: Callable | None = None,
                 layout_file: Path | None = None):
        # inside the main window (a parent given) it's a page; never briefly a window of its own
        super().__init__(parent, Qt.Widget if parent is not None else Qt.Window)
        self.accounts_fn, self.fetch, self.run = accounts, fetch, run
        self.balance_fn, self.bars_fn, self.layout_file = balance, bars, layout_file
        self.hidden: set[str] = self._load_hidden()
        self.bot_log, self.tz = bot_log, tz
        self.trips: list[pf.RoundTrip] = []
        self.loaded_for: int | None = None
        self.setWindowTitle(f"Performance · {theme.APP_NAME}")
        self.resize(1100, 860)
        self._build()
        self.reload_accounts(account_id)

    # --- layout ------------------------------------------------------------------------------------
    def _build(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        bar = QFrame()
        bar.setObjectName("header")
        hl = QVBoxLayout(bar)
        hl.setContentsMargins(0, 0, 0, 0)
        h = FlowLayout(spacing=8)  # wraps when the window is narrow
        h.setContentsMargins(16, 10, 16, 10)
        hl.addLayout(h)
        title = QLabel("Performance")
        title.setObjectName("brand")
        self.account = QComboBox()
        self.account.setMinimumWidth(220)
        self.account.activated.connect(lambda _i: self.load())
        self.period = QComboBox()
        self.period.addItems(pf.PERIODS + ["Custom"])
        self.period.setCurrentText("This month")
        self.period.activated.connect(self._period_changed)
        self.start, self.end = QDateEdit(), QDateEdit()
        for d in (self.start, self.end):
            d.setCalendarPopup(True)
            d.setDisplayFormat("dd/MM/yyyy")
            d.dateChanged.connect(lambda _d: self.period.currentText() == "Custom" and self.render())
        self.bot = QComboBox()
        self.bot.setMinimumWidth(170)
        self.bot.activated.connect(lambda _i: self.render())
        self.market = QComboBox()
        self.market.setMinimumWidth(170)
        self.market.activated.connect(lambda _i: self.render())
        self.custom_btn = QPushButton("Customise")
        self.custom_btn.setToolTip("Choose which figures, charts and tables this page shows")
        self.custom_btn.clicked.connect(self.customise)
        self.refresh_btn = QPushButton("Refresh")
        self.refresh_btn.clicked.connect(lambda: self.load(force=True))
        self.status = QLabel("")
        self.status.setObjectName("muted")
        self.status.setWordWrap(True)
        self.status.setMaximumWidth(320)
        h.addWidget(title)
        h.addWidget(self.account)
        h.addWidget(self.period)
        h.addWidget(self.start)
        h.addWidget(QLabel("to"))
        h.addWidget(self.end)
        h.addWidget(self.bot)
        h.addWidget(self.market)
        h.add_stretch()
        h.addWidget(self.status)
        h.addWidget(self.custom_btn)
        h.addWidget(self.refresh_btn)
        outer.addWidget(bar)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        body = QWidget()
        lay = QVBoxLayout(body)
        lay.setContentsMargins(16, 14, 16, 18)
        lay.setSpacing(12)

        self.grid = grid = QGridLayout()
        grid.setSpacing(10)
        self.tile_names = names = [("net", "Total P&L"), ("win", "Trade win %"), ("ratio", "Avg win / avg loss"),
                 ("pf", "Profit factor"), ("daywin", "Day win %"), ("bestday", "Best day % of total profit"),
                 ("trades", "Trades"), ("dur", "Avg trade duration"), ("dir", "Long trades"),
                 ("dd", "Max drawdown"), ("best", "Best trade"), ("worst", "Worst trade"),
                 ("topday", "Most profitable weekday"), ("lowday", "Least profitable weekday"),
                 ("busy", "Most active weekday"), ("fees", "Fees")]
        self.tiles: dict[str, Tile] = {}
        for key, name in names:
            self.tiles[key] = Tile(name)
        lay.addLayout(grid)
        # Everything below the figures, by the key Customise uses: (name, widget).
        self.sections: dict[str, tuple[str, QWidget]] = {}

        def chart_box(title_text: str, chart: Chart, height: int) -> QFrame:
            box = QFrame()
            box.setObjectName("box")
            bl = QVBoxLayout(box)
            bl.setContentsMargins(14, 10, 14, 10)
            t = QLabel(title_text.upper())
            t.setObjectName("statTitle")
            bl.addWidget(t)
            bl.addWidget(chart, 1)
            box.setMinimumHeight(height)
            return box

        self.balance = Chart("balance")
        box = chart_box("Daily account balance", self.balance, 440)
        self.sections["balance"] = ("Daily account balance", box)
        lay.addWidget(box)
        charts = QHBoxLayout()
        charts.setSpacing(10)
        self.curve, self.bars = Chart("curve"), Chart("bars")
        for key, title_text, chart in (("curve", "Cumulative P&L", self.curve), ("bars", "Daily P&L", self.bars)):
            box = chart_box(title_text, chart, 260)
            self.sections[key] = (title_text, box)
            charts.addWidget(box, 1)
        lay.addLayout(charts)

        self.calendar = MonthCalendar()
        for w in (self.balance, self.curve, self.bars, self.calendar):
            w.day_clicked.connect(self.open_day)
        self.sections["calendar"] = ("Calendar", self.calendar)
        lay.addWidget(self.calendar)

        for key, title_text, attr, headers in (
                ("by_bot", "By bot", "by_bot", ["BOT", "TRADES", "WIN %", "NET P&L"]),
                ("by_market", "By market", "by_market", ["MARKET", "TRADES", "WIN %", "NET P&L"]),
                ("trades", "Trades", "trades_table", ["DATE", "BOT", "MARKET", "SIDE", "SIZE", "ENTRY TIME",
                                                      "EXIT TIME", "DURATION", "ENTRY", "EXIT", "POINTS", "FEES",
                                                      "NET P&L"])):
            wrap = QWidget()
            wl = QVBoxLayout(wrap)
            wl.setContentsMargins(0, 0, 0, 0)
            wl.setSpacing(6)
            t = QLabel(title_text.upper() + ("   ·   click a trade for its details" if key == "trades" else ""))
            t.setObjectName("statTitle")
            wl.addWidget(t)
            table = _table(headers)
            setattr(self, attr, table)
            wl.addWidget(table)
            self.sections[key] = (title_text, wrap)
            lay.addWidget(wrap)
        self._trade_rows: list[pf.RoundTrip] = []
        self._hover_row = -1
        tt = self.trades_table
        tt.setMouseTracking(True)
        tt.viewport().setCursor(Qt.PointingHandCursor)
        tt.cellEntered.connect(lambda r, _c: self._hover_trade(r))
        tt.cellClicked.connect(lambda r, _c: self.open_trade(r))
        tt.viewport().installEventFilter(self)
        note = QLabel("Figures come from Topstep's own record of the account's fills, after fees, so they should "
                      "match TopstepX. Trades are grouped flat to flat; trades the app didn't place show as "
                      f"\"{pf.MANUAL}\".")
        note.setObjectName("muted")
        note.setWordWrap(True)
        lay.addWidget(note)
        lay.addStretch(1)
        scroll.setWidget(body)
        outer.addWidget(scroll, 1)
        self._apply_layout()
        self._period_changed()

    # --- customise ---------------------------------------------------------------------------------
    def _load_hidden(self) -> set[str]:
        try:
            return set(json.loads(self.layout_file.read_text()).get("hidden", [])) if self.layout_file else set()
        except (OSError, ValueError):
            return set()

    def _save_hidden(self) -> None:
        if not self.layout_file:
            return
        try:
            self.layout_file.parent.mkdir(parents=True, exist_ok=True)
            self.layout_file.write_text(json.dumps({"hidden": sorted(self.hidden)}))
        except OSError as e:
            log.debug("couldn't save the Performance layout: %s", e)

    def _apply_layout(self) -> None:
        """Show what's switched on; the figures close up into rows of four (two in a narrow window)."""
        cols = self._cols = 4 if self.width() >= 900 else 2
        for key, tile in self.tiles.items():
            self.grid.removeWidget(tile)
            tile.setVisible(key not in self.hidden)
        shown = [k for k, _n in self.tile_names if k not in self.hidden]
        for i, key in enumerate(shown):
            self.grid.addWidget(self.tiles[key], i // cols, i % cols)
        for key, (_name, w) in self.sections.items():
            w.setVisible(key not in self.hidden)

    def resizeEvent(self, e):  # noqa: N802
        super().resizeEvent(e)
        if getattr(self, "_cols", None) != (4 if self.width() >= 900 else 2) and hasattr(self, "tiles"):
            self._apply_layout()

    def customise(self) -> None:
        """Tick what the page shows. Changes apply as you tick and are remembered."""
        dlg = QDialog(self)
        dlg.setWindowTitle("Customise Performance")
        lay = QVBoxLayout(dlg)
        lay.setContentsMargins(18, 16, 18, 16)
        lay.setSpacing(10)
        boxes: dict[str, QCheckBox] = {}

        def group(title: str, items: list[tuple[str, str]]) -> None:
            t = QLabel(title.upper())
            t.setObjectName("statTitle")
            lay.addWidget(t)
            g = QGridLayout()
            g.setHorizontalSpacing(24)
            g.setVerticalSpacing(6)
            for i, (key, name) in enumerate(items):
                cb = QCheckBox(name)
                cb.setChecked(key not in self.hidden)
                cb.toggled.connect(lambda on, k=key: self._toggle(k, on))
                boxes[key] = cb
                g.addWidget(cb, i // 2, i % 2)
            lay.addLayout(g)

        group("Figures", self.tile_names)
        group("Charts, calendar and tables", [(k, n) for k, (n, _w) in self.sections.items()])
        buttons = QDialogButtonBox(QDialogButtonBox.Close)
        show_all = buttons.addButton("Show everything", QDialogButtonBox.ResetRole)
        show_all.clicked.connect(lambda: [cb.setChecked(True) for cb in boxes.values()])
        buttons.rejected.connect(dlg.reject)
        lay.addWidget(buttons)
        dlg.exec()

    def _toggle(self, key: str, on: bool) -> None:
        (self.hidden.discard if on else self.hidden.add)(key)
        self._save_hidden()
        self._apply_layout()

    # --- trades: hover and click -------------------------------------------------------------------
    def _hover_trade(self, row: int) -> None:
        t = self.trades_table
        for r, colour in ((self._hover_row, None), (row, theme.PANEL_2)):
            if 0 <= r < t.rowCount():
                for c in range(t.columnCount()):
                    it = t.item(r, c)
                    if it:
                        it.setBackground(QColor(colour) if colour else QColor(0, 0, 0, 0))
        self._hover_row = row

    def eventFilter(self, obj, e):
        if obj is self.trades_table.viewport() and e.type() == e.Type.Leave:
            self._hover_trade(-1)
        return super().eventFilter(obj, e)

    def open_day(self, day: date) -> None:
        """A day's trades: one trade opens straight away, several are listed to pick from."""
        trips = sorted((t for t in self.selected() if pf.trade_day(t) == day),
                       key=lambda t: t.entry_time)
        log.info("clicked %s: %d trade%s", day.strftime("%a %d %b"), len(trips), "" if len(trips) == 1 else "s")
        if not trips:
            QToolTip.showText(self.cursor().pos(), f"No trades on {day:%a %d %b}", self)
            return
        if len(trips) == 1:
            return self._open(trips[0])
        dlg = QDialog(self)
        dlg.setWindowTitle(f"{day:%A %d %B} · {theme.APP_NAME}")
        dlg.resize(1080, 120 + 34 * len(trips))
        lay = QVBoxLayout(dlg)
        lay.setContentsMargins(18, 16, 18, 16)
        net = sum(t.net for t in trips)
        head = QLabel(f"{day:%A %d %B}  ·  {len(trips)} trades  ·  "
                      f"<b style='color:{pnl_color(net) or theme.TEXT}'>{money(net)}</b>")
        head.setObjectName("h2")
        lay.addWidget(head)
        accounts = sorted({t.account for t in trips if t.account})
        hint = QLabel(("  ·  ".join(accounts) + "  ·  " if accounts else "") + "Click a trade for its details")
        hint.setObjectName("muted")
        lay.addWidget(hint)
        table = _table(["BOT", "MARKET", "SIDE", "SIZE", "IN", "OUT", "DURATION", "ENTRY", "EXIT", "POINTS", "FEES",
                        "NET P&L"])
        rows = []
        for t in trips:
            a, b = t.entry_time.astimezone(self.tz), t.exit_time.astimezone(self.tz)
            rows.append([(t.bot, None), (pf.market_label(t.market), None),
                         ("Long" if t.side is Side.BUY else "Short", theme.UP if t.side is Side.BUY else theme.DOWN),
                         (str(t.size), None), (a.strftime("%H:%M:%S"), None), (b.strftime("%H:%M:%S"), None),
                         (pf.fmt_duration(t.duration), None),
                         (f"{t.entry_price:,.2f}", None), (f"{t.exit_price:,.2f}", None),
                         (f"{t.points:+,.2f}", pnl_color(t.points)), (money(-t.fees), theme.TEXT_2),
                         (money(t.net), pnl_color(t.net))])
        _fill(table, rows)
        for c in (0, 1):  # bot and market names in full
            table.horizontalHeader().setSectionResizeMode(c, QHeaderView.ResizeToContents)
        table.viewport().setCursor(Qt.PointingHandCursor)
        table.cellClicked.connect(lambda r, _c: self._open(trips[r]))
        lay.addWidget(table)
        lay.addStretch(1)
        dlg.exec()

    def _open(self, trip: pf.RoundTrip) -> None:
        from .trade_view import TradeDetail
        log.info("trade details: %s %s", trip.bot, trip.entry_time.astimezone(self.tz).strftime("%d %b %H:%M:%S"))
        try:
            TradeDetail(trip, self.tz, self.bars_fn, self.run, self).exec()
        except Exception as e:  # noqa: BLE001 - say why instead of silently doing nothing
            log.exception("trade details didn't open")
            QToolTip.showText(self.cursor().pos(), f"Couldn't open the trade's details: {e}", self)

    def open_trade(self, row: int) -> None:
        if not 0 <= row < len(self._trade_rows):
            return
        self._open(self._trade_rows[row])

    # --- data --------------------------------------------------------------------------------------
    def reload_accounts(self, select: int | None = None):
        current = select if select is not None else self.account.currentData()
        self.account.blockSignals(True)
        self.account.clear()
        accts = self.accounts_fn()
        for acct_id, name in accts:
            self.account.addItem(name, acct_id)
        if len(accts) > 1:
            self.account.addItem("All accounts", ALL_ACCOUNTS)
        i = self.account.findData(current)
        self.account.setCurrentIndex(max(i, 0))
        self.account.blockSignals(False)
        self.load()

    def load(self, force: bool = False):
        acct = self.account.currentData()
        if acct is None:
            self.status.setText("Log in and choose an account first (Account menu).")
            return
        if acct == self.loaded_for and not force:
            self.render()
            return
        ids = [(a, n) for a, n in self.accounts_fn() if acct in (ALL_ACCOUNTS, a)]
        since = datetime.now(timezone.utc) - timedelta(days=HISTORY_DAYS)
        self.status.setText("Loading trades from Topstep…")
        self.refresh_btn.setEnabled(False)

        def work():
            trips = []
            for a, name in ids:
                trips += pf.round_trips(self.fetch(a, since), name)
            pf.label_bots(trips, pf.read_bot_log(self.bot_log), self.tz)
            return trips

        def done(trips, err):
            self.refresh_btn.setEnabled(True)
            if err:
                self.status.setText(f"Couldn't load trades: {err}")
                return
            self.trips, self.loaded_for = trips, acct
            self.status.setText(f"Updated {datetime.now().strftime('%H:%M')}")
            self._fill_bots()
            self.render()
        self.run(work, done)

    def _fill_bots(self):
        current = self.bot.currentData()
        self.bot.blockSignals(True)
        self.bot.clear()
        self.bot.addItem("All bots", "")
        for name in sorted({t.bot for t in self.trips}, key=lambda n: (n == pf.MANUAL, n)):
            self.bot.addItem(name, name)
        i = self.bot.findData(current)
        self.bot.setCurrentIndex(max(i, 0))
        self.bot.blockSignals(False)
        current = self.market.currentData()
        self.market.blockSignals(True)
        self.market.clear()
        self.market.addItem("All markets", "")
        for m in sorted({t.market for t in self.trips}):
            self.market.addItem(pf.market_label(m), m)
        self.market.setCurrentIndex(max(self.market.findData(current), 0))
        self.market.blockSignals(False)

    def _period_changed(self, _i: int = 0):
        custom = self.period.currentText() == "Custom"
        if not custom:
            start, end = pf.period_range(self.period.currentText(), pf.trading_day(datetime.now(self.tz)))
            for w, d in ((self.start, start), (self.end, end)):
                w.blockSignals(True)
                w.setDate(QDate(d.year, d.month, d.day) if d else QDate.currentDate().addDays(-HISTORY_DAYS + 1)
                          if w is self.start else QDate.currentDate())
                w.blockSignals(False)
        self.start.setEnabled(custom)
        self.end.setEnabled(custom)
        self.render()

    def _balances(self) -> list[tuple[date, float]]:
        """End-of-day balances over the period, from the account's balance now and every trade since."""
        acct = self.account.currentData()
        if self.balance_fn is None or acct is None:
            return []
        ids = [a for a, _n in self.accounts_fn() if acct in (ALL_ACCOUNTS, a)]
        now = [self.balance_fn(a) for a in ids]
        if not ids or any(v is None for v in now):
            return []
        s, e = self.start.date(), self.end.date()
        start = date(s.year(), s.month(), s.day())
        if self.period.currentText() == "All time" and self.trips:
            # start the day before the first trade, not a year of flat line before it
            first = min(pf.trade_day(t) for t in self.trips)
            start = max(start, first - timedelta(days=1))
        return pf.daily_balances(self.trips, self.tz, sum(now), start,
                                 date(e.year(), e.month(), e.day()), pf.trading_day(datetime.now(self.tz)))

    def selected(self) -> list[pf.RoundTrip]:
        s, e = self.start.date(), self.end.date()
        return pf.filter_trips(self.trips, self.tz, date(s.year(), s.month(), s.day()),
                               date(e.year(), e.month(), e.day()), self.bot.currentData() or "",
                               self.market.currentData() or "")

    # --- drawing -----------------------------------------------------------------------------------
    def render(self):
        if not hasattr(self, "tiles"):
            return
        trips = self.selected()
        s = pf.summarise(trips, self.tz)
        T = self.tiles
        T["net"].set(money(s.net), f"{s.wins} won · {s.losses} lost", pnl_color(s.net))
        T["win"].set(pct(s.win_rate), f"{s.wins} of {s.trades} trades")
        T["ratio"].set("–" if s.win_loss_ratio is None else f"{s.win_loss_ratio:.2f}",
                       f"{money(s.avg_win)} / {money(s.avg_loss)}")
        T["pf"].set("–" if s.profit_factor is None else f"{s.profit_factor:.2f}",
                    f"won {money(s.gross_win)} · lost {money(s.gross_loss)}")
        T["daywin"].set(pct(s.day_win_rate), f"{sum(g.net > 0 for g in s.days.values())} of {len(s.days)} days")
        bd = s.best_day
        T["bestday"].set(pct(s.best_day_share), f"{bd[0].strftime('%a %d %b')}: {money(bd[1])}" if bd else "")
        T["trades"].set(str(s.trades), f"{s.contracts} contracts")
        T["dur"].set(pf.fmt_duration(s.avg_duration),
                     f"wins {pf.fmt_duration(s.avg_win_duration)} · losses {pf.fmt_duration(s.avg_loss_duration)}")
        T["dir"].set(pct(s.longs / s.trades if s.trades else None), f"{s.longs} long · {s.trades - s.longs} short")
        T["dd"].set(money(s.max_drawdown), "from the highest point of the period",
                    theme.DOWN if s.max_drawdown < 0 else None)
        for key, t in (("best", s.best), ("worst", s.worst)):
            if t is None:
                T[key].set("–")
            else:
                side = "Long" if t.side is Side.BUY else "Short"
                T[key].set(money(t.net), f"{side} {t.size} @ {t.entry_price:,.2f} → {t.exit_price:,.2f} · "
                           f"{t.exit_time.astimezone(self.tz).strftime('%d/%m %H:%M')} · {t.bot}", pnl_color(t.net))
        wd = s.weekdays
        top = max(wd, key=lambda g: g.net) if wd else None
        low = min(wd, key=lambda g: g.net) if wd else None
        busy = max(wd, key=lambda g: g.trades) if wd else None
        T["topday"].set(top.name if top else "–", money(top.net) if top else "", pnl_color(top.net) if top else None)
        T["lowday"].set(low.name if low else "–", money(low.net) if low else "", pnl_color(low.net) if low else None)
        T["busy"].set(busy.name if busy else "–", f"{busy.trades} trades" if busy else "")
        T["fees"].set(money(s.fees), "commissions and exchange fees")

        self.balance.set_points(self._balances())
        self.curve.set_points(s.curve)
        self.bars.set_points(sorted((d, g.net) for d, g in s.days.items()))
        self.calendar.set_days(s.days)
        if trips:
            last = max(pf.trade_day(t) for t in trips)
            self.calendar.month = date(last.year, last.month, 1)
            self.calendar.render()

        for table, groups in ((self.by_bot, s.bots), (self.by_market, s.markets)):
            _fill(table, [[(g.name, None), (str(g.trades), None), (pct(g.win_rate), None),
                           (money(g.net), pnl_color(g.net))] for g in groups])
        rows = []
        self._trade_rows = sorted(trips, key=lambda t: t.entry_time, reverse=True)
        self._hover_row = -1
        for t in self._trade_rows:
            a, b = t.entry_time.astimezone(self.tz), t.exit_time.astimezone(self.tz)
            rows.append([(a.strftime("%a %d/%m"), None), (t.bot, None), (t.market, None),
                         ("Long" if t.side is Side.BUY else "Short", theme.UP if t.side is Side.BUY else theme.DOWN),
                         (str(t.size), None), (a.strftime("%H:%M:%S"), None), (b.strftime("%H:%M:%S"), None),
                         (pf.fmt_duration(t.duration), None), (f"{t.entry_price:,.2f}", None),
                         (f"{t.exit_price:,.2f}", None), (f"{t.points:+,.2f}", pnl_color(t.points)),
                         (money(-t.fees), theme.TEXT_2),
                         (money(t.net), pnl_color(t.net))])
        _fill(self.trades_table, rows, max_height=520)
