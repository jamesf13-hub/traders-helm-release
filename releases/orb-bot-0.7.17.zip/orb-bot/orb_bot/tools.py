"""One-off jobs shared by the command line and the app: connection check, bracket test, replay."""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

from .broker.projectx import ProjectXBroker, ProjectXError
from .broker.sim import SimBroker
from .config import Config, save_broker_setting
from .engine import Engine
from .models import Account, Contract, Side

log = logging.getLogger("orb_bot")


class ToolError(RuntimeError):
    pass


@dataclass
class CheckResult:
    accounts: list[Account]
    selected: Account | None
    contract: Contract
    recent_bars: int
    latest: datetime | None
    latest_close: float | None
    bracket_mode: str | None


def check(b: ProjectXBroker, cfg: Config) -> CheckResult:
    """Log in, list accounts (auto-pick the first Practice one if none is set), find the contract, test data."""
    try:
        b.connect()
    except ProjectXError as e:
        raise ToolError(f"Could not log in to TopstepX: {e}") from e
    accounts = b.list_accounts()
    if cfg.broker.account_id is None:
        prac = [a for a in accounts if is_practice(a)]
        if prac:
            select_account(cfg, b, prac[0].id, prac[0].name)
    selected = next((a for a in accounts if a.id == cfg.broker.account_id), None)
    c = b.get_contract()
    now = datetime.now(timezone.utc)
    bars = b.get_historical_bars(now - timedelta(days=3), now, 1)
    return CheckResult(accounts, selected, c, len(bars), bars[-1].time if bars else None,
                       bars[-1].close if bars else None, cfg.broker.bracket_tick_mode)


def is_practice(acct: Account) -> bool:
    return acct.name.upper().startswith("PRAC")


def may_trade(cfg: Config, acct: Account) -> bool:
    """Practice accounts, plus non-Practice accounts (e.g. a Combine) you confirmed in the app."""
    b = cfg.broker
    return is_practice(acct) or acct.id == b.confirmed_account_id or acct.id in b.confirmed_accounts


def confirm_account(cfg: Config, account_id: int) -> None:
    """Allow real orders on a non-Practice account (asked in the app first). Saved in config.toml."""
    b = cfg.broker
    if account_id not in b.confirmed_accounts:
        b.confirmed_accounts.append(account_id)
    if cfg.path:
        save_broker_setting(cfg.path, "confirmed_accounts", b.confirmed_accounts)


def select_account(cfg: Config, b: ProjectXBroker | None, account_id: int, name: str = "",
                   confirmed: bool = False) -> None:
    cfg.broker.account_id = account_id
    cfg.broker.account_name = name
    if confirmed:
        confirm_account(cfg, account_id)
    if b is not None:
        b.account_id = account_id
    if cfg.path:
        save_broker_setting(cfg.path, "account_id", account_id)
        if name:
            save_broker_setting(cfg.path, "account_name", name)


def bracket_test(b: ProjectXBroker, cfg: Config) -> str:
    """Buy 1 contract on Practice with a 40-tick stop and target, check the legs' sides, close it.

    Returns the tick mode that worked ("signed"/"unsigned") and saves it. Only touches its own orders.
    """
    b.connect()
    acct = b.get_account_state()
    if not acct.name.upper().startswith("PRAC"):
        raise ToolError(f"Account {acct.name} is not a Practice account. Pick a Practice account first.")
    if not acct.can_trade:
        raise ToolError(f"Account {acct.name} cannot trade right now.")
    c = b.get_contract()
    if b.get_positions():
        raise ToolError(f"{c.name} already has an open position on this account. Run the test when it's flat.")
    log.info("bracket test on %s (%s): buying 1 %s with a 40-tick stop and target", acct.name, acct.id, c.name)
    for mode in ("signed", "unsigned"):
        pre = {o.id for o in b.get_open_orders()}
        log.info("trying bracket tick mode: %s", mode)
        r = b.place_bracket_with_mode(Side.BUY, 1, 40, 40, mode, tag=f"orb-test-{int(time.time())}")
        if not r.ok:
            log.warning("rejected: %s", r.error)
            if "Auto OCO" in (r.error or "") or "Position Brackets" in (r.error or ""):
                raise ToolError("TopstepX needs Auto OCO Brackets turned on: TopstepX → Settings → Risk Settings "
                                "→ Auto OCO Brackets (you must be flat to change it).")
            continue
        time.sleep(3)
        pos = b.get_positions()
        mine = [o for o in b.get_open_orders() if o.id not in pre]
        for o in mine:
            b.cancel_order(o.id)
        if pos:
            b.close_size(Side.BUY, 1)
        if not pos:
            log.warning("no position after the market order; it may have been closed immediately")
            continue
        # The entry's own fill price (the position average would include anyone else's contracts).
        fills = [f for f in b.get_fills(datetime.now(timezone.utc) - timedelta(minutes=2)) if f.order_id == r.order_id]
        entry = fills[0].price if fills else pos[0].average_price
        stops = [o.stop_price for o in mine if o.stop_price is not None]
        limits = [o.limit_price for o in mine if o.limit_price is not None]
        log.info("entry %.2f, stop orders %s, target orders %s", entry, stops, limits)
        if stops and limits and all(s < entry for s in stops) and all(lp > entry for lp in limits):
            cfg.broker.bracket_tick_mode = mode
            if cfg.path:
                save_broker_setting(cfg.path, "bracket_tick_mode", mode)
            log.info("bracket test passed with '%s' ticks; position closed", mode)
            return mode
        log.warning("brackets were not on the expected sides with '%s' ticks", mode)
        time.sleep(2)
    raise ToolError("Bracket test failed in both modes. Send logs/orb-bot.log.")


def paper_broker(b: ProjectXBroker, cfg: Config) -> tuple[SimBroker, str]:
    """Simulated orders that start from the selected account's real balance, so paper looks like the account."""
    try:
        acct = b.get_account_state()
        start, label = acct.balance, f"Paper · {acct.name}"
    except Exception as e:  # noqa: BLE001 - no account picked yet: fall back to the sizing balance
        log.info("paper mode: account balance unavailable (%s); starting from $%s", e, f"{cfg.risk.account_size:,.0f}")
        start, label = cfg.risk.account_size, "Paper (simulated)"
    log.info("paper mode: simulated orders, starting from %s's balance $%s", label.removeprefix("Paper · "),
             f"{start:,.2f}")
    return SimBroker(b.get_contract(), cfg.sim, starting_balance=start), label


def replay(b: ProjectXBroker, cfg: Config, start: date, end: date, out: Path) -> list:
    """Run the strategy over past bars with TradingView-style fills; writes a CSV and returns the trades."""
    b.connect()
    s = datetime.combine(start, datetime.min.time(), cfg.timezone)
    e = datetime.combine(end, datetime.min.time(), cfg.timezone) + timedelta(days=1)
    sim = SimBroker(b.get_contract(), cfg.sim, starting_balance=cfg.risk.account_size)
    return Engine(cfg, b, sim, "replay").run_replay(s, e, out)
