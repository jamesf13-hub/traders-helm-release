"""The trade detail window: click a trade in Performance to see its fills, timings, the bot's plan for it
(signal, stop, target, slippage) and a chart of the candles around it with the entry and exit marked."""
from __future__ import annotations

import json
import logging
from datetime import timedelta
from typing import Callable

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QApplication, QDialog, QFrame, QGridLayout, QHBoxLayout, QLabel, QVBoxLayout,
                               QWidget)

from . import performance as pf
from . import theme
from .models import Side

log = logging.getLogger(__name__)


def money(v: float | None, sign: bool = False) -> str:
    if v is None:
        return "–"
    s = f"${abs(v):,.2f}"
    return ("+" if v >= 0 else "−") + s if sign else (s if v >= 0 else "−" + s)


def contract_label(contract_id: str) -> str:
    """"CON.F.US.MNQ.Z26" → "MNQ Z26"."""
    parts = contract_id.split(".")
    return " ".join(parts[-2:]) if len(parts) >= 2 else contract_id


def _num(row: dict | None, key: str) -> float | None:
    try:
        v = (row or {}).get(key)
        return float(v) if v not in (None, "") else None
    except ValueError:
        return None


def facts(t: pf.RoundTrip, tz) -> list[tuple[str, str, str | None]]:
    """(label, value, colour) for the detail grid."""
    long = t.side is Side.BUY
    pts = (t.exit_price - t.entry_price) * (1 if long else -1)
    point_value = t.pnl / (pts * t.size) if pts and t.size else None
    a, b = t.entry_time.astimezone(tz), t.exit_time.astimezone(tz)
    up = lambda v: theme.UP if v >= 0 else theme.DOWN  # noqa: E731
    out = [("Net P&L", money(t.net, True), up(t.net)), ("Gross P&L", money(t.pnl, True), up(t.pnl)),
           ("Fees", money(-t.fees), theme.TEXT_2), ("Bot", t.bot, None), ("Account", t.account or "–", None),
           ("Market", f"{pf.market_label(t.market)}  ({contract_label(t.contract)})", None),
           ("Side", "Long" if long else "Short", theme.UP if long else theme.DOWN), ("Size", str(t.size), None),
           ("Entry", f"{t.entry_price:,.2f}  ·  {a:%a %d %b %H:%M:%S}", None),
           ("Exit", f"{t.exit_price:,.2f}  ·  {b:%a %d %b %H:%M:%S}", None),
           ("Duration", pf.fmt_duration(t.duration), None),
           ("Points", f"{pts:+,.2f} per contract", up(pts))]
    row = t.log
    stop, target = _num(row, "stop"), _num(row, "target")
    if row:
        sig = _num(row, "signal_price")
        if row.get("signal_time") or sig is not None:
            out.append(("Signal", f"{sig:,.2f}  ·  {row.get('signal_time', '')}" if sig is not None
                        else row.get("signal_time", ""), None))
        delay = _num(row, "order_delay_s")
        if delay is not None:
            out.append(("Order sent", f"{delay:.1f} s after the signal", None))
        for key, label in (("entry_slip_ticks", "Entry slippage"), ("exit_slip_ticks", "Exit slippage")):
            v = _num(row, key)
            if v is not None:
                out.append((label, "none" if not v else f"{abs(v):g} tick{'s' if abs(v) != 1 else ''} "
                            f"{'worse' if v > 0 else 'better'}", theme.DOWN if v > 0 else None))
        if row.get("exit_reason"):
            out.append(("Closed by", row["exit_reason"].capitalize(), None))
    if stop is not None:
        out.append(("Planned stop", f"{stop:,.2f}  ({abs(t.entry_price - stop):,.2f} pts)", theme.DOWN))
    if target is not None:
        out.append(("Planned target", f"{target:,.2f}  ({abs(target - t.entry_price):,.2f} pts)", theme.UP))
    if stop is not None and point_value:
        risk = abs(t.entry_price - stop) * t.size * point_value
        if risk:
            out.append(("Result in R", f"{t.net / risk:+.2f} R  (risked {money(risk)})", up(t.net)))
    return out


def chart_minutes(t: pf.RoundTrip) -> int:
    d = t.duration
    return 1 if d <= timedelta(hours=1) else 5 if d <= timedelta(hours=6) else 15


class TradeDetail(QDialog):
    """bars(contract_id, start, end, minutes) -> bars runs in the background via run(fn, callback)."""

    def __init__(self, t: pf.RoundTrip, tz, bars: Callable | None = None, run: Callable | None = None,
                 parent=None):
        super().__init__(parent)
        self.t, self.tz, self.bars_fn, self.run = t, tz, bars, run
        long = t.side is Side.BUY
        self.setWindowTitle(f"{'Long' if long else 'Short'} {t.size} {contract_label(t.contract)} · {theme.APP_NAME}")
        self.resize(1000, 780)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(18, 16, 18, 16)
        lay.setSpacing(12)

        head = QHBoxLayout()
        title = QLabel(f"{'Long' if long else 'Short'} {t.size} {contract_label(t.contract)}")
        title.setObjectName("h2")
        net = QLabel(money(t.net, True))
        net.setObjectName("h2")
        net.setStyleSheet(f"color: {theme.UP if t.net >= 0 else theme.DOWN};")
        when = QLabel(f"{t.bot}  ·  {t.entry_time.astimezone(tz):%a %d %b %Y}")
        when.setObjectName("muted")
        head.addWidget(title)
        head.addSpacing(10)
        head.addWidget(when)
        head.addStretch(1)
        head.addWidget(net)
        lay.addLayout(head)

        self.chart = self._make_chart()
        if self.chart is not None:
            lay.addWidget(self.chart, 1)

        box = QFrame()
        box.setObjectName("box")
        grid = QGridLayout(box)
        grid.setContentsMargins(14, 12, 14, 12)
        grid.setHorizontalSpacing(18)
        grid.setVerticalSpacing(6)
        items = facts(t, tz)
        per_col = (len(items) + 1) // 2
        for i, (label, value, colour) in enumerate(items):
            col, r = divmod(i, per_col)
            k = QLabel(label.upper())
            k.setObjectName("statTitle")
            v = QLabel(value)
            v.setTextInteractionFlags(Qt.TextSelectableByMouse)
            if colour:
                v.setStyleSheet(f"color: {colour};")
            grid.addWidget(k, r, col * 2)
            grid.addWidget(v, r, col * 2 + 1)
        grid.setColumnStretch(1, 1)
        grid.setColumnStretch(3, 1)
        lay.addWidget(box)

        fills = QLabel("FILLS")
        fills.setObjectName("statTitle")
        lay.addWidget(fills)
        from .perf_view import _fill, _table  # the same table look as the Performance page
        table = _table(["TIME", "SIDE", "SIZE", "PRICE", "P&L", "FEES", "ORDER"])
        rows = []
        for f in t.fills:
            buy = f.side is Side.BUY
            rows.append([(f.time.astimezone(tz).strftime("%H:%M:%S"), None),
                         ("Buy" if buy else "Sell", theme.UP if buy else theme.DOWN), (str(f.size), None),
                         (f"{f.price:,.2f}", None),
                         (money(f.pnl, True) if f.pnl is not None else "–",
                          None if f.pnl is None else (theme.UP if f.pnl >= 0 else theme.DOWN)),
                         (money(-f.fees), theme.TEXT_2), (str(f.order_id), theme.TEXT_2)])
        _fill(table, rows, max_height=200)
        lay.addWidget(table)
        if self.chart is None:
            lay.addStretch(1)

    # --- chart --------------------------------------------------------------------------------------
    def _make_chart(self) -> QWidget | None:
        self.native = None
        if self.bars_fn is None or self.run is None:
            return None
        from . import chart_view
        if chart_view.USE_NATIVE or not QApplication.testAttribute(Qt.AA_ShareOpenGLContexts):
            from .native_chart import NativeChart
            self.native = NativeChart()
            self.native.setMinimumHeight(330)
            self._page_ready(True)
            return self.native
        try:
            from PySide6.QtWebEngineWidgets import QWebEngineView

            from .chart_view import load_page
        except Exception as e:  # noqa: BLE001
            log.debug("no trade chart: %s", e)
            return None
        view = QWebEngineView()
        view.setMinimumHeight(330)
        view.page().setBackgroundColor(Qt.transparent)
        view.loadFinished.connect(self._page_ready)
        try:
            load_page(view)
        except OSError as e:
            log.warning("trade chart files missing: %s", e)
            return None
        self.view = view
        return view

    def _page_ready(self, ok: bool) -> None:
        if not ok:
            return
        t, m = self.t, chart_minutes(self.t)
        start = t.entry_time - timedelta(minutes=m * 40)
        end = t.exit_time + timedelta(minutes=m * 20)
        self.run(lambda: self.bars_fn(t.contract, start, end, m), self._bars_loaded)

    def _bars_loaded(self, bars, err) -> None:
        if err:
            self._js("showMessage", f"Couldn't load Topstep's bars: {err}")
            return
        from .chart_view import _local, bars_json, trade_boxes
        t, m = self.t, chart_minutes(self.t)
        self._js("setBars", bars_json(bars, self.tz))
        markers = []
        if bars:
            first, step = bars[0].time, timedelta(minutes=m)
            floor = lambda when: when - ((when - first) % step)  # noqa: E731
            for f in t.fills:
                adds = f.pnl is None  # opening fills carry no P&L
                markers.append({"time": _local(floor(f.time), self.tz),
                                "position": "belowBar" if f.side is Side.BUY else "aboveBar",
                                "color": theme.ACCENT if adds else (theme.UP if (f.pnl or 0) >= 0 else theme.DOWN),
                                "shape": ("arrowUp" if f.side is Side.BUY else "arrowDown") if adds else "circle",
                                "text": f"{'Buy' if f.side is Side.BUY else 'Sell'} {f.size} @ {f.price:,.2f}"})
            markers.sort(key=lambda x: x["time"])
        self._js("setMarkers", markers)
        self._js("setTrades", trade_boxes([t], bars, self.tz))  # the app-drawn chart shows it TradingView-style
        lines = [{"price": t.entry_price, "color": theme.TEXT_2, "title": "entry", "style": 0},
                 {"price": t.exit_price, "color": theme.UP if t.net >= 0 else theme.DOWN, "title": "exit",
                  "style": 0}]
        stop, target = _num(t.log, "stop"), _num(t.log, "target")
        if stop is not None:
            lines.append({"price": stop, "color": theme.DOWN, "title": "stop"})
        if target is not None:
            lines.append({"price": target, "color": theme.UP, "title": "target"})
        self._js("setLines", lines)
        self._js("fitAll", None)

    def _js(self, fn: str, arg) -> None:
        if self.native is not None:
            getattr(self.native, fn)(*(() if arg is None else (arg,)))
        else:
            self.view.page().runJavaScript(f"{fn}({'' if arg is None else json.dumps(arg)})")
