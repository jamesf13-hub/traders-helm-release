"""A candle chart drawn by the app itself, used when the Mac won't run the web chart (its helper process gets
stopped). Same calls as the web page: setBars, updateBar, setMarkers, setLines, prependBars, fitAll,
showMessage. Times arrive already shifted to the app's time zone (seconds, read as UTC).

Scroll or pinch to zoom, drag to move back in time; reaching the left edge asks for older candles. Drag or pinch
the price axis to stretch the prices; double-click to fit them to the candles again."""
from __future__ import annotations

import math
from bisect import bisect_right
from datetime import datetime, timezone
from typing import Callable

from PySide6.QtCore import QEvent, QPointF, QRectF, Qt, QTimer
from PySide6.QtGui import QColor, QFont, QPainter, QPen, QPolygonF
from PySide6.QtWidgets import QSizePolicy, QWidget

from . import theme

AXIS_W, AXIS_H, PAD_TOP = 78, 24, 10


class NativeChart(QWidget):
    def __init__(self, on_older: Callable[[], None] | None = None, parent=None):
        super().__init__(parent)
        self.on_older = on_older
        self.bars: list[dict] = []
        self.markers: list[dict] = []
        self.lines: list[dict] = []
        self.trades: list[dict] | None = None
        self.ranges: list[dict] = []
        self.message = "Loading Topstep bars…"
        self.visible = 120  # bars across the view
        self.right = 0.0  # bars hidden off the right edge (negative = empty space on the right)
        self.right_gap = 6.0
        self.fitted = False
        self.want_older = False
        self.mouse: QPointF | None = None
        self._yr: tuple[float, float] | None = None  # the price range on screen
        self.y_manual: tuple[float, float] | None = None  # set once you stretch the price scale
        self._ydrag = None
        self._plot_h = 1.0
        self._drag: tuple[float, float] | None = None
        self.setMouseTracking(True)
        self.setMinimumHeight(160)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

    # --- the web page's calls -------------------------------------------------------------------
    def setBars(self, bars: list[dict]) -> None:  # noqa: N802 - same names as the web page
        self.bars = list(bars)
        self._yr = self.y_manual = None  # a new symbol or timeframe: fit the prices afresh
        self.message = "" if bars else "No bars for this period."
        if not self.fitted and bars:
            self.visible, self.right, self.fitted = min(90, len(bars) + 6), -self.right_gap, True
        self.update()

    def updateBar(self, bar: dict) -> None:  # noqa: N802
        if self.bars and self.bars[-1]["time"] == bar["time"]:
            self.bars[-1] = bar
        elif not self.bars or bar["time"] > self.bars[-1]["time"]:
            self.bars.append(bar)
            if self.right > 0:  # looking back in time: keep the view where it is
                self.right += 1
        self.update()

    def setMarkers(self, markers: list[dict]) -> None:  # noqa: N802
        self.markers = list(markers)
        self.update()

    def setTrades(self, trades: list[dict]) -> None:  # noqa: N802
        """TradingView-style trades (see chart_view.trade_boxes); once set, they replace the simple markers."""
        self.trades = list(trades)
        self.update()

    def setRanges(self, ranges: list[dict]) -> None:  # noqa: N802
        self.ranges = list(ranges)
        self.update()

    def setLines(self, lines: list[dict]) -> None:  # noqa: N802
        self.lines = list(lines)
        self.update()

    def prependBars(self, all_bars: list[dict], added: int, more: bool) -> None:  # noqa: N802
        self.bars = list(all_bars)
        self.want_older = not more
        self.update()

    def fitAll(self) -> None:  # noqa: N802
        self.visible, self.right = max(len(self.bars) + 2, 10), -1
        self.update()

    def goLive(self) -> None:  # noqa: N802
        """Back to the latest candle at the usual zoom, prices fitted to the candles."""
        self.visible, self.right, self.y_manual = min(90.0, len(self.bars) + 6.0), -self.right_gap, None
        self.update()

    def showMessage(self, text: str) -> None:  # noqa: N802
        self.message = text
        self.update()

    def _trade_arrows(self, p: QPainter, plot: QRectF, xt, y) -> None:
        """Entry arrow (with side, size and bot) and exit arrow (with the result) at the exact fills; labels are
        pushed apart so trades close together stay readable."""
        taken: list[QRectF] = []
        fm = p.fontMetrics()

        def label(text: str, x: float, yy: float, above: bool, c: QColor) -> None:
            w = fm.horizontalAdvance(text) + 8
            r = QRectF(x - w / 2, yy - 32 if above else yy + 16, w, 15)
            while any(r.intersects(t) for t in taken):
                r.translate(0, -15 if above else 15)
            taken.append(r)
            bg = QColor(theme.BG)
            bg.setAlpha(215)
            p.setPen(Qt.NoPen)
            p.setBrush(bg)
            p.drawRoundedRect(r, 3, 3)  # a dark backing so the text reads over candles
            p.setPen(c)
            p.drawText(r, Qt.AlignCenter, text)

        for t in self.trades or []:
            x0, x1 = xt(t["t0"]), xt(t["t1"])
            if x1 < plot.left() - 40 or x0 > plot.right() + 40:
                continue
            long = t["long"]
            entry_c = QColor(theme.ACCENT)
            # entry: a long's arrow comes up from below, a short's comes down from above
            _arrow(p, x0, y(t["entry"]), down=not long, c=entry_c)
            label(t["text"], x0, y(t["entry"]), above=not long, c=entry_c)
            exit_c = QColor(theme.UP if t["win"] else theme.DOWN)
            if t.get("open"):  # still running: no exit arrow yet, just the open P&L at the box's right edge
                label(t["result"], x1, y(t["entry"]), above=long, c=exit_c)
                continue
            _arrow(p, x1, y(t["exit"]), down=long, c=exit_c)
            label(t["result"], x1, y(t["exit"]), above=long, c=exit_c)

    # --- mouse ----------------------------------------------------------------------------------
    def _step(self) -> float:
        return max(0.5, (self.width() - AXIS_W) / max(self.visible, 1))

    def wheelEvent(self, e):
        """Smooth zoom around the mouse: a trackpad's many small scrolls each zoom a little, a mouse wheel notch
        about 15%. Sideways scrolling (trackpad swipe, shift-wheel) moves the chart left and right."""
        px, ang = e.pixelDelta(), e.angleDelta()
        dx = px.x() if not px.isNull() else ang.x() / 8 * 2
        dy = px.y() if not px.isNull() else ang.y() / 8 * 2  # a notch (120) ~ 30 px
        if abs(dx) > abs(dy):  # sideways: pan
            self.right += dx / self._step()
            self._clamp()
            self.update()
            return
        if not dy or not self.bars:
            return
        step = self._step()
        plot_w = self.width() - AXIS_W
        mx = min(max(e.position().x(), 0.0), plot_w)
        bars_from_right = (plot_w - mx) / step  # keep the candle under the mouse where it is
        old = self.visible
        hi = max(len(self.bars) + 20, 40)
        self.visible = min(max(old * 0.995 ** dy, 6.0), float(hi))
        self.right += bars_from_right * (1 - self.visible / old)
        self._clamp()
        self.update()

    def _on_axis(self, x: float) -> bool:
        return x > self.width() - AXIS_W

    def _scale_price(self, factor: float) -> None:
        """Stretch (factor < 1) or squash (> 1) the price scale around its middle; it stops following the
        candles until you double-click the price axis."""
        lo, hi = self.y_manual or self._yr or (0.0, 1.0)
        mid, half = (lo + hi) / 2, max((hi - lo) / 2 * factor, 1e-6)
        self.y_manual = (mid - half, mid + half)
        self.update()

    def mousePressEvent(self, e):
        if e.button() != Qt.LeftButton:
            return
        pos = e.position()
        if self._on_axis(pos.x()):  # drag the price axis up or down to stretch or squash it
            self._ydrag = (pos.y(), self.y_manual or self._yr)
        else:
            self._drag = (pos.x(), self.right, pos.y(), self.y_manual)

    def mouseReleaseEvent(self, e):
        self._drag = self._ydrag = None

    def mouseDoubleClickEvent(self, e):
        self.y_manual = None  # back to fitting the price scale to the candles
        self.update()

    def mouseMoveEvent(self, e):
        pos = e.position()
        self.mouse = pos
        self.setCursor(Qt.SizeVerCursor if self._on_axis(pos.x()) or self._ydrag else Qt.CrossCursor)
        if self._ydrag and self._ydrag[1]:
            y0, (lo, hi) = self._ydrag
            mid, half = (lo + hi) / 2, (hi - lo) / 2 * math.exp((pos.y() - y0) * 0.006)
            self.y_manual = (mid - half, mid + half)
        elif self._drag:
            x0, r0, y0, yr = self._drag
            self.right = r0 + (pos.x() - x0) / self._step()
            self._clamp()
            if yr:  # a stretched price scale also moves up and down with the drag
                shift = (pos.y() - y0) * (yr[1] - yr[0]) / max(self._plot_h, 1)
                self.y_manual = (yr[0] + shift, yr[1] + shift)
        self.update()

    def event(self, e):
        if e.type() == QEvent.NativeGesture and e.gestureType() == Qt.ZoomNativeGesture:  # trackpad pinch
            v = e.value()
            if self._on_axis(e.position().x()):
                self._scale_price(1 - v)
            elif self.bars:
                old = self.visible
                self.visible = min(max(old * (1 - v), 6.0), float(max(len(self.bars) + 20, 40)))
                plot_w = self.width() - AXIS_W
                bars_from_right = (plot_w - min(max(e.position().x(), 0.0), plot_w)) / self._step()
                self.right += bars_from_right * (1 - self.visible / old)
                self._clamp()
                self.update()
            return True
        return super().event(e)

    def leaveEvent(self, e):
        self.mouse = None
        self.update()

    def _clamp(self) -> None:
        self.right = min(max(self.right, -self.visible + 5), max(len(self.bars) - 5, 0))
        first = len(self.bars) - self.right - self.visible
        if first < 10 and self.bars and not self.want_older and self.on_older:
            self.want_older = True
            self.on_older()

    # --- drawing --------------------------------------------------------------------------------
    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.fillRect(self.rect(), QColor(theme.BG))
        f = QFont(self.font())
        f.setPixelSize(11)
        p.setFont(f)
        plot = QRectF(0, PAD_TOP, self.width() - AXIS_W, self.height() - AXIS_H - PAD_TOP)
        if not self.bars:
            p.setPen(QColor(theme.TEXT_2))
            p.drawText(QRectF(self.rect()), Qt.AlignCenter, self.message or "")
            return
        step = self._step()
        n = len(self.bars)
        last = n - 1 - self.right  # index at the right edge (can be fractional / beyond the data)

        def x(i: float) -> float:
            return plot.right() - (last - i + 0.5) * step

        lo_i, hi_i = max(0, int(last - self.visible) - 1), min(n - 1, int(last) + 1)
        shown = self.bars[lo_i:hi_i + 1] or self.bars[-1:]
        lo, hi = min(b["low"] for b in shown), max(b["high"] for b in shown)
        for ln in self.lines:  # keep a nearby stop or target in view, but don't shrink the candles for far ones
            if lo - (hi - lo) * 0.15 <= ln["price"] <= hi + (hi - lo) * 0.15:
                lo, hi = min(lo, ln["price"]), max(hi, ln["price"])
        if hi == lo:
            hi, lo = hi + 1, lo - 1
        pad = (hi - lo) * 0.04
        lo, hi = lo - pad, hi + pad
        self._plot_h = plot.height()
        if self.y_manual:
            lo, hi = self.y_manual
        # glide the price scale to its new range over a few frames instead of snapping as candles come and go
        elif self._yr is not None:
            a, b = self._yr
            lo, hi = a + (lo - a) * 0.3, b + (hi - b) * 0.3
            if abs(lo - a) + abs(hi - b) > (hi - lo) * 0.002:
                QTimer.singleShot(16, self.update)
        self._yr = (lo, hi)

        def y(v: float) -> float:
            return plot.bottom() - (v - lo) / (hi - lo) * plot.height()

        # grid + price axis
        p.setPen(QPen(QColor(theme.LINE), 1))
        nice = _nice_step((hi - lo) / max(2.0, plot.height() / 42))  # a price label every ~40 px, like TradingView
        v = (lo // nice + 1) * nice
        while v < hi:
            p.setPen(QPen(QColor("#1b2029"), 1))
            p.drawLine(QPointF(plot.left(), y(v)), QPointF(plot.right(), y(v)))
            p.setPen(QColor(theme.TEXT_2))
            p.drawText(QRectF(plot.right() + 6, y(v) - 8, AXIS_W - 8, 16), Qt.AlignLeft | Qt.AlignVCenter, f"{v:,.2f}")
            v += nice
        # time axis: labels on round times, about every 75 px
        span = (self.bars[1]["time"] - self.bars[0]["time"]) if n > 1 else 300
        want = span * 75 / step
        every = next((m for m in (60, 120, 300, 600, 900, 1800, 3600, 7200, 10800, 14400, 21600, 43200, 86400,
                                  604800) if m >= want), 604800)
        p.setPen(QColor(theme.TEXT_2))
        for i in range(lo_i, hi_i + 1):
            if self.bars[i]["time"] % every == 0:
                t = datetime.fromtimestamp(self.bars[i]["time"], timezone.utc)
                p.setPen(QPen(QColor("#1b2029"), 1))
                p.drawLine(QPointF(x(i), plot.top()), QPointF(x(i), plot.bottom()))
                p.setPen(QColor(theme.TEXT_2))
                label = t.strftime("%d %b") if t.hour == 0 and t.minute == 0 else t.strftime("%H:%M")
                p.drawText(QRectF(x(i) - 40, plot.bottom() + 4, 80, 16), Qt.AlignCenter, label)
        p.setPen(QPen(QColor(theme.LINE), 1))
        p.drawLine(QPointF(plot.right(), plot.top()), QPointF(plot.right(), plot.bottom()))
        p.drawLine(QPointF(plot.left(), plot.bottom()), QPointF(plot.right(), plot.bottom()))

        span = (self.bars[1]["time"] - self.bars[0]["time"]) if n > 1 else 300
        times = [b["time"] for b in self.bars]

        def xt(t: float) -> float:
            """x for an exact time: candle k covers [its time, its time + one candle)."""
            k = max(bisect_right(times, t) - 1, 0)
            return x(k + min(max((t - times[k]) / span, 0.0), 1.0) - 0.5)

        p.save()
        p.setClipRect(plot)
        # behind the candles: opening ranges (shaded band, high and low carried on) and trade boxes
        for r in self.ranges:
            x0, x1, x2 = xt(r["t0"]), xt(r["t1"]), xt(r["t2"])
            if x2 < plot.left() or x0 > plot.right():
                continue
            p.fillRect(QRectF(x0, plot.top(), x1 - x0, plot.height()), QColor(111, 155, 255, 34))
            p.setPen(QPen(QColor(theme.WARN), 1.2))
            for v in (r["high"], r["low"]):
                p.drawLine(QPointF(x0, y(v)), QPointF(x2, y(v)))
        for t in self.trades or []:
            x0, x1 = xt(t["t0"]), max(xt(t["t1"]), xt(t["t0"]) + 3)
            if x1 < plot.left() or x0 > plot.right():
                continue
            if t.get("stop") is not None or t.get("target") is not None:
                for v, col in ((t.get("target"), QColor(38, 194, 129, 60)), (t.get("stop"), QColor(239, 83, 80, 60))):
                    if v is not None:
                        top, bot = sorted((y(t["entry"]), y(v)))
                        p.fillRect(QRectF(x0, top, x1 - x0, bot - top), col)
            else:  # stop and target unknown: entry to exit, coloured by the result
                top, bot = sorted((y(t["entry"]), y(t["exit"])))
                p.fillRect(QRectF(x0, top, x1 - x0, max(bot - top, 1.0)),
                           QColor(38, 194, 129, 60) if t["win"] else QColor(239, 83, 80, 60))
            p.setPen(QPen(QColor(theme.TEXT_2), 1, Qt.DashLine))
            p.drawLine(QPointF(x0, y(t["entry"])), QPointF(x1, y(t["entry"])))

        # candles
        p.setRenderHint(QPainter.Antialiasing, False)
        w = max(1.0, step * 0.78)
        for i in range(lo_i, hi_i + 1):
            b = self.bars[i]
            c = QColor(theme.UP if b["close"] >= b["open"] else theme.DOWN)
            p.setPen(QPen(c, 1))
            p.drawLine(QPointF(x(i), y(b["high"])), QPointF(x(i), y(b["low"])))
            top, bot = sorted((y(b["open"]), y(b["close"])))
            p.fillRect(QRectF(x(i) - w / 2, top, w, max(1.0, bot - top)), c)
        p.setRenderHint(QPainter.Antialiasing, True)
        # markers: an arrow at each entry's fill price, a dot at each exit's, joined by a dotted line; labels
        # are nudged apart so two trades close together stay readable
        index = {b["time"]: k for k, b in enumerate(self.bars)}
        spots = []
        if self.trades is not None:
            self._trade_arrows(p, plot, xt, y)
        for m in (self.markers if self.trades is None else []):
            k = index.get(m["time"])
            if k is None or not lo_i - 30 <= k <= hi_i + 30:
                continue
            b = self.bars[k]
            below = m.get("position") == "belowBar"
            price = m.get("price")
            yy = y(price) if price is not None else (y(b["low"]) + 10 if below else y(b["high"]) - 10)
            spots.append((m, k, yy, below))
        trades: dict = {}
        for m, k, yy, _below in spots:
            if m.get("trade") is not None:
                trades.setdefault(m["trade"], []).append((m, k, yy))
        for legs in trades.values():
            if len(legs) == 2:
                (_m1, k1, y1), (m2, k2, y2) = legs
                p.setPen(QPen(QColor(m2.get("color", theme.TEXT_2)), 1, Qt.DotLine))
                p.drawLine(QPointF(x(k1), y1), QPointF(x(k2), y2))
        taken: list[QRectF] = []
        for m, k, yy, below in spots:
            c = QColor(m.get("color", theme.ACCENT))
            p.setPen(Qt.NoPen)
            p.setBrush(c)
            exact = m.get("price") is not None
            if m.get("shape") == "circle":
                p.drawEllipse(QPointF(x(k), yy), 4, 4)
                gap = 8
            else:
                up = m.get("shape") == "arrowUp"
                # with a price: the arrow's tip touches the fill price (below it for a long, above for a short)
                tip = yy if exact else (yy - 6 if up else yy + 6)
                base = tip + 10 if up else tip - 10
                p.drawPolygon(QPolygonF([QPointF(x(k), tip), QPointF(x(k) - 5, base), QPointF(x(k) + 5, base)]))
                gap = 12
            if m.get("text"):
                fm = p.fontMetrics()
                tw = fm.horizontalAdvance(m["text"]) + 8
                r = QRectF(x(k) - tw / 2, yy + gap if below else yy - gap - 16, tw, 16)
                while any(r.intersects(t) for t in taken):  # move away from the price until it's clear
                    r.translate(0, 16 if below else -16)
                taken.append(r)
                p.setPen(c)
                p.drawText(r, Qt.AlignCenter, m["text"])
        p.restore()

        # price lines and the last price
        last_bar = self.bars[-1]
        lines = list(self.lines) + [{"price": last_bar["close"], "style": 3, "title": "",
                                     "color": theme.UP if last_bar["close"] >= last_bar["open"] else theme.DOWN}]
        for ln in lines:
            yy = y(ln["price"])
            if not plot.top() <= yy <= plot.bottom():
                continue
            c = QColor(ln.get("color", theme.TEXT_2))
            pen = QPen(c, ln.get("width", 1))
            pen.setStyle(Qt.SolidLine if ln.get("style", 2) == 0 else Qt.DashLine if ln.get("style", 2) == 2
                         else Qt.DotLine)
            p.setPen(pen)
            p.drawLine(QPointF(plot.left(), yy), QPointF(plot.right(), yy))
            p.fillRect(QRectF(plot.right() + 1, yy - 9, AXIS_W - 2, 18), c)
            p.setPen(QColor("#0b0d12"))
            p.drawText(QRectF(plot.right() + 6, yy - 9, AXIS_W - 8, 18), Qt.AlignLeft | Qt.AlignVCenter,
                       f"{ln['price']:,.2f}")
            if ln.get("title"):
                tw = p.fontMetrics().horizontalAdvance(ln["title"]) + 12
                p.fillRect(QRectF(plot.right() - tw - 4, yy - 9, tw, 18), c)
                p.drawText(QRectF(plot.right() - tw - 4, yy - 9, tw, 18), Qt.AlignCenter, ln["title"])

        # crosshair with the bar's prices
        if self.mouse and plot.contains(self.mouse) and not self._drag:
            p.setPen(QPen(QColor(theme.TEXT_3), 1, Qt.DashLine))
            p.drawLine(QPointF(plot.left(), self.mouse.y()), QPointF(plot.right(), self.mouse.y()))
            k = round(last - (plot.right() - self.mouse.x()) / step + 0.5)
            if 0 <= k < n:
                p.drawLine(QPointF(x(k), plot.top()), QPointF(x(k), plot.bottom()))
                b = self.bars[k]
                t = datetime.fromtimestamp(b["time"], timezone.utc)
                p.setPen(QColor(theme.TEXT_2))
                p.drawText(QRectF(10, PAD_TOP, plot.width() - 20, 18), Qt.AlignLeft | Qt.AlignVCenter,
                           f"{t:%a %d %b %H:%M}   O {b['open']:,.2f}   H {b['high']:,.2f}   "
                           f"L {b['low']:,.2f}   C {b['close']:,.2f}")
            price = lo + (plot.bottom() - self.mouse.y()) / plot.height() * (hi - lo)
            p.fillRect(QRectF(plot.right() + 1, self.mouse.y() - 9, AXIS_W - 2, 18), QColor(theme.PANEL_2))
            p.setPen(QColor(theme.TEXT))
            p.drawText(QRectF(plot.right() + 6, self.mouse.y() - 9, AXIS_W - 8, 18),
                       Qt.AlignLeft | Qt.AlignVCenter, f"{price:,.2f}")
        if self.message:
            p.setPen(QColor(theme.TEXT_2))
            p.drawText(plot, Qt.AlignCenter, self.message)


def _arrow(p: QPainter, x: float, tip: float, down: bool, c: QColor) -> None:
    """A small TradingView-style arrow whose point touches the price."""
    d = -1 if down else 1  # the arrow body sits above a downward arrow
    p.setPen(QPen(c, 1.6))
    p.drawLine(QPointF(x, tip + d * 4), QPointF(x, tip + d * 14))
    p.setPen(Qt.NoPen)
    p.setBrush(c)
    p.drawPolygon(QPolygonF([QPointF(x, tip), QPointF(x - 4.5, tip + d * 6), QPointF(x + 4.5, tip + d * 6)]))


def _nice_step(raw: float) -> float:
    if raw <= 0:
        return 1.0
    mag = 10 ** int(f"{raw:e}".split("e")[1])
    for m in (1, 2, 2.5, 5, 10):
        if raw <= m * mag:
            return m * mag
    return 10 * mag
