"""The Help window: topics on the left, the page on the right, and a search box."""
from __future__ import annotations

import re

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QFrame, QHBoxLayout, QLabel, QLineEdit, QListWidget, QListWidgetItem, QTextBrowser,
                               QVBoxLayout, QWidget)

from . import theme
from .help_content import TOPICS


def _plain(html: str) -> str:
    return re.sub(r"<[^>]+>", " ", html).lower()


class HelpWindow(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent, Qt.Widget if parent is not None else Qt.Window)
        self.setWindowTitle(f"Help · {theme.APP_NAME}")
        self.resize(940, 720)
        outer = QHBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        side = QFrame()
        side.setObjectName("header")
        side.setFixedWidth(250)
        sl = QVBoxLayout(side)
        sl.setContentsMargins(12, 14, 12, 12)
        sl.setSpacing(10)
        title = QLabel("Help")
        title.setObjectName("brand")
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search help")
        self.search.setClearButtonEnabled(True)
        self.search.textChanged.connect(self._filter)
        self.topics = QListWidget()
        self.topics.setFrameShape(QFrame.NoFrame)
        self.topics.setStyleSheet(
            f"QListWidget {{ background: transparent; border: 0; }}"
            f"QListWidget::item {{ padding: 7px 8px; border-radius: 6px; color: {theme.TEXT_2}; }}"
            f"QListWidget::item:selected {{ background: #2a3140; color: {theme.TEXT}; }}")
        for tid, name, _html in TOPICS:
            it = QListWidgetItem(name)
            it.setData(Qt.UserRole, tid)
            self.topics.addItem(it)
        self.topics.currentItemChanged.connect(self._show)
        sl.addWidget(title)
        sl.addWidget(self.search)
        sl.addWidget(self.topics, 1)
        self.footer = QVBoxLayout()  # the main window puts the version and Check for updates here
        self.footer.setSpacing(6)
        sl.addLayout(self.footer)
        outer.addWidget(side)

        self.page = QTextBrowser()
        self.page.setOpenExternalLinks(True)
        self.page.setFrameShape(QFrame.NoFrame)
        self.page.document().setDocumentMargin(24)
        self.page.document().setDefaultStyleSheet(
            f"h2 {{ font-size: 20px; font-weight: 600; color: {theme.TEXT}; }}"
            f"h3 {{ font-size: 14px; font-weight: 600; color: {theme.TEXT}; margin-top: 14px; }}"
            f"p, li, td {{ color: {theme.TEXT_2}; line-height: 140%; }}"
            f"b {{ color: {theme.TEXT}; }}"
            f"code {{ font-family: '{theme.MONO}', Menlo, monospace; color: {theme.ACCENT}; }}")
        outer.addWidget(self.page, 1)
        self.show_topic("start")

    def show_topic(self, tid: str) -> None:
        for i in range(self.topics.count()):
            it = self.topics.item(i)
            if it.data(Qt.UserRole) == tid:
                it.setHidden(False)
                self.topics.setCurrentItem(it)
                return

    def _show(self, item: QListWidgetItem | None, _prev=None) -> None:
        if item is None:
            return
        html = next(h for t, _n, h in TOPICS if t == item.data(Qt.UserRole))
        self.page.setHtml(html)

    def _filter(self, text: str) -> None:
        words = text.lower().split()
        first = None
        for i, (_tid, name, html) in enumerate(TOPICS):
            hit = all(w in name.lower() or w in _plain(html) for w in words)
            self.topics.item(i).setHidden(not hit)
            if hit and first is None:
                first = self.topics.item(i)
        if first is not None and (self.topics.currentItem() is None or self.topics.currentItem().isHidden()):
            self.topics.setCurrentItem(first)
