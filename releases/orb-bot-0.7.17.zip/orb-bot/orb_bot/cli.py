"""Command line: orb-bot setup | check | bracket-test | run | replay"""
from __future__ import annotations

import argparse
import getpass
import logging
import os
import shutil
import subprocess
import sys
import threading
import time
from datetime import datetime, timedelta, timezone
from logging.handlers import RotatingFileHandler
from pathlib import Path

from .brand import APP_NAME
from .broker.projectx import ProjectXBroker, ProjectXError
from .broker.sim import SimBroker
from .config import Config, load_config, save_broker_setting
from .engine import Engine
from .models import Side

KEYRING_SERVICE = "orb-bot-topstepx"
log = logging.getLogger("orb_bot")


_thread_bot = threading.local()


def set_thread_bot(name: str | None) -> None:
    """Tag every log line from the current thread with this bot's name ("[ORB M5] ...")."""
    _thread_bot.name = name


class BotNameFilter(logging.Filter):
    def filter(self, record):
        name = getattr(_thread_bot, "name", None)
        record.bot = f"[{name}] " if name else ""
        return True


def setup_logging(log_dir: Path, verbose: bool) -> None:
    log_dir.mkdir(parents=True, exist_ok=True)
    fmt = logging.Formatter("%(asctime)s %(levelname)-7s %(bot)s%(message)s", "%Y-%m-%d %H:%M:%S")
    root = logging.getLogger()
    root.setLevel(logging.DEBUG if verbose else logging.INFO)
    fh = RotatingFileHandler(log_dir / "orb-bot.log", maxBytes=5_000_000, backupCount=10)
    fh.setFormatter(fmt)
    fh.addFilter(BotNameFilter())
    sh = logging.StreamHandler(sys.stdout)
    sh.setFormatter(fmt)
    sh.addFilter(BotNameFilter())
    root.handlers[:] = [fh, sh]
    logging.getLogger("urllib3").setLevel(logging.WARNING)


# --- credentials (macOS Keychain via keyring; env vars as fallback) -------------------
def save_credentials(username: str, api_key: str) -> None:
    import keyring
    keyring.set_password(KEYRING_SERVICE, "username", username)
    keyring.set_password(KEYRING_SERVICE, "api_key", api_key)


def get_credentials() -> tuple[str, str] | None:
    """Saved TopstepX username and API key, or None if there are none."""
    user, key = os.environ.get("PX_USER"), os.environ.get("PX_KEY")
    if user and key:
        return user, key
    import keyring
    user = keyring.get_password(KEYRING_SERVICE, "username")
    key = keyring.get_password(KEYRING_SERVICE, "api_key")
    return (user, key) if user and key else None


def load_credentials() -> tuple[str, str]:
    try:
        creds = get_credentials()
    except Exception as e:  # keyring backend missing
        sys.exit(f"Could not read the Keychain ({e}). Run `orb-bot setup` again.")
    if not creds:
        sys.exit("No TopstepX credentials saved. Run `orb-bot setup` first.")
    return creds


def make_broker(cfg: Config) -> ProjectXBroker:
    user, key = load_credentials()
    return ProjectXBroker(cfg.broker, user, key)


def require_practice(broker: ProjectXBroker, cfg: Config, allow_other: bool) -> None:
    from .tools import may_trade
    acct = broker.get_account_state()
    if not acct.can_trade:
        sys.exit(f"Account {acct.name} cannot trade right now.")
    if not may_trade(cfg, acct) and not allow_other:
        sys.exit(f"Account {acct.name} does not look like a Practice account. Refusing to place orders.\n"
                 "Pick a Practice account id in config.toml (run `orb-bot check` to list them).")
    log.info("using account %s (%s), balance $%.2f", acct.name, acct.id, acct.balance)


def session_bar_warnings(cfg: Config) -> list[str]:
    """Sessions whose range doesn't line up with the chart's bars never build a range."""
    m, out = cfg.strategy.bar_minutes, []
    for s in cfg.sessions:
        if s.enabled and ((s.start.hour * 60 + s.start.minute) % m or s.window_minutes % m):
            out.append(f"{s.name.upper()} range {s.start:%H:%M} for {s.window_minutes} min doesn't line up with "
                       f"{m}-minute bars, so it will never build a range. Use a start on a {m}-minute mark and a "
                       f"length that's a multiple of {m}.")
    return out


def attach_fast_bars(engine, cfg: Config, broker: ProjectXBroker) -> None:
    """Fast bars are always on: bars are built from the live trade stream (acting ~0.5 s after the close) and
    TopstepX's own bar is used whenever the stream missed part of one."""
    try:
        import websocket  # noqa: F401  (websocket-client)
    except ImportError:
        log.error("fast bars need the websocket-client package: in Terminal run "
                  "`cd ~/orb-bot && source .venv/bin/activate && pip install -e .`. Using TopstepX's bars.")
        return
    from .broker.stream import get_stream
    engine.stream = get_stream(broker, broker.get_contract().id)
    log.info("fast bars: bars are built from the live trade stream and checked against TopstepX's")


def describe(cfg: Config) -> None:
    for s in cfg.sessions:
        if s.enabled:
            tz = s.timezone or cfg.timezone.key
            log.info("%s ON: range %s-%s %s, breakout window %sh, RR %.1f/%.1f, flip %s, candle SL %s, "
                     "min close %%: %g/%g", s.name, s.start.strftime("%H:%M"),
                     (datetime.combine(datetime.today(), s.start) + timedelta(minutes=s.window_minutes)).strftime("%H:%M"),
                     tz, s.breakout_window_hours or "unlimited", s.rr_first, s.rr_flip,
                     "on" if s.allow_flip else "off", "on" if s.candle_sl else "off",
                     s.min_close_pct_first, s.min_close_pct_flip)
    for w in session_bar_warnings(cfg):
        log.warning(w)
    r = cfg.risk
    log.info("risk %.1f%% of %s, max %d contracts, passer %s | %d-minute bars | %s",
             r.risk_percent, "starting balance" if r.risk_on_starting_balance else "current balance",
             r.max_contracts, "ON" if r.prop_firm_passer else "off", cfg.strategy.bar_minutes, cfg.broker.symbol)


# --- commands -------------------------------------------------------------------------
def cmd_setup(args, root: Path) -> None:
    cfg_path = root / "config.toml"
    if not cfg_path.exists():
        shutil.copy(root / "config.example.toml", cfg_path)
        print(f"Created {cfg_path}")
    print("Enter your TopstepX username and ProjectX API key. They are saved in your Mac's Keychain.")
    username = input("TopstepX username: ").strip()
    api_key = getpass.getpass("ProjectX API key (hidden): ").strip()
    save_credentials(username, api_key)
    print("Saved. Next: orb-bot check")


def cmd_check(args, cfg: Config) -> None:
    b = make_broker(cfg)
    try:
        b.connect()
    except ProjectXError as e:
        sys.exit(f"Could not connect: {e}")
    print("✓ Logged in to TopstepX")
    accounts = b.list_accounts()
    print("\nAccounts:")
    for a in accounts:
        mark = "  <- selected" if a.id == cfg.broker.account_id else ""
        print(f"  id {a.id:<10} {a.name:<28} balance ${a.balance:>12,.2f}  canTrade={a.can_trade}{mark}")
    if cfg.broker.account_id is None:
        prac = [a for a in accounts if a.name.upper().startswith("PRAC")]
        if prac:
            save_broker_setting(cfg.path, "account_id", prac[0].id)
            print(f"\n→ Selected Practice account {prac[0].name} (id {prac[0].id}) in config.toml")
        else:
            print("\nNo Practice account found. Create one in TopstepX, then run check again.")
    c = b.get_contract()
    print(f"\n✓ Contract {c.name} ({c.id}) tick {c.tick_size} = ${c.tick_value}")
    now = datetime.now(timezone.utc)
    bars = b.get_historical_bars(now - timedelta(days=3), now, 1)
    print(f"✓ {len(bars)} one-minute bars in the last 3 days; latest {bars[-1].time.astimezone(cfg.timezone):%Y-%m-%d %H:%M} "
          f"close {bars[-1].close}" if bars else "✗ no recent bars returned")
    print("\nHistory depth (15-minute bars, one week sampled at each point):")
    for days in (30, 90, 180, 365, 730):
        start = now - timedelta(days=days)
        try:
            n = len(b.get_historical_bars(start, start + timedelta(days=7), 15))
        except ProjectXError as e:
            n = f"error: {e}"
        print(f"  {days:>4} days ago: {n} bars")
    mode = cfg.broker.bracket_tick_mode
    print(f"\nBracket test: {'passed (' + mode + ')' if mode else 'not run yet. Run `orb-bot bracket-test` before practice trading.'}")


def cmd_bracket_test(args, cfg: Config) -> None:
    b = make_broker(cfg)
    b.connect()
    require_practice(b, cfg, False)
    c = b.get_contract()
    if b.get_positions():
        sys.exit("There is already an open position on this contract. Flatten it in TopstepX first.")
    if not args.yes:
        ans = input(f"This BUYS 1 {c.name} at market on your PRACTICE account with a 40-tick stop and target, "
                    "checks the bracket, then closes it. Type YES to continue: ")
        if ans.strip().upper() != "YES":
            sys.exit("Cancelled.")
    from .tools import ToolError, bracket_test
    try:
        mode = bracket_test(b, cfg)
    except ToolError as e:
        sys.exit(f"✗ {e}")
    print(f"\n✓ Bracket test passed with '{mode}' ticks. Saved to config.toml. Position closed.")


def cmd_run(args, cfg: Config) -> None:
    b = make_broker(cfg)
    b.connect()
    if args.mode == "practice":
        if cfg.broker.bracket_tick_mode is None:
            sys.exit("Run `orb-bot bracket-test` first.")
        require_practice(b, cfg, args.allow_non_practice)
        orders = b
    else:
        from .tools import paper_broker
        orders, _ = paper_broker(b, cfg)
    describe(cfg)
    engine = Engine(cfg, b, orders, args.mode)
    attach_fast_bars(engine, cfg, b)
    engine.run_live()


def cmd_replay(args, cfg: Config) -> None:
    b = make_broker(cfg)
    b.connect()
    from .tools import replay
    describe(cfg)
    out = Path(args.out)
    trades = replay(b, cfg, datetime.fromisoformat(args.start).date(), datetime.fromisoformat(args.end).date(), out)
    closed = [t for t in trades if t.exit_time]
    wins = sum(1 for t in closed if t.pnl > 0)
    total = sum(t.pnl for t in closed)
    print(f"\n{len(closed)} closed trades, {wins} winners, net ${total:,.2f} (hypothetical, "
          f"{cfg.broker.symbol}). Trade list: {out}")


def cmd_app(args, root: Path) -> None:
    from .gui import main as gui_main
    gui_main([sys.argv[0]])


def cmd_make_app(args, root: Path) -> None:
    """Create ~/Applications/<app name>.app, a double-click launcher for the app window."""
    exe = Path(sys.executable).parent / "orb-bot-gui"
    if not exe.exists():
        sys.exit(f"{exe} not found. Run `pip install -e .` in {root} first.")
    apps = Path.home() / "Applications"
    old = apps / "ORB Bot.app"  # the launcher older versions made, before the Traders Helm name
    if old.exists():
        shutil.rmtree(old)
        print(f"Removed the old {old.name}")
    app = apps / f"{APP_NAME}.app"
    macos = app / "Contents" / "MacOS"
    macos.mkdir(parents=True, exist_ok=True)
    (app / "Contents" / "Info.plist").write_text("""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>CFBundleName</key><string>{APP_NAME}</string>
  <key>CFBundleDisplayName</key><string>{APP_NAME}</string>
  <key>CFBundleIdentifier</key><string>local.traders-helm</string>
  <key>CFBundleExecutable</key><string>{APP_NAME}</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleShortVersionString</key><string>0.2</string>
  <key>CFBundleIconFile</key><string>AppIcon</string>
  <key>NSHighResolutionCapable</key><true/>
</dict></plist>
""".replace("{APP_NAME}", APP_NAME))
    res = app / "Contents" / "Resources"
    res.mkdir(exist_ok=True)
    shutil.copyfile(Path(__file__).parent / "assets" / "AppIcon.icns", res / "AppIcon.icns")
    launcher = macos / APP_NAME
    launcher.write_text(f'#!/bin/bash\ncd "{root}"\nexec "{exe}"\n')
    launcher.chmod(0o755)
    app.touch()  # so Finder and the Dock pick up the new icon
    lsregister = Path("/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework"
                      "/Support/lsregister")
    if lsregister.exists():  # tell Launchpad about the new name and icon now, not after a restart
        subprocess.run([str(lsregister), "-f", str(app)], check=False)
    print(f"Created {app}\nOpen it from Finder (Go > Home > Applications) or drag it to your Dock.")


def main(argv: list[str] | None = None) -> None:
    root = Path.cwd()
    p = argparse.ArgumentParser(prog="orb-bot", description="NQ Opening Range Breakout bot for TopstepX")
    p.add_argument("--config", default="config.toml")
    p.add_argument("-v", "--verbose", action="store_true")
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("setup", help="save TopstepX credentials to the Keychain and create config.toml")
    sub.add_parser("check", help="test the connection, list accounts, check market data")
    sub.add_parser("app", help="open the app window")
    sub.add_parser("make-app", help=f"create a double-click '{APP_NAME}' app in ~/Applications")
    bt = sub.add_parser("bracket-test", help="place and close one 1-lot bracket trade on Practice")
    bt.add_argument("--yes", action="store_true")
    r = sub.add_parser("run", help="run the bot")
    r.add_argument("--mode", choices=["paper", "practice"], default="paper",
                   help="paper = simulated orders (default); practice = real orders on a Practice account")
    r.add_argument("--allow-non-practice", action="store_true", help=argparse.SUPPRESS)
    rp = sub.add_parser("replay", help="run the strategy over past bars and write a trade list")
    rp.add_argument("--start", required=True, help="YYYY-MM-DD")
    rp.add_argument("--end", required=True, help="YYYY-MM-DD")
    rp.add_argument("--out", default="replay-trades.csv")
    args = p.parse_args(argv)

    if args.cmd == "setup":
        return cmd_setup(args, root)
    if args.cmd == "app":
        return cmd_app(args, root)
    if args.cmd == "make-app":
        return cmd_make_app(args, root)
    cfg_path = Path(args.config)
    if not cfg_path.exists():
        sys.exit(f"{cfg_path} not found. Run `orb-bot setup` first.")
    cfg = load_config(cfg_path)
    setup_logging(cfg.log_dir, args.verbose)
    {"check": cmd_check, "bracket-test": cmd_bracket_test, "run": cmd_run, "replay": cmd_replay}[args.cmd](args, cfg)


if __name__ == "__main__":
    main()
