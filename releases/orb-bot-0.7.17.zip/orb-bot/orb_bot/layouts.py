"""Layout helpers that let the window shrink, e.g. to half the screen for two apps side by side."""
from __future__ import annotations

from PySide6.QtCore import QPoint, QRect, QSize, Qt
from PySide6.QtWidgets import QLayout, QSizePolicy, QStackedWidget, QWidget


class FlowLayout(QLayout):
    """Lays widgets out in a row and wraps onto the next line when the row runs out of room, like words in a
    paragraph. Widgets added after add_stretch() sit on the right of whichever line they land on."""

    def __init__(self, parent: QWidget | None = None, spacing: int = 8, v_spacing: int | None = None):
        super().__init__(parent)
        self._items = []
        self._push: set[int] = set()  # item indexes that start the right-hand group
        self.setSpacing(spacing)
        self._v = spacing if v_spacing is None else v_spacing

    def add_stretch(self) -> None:
        self._push.add(len(self._items))

    def addItem(self, item) -> None:  # noqa: N802 - Qt name
        self._items.append(item)

    def count(self) -> int:
        return len(self._items)

    def itemAt(self, i: int):  # noqa: N802
        return self._items[i] if 0 <= i < len(self._items) else None

    def takeAt(self, i: int):  # noqa: N802
        return self._items.pop(i) if 0 <= i < len(self._items) else None

    def expandingDirections(self):  # noqa: N802
        return Qt.Orientation(0)

    def hasHeightForWidth(self) -> bool:  # noqa: N802
        return True

    def heightForWidth(self, width: int) -> int:  # noqa: N802
        return self._lay(QRect(0, 0, width, 0), move=False)

    def setGeometry(self, rect: QRect) -> None:  # noqa: N802
        super().setGeometry(rect)
        self._lay(rect, move=True)

    def sizeHint(self) -> QSize:  # noqa: N802
        m = self.contentsMargins()
        vis = [it for it in self._items if not it.isEmpty()]
        w = sum(it.sizeHint().width() for it in vis) + self.spacing() * max(len(vis) - 1, 0)
        h = max((it.sizeHint().height() for it in vis), default=0)
        return QSize(w + m.left() + m.right(), h + m.top() + m.bottom())

    def minimumSize(self) -> QSize:  # noqa: N802
        m = self.contentsMargins()
        size = QSize()
        for it in self._items:
            if not it.isEmpty():
                size = size.expandedTo(it.minimumSize())
        return size + QSize(m.left() + m.right(), m.top() + m.bottom())

    def _lay(self, rect: QRect, move: bool) -> int:
        m = self.contentsMargins()
        r = rect.adjusted(m.left(), m.top(), -m.right(), -m.bottom())
        # split into lines first, then place each line (so a line's right-hand group can sit on the right)
        lines, line, x = [], [], 0
        for i, it in enumerate(self._items):
            if it.isEmpty():
                continue
            w = min(it.sizeHint().width(), r.width()) if r.width() > 0 else it.sizeHint().width()
            w = max(w, min(it.minimumSize().width(), r.width()))
            need = w if not line else x + self.spacing() + w
            if line and need > r.width():
                lines.append(line)
                line, need = [], w
            line.append((i, it, w))
            x = need
        if line:
            lines.append(line)
        y = r.y()
        for line in lines:
            h = max(it.sizeHint().height() for _i, it, _w in line)
            start = min(self._push, default=None)
            push = next((k for k, (i, _it, _w) in enumerate(line) if start is not None and i >= start), None)
            if move:
                xs = r.x()
                if push:
                    right = sum(w for _i, _it, w in line[push:]) + self.spacing() * (len(line) - push - 1)
                for k, (_i, it, w) in enumerate(line):
                    if push and k == push:
                        xs = max(xs, r.right() + 1 - right)
                    ih = it.sizeHint().height()
                    it.setGeometry(QRect(QPoint(xs, y + (h - ih) // 2), QSize(w, ih)))
                    xs += w + self.spacing()
            y += h + self._v
        return y - self._v - r.y() + m.top() + m.bottom() if lines else m.top() + m.bottom()


def flow_widget(spacing: int = 8, margins: tuple[int, int, int, int] = (0, 0, 0, 0)) -> tuple[QWidget, FlowLayout]:
    w = QWidget()
    lay = FlowLayout(w, spacing)
    lay.setContentsMargins(*margins)
    pol = QSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)
    pol.setHeightForWidth(True)
    w.setSizePolicy(pol)
    return w, lay


class PageStack(QStackedWidget):
    """A stacked widget that only needs room for the page being shown, so one wide page (Performance) doesn't
    stop the whole window getting narrower."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.currentChanged.connect(lambda _i: self.updateGeometry())

    def minimumSizeHint(self) -> QSize:  # noqa: N802
        w = self.currentWidget()
        return w.minimumSizeHint().expandedTo(w.minimumSize()) if w else QSize(0, 0)

    def sizeHint(self) -> QSize:  # noqa: N802
        w = self.currentWidget()
        return w.sizeHint() if w else QSize(0, 0)
