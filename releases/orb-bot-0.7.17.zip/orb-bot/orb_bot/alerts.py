"""TradingView alerts bots: trade whatever a TradingView script's alerts say, straight into Topstep.

This replaces PickMyTrade. TradingView sends each alert to the app (see webhook.py); the bot keeps its own
position in line with the script's and puts every entry on Topstep with a stop and target attached (Auto OCO),
so a trade stays protected even if an exit alert never arrives.

Alert messages are JSON. The fullest form (paste it into the alert's Message box) is
    {"bot": "tvnq", "key": "<secret>", "action": "{{strategy.order.action}}",
     "contracts": "{{strategy.order.contracts}}", "position": "{{strategy.market_position}}",
     "position_size": "{{strategy.market_position_size}}", "price": "{{close}}", "ticker": "{{ticker}}"}
With "position" the bot mirrors the script's position exactly (missed alerts fix themselves on the next one).
Indicator alerts can just say {"bot": ..., "key": ..., "action": "buy"} ("sell", "exit"). PickMyTrade-style
messages ("data", "quantity", "symbol", "sl", "tp") work too once "bot" and "key" are added.
"""
from __future__ import annotations

import json
import logging
import math
import queue
import re
import time as _time
from dataclasses import dataclass, field
from datetime import datetime, time as dtime, timedelta, timezone

from . import notify
from .broker.sim import SimBroker
from .engine import _LIVE, Engine, StopRequested
from .models import Bar, Side, Signal

log = logging.getLogger(__name__)

HOUSEKEEPING_SECONDS = 5.0
MAX_ALERT_AGE = 60.0  # seconds; older alerts (e.g. queued while the app was busy) are not traded


class AlertError(ValueError):
    pass


@dataclass
class Alert:
    bot: str = ""
    key: str = ""
    action: str | None = None  # "buy", "sell" or "exit"
    contracts: float | None = None  # the order's size on TradingView
    position: str | None = None  # TradingView's position after the order: "long", "short" or "flat"
    position_size: float | None = None
    price: float | None = None
    ticker: str = ""
    stop: float | None = None  # optional prices from the script
    target: float | None = None
    sent_levels: str = ""  # the stop / target exactly as TradingView sent them, for the log
    text: str = ""
    received: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def describe(self) -> str:
        parts = [self.action or "?"]
        if self.contracts:
            parts.append(f"{self.contracts:g}")
        if self.position:
            parts.append(f"→ TV {self.position}" + (f" {self.position_size:g}" if self.position_size else ""))
        if self.price:
            parts.append(f"@ {self.price:g}")
        return " ".join(parts)


def _num(v) -> float | None:
    if v is None or v == "":
        return None
    try:
        f = float(str(v).replace(",", ""))
    except ValueError:
        return None
    return f if math.isfinite(f) else None  # a plot with no value comes through as NaN


def _action(v) -> str | None:
    s = str(v or "").strip().lower()
    if not s:
        return None
    if any(w in s for w in ("exit", "close", "flat")):
        return "exit"
    if s in ("buy", "long", "enter long", "entry long", "b"):
        return "buy"
    if s in ("sell", "short", "enter short", "entry short", "s"):
        return "sell"
    return None


def parse_alert(body: str, bot: str = "", key: str = "") -> Alert:
    """Read an alert message. `bot`/`key` come from the URL when the message is plain text."""
    text = body.strip()
    a = Alert(bot=bot, key=key, text=text[:500])
    if text.startswith("{"):
        try:
            d = json.loads(text)
        except ValueError as e:
            # A placeholder TradingView couldn't fill (e.g. {{plot("Active Stop")}}) can leave stray quotes.
            try:
                d = json.loads(re.sub(r'\{\{[^{}]*\}\}', "", text))
            except ValueError:
                raise AlertError(f"the alert message isn't valid JSON ({e})") from e
        if not isinstance(d, dict):
            raise AlertError("the alert message must be a JSON object")
        d = {str(k).lower(): v for k, v in d.items()}
        a.bot = str(d.get("bot") or a.bot).strip().lower()
        a.key = str(d.get("key") or d.get("secret") or a.key).strip()
        raw_action = d.get("action", d.get("data", d.get("side")))
        a.action = _action(raw_action)
        if raw_action not in (None, "") and a.action is None:
            raise AlertError(f"unknown action {raw_action!r} (use buy, sell or exit)")
        a.contracts = _num(d.get("contracts", d.get("quantity", d.get("qty"))))
        pos = str(d.get("position") or d.get("market_position") or "").strip().lower()
        if pos:
            if pos not in ("long", "short", "flat"):
                raise AlertError(f"unknown position {pos!r} (expected long, short or flat)")
            a.position = pos
        a.position_size = _num(d.get("position_size", d.get("market_position_size")))
        a.price = _num(d.get("price", d.get("close")))
        a.ticker = str(d.get("ticker") or d.get("symbol") or "").strip()
        a.stop = _num(d.get("stop", d.get("sl", d.get("stop_price"))))
        a.target = _num(d.get("target", d.get("tp", d.get("target_price"))))
        a.sent_levels = " ".join(f"{k}={d[k]!r}" for k in ("stop", "sl", "stop_price", "target", "tp", "target_price")
                                 if k in d)
    else:
        a.action = _action(text)
        if a.action is None:
            raise AlertError(f"unknown alert text {text[:40]!r} (use buy, sell or exit)")
    if a.action is None and a.position is None:
        raise AlertError("the alert has no action (buy, sell or exit) and no position")
    return a


def _root(symbol: str) -> str:
    """CME_MINI:MNQZ2025 / MNQ1! / MNQZ6 / MNQ -> NQ (micro and full size count as the same market)."""
    s = symbol.split(":")[-1].strip().upper()
    letters = re.match(r"[A-Z]*", s).group(0)
    rest = s[len(letters):]
    if rest and rest[0].isdigit() and not rest.endswith("!") and len(letters) >= 3 and letters[-1] in "FGHJKMNQUVXZ":
        letters = letters[:-1]  # month code of a dated contract
    return letters[1:] if letters.startswith("M") and len(letters) >= 3 else letters


def same_market(ticker: str, symbol: str) -> bool:
    return not ticker or _root(ticker) == _root(symbol)


class AlertEngine(Engine):
    """One TradingView alerts bot on one account (or paper). Alerts arrive from the webhook server's thread."""

    def __init__(self, config, data, orders, mode: str):
        super().__init__(config, data, orders, mode)
        self.alerts: queue.Queue[Alert] = queue.Queue()
        self.tv_pos = 0.0  # TradingView's position, as far as the alerts have told us
        self.history: list[dict] = []  # recent alerts and what the bot did, newest last

    # --- from the webhook server ------------------------------------------------------------
    def submit(self, a: Alert) -> None:
        self.alerts.put(a)
        self._wake.set()

    # --- state -------------------------------------------------------------------------------
    def _save_state(self) -> None:
        super()._save_state()
        if self.mode == "replay":
            return
        try:
            state = json.loads(self.state_path.read_text())
            state["tv_pos"] = self.tv_pos
            self.state_path.write_text(json.dumps(state))
        except (OSError, ValueError) as e:
            log.debug("could not save tv position: %s", e)

    def _tag(self, s: Signal, when: datetime) -> str:
        return f"{self.cfg.slug}-{s.session}-{when.strftime('%Y%m%d%H%M%S')}"

    # --- live loop ---------------------------------------------------------------------------
    def run_live(self) -> None:
        from .webhook import register, unregister
        self.running = True
        _LIVE.add(self)
        register(self)
        try:
            if self.mode == "practice":
                self.refresh_balance()
                self.reconcile()
            self.tv_pos = float(self._load_state().get("tv_pos") or 0.0) if self.trade else 0.0
            self._roll_day(datetime.now(timezone.utc))
            log.info("waiting for TradingView alerts for %s on %s with %s.", self.cfg.slug, self.contract.name,
                     "REAL ORDERS" if self.mode == "practice" else "paper (simulated) orders")
            next_check = 0.0
            while True:
                try:
                    self._sleep(1.0)
                    self._handle_alerts()
                    if _time.monotonic() >= next_check:
                        self._roll_day(datetime.now(timezone.utc))
                        self._housekeeping()
                        next_check = _time.monotonic() + HOUSEKEEPING_SECONDS
                except StopRequested:
                    raise
                except Exception as e:  # keep running through network blips; brackets protect trades
                    log.exception("alerts loop error: %s", e)
                    self._sleep(5)
        except (KeyboardInterrupt, StopRequested):
            log.info("stopped")
            if self.trade:
                log.warning("the bot's trade is still open; its stop and target stay active at the broker")
        finally:
            self.running = False
            unregister(self)
            _LIVE.discard(self)

    def _housekeeping(self) -> None:
        if isinstance(self.orders, SimBroker) and self.trade:
            price = self._price(None)
            if price is not None:
                # From the previous price to this one, so a stop or target in between fills at its own price.
                prev = self.orders.last_bar.close if self.orders.last_bar else price
                self.orders.update(Bar(datetime.now(timezone.utc), prev, max(prev, price), min(prev, price), price))
                self._collect_sim_exits()
        super()._housekeeping()

    def _price(self, alert_price: float | None) -> float | None:
        if alert_price:
            return alert_price
        try:
            p = self.data.get_last_price()
        except Exception as e:  # noqa: BLE001
            log.debug("last price unavailable: %s", e)
            p = None
        if p is not None:
            self.last_price = p
        return p

    def _handle_alerts(self) -> None:
        while True:
            try:
                a = self.alerts.get_nowait()
            except queue.Empty:
                return
            try:
                result = self.handle(a)
            except StopRequested:
                raise
            except Exception as e:  # noqa: BLE001 - one bad alert mustn't stop the bot
                log.exception("alert failed: %s", e)
                result = f"error: {e}"
            self.history.append({"time": a.received, "alert": a.describe(), "result": result})
            del self.history[:-50]

    # --- turning an alert into orders ------------------------------------------------------------
    def tv_target(self, a: Alert) -> float:
        """TradingView's position after this alert (signed contracts)."""
        if a.position is not None:
            if a.position == "flat":
                return 0.0
            size = a.position_size if a.position_size is not None else (a.contracts or 1.0)
            return abs(size) * (1 if a.position == "long" else -1)
        if a.action == "exit":
            return 0.0
        sign = 1 if a.action == "buy" else -1
        if a.contracts is None:  # an indicator's "buy": go long (reversing a short)
            return float(sign)
        return self.tv_pos + sign * abs(a.contracts)  # a strategy's order: apply it to the position

    def size_for(self, tv_size: float) -> int:
        al, r = self.cfg.alerts, self.cfg.risk
        if al.sizing == "fixed":
            n = al.contracts
        else:
            n = max(1, round(abs(tv_size) * al.multiplier))
        return max(1, min(n, r.max_contracts))

    def handle(self, a: Alert) -> str:
        age = (datetime.now(timezone.utc) - a.received).total_seconds()
        if age > MAX_ALERT_AGE:
            log.warning("alert %s is %.0fs old; not trading it", a.describe(), age)
            return f"too old ({age:.0f}s), not traded"
        if not same_market(a.ticker, self.cfg.broker.symbol):
            log.error("alert is for %s but this bot trades %s; ignored", a.ticker, self.contract.name)
            return f"ignored: alert is for {a.ticker}, bot trades {self.contract.name}"
        before = self.tv_pos
        target = self.tv_target(a)
        self.tv_pos = target
        log.info("ALERT %s (TradingView position %+g -> %+g)%s", a.describe(), before, target,
                 f"; alert sent {a.sent_levels}" if a.sent_levels else "; alert sent no stop / target")
        own = self.trade.side.sign if self.trade else 0
        want = (target > 0) - (target < 0)
        if want == 0:
            if not self.trade:
                self._save_state()
                return "already flat (Topstep's stop or target closed it)" if a.action == "exit" or before \
                    else "already flat"
            if self.cfg.alerts.exit_alerts == "ignore":
                self._save_state()
                return "exit left to Topstep's stop and target"
            size = self.trade.size
            self._close_at(a, "alert exit")
            return f"closed {size}"
        if own == want:
            self._save_state()
            return f"already {'long' if want > 0 else 'short'} {self.trade.size}; size changes aren't followed"
        done = []
        if self.trade:
            size = self.trade.size
            self._close_at(a, "reversed")
            done.append(f"closed {size}")
        opened = self._open(Side.BUY if want > 0 else Side.SELL, abs(target), a)
        done.append(opened)
        return ", ".join(done)

    def script_stop(self, side: Side, n: float, a: Alert, price: float, wait: float = 4.0):
        """The script's own stop, when its alert doesn't send it: (price, where it came from) or None.

        A breakout script puts its stop at the opening range's far edge or, after a big breakout candle, at that
        candle's high/low, and sizes the trade as floor(risk / stop $). So the stop distance lies between
        risk/(n+1) and risk/n per contract; the candidate inside that window is the script's stop."""
        al, tick = self.cfg.alerts, self.contract.tick_size
        if not al.range_start:
            return None
        try:
            hh, mm = (int(x) for x in al.range_start.split(":"))
        except ValueError:
            log.warning("range start %r isn't a time like 15:00", al.range_start)
            return None
        m = al.chart_minutes
        now = a.received.astimezone(self.tz)
        r0 = datetime.combine(now.date(), dtime(hh, mm), self.tz)
        if r0 > now:
            r0 -= timedelta(days=1)
        r1 = r0 + timedelta(minutes=al.range_minutes)
        # The breakout candle is the last bar to close by the time the alert fired (TopstepX can lag 1-3 s).
        last_open = now.replace(second=0, microsecond=0) - timedelta(minutes=now.minute % m + m)
        end = _time.monotonic() + wait
        while True:
            try:
                bars = self.data.get_historical_bars(r0, last_open + timedelta(minutes=m), m)
            except Exception as e:  # noqa: BLE001
                log.warning("couldn't load bars to find the script's stop: %s", e)
                return None
            if any(b.time == last_open for b in bars) or _time.monotonic() >= end:
                break
            _time.sleep(0.5)
        rng = [b for b in bars if r0 <= b.time < r1]
        candle = next((b for b in bars if b.time == last_open), None)
        if not rng or candle is None:
            log.info("no bars for the range or breakout candle; can't work out the script's stop")
            return None
        long = side is Side.BUY
        cands = {"range low" if long else "range high": min(b.low for b in rng) if long else max(b.high for b in rng),
                 "breakout candle low" if long else "breakout candle high": candle.low if long else candle.high}
        point = self.contract.tick_value / tick  # $ per point per contract
        lo, hi = al.script_risk / ((n + 1) * point), al.script_risk / (n * point)
        fits, notes = {}, []
        for name, level in cands.items():
            dist = (price - level) * (1 if long else -1)
            ok = lo - tick <= dist <= hi + tick
            notes.append(f"{name} {level:g} ({dist:.2f} pts{', fits' if ok else ''})")
            if ok:
                fits.setdefault(level, name)
        log.info("script stop: %g contracts means %.2f-%.2f pts; %s", n, lo, hi, "; ".join(notes))
        if len(fits) != 1:
            return None
        level, name = next(iter(fits.items()))
        return level, f"{name}, fits {n:g} contracts at ${al.script_risk:,.0f}"

    def _close_at(self, a: Alert, reason: str) -> None:
        if isinstance(self.orders, SimBroker):
            price = self._price(a.price)
            if price is not None:
                self.orders.last_bar = Bar(datetime.now(timezone.utc), price, price, price, price)
        self._close_own(reason)

    def _open(self, side: Side, tv_size: float, a: Alert) -> str:
        if self.trade:
            return "not opened: previous trade still open"
        al, tick = self.cfg.alerts, self.contract.tick_size
        limit = self.cfg.safety.max_daily_loss
        day = self.day_pnl()
        if limit and day <= -limit:
            log.warning("daily loss limit reached (%s today); entry skipped", f"${day:,.2f}")
            notify.send("problem", f"⛔ Daily loss limit reached ({day:,.2f} today). {self._where()} skipped "
                        f"a {a.action} alert.", self.mode)
            return "skipped: daily loss limit reached"
        price = self._price(a.price)
        if price is None:
            log.error("no price for the entry; skipped")
            return "skipped: no price"
        stop_ticks, source = al.stop_ticks, f"default {al.stop_ticks} ticks"
        if a.stop and (a.stop - price) * side.sign < 0:
            stop_ticks, source = max(1, round(abs(price - a.stop) / tick)), "from the alert"
        elif al.script_risk > 0 and abs(tv_size) >= 1 and (found := self.script_stop(side, abs(tv_size), a, price)):
            stop_price, source = found
            stop_ticks = max(1, round(abs(price - stop_price) / tick))
        elif al.script_risk > 0 and abs(tv_size) >= 1:
            # The script sized n = floor(risk / stop $), so its stop $ per contract lies between risk/(n+1) and
            # risk/n. Take the middle: on 12 Oct (n=6) that gave 38.7 pts against the script's real 37.5.
            n = abs(tv_size)
            per_contract = al.script_risk * (1 / n + 1 / (n + 1)) / 2
            stop_ticks = max(1, round(per_contract / self.contract.tick_value))
            source = f"from ${al.script_risk:,.0f} script risk / {abs(tv_size):g} contracts"
        if a.stop and source != "from the alert":
            log.warning("alert stop %s is on the wrong side of %s for a %s; using the stop %s", a.stop, price,
                        side.value, source)
        elif not a.stop:
            log.info("alert has no stop price; using the stop %s", source)
        target_ticks = max(1, round(stop_ticks * al.target_rr)) if al.target_rr > 0 else al.target_ticks
        if a.target and (a.target - price) * side.sign > 0:
            target_ticks = max(1, round(abs(a.target - price) / tick))
        size = self.size_for(tv_size)
        if limit:  # never let one stop-out go past the daily loss limit
            room = limit + day
            per_contract = stop_ticks * self.contract.tick_value
            if per_contract > 0 and size * per_contract > room:
                fit = int(room // per_contract)
                if fit < 1:
                    log.warning("a stop-out would breach the daily loss limit; entry skipped")
                    return "skipped: stop would breach daily loss limit"
                log.info("size cut from %d to %d so a stop-out stays inside the daily loss limit", size, fit)
                size = fit
        s = Signal("tv", side, price, price - side.sign * stop_ticks * tick, price + side.sign * target_ticks * tick,
                   size, f"TradingView alert: {a.describe()}")
        if isinstance(self.orders, SimBroker):
            self.orders.last_bar = Bar(datetime.now(timezone.utc), price, price, price, price)
        now = datetime.now(timezone.utc)
        self.signal_at = a.received
        self._execute(s, Bar(now, price, price, price, price))
        if not self.trade:
            return "order rejected (see log)"
        t = self.trade
        return (f"{'bought' if side is Side.BUY else 'sold'} {size} · stop {t.stop:.2f} ({source}) · "
                f"target {t.target:.2f}")

    def snapshot(self) -> dict:
        snap = super().snapshot()
        snap["sessions"] = []
        snap["last_bar"] = None
        snap["tv_position"] = self.tv_pos
        snap["alerts"] = [dict(h, time=h["time"].astimezone(self.tz).strftime("%H:%M:%S"))
                          for h in self.history]
        return snap
