"""Phone alerts through Telegram: a message when a trade opens or closes, and when something needs attention.

Set up once in the app (Account → Phone alerts…): make a Telegram bot with @BotFather, paste its token (kept in
the Keychain), message the bot once, and the app finds your chat id. Messages go out on a background thread so
a slow or failed send never holds up a trade."""
from __future__ import annotations

import logging
import queue
import threading
import time

import requests

from .brand import APP_NAME

log = logging.getLogger(__name__)

API = "https://api.telegram.org"
KEYRING_SERVICE = "orb-bot-topstepx"  # same Keychain entry as the TopstepX login
TOKEN_KEY = "telegram_token"
REPEAT_SECONDS = 600  # the same problem is sent at most once per 10 minutes


class NotifyError(RuntimeError):
    pass


def get_token() -> str | None:
    try:
        import keyring
        return keyring.get_password(KEYRING_SERVICE, TOKEN_KEY)
    except Exception:  # noqa: BLE001 - no Keychain: phone alerts are simply off
        return None


def save_token(token: str) -> None:
    import keyring
    if token:
        keyring.set_password(KEYRING_SERVICE, TOKEN_KEY, token.strip())
    else:
        try:
            keyring.delete_password(KEYRING_SERVICE, TOKEN_KEY)
        except Exception:  # noqa: BLE001 - nothing saved
            pass


def _call(token: str, method: str, **params) -> dict:
    try:
        r = requests.post(f"{API}/bot{token}/{method}", json=params, timeout=10)
        data = r.json()
    except (requests.RequestException, ValueError) as e:
        raise NotifyError(f"couldn't reach Telegram ({type(e).__name__})") from None
    if not data.get("ok"):
        raise NotifyError(data.get("description") or f"Telegram said no (HTTP {r.status_code})")
    return data


def send_message(token: str, chat_id: str, text: str) -> None:
    _call(token, "sendMessage", chat_id=chat_id, text=text, disable_web_page_preview=True)


def find_chat_id(token: str) -> tuple[str, str]:
    """The chat of the latest message sent to the bot: (chat id, who sent it)."""
    updates = _call(token, "getUpdates").get("result") or []
    for u in reversed(updates):
        msg = u.get("message") or u.get("edited_message") or {}
        chat = msg.get("chat") or {}
        if "id" in chat:
            who = chat.get("username") or chat.get("first_name") or chat.get("title") or ""
            return str(chat["id"]), who
    raise NotifyError("no messages found. Open your bot in Telegram, send it any message, then try again.")


class Notifier:
    """Sends in the background. `kind` is "trade" or "problem"; each can be switched off."""

    def __init__(self, token: str | None, chat_id: str, trades: bool = True, problems: bool = True,
                 paper: bool = False, sender=send_message):
        self.token, self.chat_id = token, chat_id
        self.trades, self.problems, self.paper = trades, problems, paper
        self.sender = sender
        self._last: dict[str, float] = {}
        self._q: queue.Queue[str] = queue.Queue()
        self._thread: threading.Thread | None = None

    @property
    def enabled(self) -> bool:
        return bool(self.token and self.chat_id)

    def wants(self, kind: str, mode: str = "practice") -> bool:
        if not self.enabled or (mode == "paper" and not self.paper) or mode == "replay":
            return False
        return self.trades if kind == "trade" else self.problems

    def send(self, kind: str, text: str, mode: str = "practice") -> bool:
        if not self.wants(kind, mode):
            return False
        if kind == "problem":
            now = time.monotonic()
            if now - self._last.get(text, -REPEAT_SECONDS) < REPEAT_SECONDS:
                return False
            self._last[text] = now
        self._q.put(text)
        if self._thread is None or not self._thread.is_alive():
            self._thread = threading.Thread(target=self._run, name="telegram", daemon=True)
            self._thread.start()
        return True

    def _run(self):
        while True:
            try:
                text = self._q.get(timeout=30)
            except queue.Empty:
                return
            try:
                self.sender(self.token, self.chat_id, text)
            except Exception as e:  # noqa: BLE001 - never let an alert failure reach the trading code
                log.debug("phone alert not sent: %s", e)

    def flush(self, timeout: float = 5.0) -> None:
        """Wait for queued messages (tests, and on quit)."""
        end = time.monotonic() + timeout
        while not self._q.empty() and time.monotonic() < end:
            time.sleep(0.02)
        time.sleep(0.05)


    def reply(self, text: str) -> None:
        """An answer to a command: always sent, whatever the trades / problems switches say."""
        if not self.enabled:
            return
        self._q.put(text)
        if self._thread is None or not self._thread.is_alive():
            self._thread = threading.Thread(target=self._run, name="telegram", daemon=True)
            self._thread.start()


HELP = ("Commands:\n/status  what each bot is doing\n/stop  stop every bot (open trades keep their stop and "
        "target at Topstep)\n/flatten  close every bot's open trade at market and stop all bots")
CONFIRM_SECONDS = 60


class CommandListener:
    """Reads messages sent to the Telegram bot and passes commands from YOUR chat to `on_command`.

    Messages from any other chat are ignored. /flatten only runs after a "yes" within a minute. Messages sent
    while the app was closed are skipped, so an old /flatten never fires on start-up."""

    def __init__(self, token: str, chat_id: str, on_command, fetch=None):
        self.token, self.chat_id = token, str(chat_id)
        self.on_command = on_command  # called with "status", "stop" or "flatten" (on this thread)
        self.fetch = fetch or (lambda offset, wait: _call(self.token, "getUpdates", offset=offset, timeout=wait,
                                                          allowed_updates=["message"]).get("result") or [])
        self.offset: int | None = None
        self.pending_flatten: float | None = None
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self):
        self._thread = threading.Thread(target=self._run, name="telegram-commands", daemon=True)
        self._thread.start()

    def stop(self):
        self._stop.set()

    def _skip_old(self):
        old = self.fetch(-1, 0)
        self.offset = old[-1]["update_id"] + 1 if old else 0

    def _run(self):
        while not self._stop.is_set():
            try:
                if self.offset is None:
                    self._skip_old()
                for u in self.fetch(self.offset, 25):
                    self.offset = u["update_id"] + 1
                    self.handle(u)
            except Exception as e:  # noqa: BLE001 - network blips: wait and try again
                log.debug("telegram commands: %s", e)
                self._stop.wait(10)

    def handle(self, update: dict) -> str | None:
        """Work out what one message asks for; returns the command run (or None)."""
        msg = update.get("message") or {}
        if str((msg.get("chat") or {}).get("id")) != self.chat_id:
            return None  # not you
        text = (msg.get("text") or "").strip().lower().split("@")[0]
        word = text.lstrip("/").split()[0] if text.strip("/ ") else ""
        now = time.monotonic()
        if word in ("yes", "y", "confirm") and self.pending_flatten and now - self.pending_flatten < CONFIRM_SECONDS:
            self.pending_flatten = None
            self.on_command("flatten")
            return "flatten"
        self.pending_flatten = None
        if word in ("flatten", "flat", "closeall", "close"):
            self.pending_flatten = now
            self.on_command("confirm_flatten")
            return "confirm_flatten"
        if word in ("stop", "off", "stopall", "kill"):
            self.on_command("stop")
            return "stop"
        if word in ("status", "s", "pos", "positions"):
            self.on_command("status")
            return "status"
        self.on_command("help")
        return "help"


_current = Notifier(None, "")


def configure(notifier: Notifier) -> None:
    global _current
    _current = notifier


def current() -> Notifier:
    return _current


def send(kind: str, text: str, mode: str = "practice") -> bool:
    return _current.send(kind, text, mode)


class ProblemHandler(logging.Handler):
    """Forwards errors from the log (rejected orders, TradingView can't reach the app, crashes) as problems."""

    def __init__(self):
        super().__init__(logging.ERROR)

    def emit(self, record):
        try:
            if record.name == __name__:
                return
            bot = getattr(record, "bot", "").strip()
            send("problem", f"⚠️ {APP_NAME}{' ' + bot if bot else ''}: {record.getMessage()}")
        except Exception:  # noqa: BLE001
            pass
