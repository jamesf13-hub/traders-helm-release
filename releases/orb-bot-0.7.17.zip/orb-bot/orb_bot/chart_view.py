"""The chart on the main screen: Topstep's own bars drawn with TradingView's Lightweight Charts, with the bots' trades marked.

Entries and exits come from Topstep's fills (the same record the Performance window uses), each tagged with the
bot that placed it. The open trade's entry, stop and target, and any opening range being built or watched, are
drawn as lines. The last bar updates every few seconds."""
from __future__ import annotations

import json
import logging
from bisect import bisect_right
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Callable

from PySide6.QtCore import QTimer, QUrl, Qt
from PySide6.QtWidgets import QComboBox, QFrame, QHBoxLayout, QLabel, QPushButton, QVBoxLayout, QWidget

from . import theme
from .models import Side
from .performance import MANUAL, label_bots, read_bot_log, round_trips

log = logging.getLogger(__name__)

PAGE = Path(__file__).parent / "assets" / "chart" / "chart.html"
TIMEFRAMES = [(1, "1 min"), (2, "2 min"), (3, "3 min"), (5, "5 min"), (10, "10 min"), (15, "15 min"),
              (30, "30 min"), (60, "1 hour"), (120, "2 hours"), (240, "4 hours"), (1440, "1 day"), (10080, "1 week")]
# how much history each timeframe loads first (scroll left for more)
DAYS = {1: 2, 2: 3, 3: 4, 5: 5, 10: 8, 15: 10, 30: 20, 60: 30, 120: 60, 240: 120, 1440: 400, 10080: 1500}
# Markets Topstep trades, offered in the chart's list after the bots' own.
MARKETS = ["MNQ", "NQ", "MES", "ES", "MYM", "YM", "M2K", "RTY", "MGC", "GC", "SIL", "SI", "MCL", "CL", "QM", "NG",
           "QG", "HG", "PL", "6E", "M6E", "6B", "6J", "6A", "6C", "ZB", "ZN", "ZF", "ZT", "ZC", "ZS", "ZW", "HE", "LE",
           "MBT", "MET"]
LIVE_SECONDS = 5
USE_NATIVE = False  # set once the web chart has failed (or can't run), so other charts draw themselves too


def _local(t: datetime, tz) -> int:
    """Lightweight Charts shows UTC; shift each time so the axis reads in the app's time zone."""
    return int(t.timestamp() + t.astimezone(tz).utcoffset().total_seconds())


def bars_json(bars, tz) -> list[dict]:
    return [{"time": _local(b.time, tz), "open": b.open, "high": b.high, "low": b.low, "close": b.close}
            for b in bars]


def trade_markers(trips, bars, tz, minutes: int) -> list[dict]:
    """An arrow at each entry and a dot at each exit, on the bar the fill happened in."""
    if not bars:
        return []
    first = bars[0].time
    times = [b.time for b in bars]

    def floor(when):  # the bar the fill fell in: the last one starting at or before it (days and weeks too)
        return times[max(bisect_right(times, when) - 1, 0)]

    out = []
    for n, t in enumerate(trips):
        if t.entry_time < first:
            continue
        long = t.side is Side.BUY
        who = "" if t.bot == MANUAL else f" · {t.bot}"
        # price and trade let the app-drawn chart mark the exact fill and join entry to exit; the web chart ignores them
        out.append({"time": _local(floor(t.entry_time), tz), "position": "belowBar" if long else "aboveBar",
                    "color": theme.ACCENT, "shape": "arrowUp" if long else "arrowDown",
                    "text": f"{'Long' if long else 'Short'} {t.size}{who}", "price": t.entry_price, "trade": n})
        out.append({"time": _local(floor(t.exit_time), tz), "position": "aboveBar" if long else "belowBar",
                    "color": theme.UP if t.net >= 0 else theme.DOWN, "shape": "circle",
                    "text": f"{'+' if t.net >= 0 else '−'}${abs(t.net):,.2f}", "price": t.exit_price, "trade": n})
    out.sort(key=lambda m: m["time"])
    return out


def _num(v) -> float | None:
    try:
        return float(v) if v not in (None, "") else None
    except (TypeError, ValueError):
        return None


def trade_boxes(trips, bars, tz) -> list[dict]:
    """TradingView-style trades: exact entry and exit (time and price), and the stop and target the bot set
    (from logs/fills.csv). Trades with no known stop or target get one box from entry to exit."""
    if not bars:
        return []
    first = bars[0].time
    out = []
    for t in trips:
        if t.exit_time < first:
            continue
        long = t.side is Side.BUY
        logged = getattr(t, "log", None) or {}
        who = "" if t.bot == MANUAL else f" {t.bot}"
        out.append({"t0": _local(t.entry_time, tz), "t1": _local(t.exit_time, tz), "long": long,
                    "entry": t.entry_price, "exit": t.exit_price,
                    "stop": _num(logged.get("stop")), "target": _num(logged.get("target")),
                    "text": f"{'+' if long else '−'}{t.size}{who} {'Long' if long else 'Short'}",
                    "result": f"{'+' if t.net >= 0 else '−'}${abs(t.net):,.2f}", "win": t.net >= 0})
    return out


def open_boxes(trades, bars, tz) -> list[dict]:
    """Open trades: the box runs from the entry to the current candle, with the stop and target zones."""
    if not bars:
        return []
    now_end = bars[-1].time + ((bars[1].time - bars[0].time) if len(bars) > 1 else timedelta(minutes=5))
    out = []
    for t in trades:
        long = t["side"] == "buy"
        upl = t.get("unrealized")
        out.append({"t0": _local(t["at"], tz), "t1": _local(now_end, tz), "long": long, "open": True,
                    "entry": t["entry"], "exit": t.get("last") or t["entry"],
                    "stop": t.get("stop"), "target": t.get("target"),
                    "text": f"{'+' if long else '−'}{t['size']} {t.get('bot', '')} {'Long' if long else 'Short'}"
                    .replace("  ", " "),
                    "result": "open" if upl is None else f"{'+' if upl >= 0 else '−'}${abs(upl):,.2f} open",
                    "win": (upl or 0) >= 0})
    return out


RANGE_CANDLES = 10  # the range's high and low lines run on this many candles past the range


def range_boxes(windows, bars, tz) -> list[dict]:
    """Opening ranges: windows are (label, start, end, _); the high and low come from the candles inside."""
    out = []
    candle = (bars[1].time - bars[0].time) if len(bars) > 1 else timedelta(minutes=5)
    for label, start, end, _until in windows:
        until = end + candle * RANGE_CANDLES
        inside = [b for b in bars if start <= b.time < end]
        if not inside or inside[0].time != start:  # bigger candles than the range, or no data: nothing to show
            continue
        out.append({"t0": _local(start, tz), "t1": _local(end, tz), "t2": _local(until, tz), "label": label,
                    "high": max(b.high for b in inside), "low": min(b.low for b in inside)})
    return out


def load_page(view) -> None:
    """The page and the chart library go in as one piece of HTML, so nothing is read from disk by the web view."""
    html = PAGE.read_text(encoding="utf-8")
    lib = (PAGE.parent / "lightweight-charts.js").read_text(encoding="utf-8")
    html = html.replace('<script src="lightweight-charts.js"></script>', f"<script>{lib}</script>")
    view.setHtml(html, QUrl("https://chart.local/"))


class ChartPanel(QWidget):
    """fetch(account_id, symbol, minutes, start, end, with_fills, fills_from) -> (contract, bars, fills or None)
    runs in the background;
    lines(account_id, contract_name) -> price lines from the running bots; run(fn, callback) runs a job."""

    def __init__(self, accounts_fn, symbols_fn, fetch, lines, run, bot_log: Path, tz, account_id=None, parent=None,
                 native: bool = False, use_native: Callable[[], None] | None = None, ranges=None,
                 open_trades=None):
        super().__init__(parent)
        self.ranges = ranges  # ranges(account_id, contract_name, days) -> [(label, start, end, until)]
        self.open_trades = open_trades  # open_trades(account_id, contract_name) -> running bots' open trades
        self.native = None  # the app-drawn chart, when the web one can't run on this Mac
        self.use_native_cb = use_native
        self.accounts_fn, self.symbols_fn, self.fetch, self.lines, self.run = \
            accounts_fn, symbols_fn, fetch, lines, run
        self.bot_log, self.tz = bot_log, tz
        self.contract = None
        self.bars: list = []
        self.busy = False
        self._go_live = False
        self.ready = False
        self.ticks = 0
        self.trips: list = []

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        head = QFrame()
        head.setObjectName("header")
        bar = QHBoxLayout(head)
        bar.setContentsMargins(10, 4, 10, 4)
        bar.setSpacing(8)
        self.account = QComboBox()
        self.account.setMinimumWidth(260)
        self.symbol = QComboBox()
        self.timeframe = QComboBox()
        for m, name in TIMEFRAMES:
            self.timeframe.addItem(name, m)
        self.timeframe.setCurrentIndex(self.timeframe.findData(5))
        self.timeframe.setMaxVisibleItems(len(TIMEFRAMES))
        self.symbol.setMaxVisibleItems(16)
        self.status = QLabel()
        self.status.setStyleSheet(f"color: {theme.TEXT_2};")
        refresh = QPushButton("Refresh")
        refresh.setToolTip("Reload the candles and go back to the current price")
        refresh.clicked.connect(self.refresh)
        for w in (self.account, self.symbol, self.timeframe):
            w.activated.connect(lambda _i: self.load(full=True))
        self.account.hide()  # follows the account chosen at the top of the app
        for w in (QLabel("Chart"), self.symbol, self.timeframe):
            bar.addWidget(w)
        bar.addStretch(1)
        bar.addWidget(self.status)
        bar.addWidget(refresh)
        outer.addWidget(head)
        self.head = head
        self.spinner = theme.LogoSpinner(self)  # the wheel turning while the chart is blank or loading

        self.outer = outer
        self.tries = 0
        self.view = None
        if not native:
            try:
                self._make_web_view()
            except Exception as e:  # noqa: BLE001 - no web engine: draw it ourselves
                log.warning("chart: web chart unavailable (%s), using the built-in chart", e)
        if self.view is None:
            self._switch_to_native(remember=False)

        self.spinner.start()
        self.timer = QTimer(self)
        self.timer.timeout.connect(lambda: self.load(full=False))
        self.reload_lists(account_id)

    def resizeEvent(self, e):  # noqa: N802
        super().resizeEvent(e)
        h = self.head.height()
        self.spinner.setGeometry(0, h, self.width(), max(self.height() - h, 0))

    def _make_web_view(self) -> None:
        from PySide6.QtWebEngineCore import QWebEnginePage
        from PySide6.QtWebEngineWidgets import QWebEngineView

        class Page(QWebEnginePage):
            def javaScriptConsoleMessage(self, level, message, line, source):  # noqa: N802 - Qt's name
                log.warning("chart page: %s (line %s)", message, line)
        self.view = QWebEngineView()
        self.view.setPage(Page(self.view))
        self.view.page().setBackgroundColor(Qt.transparent)
        self.view.loadFinished.connect(self._page_ready)
        self.view.titleChanged.connect(self._page_asks)  # the page asks for older candles via its title
        page = self.view.page()
        page.renderProcessTerminated.connect(
            lambda status, code: log.warning("chart: the web view's process stopped (%s, exit code %s)",
                                             getattr(status, "name", status), code))
        if hasattr(page, "loadingChanged"):  # Qt 6.2+: says why a load failed
            page.loadingChanged.connect(self._loading_changed)
        self._load_page()
        self.outer.addWidget(self.view, 1)
        self.spinner.raise_()

    def _switch_to_native(self, remember: bool = True) -> None:
        """Draw the chart in the app instead of the web view (same data, same marks)."""
        from .native_chart import NativeChart
        global USE_NATIVE
        USE_NATIVE = True
        if self.view is not None:
            self.view.hide()
            self.outer.removeWidget(self.view)
            self.view.deleteLater()
            self.view = None
        self.native = NativeChart(on_older=self.load_older)
        self.outer.addWidget(self.native, 1)
        self.spinner.raise_()
        self.ready = True
        self.bars, self.trips = [], []
        if remember:
            log.info("chart: this Mac stopped the web chart, so the app draws it itself from now on")
            if self.use_native_cb:
                self.use_native_cb()
        self.load(full=True)

    # --- choices ------------------------------------------------------------------------------
    def reload_lists(self, account_id=None) -> None:
        keep = account_id if account_id is not None else self.account.currentData()
        self.account.clear()
        for aid, name in self.accounts_fn():
            self.account.addItem(name, aid)
        i = self.account.findData(keep)
        self.account.setCurrentIndex(max(i, 0))
        sym = self.symbol.currentText()
        self.symbol.clear()
        mine = self.symbols_fn() or ["MNQ"]
        self.symbol.addItems(mine + [m for m in MARKETS if m not in mine])
        if sym and self.symbol.findText(sym) >= 0:
            self.symbol.setCurrentText(sym)

    # --- data ---------------------------------------------------------------------------------
    def set_account(self, account_id) -> None:
        """Show the account picked at the top of the app."""
        if account_id == self.account.currentData() and self.bars:
            return
        self.bars, self.trips = [], []
        self.reload_lists(account_id)
        self.load(full=True)

    def _load_page(self) -> None:
        self.tries += 1
        try:
            load_page(self.view)
        except OSError as e:
            self.status.setText("The chart files are missing")
            log.error("chart: couldn't read %s: %s", PAGE.parent, e)

    def _loading_changed(self, info) -> None:
        try:
            failed = info.status().name == "LoadFailedStatus"
        except AttributeError:
            return
        if failed:
            log.warning("chart: page load failed: %s (code %s)", info.errorString(), info.errorCode())

    def _page_ready(self, ok: bool) -> None:
        self.ready = ok
        if ok:
            self.load(full=True)
        elif self.tries < 3:
            log.warning("chart: page didn't load, trying again")
            QTimer.singleShot(2000, self._load_page)
        else:
            log.warning("chart: the web chart didn't load after %d tries", self.tries)
            self.status.setText("")
            self._switch_to_native()

    def showEvent(self, e):
        super().showEvent(e)
        self.timer.start(LIVE_SECONDS * 1000)

    def hideEvent(self, e):
        self.timer.stop()
        super().hideEvent(e)

    def load(self, full: bool) -> None:
        if not self.ready or self.busy or self.account.currentData() is None:
            if self.account.currentData() is None:
                self.spinner.stop()
                self._js("showMessage", "Choose an account first: Account → Check connection.")
            return
        aid, sym, m = self.account.currentData(), self.symbol.currentText(), self.timeframe.currentData()
        now = datetime.now(timezone.utc)
        start = now - timedelta(days=DAYS.get(m, 5)) if full or not self.bars else self.bars[-1].time
        self.busy = True
        self.ticks += 1
        with_fills = full or self.ticks % 6 == 0  # new trades show within ~30 s
        fills_from = now - timedelta(days=DAYS.get(m, 5))
        if full:
            self.status.setText("Loading…")
            self.spinner.start(solid=not self.bars)
        self.run(lambda: self.fetch(aid, sym, m, start, now + timedelta(minutes=m), with_fills, fills_from),
                 lambda res, err: self._loaded(full, m, res, err))

    def _loaded(self, full: bool, minutes: int, res, err) -> None:
        self.busy = False
        if full:
            self.spinner.stop()
        if err:
            self.status.setText("Couldn't load bars")
            self._js("showMessage", f"Couldn't load Topstep's bars: {err}")
            return
        contract, bars, fills = res
        self.contract = contract
        if full:
            self.bars = bars
            self._js("setBars", bars_json(bars, self.tz))
            if self._go_live:
                self._go_live = False
                self._js_call("goLive")
        else:
            by_time = {b.time: b for b in self.bars}
            for b in bars:
                if b.time not in by_time:
                    self.bars.append(b)
                by_time[b.time] = b
                self._js("updateBar", bars_json([b], self.tz)[0])
            self.bars = [by_time[t] for t in sorted(by_time)]
        if fills is not None:
            trips = [t for t in round_trips(fills) if t.contract == contract.id]
            label_bots(trips, read_bot_log(self.bot_log), self.tz, contract.tick_size)
            keep = {(t.entry_time, t.side): t for t in self.trips} if not full else {}
            keep.update({(t.entry_time, t.side): t for t in trips})  # older trips loaded by scrolling stay
            self.trips = sorted(keep.values(), key=lambda t: t.entry_time)
            trips = self.trips
            self._js("setMarkers", trade_markers(trips, self.bars, self.tz, minutes))
        self._extras()
        self._js("setLines", self.lines(self.account.currentData(), contract.name))
        self.status.setText("")  # only says something while loading or when there's a problem

    def _page_asks(self, title: str) -> None:
        if title.startswith("older:"):
            self.load_older()

    def load_older(self) -> None:
        """Fetch the chunk of candles before the oldest one shown (as far back as Topstep keeps)."""
        if self.busy or not self.bars or self.account.currentData() is None:
            return
        aid, sym, m = self.account.currentData(), self.symbol.currentText(), self.timeframe.currentData()
        end = self.bars[0].time
        start = end - timedelta(days=max(DAYS.get(m, 5), 4))  # at least 4 days, so a weekend isn't "the end"
        self.busy = True
        self.status.setText("Loading older candles…")
        self.run(lambda: self.fetch(aid, sym, m, start, end, True, start),
                 lambda res, err: self._older_loaded(m, res, err))

    def _older_loaded(self, minutes: int, res, err) -> None:
        self.busy = False
        if err or m_changed(self, minutes):
            self.status.setText("Couldn't load older candles" if err else self.status.text())
            return
        _contract, bars, fills = res
        first = self.bars[0].time
        older = [b for b in bars if b.time < first]
        self.bars = older + self.bars
        self._js_call("prependBars", bars_json(self.bars, self.tz), len(older), bool(older))
        if fills is not None:
            have = {(t.entry_time, t.side) for t in self.trips}
            extra = [t for t in round_trips(fills) if t.contract == _contract.id and (t.entry_time, t.side) not in have]
            label_bots(extra, read_bot_log(self.bot_log), self.tz, _contract.tick_size)
            self.trips = extra + self.trips
            self._js("setMarkers", trade_markers(self.trips, self.bars, self.tz, minutes))
        self._extras()
        oldest = self.bars[0].time.astimezone(self.tz).strftime("%d %b") if self.bars else "–"
        self.status.setText("" if older else f"Topstep has no candles before {oldest}")

    def _extras(self) -> None:
        """The trades as boxes (entry to exit, stop and target) and the bots' opening ranges."""
        boxes = trade_boxes(self.trips, self.bars, self.tz)
        if self.open_trades and self.bars and getattr(self, "contract", None) is not None:
            try:
                live = self.open_trades(self.account.currentData(), self.contract.name)
            except Exception as e:  # noqa: BLE001
                log.debug("chart: couldn't read the open trades: %s", e)
                live = []
            boxes += open_boxes(live, self.bars, self.tz)
        self._js("setTrades", boxes)
        windows = []
        if self.ranges and self.bars and getattr(self, "contract", None) is not None:
            days = {b.time.astimezone(self.tz).date() for b in self.bars}
            try:
                windows = self.ranges(self.account.currentData(), self.contract.name, days)
            except Exception as e:  # noqa: BLE001 - the chart still works without them
                log.debug("chart: couldn't work out the ranges: %s", e)
        self._js("setRanges", range_boxes(windows, self.bars, self.tz))

    def refresh(self) -> None:
        """Refresh: fresh candles, then back to the latest one with the price scale fitted again."""
        self._go_live = True
        self._js_call("goLive")  # straight away, so the button does something even while the load runs
        self.load(full=True)

    def _js(self, fn: str, arg) -> None:
        self._js_call(fn, arg)

    def _js_call(self, fn: str, *args) -> None:
        if self.native is not None:
            getattr(self.native, fn)(*args)
        elif self.view is not None:
            self.view.page().runJavaScript(f"{fn}({', '.join(json.dumps(a) for a in args)})")


def m_changed(w: ChartPanel, minutes: int) -> bool:
    """The timeframe was switched while older candles were loading: drop them."""
    return w.timeframe.currentData() != minutes
