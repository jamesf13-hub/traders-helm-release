"""The product name, tagline and logo, in one place."""
APP_NAME = "Traders Helm"
TAGLINE = "Automated trading, you at the helm."
# The wordmark: TRADERS in the text colour, HELM in the accent colour, in Archivo ExtraBold capitals.
WORDMARK = ("TRADERS", "HELM")
