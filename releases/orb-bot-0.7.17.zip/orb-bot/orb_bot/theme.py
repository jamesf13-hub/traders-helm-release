"""The app's look ("Desk"): dark, dense, built for watching trades. Colours, fonts and the stylesheet live here.
The product name lives in brand.py."""
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import QRectF, Qt, QTimer
from PySide6.QtGui import QColor, QFont, QFontDatabase, QIcon, QPainter, QPalette, QPixmap
from PySide6.QtWidgets import QApplication, QSplitter, QSplitterHandle, QWidget

from .brand import APP_NAME, TAGLINE, WORDMARK  # noqa: F401 - re-exported for the app

# Surfaces, from the window background up.
BG, PANEL, PANEL_2, LINE, LINE_2 = "#11141a", "#171b23", "#1d222c", "#262c38", "#3a4252"
# Text: main, secondary, faint.
TEXT, TEXT_2, TEXT_3 = "#e6e9ef", "#8b93a5", "#5f6779"
ACCENT = "#6f9bff"
# Meaning: profit / long, loss / short / real orders, waiting.
UP, DOWN, WARN = "#2fc489", "#f05d5e", "#e6a23c"
DOWN_SOFT = "#ff8b8b"
# Tiles: a soft top-lit fill, a faint edge and a brighter top edge, so they read as raised panels.
TILE_BG = "qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #1c212b, stop:1 #161a22)"
# The frame around the pages (left bar, top bar): a shade darker than the pages, no lines between them.
CHROME = "#0b0d12"
TILE_EDGE, TILE_TOP = "rgba(255, 255, 255, 0.06)", "rgba(255, 255, 255, 0.13)"

FONT_DIR = Path(__file__).parent / "assets" / "fonts"
SANS, MONO = "IBM Plex Sans", "IBM Plex Mono"
WORDMARK_FONT = "Archivo ExtraBold"  # bundled, SIL Open Font License (assets/fonts/Archivo-OFL.txt)
_applied = False


def load_fonts() -> tuple[str, str]:
    """Register the bundled IBM Plex and Archivo fonts (SIL Open Font License). Falls back to the system fonts."""
    sans, mono = SANS, MONO
    families: set[str] = set()
    for f in sorted(FONT_DIR.glob("*.ttf")):
        i = QFontDatabase.addApplicationFont(str(f))
        if i >= 0:
            families.update(QFontDatabase.applicationFontFamilies(i))
    if SANS not in families:
        sans = QFont().defaultFamily()
    if MONO not in families:
        mono = "Menlo"
    return sans, mono


def _asset(name: str) -> str:
    return (Path(__file__).parent / "assets" / name).as_posix()


def stylesheet(sans: str, mono: str) -> str:
    return f"""
    * {{ font-family: "{sans}"; }}
    QWidget {{ color: {TEXT}; font-size: 13px; }}
    QMainWindow, QDialog, QMessageBox {{ background: {BG}; }}
    QToolTip {{ background: {PANEL_2}; color: {TEXT}; border: 1px solid {LINE_2}; padding: 5px 7px; }}
    QLabel {{ background: transparent; }}
    QLabel#muted {{ color: {TEXT_2}; }}
    QLabel#h2 {{ font-size: 16px; font-weight: 600; }}
    QLabel#big {{ font-size: 18px; font-weight: 600; }}
    QPushButton#link {{ background: transparent; border: none; color: {ACCENT}; padding: 2px 4px; }}
    QPushButton#link:hover {{ color: {TEXT}; }}
    QLabel#huge {{ font-size: 26px; font-weight: 600; }}
    QLabel#value {{ font-size: 15px; }}
    QLabel#code {{ background: {PANEL_2}; border: 1px solid {LINE}; border-radius: 6px; padding: 7px 9px;
        font-family: "{mono}"; font-size: 12px; color: {TEXT_2}; }}
    QLabel#lbl {{ color: {TEXT_3}; font-size: 10.5px; font-weight: 500; letter-spacing: 0.8px; }}

    /* header */
    QFrame#topbar {{ background: {CHROME}; }}
    QFrame#header {{ background: transparent; }}
    QLabel#brand {{ font-size: 14px; font-weight: 600; letter-spacing: 0.3px; }}
    QLabel#chip {{ background: {TILE_BG}; border: 1px solid {TILE_EDGE}; border-top-color: {TILE_TOP}; border-radius: 8px; padding: 5px 9px; font-size: 12px; }}
    QLabel#pill {{ border-radius: 10px; padding: 2px 10px; font-size: 12px; }}

    /* left icon bar */
    QFrame#rail {{ background: {CHROME}; }}
    QToolButton#nav {{ background: transparent; border: 0; border-radius: 9px; padding: 0; }}
    QToolButton#nav:hover {{ background: {PANEL}; }}
    QToolButton#nav:checked {{ background: {PANEL_2}; }}

    /* stat strip */
    QFrame#stats {{ background: {BG}; border-bottom: 1px solid {LINE}; }}
    QFrame#stat {{ border-right: 1px solid {LINE}; }}
    QFrame#stat[last="true"] {{ border-right: 0; }}
    QLabel#statTitle {{ color: {TEXT_3}; font-size: 10.5px; font-weight: 500; letter-spacing: 0.8px; }}
    QLabel#statValue {{ font-size: 21px; font-weight: 600; }}

    /* panels */
    QFrame#box {{ background: {TILE_BG}; border: 1px solid {TILE_EDGE}; border-top-color: {TILE_TOP}; border-radius: 12px; }}
    QGroupBox {{ font-size: 10.5px; font-weight: 500; background: {TILE_BG}; border: 1px solid {TILE_EDGE}; border-top-color: {TILE_TOP}; border-radius: 12px; margin-top: 0; padding: 30px 12px 12px 12px; }}
    QGroupBox::title {{ subcontrol-origin: padding; subcontrol-position: top left; left: 14px; top: 10px; color: {TEXT_3}; font-size: 10.5px; font-weight: 500; letter-spacing: 0.8px; }}

    /* buttons */
    QPushButton, QToolButton {{ background: {PANEL_2}; border: 1px solid {LINE}; border-radius: 7px; padding: 6px 12px; color: {TEXT}; }}
    QPushButton:hover, QToolButton:hover {{ border-color: {LINE_2}; }}
    QPushButton:pressed {{ background: {LINE}; }}
    QPushButton:disabled, QToolButton:disabled {{ color: {TEXT_3}; }}
    QPushButton::menu-indicator, QToolButton::menu-indicator {{ image: none; width: 0; }}
    QPushButton#start {{ background: {UP}; color: #062417; border: 0; font-weight: 600; padding: 7px 18px; }}
    QPushButton#start:hover {{ background: #45d49b; }}
    QPushButton#start:disabled {{ background: {PANEL_2}; color: {TEXT_3}; }}
    QPushButton#stop {{ background: #2a1517; color: {DOWN_SOFT}; border: 1px solid #5b2a2d; font-weight: 600; padding: 7px 18px; }}
    QPushButton#stop:hover {{ border-color: #7a3438; }}
    QPushButton#stop:disabled {{ color: {TEXT_3}; border-color: {LINE}; background: {PANEL_2}; }}
    QPushButton#close {{ background: transparent; color: {DOWN_SOFT}; border: 1px solid #5b2a2d; padding: 7px; }}
    QPushButton#close:hover {{ background: #2a1517; }}
    QPushButton#close:disabled {{ color: {TEXT_3}; border-color: {LINE}; }}
    QPushButton#flat {{ background: transparent; border: 0; color: {TEXT_2}; padding: 6px 8px; }}
    QPushButton#flat:hover {{ color: {TEXT}; }}

    /* Paper / Live orders switch */
    QFrame#seg {{ background: {PANEL_2}; border: 1px solid {LINE}; border-radius: 8px; }}
    QFrame#seg QPushButton {{ background: transparent; border: 0; border-radius: 6px; padding: 4px 11px; color: {TEXT_2}; font-size: 12px; }}
    QFrame#seg QPushButton:checked {{ background: #2a3140; color: {TEXT}; }}
    QFrame#seg QPushButton#live:checked {{ background: rgba(240,93,94,0.18); color: {DOWN_SOFT}; }}
    QFrame#seg QPushButton:disabled {{ color: {TEXT_3}; }}
    QFrame#seg QPushButton:checked:disabled {{ color: {TEXT_2}; }}

    /* inputs */
    QComboBox, QLineEdit, QSpinBox, QDoubleSpinBox, QTimeEdit, QDateEdit {{
        background: {PANEL_2}; border: 1px solid {LINE}; border-radius: 6px; padding: 5px 8px; color: {TEXT};
        selection-background-color: {ACCENT}; }}
    QComboBox:hover, QLineEdit:hover, QSpinBox:hover, QDoubleSpinBox:hover {{ border-color: {LINE_2}; }}
    QLineEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus, QTimeEdit:focus {{ border-color: {ACCENT}; }}
    QComboBox:disabled, QLineEdit:disabled, QSpinBox:disabled, QDoubleSpinBox:disabled, QTimeEdit:disabled {{ color: {TEXT_3}; }}
    QComboBox::drop-down {{ border: 0; width: 22px; }}
    QComboBox QAbstractItemView {{ background: {PANEL_2}; border: 1px solid {LINE_2}; selection-background-color: #2a3140; outline: 0; padding: 4px; }}
    QSpinBox::up-button, QSpinBox::down-button, QDoubleSpinBox::up-button, QDoubleSpinBox::down-button,
    QTimeEdit::up-button, QTimeEdit::down-button {{ width: 0; border: 0; }}
    QCheckBox {{ spacing: 8px; }}
    QCheckBox::indicator, QTableWidget::indicator {{ width: 30px; height: 16px; border: 0; background: transparent;
        image: url({_asset("switch-off.svg")}); }}
    QCheckBox::indicator:checked, QTableWidget::indicator:checked {{ image: url({_asset("switch-on.svg")}); }}
    QCheckBox::indicator:disabled {{ image: url({_asset("switch-disabled.svg")}); }}
    QCheckBox::indicator:checked:disabled {{ image: url({_asset("switch-on-disabled.svg")}); }}

    /* tabs */
    QTabWidget::pane {{ border: 0; }}
    QTabBar {{ background: transparent; }}
    QTabBar::tab {{ background: transparent; color: {TEXT_2}; padding: 9px 14px; border: 0; border-bottom: 2px solid transparent; margin-right: 2px; }}
    QTabBar::tab:selected {{ color: {TEXT}; border-bottom: 2px solid {ACCENT}; }}
    QTabBar::tab:hover {{ color: {TEXT}; }}
    QFrame#tabline {{ background: {LINE}; max-height: 1px; min-height: 1px; }}

    /* tables */
    QTableWidget {{ background: transparent; border: 0; gridline-color: transparent; alternate-background-color: transparent;
        selection-background-color: transparent; }}
    QTableWidget::item {{ border-top: 1px solid {LINE}; padding: 4px 6px; }}
    QHeaderView {{ background: transparent; }}
    QHeaderView::section {{ background: transparent; color: {TEXT_3}; border: 0; padding: 4px 6px; font-size: 10.5px; font-weight: 500; }}
    QTableCornerButton::section {{ background: transparent; border: 0; }}

    /* log, scroll areas */
    QPlainTextEdit {{ background: {BG}; border: 0; color: {TEXT_2}; font-family: "{mono}"; font-size: 12px; padding: 6px 10px; }}
    QScrollArea {{ background: transparent; border: 0; }}
    QScrollArea > QWidget > QWidget {{ background: transparent; }}
    QScrollBar:vertical {{ background: transparent; width: 10px; margin: 2px; }}
    QScrollBar::handle:vertical {{ background: {LINE_2}; border-radius: 3px; min-height: 30px; }}
    QScrollBar:horizontal {{ background: transparent; height: 10px; margin: 2px; }}
    QScrollBar::handle:horizontal {{ background: {LINE_2}; border-radius: 3px; min-width: 30px; }}
    QScrollBar::add-line, QScrollBar::sub-line {{ width: 0; height: 0; }}
    QScrollBar::add-page, QScrollBar::sub-page {{ background: transparent; }}

    QMenuBar {{ background: {BG}; }}
    QMenuBar::item:selected {{ background: {PANEL_2}; }}
    QMenu {{ background: {PANEL_2}; border: 1px solid {LINE_2}; padding: 4px; }}
    QMenu::item {{ padding: 6px 18px; border-radius: 5px; }}
    QMenu::item:selected {{ background: #2a3140; }}
    QMenu::separator {{ height: 1px; background: {LINE}; margin: 4px 6px; }}
    QCalendarWidget QWidget {{ alternate-background-color: {PANEL}; }}
    """


def apply(app: QApplication | None = None) -> None:
    """Dark palette, bundled fonts and the stylesheet, for every window and dialog. Safe to call more than once."""
    global _applied
    app = app or QApplication.instance()
    if app is None or _applied:
        return
    _applied = True
    app.setStyle("Fusion")  # draws the same on Mac and Windows, and honours the stylesheet fully
    sans, mono = load_fonts()
    font = QFont(sans)
    font.setPixelSize(13)
    app.setFont(font)
    pal = QPalette()
    for role, color in [(QPalette.Window, BG), (QPalette.WindowText, TEXT), (QPalette.Base, PANEL_2),
                        (QPalette.AlternateBase, PANEL), (QPalette.Text, TEXT), (QPalette.Button, PANEL_2),
                        (QPalette.ButtonText, TEXT), (QPalette.Highlight, ACCENT), (QPalette.HighlightedText, "#ffffff"),
                        (QPalette.ToolTipBase, PANEL_2), (QPalette.ToolTipText, TEXT), (QPalette.PlaceholderText, TEXT_3),
                        (QPalette.Mid, LINE), (QPalette.Dark, BG), (QPalette.Light, LINE_2)]:
        pal.setColor(role, QColor(color))
    pal.setColor(QPalette.Disabled, QPalette.Text, QColor(TEXT_3))
    pal.setColor(QPalette.Disabled, QPalette.ButtonText, QColor(TEXT_3))
    pal.setColor(QPalette.Disabled, QPalette.WindowText, QColor(TEXT_3))
    app.setPalette(pal)
    app.setStyleSheet(stylesheet(sans, mono))


def dot_icon(color: str) -> QIcon:
    """A small coloured dot for tabs (green = running)."""
    if color not in _dots:
        pm = QPixmap(16, 16)
        pm.fill(Qt.transparent)
        p = QPainter(pm)
        p.setRenderHint(QPainter.Antialiasing)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(color))
        p.drawEllipse(5, 5, 7, 7)
        p.end()
        _dots[color] = QIcon(pm)
    return _dots[color]


_dots: dict[str, QIcon] = {}


def logo_pixmap(size: int = 18) -> QPixmap:
    """The app mark: the compass ship's wheel (assets/logo.svg), drawn sharp on Retina screens."""
    from PySide6.QtSvg import QSvgRenderer
    scale = 2
    pm = QPixmap(size * scale, size * scale)
    pm.setDevicePixelRatio(scale)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing)
    QSvgRenderer(_asset("logo.svg")).render(p, QRectF(0, 0, size, size))
    p.end()
    return pm


# Left icon bar: 24×24 line drawings, stroke filled in per state.
NAV_ICONS = {
    "chart": '<path d="M6 3v4M6 15v6M12 2v3M12 13v4M18 6v4M18 16v4"/><rect x="4" y="7" width="4" height="8" rx="1"/>'
             '<rect x="10" y="5" width="4" height="8" rx="1"/><rect x="16" y="10" width="4" height="6" rx="1"/>',
    "bots": '<rect x="5" y="8" width="14" height="11" rx="3"/><path d="M12 8V5.5"/><circle cx="12" cy="4.3" r="1.2"/>'
            '<circle cx="9.5" cy="13" r="1.1" fill="{c}"/><circle cx="14.5" cy="13" r="1.1" fill="{c}"/>'
            '<path d="M9.5 16.3h5M3 12.5v3M21 12.5v3"/>',
    "performance": '<path d="M3 20h18"/><path d="M4 16l5-5 4 3 7-8"/><path d="M15 6h5v5"/>',
    "settings": '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1'
                'M4.9 19.1L7 17M17 7l2.1-2.1"/><circle cx="12" cy="12" r="7"/>',
    "help": '<circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.7.3-1 .9-1 1.7v.5"/>'
            '<circle cx="12" cy="17.2" r=".6" fill="{c}"/>',
}


def nav_icon(name: str, size: int = 22) -> QIcon:
    """An icon for the left bar: grey normally, accent blue on the page that's open."""
    from PySide6.QtCore import QByteArray
    from PySide6.QtSvg import QSvgRenderer
    icon = QIcon()
    for colour, state in ((TEXT_2, QIcon.Off), (ACCENT, QIcon.On)):
        body = NAV_ICONS[name].replace("{c}", colour)
        svg = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="{colour}" '
               f'stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">{body}</svg>')
        pm = QPixmap(size * 2, size * 2)
        pm.setDevicePixelRatio(2)
        pm.fill(Qt.transparent)
        p = QPainter(pm)
        p.setRenderHint(QPainter.Antialiasing)
        QSvgRenderer(QByteArray(svg.encode())).render(p, QRectF(0, 0, size, size))
        p.end()
        icon.addPixmap(pm, QIcon.Normal, state)
    return icon


def app_icon() -> QIcon:
    """The window and Dock icon: the wheel on a dark rounded tile (assets/icon.svg)."""
    return QIcon(_asset("icon.svg"))


def wordmark_html(size: int = 15) -> str:
    """TRADERS HELM for a QLabel, with HELM in the accent colour."""
    first, second = WORDMARK
    return (f"<span style=\"font-family:'{WORDMARK_FONT}'; font-size:{size}px; letter-spacing:1.2px;\">"
            f"<span style=\"color:{TEXT}\">{first}</span> <span style=\"color:{ACCENT}\">{second}</span></span>")


def mono_font() -> QFont:
    f = QFont(MONO if MONO in QFontDatabase.families() else "Menlo")
    f.setStyleHint(QFont.Monospace)
    f.setPixelSize(12)
    return f


ALIGN_RIGHT = Qt.AlignRight | Qt.AlignVCenter


# --- dividers ----------------------------------------------------------------------------------------
class GripHandle(QSplitterHandle):
    """A divider you can see and grab: a wide pill of dots in the middle that lights up on hover."""

    def __init__(self, orientation, parent):
        super().__init__(orientation, parent)
        self.setAttribute(Qt.WA_Hover, True)

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        hot = self.underMouse()
        r = QRectF(self.rect())
        vertical = self.orientation() == Qt.Vertical  # the handle runs across, between stacked sections
        c = r.center()
        line = QColor(ACCENT if hot else LINE_2)
        # a line the full width of the divider, and a grip in the middle of it
        p.fillRect(QRectF(r.left(), c.y() - 0.5, r.width(), 1) if vertical else QRectF(c.x() - 0.5, r.top(), 1, r.height()),
                   line)
        grip = QRectF(c.x() - 32, c.y() - 5, 64, 10) if vertical else QRectF(c.x() - 5, c.y() - 32, 10, 64)
        p.setPen(line)
        p.setBrush(QColor(PANEL_2))
        p.drawRoundedRect(grip, 5, 5)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(ACCENT if hot else TEXT_2))
        for i in range(-2, 3):  # five dots
            x, y = (c.x() + i * 9, c.y()) if vertical else (c.x(), c.y() + i * 9)
            p.drawEllipse(QRectF(x - 1.75, y - 1.75, 3.5, 3.5))

    def enterEvent(self, e):
        self.update()
        super().enterEvent(e)

    def leaveEvent(self, e):
        self.update()
        super().leaveEvent(e)


class GripSplitter(QSplitter):
    HANDLE = 12

    def __init__(self, orientation, parent=None):
        super().__init__(orientation, parent)
        self.setHandleWidth(self.HANDLE)

    def createHandle(self):
        return GripHandle(self.orientation(), self)


class LogoSpinner(QWidget):
    """The Traders Helm wheel turning slowly over a blank or reloading chart, like the app is thinking.
    solid=True covers whatever is underneath (nothing to see yet); otherwise it's a light veil."""

    def __init__(self, parent=None, size: int = 46, text: str = "Loading…"):
        super().__init__(parent)
        self.setAttribute(Qt.WA_TransparentForMouseEvents)
        self.logo, self.size_, self.text, self.solid = logo_pixmap(size), size, text, True
        self.angle = 0.0
        self.timer = QTimer(self)
        self.timer.setInterval(16)
        self.timer.timeout.connect(self._tick)
        self.hide()

    def start(self, solid: bool = True, text: str | None = None) -> None:
        self.solid = solid
        if text is not None:
            self.text = text
        if self.parentWidget() is not None and not self.isVisible():
            self.raise_()
        self.show()
        self.timer.start()
        self.update()

    def stop(self) -> None:
        self.timer.stop()
        self.hide()

    def _tick(self) -> None:
        self.angle = (self.angle + 3.0) % 360  # one turn in about two seconds
        self.update()

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        bg = QColor(BG)
        bg.setAlpha(255 if self.solid else 150)
        p.fillRect(self.rect(), bg)
        cx, cy = self.width() / 2, self.height() / 2 - 10
        p.save()
        p.translate(cx, cy)
        p.rotate(self.angle)
        p.drawPixmap(QRectF(-self.size_ / 2, -self.size_ / 2, self.size_, self.size_), self.logo,
                     QRectF(self.logo.rect()))
        p.restore()
        if self.text:
            f = QFont(self.font())
            f.setPixelSize(12)
            p.setFont(f)
            p.setPen(QColor(TEXT_2))
            p.drawText(QRectF(0, cy + self.size_ / 2 + 8, self.width(), 20), Qt.AlignHCenter | Qt.AlignTop, self.text)
