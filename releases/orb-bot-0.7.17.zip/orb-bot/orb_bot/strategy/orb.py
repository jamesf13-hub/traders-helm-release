"""Port of James's Pine Script "My ORB PMT" (//@version=6). Broker-agnostic: bars in, Signals out.

Each closed chart bar goes through `on_bar`, in the same order TradingView evaluates it:
1. Session state: the range starts on the first bar inside [start, start + window), grows
   with every bar inside it, and locks on the first bar after it (that bar can already trade).
2. Breakout: bar CLOSE beyond the locked range, within `breakout_window_hours` of the lock,
   max 1 trade (2 with bias flip; the flip must be the opposite direction), flat position,
   plus the optional penetration / body / exhaustion filters.
3. Stop = other side of the range, or the breakout candle's low/high when candle SL triggers.
   Target = close +/- RR x risk. Entry at the bar close (process_orders_on_close=true).
4. Size = floor(equity x risk% [x passer multiplier] / (stop distance x point value)),
   at least 1, at most max_contracts.
Times use `timezone` (Australia/Brisbane in the Pine Script), or a session's own `timezone`.
"""
from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo

from ..config import Config, SessionConfig, session_tz
from ..models import Bar, Contract, Side, Signal

log = logging.getLogger(__name__)
NEW_YORK = ZoneInfo("America/New_York")


def trading_day(t: datetime) -> date:
    """CME trading day: a new day starts at 18:00 New York time."""
    return (t.astimezone(NEW_YORK) + timedelta(hours=6)).date()


@dataclass
class SessionState:
    high: float | None = None
    low: float | None = None
    locked: bool = False
    lock_time: datetime | None = None
    trades: int = 0
    blocked: Side | None = None
    prev_in_session: bool = False


@dataclass
class ORBStrategy:
    config: Config
    contract: Contract
    state: dict[str, SessionState] = field(default_factory=dict)
    passer_high: bool = True
    passer_wins_since_loss: int = 0

    def __post_init__(self):
        for s in self.config.sessions:
            self.state.setdefault(s.name, SessionState())

    # --- Prop Firm Passer (sizing only) ---------------------------------------------
    def on_trade_closed(self, pnl: float) -> None:
        r = self.config.risk
        if not r.prop_firm_passer:
            return
        if pnl > 0:  # Pine: strategy.wintrades only counts profit > 0
            if not self.passer_high:
                self.passer_wins_since_loss += 1
                if self.passer_wins_since_loss >= r.passer_recovery_wins:
                    self.passer_high, self.passer_wins_since_loss = True, 0
        else:
            self.passer_high, self.passer_wins_since_loss = False, 0
        log.info("passer: %s risk (wins since loss %d)", "HIGH" if self.passer_high else "base",
                 self.passer_wins_since_loss)

    def qty_for_risk(self, stop_distance: float, equity: float) -> int:
        r = self.config.risk
        mult = r.passer_multiplier if (r.prop_firm_passer and self.passer_high) else 1.0
        if r.risk_mode == "dollars":
            risk_dollars = r.risk_dollars * mult
        else:
            base = r.account_size if r.risk_on_starting_balance else equity
            risk_dollars = base * (r.risk_percent / 100) * mult
        point_value = self.contract.tick_value / self.contract.tick_size
        per_contract = stop_distance * point_value
        if per_contract <= 0:
            return 1
        return min(r.max_contracts, max(1, math.floor(risk_dollars / per_contract)))

    def mark_session_done(self, name: str) -> None:
        cfg = next(s for s in self.config.sessions if s.name == name)
        self.state[name].trades = cfg.max_trades

    # --- per bar --------------------------------------------------------------------------
    def on_bar(self, bar: Bar, equity: float, in_position: bool, day_pnl: float = 0.0) -> Signal | None:
        for cfg in self.config.sessions:
            local = bar.time.astimezone(session_tz(self.config, cfg))
            self._update_session(cfg, self.state[cfg.name], bar, local.hour * 60 + local.minute)
        if in_position:
            return None
        for cfg in self.config.sessions:
            sig = self._check_entry(cfg, self.state[cfg.name], bar, equity, day_pnl)
            if sig:
                return sig
        return None

    def _update_session(self, cfg: SessionConfig, st: SessionState, bar: Bar, cur_min: int) -> None:
        start_min = cfg.start.hour * 60 + cfg.start.minute
        # Ranges are tracked even for switched-off sessions, so switching one on mid-session uses the full range.
        in_session = start_min <= cur_min < start_min + cfg.window_minutes
        if in_session and not st.prev_in_session:
            st.high, st.low, st.locked, st.trades, st.blocked = bar.high, bar.low, False, 0, None
        if in_session:
            st.high, st.low = max(st.high, bar.high), min(st.low, bar.low)
        if not in_session and st.prev_in_session:
            st.locked, st.lock_time = True, bar.time
            if cfg.enabled:
                log.info("%s range locked: high %.2f low %.2f (%.2f pts)", cfg.name, st.high, st.low,
                         st.high - st.low)
        st.prev_in_session = in_session

    def _check_entry(self, cfg: SessionConfig, st: SessionState, bar: Bar, equity: float,
                     day_pnl: float) -> Signal | None:
        if not cfg.enabled or not st.locked or st.trades >= cfg.max_trades:
            return None
        if cfg.breakout_window_hours and bar.time - st.lock_time > timedelta(hours=cfg.breakout_window_hours):
            return None
        o, h, l, c = bar.open, bar.high, bar.low, bar.close
        candle = h - l
        first = st.trades == 0
        min_pct = (cfg.min_close_pct_first if first else cfg.min_close_pct_flip) / 100
        rr = cfg.rr_first if first else cfg.rr_flip
        body_ok = not cfg.body_filter or (abs(c - o) / candle * 100 if candle > 0 else 0) >= cfg.min_body_pct
        rng = st.high - st.low
        if (c > st.high and st.blocked is not Side.BUY and candle > 0 and (c - st.high) / candle >= min_pct
                and body_ok and (not cfg.exhaustion_filter or h - max(c, o) <= rng)):
            side, sl = Side.BUY, st.low
            if cfg.candle_sl and candle > 0 and (h - max(l, st.high)) / candle * 100 > cfg.candle_sl_threshold:
                sl = l
        elif (c < st.low and st.blocked is not Side.SELL and candle > 0 and (st.low - c) / candle >= min_pct
              and body_ok and (not cfg.exhaustion_filter or min(c, o) - l <= rng)):
            side, sl = Side.SELL, st.high
            if cfg.candle_sl and candle > 0 and (min(h, st.low) - l) / candle * 100 > cfg.candle_sl_threshold:
                sl = h
        else:
            return None

        # Pine counts the trade the moment the entry fires.
        st.trades += 1
        st.blocked = side
        label = "First" if first else "Flip"
        blocked = self._safety_block(day_pnl)
        if blocked:
            log.info("%s %s %s breakout skipped: %s", cfg.name, side.value, label, blocked)
            return None
        risk = (c - sl) * side.sign
        tp = c + side.sign * rr * risk
        qty = self.qty_for_risk(risk, equity)
        qty = self._cap_for_daily_loss(cfg.name, qty, risk, day_pnl)
        if qty < 1:
            return None
        return Signal(cfg.name, side, c, sl, tp, qty,
                      f"{label}: close {c:.2f} beyond range {st.low:.2f}-{st.high:.2f}, RR {rr}")

    def _cap_for_daily_loss(self, name: str, qty: int, stop_distance: float, day_pnl: float) -> int:
        """Bot-only: shrink size so a full stop-out (plus 1 tick of slippage) can't take the day past the limit."""
        limit = abs(self.config.safety.max_daily_loss)
        if not limit:
            return qty
        point_value = self.contract.tick_value / self.contract.tick_size
        per_contract = (stop_distance + self.contract.tick_size) * point_value
        room = limit + day_pnl
        allowed = math.floor(room / per_contract) if per_contract > 0 else qty
        if allowed < qty:
            if allowed < 1:
                log.info("%s trade skipped: a stop-out would lose $%.0f, only $%.0f left before the $%.0f daily "
                         "loss limit", name, per_contract, room, limit)
            else:
                log.info("%s size cut from %d to %d to stay inside the $%.0f daily loss limit", name, qty, allowed,
                         limit)
        return min(qty, allowed)

    def _safety_block(self, day_pnl: float) -> str | None:
        s = self.config.safety
        if s.max_daily_loss and day_pnl <= -abs(s.max_daily_loss):
            return f"max daily loss reached (${day_pnl:.2f})"
        if s.stop_after_daily_profit and day_pnl >= s.stop_after_daily_profit:
            return f"daily profit target reached (${day_pnl:.2f})"
        return None
