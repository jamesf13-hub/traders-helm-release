"""Simulated order handling for paper trading and replay. Never touches a real account.

Fills follow TradingView's broker emulator so replays line up with the strategy tester:
- Entry at the signal bar's close (process_orders_on_close=true), plus optional slippage.
- From the next bar: if the bar opens through the stop or target, fill at the open.
- If both are inside one bar, TradingView assumes the extreme nearer the open came first
  (open -> high -> low when the high is closer to the open, else open -> low -> high).
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime

from ..config import SimConfig
from ..models import Account, Bar, Contract, OpenOrder, OrderResult, Position, Side
from .base import Broker

log = logging.getLogger(__name__)


@dataclass
class SimTrade:
    tag: str | None
    side: Side
    size: int
    entry_time: datetime
    entry_price: float
    stop_price: float
    target_price: float
    exit_time: datetime | None = None
    exit_price: float | None = None
    exit_reason: str | None = None
    pnl: float = 0.0


class SimBroker(Broker):
    def __init__(self, contract: Contract, sim: SimConfig, data: Broker | None = None,
                 starting_balance: float = 50_000.0):
        self.contract = contract
        self.sim = sim
        self.data = data
        self.balance = starting_balance
        self.trades: list[SimTrade] = []
        self.just_closed: list[SimTrade] = []
        self.open: SimTrade | None = None
        self.last_bar: Bar | None = None
        self._next_id = 1

    def connect(self) -> None:
        if self.data:
            self.data.connect()

    def get_account_state(self) -> Account:
        return Account(0, "SIM", self.balance, True)

    def get_contract(self) -> Contract:
        return self.contract

    def get_historical_bars(self, start, end, minutes):
        if not self.data:
            raise RuntimeError("SimBroker has no data source")
        return self.data.get_historical_bars(start, end, minutes)

    # --- simulation ---------------------------------------------------------------
    def update(self, bar: Bar) -> None:
        """Call with each closed bar BEFORE the strategy sees it, to process bracket exits."""
        self.last_bar = bar
        t = self.open
        if not t:
            return
        slip = self.sim.slippage_ticks * self.contract.tick_size * t.side.sign
        long = t.side is Side.BUY
        # Gap through a level at the open fills at the open.
        if (bar.open <= t.stop_price) if long else (bar.open >= t.stop_price):
            return self._close(bar.time, bar.open - slip, "stop")
        if (bar.open >= t.target_price) if long else (bar.open <= t.target_price):
            return self._close(bar.time, bar.open, "target")
        hit_stop = bar.low <= t.stop_price if long else bar.high >= t.stop_price
        hit_target = bar.high >= t.target_price if long else bar.low <= t.target_price
        if hit_stop and hit_target:
            high_first = (bar.high - bar.open) < (bar.open - bar.low)
            target_first = high_first if long else not high_first
            hit_stop, hit_target = not target_first, target_first
        if hit_stop:
            self._close(bar.time, t.stop_price - slip, "stop")
        elif hit_target:
            self._close(bar.time, t.target_price, "target")

    def _close(self, when: datetime, price: float, reason: str) -> None:
        t = self.open
        assert t
        ticks = (price - t.entry_price) * t.side.sign / self.contract.tick_size
        t.exit_time, t.exit_price, t.exit_reason = when, price, reason
        t.pnl = ticks * self.contract.tick_value * t.size - 2 * self.sim.commission_per_side * t.size
        self.balance += t.pnl
        self.open = None
        self.just_closed.append(t)
        log.info("SIM exit %s %s x%d @ %.2f (%s) pnl $%.2f", t.side.value, self.contract.name, t.size,
                 price, reason, t.pnl)

    # --- broker interface ---------------------------------------------------------
    def place_bracket_order(self, side, size, stop_ticks, target_ticks, tag=None) -> OrderResult:
        if self.open:
            return OrderResult(False, None, "already in a position")
        if not self.last_bar:
            return OrderResult(False, None, "no price yet")
        tick = self.contract.tick_size
        # Like TradingView: stop and target are fixed prices from the signal close; slippage only
        # moves the entry fill (and stop fills, in update()).
        ref = self.last_bar.close
        entry = ref + side.sign * self.sim.slippage_ticks * tick
        self.open = SimTrade(tag, side, size, self.last_bar.time, entry,
                             ref - side.sign * stop_ticks * tick, ref + side.sign * target_ticks * tick)
        self.trades.append(self.open)
        oid = self._next_id
        self._next_id += 1
        log.info("SIM entry %s %s x%d @ %.2f stop %.2f target %.2f", side.value, self.contract.name, size,
                 entry, self.open.stop_price, self.open.target_price)
        return OrderResult(True, oid)

    def cancel_order(self, order_id: int) -> bool:
        return True

    def modify_stop(self, order_id: int, price: float) -> bool:
        if not self.open:
            return False
        self.open.stop_price = price
        return True

    def get_positions(self) -> list[Position]:
        t = self.open
        return [Position(self.contract.id, t.side, t.size, t.entry_price)] if t else []

    def get_open_orders(self) -> list[OpenOrder]:
        t = self.open
        if not t:
            return []
        exit_side = Side.SELL if t.side is Side.BUY else Side.BUY
        return [OpenOrder(-1, self.contract.id, exit_side, t.size, 4, None, t.stop_price),
                OpenOrder(-2, self.contract.id, exit_side, t.size, 1, t.target_price, None)]

    def flatten_all(self) -> None:
        if self.open and self.last_bar:
            self._close(self.last_bar.time, self.last_bar.close, "flatten")

    def close_size(self, side: Side, size: int) -> None:
        self.flatten_all()

    def close_now(self, price: float, when: datetime, reason: str = "manual") -> None:
        if self.open:
            self._close(when, price, reason)
