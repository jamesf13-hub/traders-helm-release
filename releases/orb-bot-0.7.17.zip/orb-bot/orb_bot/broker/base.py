"""Broker interface. The engine only ever talks to brokers through these methods."""
from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import datetime

from ..models import Account, Bar, Contract, Fill, OpenOrder, OrderResult, Position, Side


class Broker(ABC):
    @abstractmethod
    def connect(self) -> None: ...

    def disconnect(self) -> None:
        pass

    @abstractmethod
    def get_account_state(self) -> Account: ...

    @abstractmethod
    def get_contract(self) -> Contract: ...

    @abstractmethod
    def get_historical_bars(self, start: datetime, end: datetime, minutes: int) -> list[Bar]:
        """Closed bars only, oldest first, times timezone-aware (UTC is fine)."""

    @abstractmethod
    def place_bracket_order(self, side: Side, size: int, stop_ticks: int, target_ticks: int,
                            tag: str | None = None) -> OrderResult:
        """Market entry with stop-loss and take-profit attached at the broker."""

    @abstractmethod
    def cancel_order(self, order_id: int) -> bool: ...

    @abstractmethod
    def get_positions(self) -> list[Position]: ...

    @abstractmethod
    def get_open_orders(self) -> list[OpenOrder]: ...

    @abstractmethod
    def flatten_all(self) -> None:
        """Close every position on the contract and cancel every working order on it."""

    def close_size(self, side: Side, size: int) -> None:
        """Close `size` contracts of a `side` trade, leaving any other contracts on the account open."""
        raise NotImplementedError

    def get_last_price(self) -> float | None:
        """Latest traded price, if the broker can provide it cheaply."""
        return None

    def get_fills(self, since: datetime) -> list[Fill]:
        """Executions on the account since `since` (used to work out the bot's own P&L)."""
        return []
