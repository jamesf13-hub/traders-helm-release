"""Live trades from the ProjectX market hub (SignalR over a WebSocket), rolled into bars as they happen.

"Fast bars": instead of waiting 1-3 s for TopstepX to publish a finished bar, the bot builds the bar from
the live trades and acts a fraction of a second after the close. A bar is only used if the stream was
connected for the whole bar; otherwise the bot falls back to TopstepX's own bar. The engine compares each
live bar with TopstepX's official one afterwards and logs any difference.

Docs: https://gateway.docs.projectx.com/docs/realtime/
"""
from __future__ import annotations

import json
import logging
import threading
import time as _time
from datetime import datetime, timedelta, timezone

from ..models import Bar
from .projectx import ProjectXBroker, _parse_ts

log = logging.getLogger(__name__)

RS = "\x1e"  # SignalR record separator
PING_EVERY = 15.0
STALE_AFTER = 30.0  # no message for this long = treat the stream as down


def hub_url(broker: ProjectXBroker) -> str:
    if broker.cfg.rtc_url:
        return broker.cfg.rtc_url
    base = broker.cfg.base_url.replace("https://", "wss://").replace("http://", "ws://")
    return base.replace("://api.", "://rtc.") + "/hubs/market"


class TradeStream:
    """One market hub connection for one contract, shared by every bot in the app."""

    def __init__(self, broker: ProjectXBroker, contract_id: str):
        self.broker = broker
        self.contract_id = contract_id
        self.minutes: dict[datetime, list[float]] = {}  # minute open (UTC) -> [open, high, low, close, volume]
        self.connected_since: datetime | None = None  # start of the current unbroken connection
        self.last_message: float = 0.0
        self.trades = 0
        self.last_price: float | None = None  # the latest trade, for live open P&L
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._ws = None

    # --- lifecycle ----------------------------------------------------------------------------------
    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, name="trade-stream", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        ws = self._ws
        if ws is not None:
            try:
                ws.close()
            except Exception:  # noqa: BLE001
                pass

    @property
    def healthy(self) -> bool:
        return self.connected_since is not None and _time.monotonic() - self.last_message < STALE_AFTER

    def _run(self) -> None:
        delay, warned = 1.0, False
        while not self._stop.is_set():
            try:
                self._session()
                delay, warned = 1.0, False
            except Exception as e:  # noqa: BLE001 - reconnect; the bot falls back to TopstepX bars meanwhile
                if self.connected_since is not None:
                    delay, warned = 1.0, False  # it was up: a fresh outage
                if not self._stop.is_set():
                    # One warning per outage; the retries (every 30 s at most) go to the log file only.
                    (log.debug if warned else log.warning)(
                        "live price stream dropped (%s); using TopstepX's bars, reconnecting in %.0fs", e, delay)
                    warned = True
            self.connected_since = None
            if self._stop.wait(delay):
                break
            delay = min(delay * 2, 30)

    def _session(self) -> None:
        import websocket  # websocket-client

        token = self.broker._ensure_token()
        ws = websocket.create_connection(f"{hub_url(self.broker)}?access_token={token}", timeout=10)
        self._ws = ws
        try:
            ws.send(json.dumps({"protocol": "json", "version": 1}) + RS)
            for msg in self._read(ws):
                if msg.get("error"):
                    raise RuntimeError(f"handshake refused: {msg['error']}")
                break  # empty handshake reply = accepted
            ws.send(json.dumps({"type": 1, "target": "SubscribeContractTrades",
                                "arguments": [self.contract_id]}) + RS)
            self.connected_since = datetime.now(timezone.utc)
            self.last_message = _time.monotonic()
            log.info("live price stream connected for %s", self.contract_id)
            ws.settimeout(PING_EVERY)
            last_ping = _time.monotonic()
            while not self._stop.is_set():
                if _time.monotonic() - last_ping >= PING_EVERY:
                    ws.send(json.dumps({"type": 6}) + RS)
                    last_ping = _time.monotonic()
                try:
                    for msg in self._read(ws):
                        self.handle(msg)
                except websocket.WebSocketTimeoutException:
                    pass
                if _time.monotonic() - self.last_message > STALE_AFTER:
                    raise RuntimeError("no data for 30s")
        finally:
            self._ws = None
            try:
                ws.close()
            except Exception:  # noqa: BLE001
                pass

    def _read(self, ws):
        raw = ws.recv()
        if isinstance(raw, bytes):
            raw = raw.decode()
        if raw == "":
            raise RuntimeError("connection closed")
        self.last_message = _time.monotonic()
        for part in raw.split(RS):
            if part:
                yield json.loads(part)

    # --- messages -----------------------------------------------------------------------------------
    def handle(self, msg: dict) -> None:
        t = msg.get("type")
        if t == 7:
            raise RuntimeError(f"server closed the stream: {msg.get('error') or 'no reason given'}")
        if t != 1 or msg.get("target") != "GatewayTrade":
            return
        args = msg.get("arguments") or []
        if len(args) < 2 or (args[0] and args[0] != self.contract_id):
            return
        data = args[1]
        for trade in data if isinstance(data, list) else [data]:
            try:
                self.add_trade(_parse_ts(trade["timestamp"]), float(trade["price"]), float(trade.get("volume") or 0))
            except (KeyError, TypeError, ValueError) as e:
                log.debug("unreadable trade %r: %s", trade, e)

    def add_trade(self, when: datetime, price: float, volume: float = 0.0) -> None:
        minute = when.replace(second=0, microsecond=0)
        with self._lock:
            self.trades += 1
            self.last_price = price
            m = self.minutes.get(minute)
            if m is None:
                self.minutes[minute] = [price, price, price, price, volume]
            else:
                m[1], m[2], m[3], m[4] = max(m[1], price), min(m[2], price), price, m[4] + volume
            if len(self.minutes) > 3 * 24 * 60:  # keep about 3 days
                for k in sorted(self.minutes)[:len(self.minutes) - 2 * 24 * 60]:
                    del self.minutes[k]

    # --- bars ---------------------------------------------------------------------------------------
    def bar(self, open_time: datetime, minutes: int) -> Bar | None:
        """The bar from open_time, built from live trades, or None if the stream didn't see all of it."""
        since = self.connected_since
        if since is None or since > open_time or not self.healthy:
            return None
        start = open_time.astimezone(timezone.utc)
        with self._lock:
            rows = [self.minutes[k] for k in sorted(self.minutes)
                    if start <= k < start + timedelta(minutes=minutes)]
        if not rows:
            return None
        return Bar(open_time, rows[0][0], max(r[1] for r in rows), min(r[2] for r in rows), rows[-1][3],
                   sum(r[4] for r in rows))


_STREAMS: dict[tuple[str, str], TradeStream] = {}
_STREAMS_LOCK = threading.Lock()


def get_stream(broker: ProjectXBroker, contract_id: str) -> TradeStream:
    """The app's one stream for this contract (started on first use)."""
    with _STREAMS_LOCK:
        key = (hub_url(broker), contract_id)
        s = _STREAMS.get(key)
        if s is None:
            s = _STREAMS[key] = TradeStream(broker, contract_id)
        s.start()
        return s
