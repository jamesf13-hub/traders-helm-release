"""TopstepX / ProjectX Gateway adapter (REST). Docs: https://gateway.docs.projectx.com"""
from __future__ import annotations

import logging
import threading
import time as _time
from datetime import datetime, timedelta, timezone

import requests

from ..config import BrokerConfig
from ..models import Account, Bar, Contract, Fill, OpenOrder, OrderResult, Position, Side
from .base import Broker

log = logging.getLogger(__name__)

ORDER_LIMIT, ORDER_MARKET, ORDER_STOP = 1, 2, 4
SIDE_CODE = {Side.BUY: 0, Side.SELL: 1}
POSITION_LONG, POSITION_SHORT = 1, 2
TOKEN_REFRESH_AFTER = timedelta(hours=20)  # tokens last 24h


class ProjectXError(RuntimeError):
    pass


class _Login:
    """One ProjectX session token, shared by every client in the app that uses the same login.

    ProjectX allows one active session per user, so several bots logging in separately would keep
    logging each other out. Instead they all use (and renew) this one token.
    """
    def __init__(self):
        self.token: str | None = None
        self.time: datetime | None = None
        self.lock = threading.Lock()


_LOGINS: dict[tuple[str, str, str], _Login] = {}
_LOGINS_LOCK = threading.Lock()


def _shared_login(base_url: str, username: str, api_key: str) -> _Login:
    with _LOGINS_LOCK:
        return _LOGINS.setdefault((base_url, username, api_key), _Login())


def _is_month(rest: str) -> bool:
    """What follows the symbol in a contract name is a month code and a year ("Z6", "H27"), so "SI" doesn't
    pick up "SILZ6"."""
    return len(rest) >= 2 and rest[0] in "FGHJKMNQUVXZ" and rest[1:].isdigit()


def _bar_unit(minutes: int) -> dict:
    """ProjectX bar units: 2 minute, 3 hour, 4 day, 5 week. Days and weeks follow the exchange's sessions."""
    if minutes % 10080 == 0:
        return {"unit": 5, "unitNumber": minutes // 10080}
    if minutes % 1440 == 0:
        return {"unit": 4, "unitNumber": minutes // 1440}
    if minutes % 60 == 0:
        return {"unit": 3, "unitNumber": minutes // 60}
    return {"unit": 2, "unitNumber": minutes}


class ProjectXBroker(Broker):
    def __init__(self, cfg: BrokerConfig, username: str, api_key: str):
        self.cfg = cfg
        self.username = username
        self.api_key = api_key
        self.session = requests.Session()
        self.session.headers.update({"accept": "text/plain", "Content-Type": "application/json"})
        self.auth = _shared_login(cfg.base_url, username, api_key)
        self.account_id: int | None = cfg.account_id
        self.contract: Contract | None = None

    # --- plumbing -------------------------------------------------------------
    @property
    def token_time(self) -> datetime | None:
        return self.auth.time

    def _post(self, path: str, body: dict, retries: int = 4) -> dict:
        token = self._ensure_token()
        delay = 1.0
        for attempt in range(retries + 1):
            try:
                r = self.session.post(self.cfg.base_url + path, json=body, timeout=20,
                                      headers={"Authorization": f"Bearer {token}"})
            except requests.RequestException as e:
                if attempt == retries:
                    raise ProjectXError(f"{path}: network error {e}") from e
                log.warning("%s: network error (%s), retrying in %.0fs", path, e, delay)
            else:
                if r.status_code == 429:
                    log.warning("%s: rate limited, backing off %.0fs", path, delay)
                elif r.status_code == 401 and path != "/api/Auth/loginKey" and attempt < retries:
                    log.warning("%s: token rejected, logging in again", path)
                    token = self._login(stale=token)
                    continue
                elif r.status_code >= 500 and attempt < retries:
                    log.warning("%s: server error %s, retrying", path, r.status_code)
                else:
                    if r.status_code != 200:
                        raise ProjectXError(f"{path}: HTTP {r.status_code} {r.text[:200]}")
                    data = r.json()
                    if not data.get("success", False):
                        raise ProjectXError(
                            f"{path}: errorCode {data.get('errorCode')} {data.get('errorMessage')}")
                    return data
            _time.sleep(delay)
            delay = min(delay * 2, 30)
        raise ProjectXError(f"{path}: gave up after {retries} retries")

    def _login(self, stale: str | None = None) -> str:
        """Log in and share the new token. With `stale`, only if nobody has replaced that token already."""
        with self.auth.lock:
            if self.auth.token is not None and self.auth.token != stale:
                return self.auth.token
            r = self.session.post(self.cfg.base_url + "/api/Auth/loginKey",
                                  json={"userName": self.username, "apiKey": self.api_key}, timeout=20)
            data = r.json() if r.status_code == 200 else {}
            if not data.get("success"):
                raise ProjectXError(
                    f"login failed: HTTP {r.status_code} {data.get('errorMessage') or r.text[:200]}")
            self.auth.token, self.auth.time = data["token"], datetime.now(timezone.utc)
            return self.auth.token

    def _ensure_token(self) -> str:
        with self.auth.lock:
            token, when = self.auth.token, self.auth.time
            if token and datetime.now(timezone.utc) - when > TOKEN_REFRESH_AFTER:
                r = self.session.post(self.cfg.base_url + "/api/Auth/validate", timeout=20,
                                      headers={"Authorization": f"Bearer {token}"})
                data = r.json() if r.status_code == 200 else {}
                if data.get("success") and data.get("newToken"):
                    self.auth.token, self.auth.time = data["newToken"], datetime.now(timezone.utc)
                    return self.auth.token
                expired = token
            elif token:
                return token
            else:
                expired = None
        return self._login(stale=expired)

    # --- account & contract ---------------------------------------------------
    def connect(self) -> None:
        self._ensure_token()  # reuses the app's existing login if there is one
        self.get_contract()

    def list_accounts(self) -> list[Account]:
        data = self._post("/api/Account/search", {"onlyActiveAccounts": True})
        return [Account(a["id"], a["name"], float(a.get("balance", 0)), bool(a.get("canTrade")))
                for a in data.get("accounts", [])]

    def get_account_state(self) -> Account:
        if self.account_id is None:
            raise ProjectXError("no account selected (set broker.account_id in config.toml)")
        for a in self.list_accounts():
            if a.id == self.account_id:
                return a
        raise ProjectXError(f"account {self.account_id} not found or not active")

    def get_contract(self) -> Contract:
        if self.contract:
            return self.contract
        data = self._post("/api/Contract/search", {"searchText": self.cfg.symbol, "live": self.cfg.live_data})
        want = self.cfg.symbol.upper()
        matches = [c for c in data.get("contracts", [])
                   if c.get("activeContract") and str(c.get("name", "")).upper().startswith(want)
                   and _is_month(str(c.get("name", "")).upper()[len(want):])]
        if not matches:
            names = [c.get("name") for c in data.get("contracts", [])]
            raise ProjectXError(f"no active {want} contract found (got {names})")
        c = matches[0]
        self.contract = Contract(str(c["id"]), c["name"], float(c["tickSize"]), float(c["tickValue"]))
        return self.contract

    # --- market data ------------------------------------------------------------
    def get_historical_bars(self, start: datetime, end: datetime, minutes: int, partial: bool = False) -> list[Bar]:
        out: dict[datetime, Bar] = {}
        cursor = start
        while cursor < end:
            chunk_end = min(end, cursor + timedelta(minutes=minutes * 10000))
            data = self._post("/api/History/retrieveBars", {
                "contractId": self.get_contract().id, "live": self.cfg.live_data,
                "startTime": cursor.astimezone(timezone.utc).isoformat().replace("+00:00", "Z"),
                "endTime": chunk_end.astimezone(timezone.utc).isoformat().replace("+00:00", "Z"),
                **_bar_unit(minutes), "limit": 20000, "includePartialBar": partial,
            })
            for b in data.get("bars") or []:
                t = datetime.fromisoformat(b["t"].replace("Z", "+00:00"))
                out[t] = Bar(t, float(b["o"]), float(b["h"]), float(b["l"]), float(b["c"]), float(b.get("v", 0)))
            cursor = chunk_end
        return [out[t] for t in sorted(out)]

    # --- orders -------------------------------------------------------------------
    def place_bracket_order(self, side: Side, size: int, stop_ticks: int, target_ticks: int,
                            tag: str | None = None) -> OrderResult:
        mode = self.cfg.bracket_tick_mode
        if mode not in ("signed", "unsigned"):
            return OrderResult(False, None, "bracket_tick_mode not set: run `orb-bot bracket-test` first")
        return self.place_bracket_with_mode(side, size, stop_ticks, target_ticks, mode, tag)

    def place_bracket_with_mode(self, side: Side, size: int, stop_ticks: int, target_ticks: int,
                                mode: str, tag: str | None = None) -> OrderResult:
        sl, tp = abs(stop_ticks), abs(target_ticks)
        if mode == "signed":  # ticks relative to entry: long stop below (-), long target above (+)
            sl, tp = -side.sign * sl, side.sign * tp
        body = {
            "accountId": self.account_id, "contractId": self.get_contract().id,
            "type": ORDER_MARKET, "side": SIDE_CODE[side], "size": size,
            "limitPrice": None, "stopPrice": None, "trailPrice": None, "customTag": tag,
            "stopLossBracket": {"ticks": sl, "type": ORDER_STOP},
            "takeProfitBracket": {"ticks": tp, "type": ORDER_LIMIT},
        }
        try:
            data = self._post("/api/Order/place", body, retries=0)
        except ProjectXError as e:
            return OrderResult(False, None, str(e))
        return OrderResult(True, int(data["orderId"]))

    def cancel_order(self, order_id: int) -> bool:
        try:
            self._post("/api/Order/cancel", {"accountId": self.account_id, "orderId": order_id})
            return True
        except ProjectXError as e:
            log.error("cancel %s failed: %s", order_id, e)
            return False

    def modify_stop(self, order_id: int, price: float) -> bool:
        """Move a stop order (e.g. a bot's Auto OCO stop leg) to a new price."""
        try:
            self._post("/api/Order/modify", {"accountId": self.account_id, "orderId": order_id, "stopPrice": price})
            return True
        except ProjectXError as e:
            log.error("moving stop %s to %.2f failed: %s", order_id, price, e)
            return False

    def get_positions(self) -> list[Position]:
        data = self._post("/api/Position/searchOpen", {"accountId": self.account_id})
        cid = self.get_contract().id
        return [Position(p["contractId"], Side.BUY if p["type"] == POSITION_LONG else Side.SELL,
                         int(p["size"]), float(p["averagePrice"]))
                for p in data.get("positions", []) if p["contractId"] == cid and int(p["size"]) != 0]

    def get_all_positions(self) -> list[Position]:
        """Every open position on the account, any contract (the bots' and manual ones)."""
        data = self._post("/api/Position/searchOpen", {"accountId": self.account_id})
        return [Position(p["contractId"], Side.BUY if p["type"] == POSITION_LONG else Side.SELL,
                         int(p["size"]), float(p["averagePrice"]))
                for p in data.get("positions", []) if int(p["size"]) != 0]

    def contract_by_id(self, contract_id: str) -> Contract:
        data = self._post("/api/Contract/searchById", {"contractId": contract_id})
        c = data.get("contract") or {}
        return Contract(str(c["id"]), c["name"], float(c["tickSize"]), float(c["tickValue"]))

    def last_price_of(self, contract_id: str) -> float | None:
        """The latest 1-minute close of any contract (used until the live stream has a trade)."""
        now = datetime.now(timezone.utc)
        data = self._post("/api/History/retrieveBars", {
            "contractId": contract_id, "live": self.cfg.live_data,
            "startTime": (now - timedelta(minutes=5)).isoformat().replace("+00:00", "Z"),
            "endTime": now.isoformat().replace("+00:00", "Z"),
            "unit": 2, "unitNumber": 1, "limit": 10, "includePartialBar": True,
        })
        bars = data.get("bars") or []
        return float(max(bars, key=lambda b: b["t"])["c"]) if bars else None

    def get_open_orders(self) -> list[OpenOrder]:
        data = self._post("/api/Order/searchOpen", {"accountId": self.account_id})
        cid = self.get_contract().id
        return [OpenOrder(int(o["id"]), o["contractId"], Side.BUY if o["side"] == 0 else Side.SELL,
                          int(o["size"]), int(o["type"]), o.get("limitPrice"), o.get("stopPrice"))
                for o in data.get("orders", []) if o["contractId"] == cid]

    def flatten_all(self) -> None:
        cid = self.get_contract().id
        if self.get_positions():
            self._post("/api/Position/closeContract", {"accountId": self.account_id, "contractId": cid})
        # Auto OCO legs only cancel when one of their own legs fills, so clean up leftovers.
        for o in self.get_open_orders():
            self.cancel_order(o.id)

    def close_size(self, side: Side, size: int) -> None:
        cid = self.get_contract().id
        pos = self.get_positions()
        if pos and pos[0].side is side and pos[0].size == size:
            self._post("/api/Position/closeContract", {"accountId": self.account_id, "contractId": cid})
        elif pos and pos[0].side is side and pos[0].size > size:
            self._post("/api/Position/partialCloseContract",
                       {"accountId": self.account_id, "contractId": cid, "size": size})
        else:  # net position is mixed with another bot's: offset our size with a plain market order
            self._post("/api/Order/place", {
                "accountId": self.account_id, "contractId": cid, "type": ORDER_MARKET,
                "side": SIDE_CODE[Side.SELL if side is Side.BUY else Side.BUY], "size": size,
                "limitPrice": None, "stopPrice": None, "trailPrice": None, "customTag": None})

    def get_last_price(self) -> float | None:
        now = datetime.now(timezone.utc)
        data = self._post("/api/History/retrieveBars", {
            "contractId": self.get_contract().id, "live": self.cfg.live_data,
            "startTime": (now - timedelta(minutes=5)).isoformat().replace("+00:00", "Z"),
            "endTime": now.isoformat().replace("+00:00", "Z"),
            "unit": 2, "unitNumber": 1, "limit": 10, "includePartialBar": True,
        })
        bars = data.get("bars") or []
        if not bars:
            return None
        return float(max(bars, key=lambda b: b["t"])["c"])

    def get_fills(self, since: datetime) -> list[Fill]:
        data = self._post("/api/Trade/search", {
            "accountId": self.account_id,
            "startTimestamp": since.astimezone(timezone.utc).isoformat().replace("+00:00", "Z"),
        })
        out = []
        for t in data.get("trades") or []:
            if t.get("voided"):
                continue
            pnl = t.get("profitAndLoss")
            out.append(Fill(int(t["orderId"]), t["contractId"], Side.BUY if t["side"] == 0 else Side.SELL,
                            int(t["size"]), float(t["price"]), None if pnl is None else float(pnl),
                            float(t.get("fees") or 0.0) + _commission(t, self.cfg.commission_per_side),
                            _parse_ts(t.get("creationTimestamp"))))
        return out


def _commission(trade: dict, per_side: float) -> float:
    """Topstep's trade list has the exchange fees but not TopstepX's commission; add it (per contract, per fill)."""
    if trade.get("commissions") is not None:  # if a later API version sends it, use theirs
        return abs(float(trade["commissions"]))
    return per_side * int(trade.get("size") or 0)


def _parse_ts(value: str | None) -> datetime:
    """ProjectX timestamps can carry 7 fractional digits; trim to microseconds."""
    if not value:
        return datetime.now(timezone.utc)
    v = value.replace("Z", "+00:00")
    if "." in v:
        head, rest = v.split(".", 1)
        digits = "".join(ch for ch in rest if ch.isdigit())
        tz = rest[len(digits):]
        v = f"{head}.{digits[:6].ljust(6, '0')}{tz}"
    try:
        dt = datetime.fromisoformat(v)
    except ValueError:
        return datetime.now(timezone.utc)
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
