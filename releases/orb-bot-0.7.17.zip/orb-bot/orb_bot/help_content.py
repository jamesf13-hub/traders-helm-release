"""The Help window's pages. Plain HTML (Qt's rich text subset): h2, h3, p, ol, ul, b, code, table.

Keep each page short and in the user's words. Facts here must match the app; update them with the code."""
from .brand import APP_NAME, TAGLINE

N = APP_NAME

TOPICS: list[tuple[str, str, str]] = [  # (id, title, html)
("start", "Getting started", f"""
<h2>Getting started</h2>
<p><i>{TAGLINE}</i></p>
<p>{N} runs your bots on this computer and places their orders straight at Topstep, each with its stop and
target attached. Setup takes about 15 minutes, once.</p>
<ol>
<li><b>TopstepX API access.</b> Subscribe and create an API key (see <i>TopstepX login and API key</i>).</li>
<li><b>Auto OCO Brackets on</b> for every account you'll trade (see <i>Accounts</i>).</li>
<li><b>Log in:</b> Account → Change TopstepX login…</li>
<li><b>Choose an account:</b> Account → Check connection and choose account…</li>
<li><b>Bracket test:</b> Account → Run bracket test… (Practice account, needs a few seconds while the market is
open). Real orders are refused until it passes.</li>
<li><b>Pick a bot</b> and press <b>Start</b>. Start always places real orders. To try a bot first without
orders, use its ••• menu → <b>Test run</b>.</li>
<li>Optional: <b>TradingView alerts</b> (trade any TradingView script) and <b>Phone alerts</b> (Telegram).</li>
</ol>
<p>Keep the app open and the computer awake while bots run. The app stops the Mac sleeping by itself while any
bot is running.</p>
"""),

("login", "TopstepX login and API key", f"""
<h2>TopstepX login and API key</h2>
<p>{N} talks to Topstep through the official ProjectX API. You need your own API subscription and key.</p>
<h3>Get a key</h3>
<ol>
<li>Log in to the <b>ProjectX dashboard</b> with your TopstepX login.</li>
<li>Subscriptions → <b>ProjectX API Access</b>. Topstep traders get a discount with the code <code>topstep</code>.</li>
<li>Create an <b>API key</b> and copy it.</li>
</ol>
<h3>Save it in the app</h3>
<p>Account → <b>Change TopstepX login…</b> Enter your TopstepX username and the API key. They are stored in your
computer's secure keychain, never in a file and never sent anywhere except Topstep.</p>
<h3>Good to know</h3>
<ul>
<li>The API trades Practice and Combine accounts (and, we expect, Express Funded). It can't trade a Live Funded
account.</li>
<li>Topstep allows one active session per user. If the TopstepX website says <i>"Multiple sessions detected"</i>,
that logs out the website only. Check the app's Activity log keeps updating.</li>
<li>Changed or revoked your key? Enter the new one in Account → Change TopstepX login…</li>
</ul>
"""),

("accounts", "Accounts", f"""
<h2>Accounts</h2>
<h3>Choosing and viewing</h3>
<p>The dropdown at the top shows which account you're looking at. <b>Switching it never stops a bot.</b> Bots
keep running on every account they were started on, and the dropdown shows how many are running on each.</p>
<p>Every account has its own copy of each bot with its own Start/Stop, risk, daily loss limit
and session switches. The strategy settings are shared and can only be changed while that bot is stopped
everywhere.</p>
<h3>Auto OCO Brackets (required)</h3>
<p>In TopstepX: <b>Settings → Risk Settings → Auto OCO Brackets → On</b>, for each account. You must be flat to
change it. Without it, Topstep rejects orders that carry a stop and target.</p>
<h3>Which accounts can trade</h3>
<ul>
<li><b>Practice</b> accounts can trade straight away.</li>
<li>Any other account (a Combine, for example) asks you to confirm once, the first time you start a bot on it with
Live orders.</li>
<li>Live Funded accounts can't be traded through the API.</li>
</ul>
<h3>Sharing an account with other bots</h3>
<p>Each bot only manages the orders it placed, tracked by order number. Close now, Flatten all and the safety
checks never touch other bots' or your own manual trades. The daily loss limit counts the whole account,
like Topstep's.</p>
"""),

("bots", "Bots, risk and modes", f"""
<h2>Bots, risk and modes</h2>
<h3>Types of bot</h3>
<ul>
<li><b>ORB</b>: the built-in opening range breakout strategy, with up to three sessions a day.</li>
<li><b>TradingView alerts</b>: trades whatever a TradingView script's alerts say (see <i>TradingView alerts</i>).</li>
</ul>
<p><b>＋ Add bot</b> makes a new one; the ••• menu on a bot has Test run, Rename and Remove.</p>
<h3>Real orders and Test run</h3>
<ul>
<li><b>Start</b> places real orders on the selected account (it asks you to confirm first).</li>
<li><b>••• → Test run</b> uses real prices but simulated fills, and nothing is sent to Topstep. The bot shows
"paper", and Today's P&amp;L and trades are the test's own. It lasts until you press Stop; the next Start is real
orders again.</li>
</ul>
<h3>Risk (change any time, applies from the next trade)</h3>
<ul>
<li><b>% of balance</b> or <b>fixed $</b> per trade. Contracts = risk ÷ (stop distance × $ per point), rounded down,
at least 1.</li>
<li><b>Max contracts</b> caps every trade.</li>
<li><b>Daily loss limit</b>: no new trades once the account is down this much today, and a trade is cut down so a
full stop-out can't go past it. Resets at 6pm New York time, like Topstep.</li>
</ul>
<h3>Sessions</h3>
<p>Each ORB session has an on/off switch you can change while running. Session 3 follows New York time, so it
moves with US daylight saving.</p>
<h3>Replay</h3>
<p>The Replay tab runs an ORB bot over past days and lists the trades it would have taken, to compare with
TradingView's Strategy Tester.</p>
"""),

("tv", "TradingView alerts", f"""
<h2>TradingView alerts</h2>
<p>Use any TradingView strategy or indicator, including invite-only scripts. When its alert arrives, {N} places
the order at Topstep with the stop and target already attached, so exits fill at Topstep with no delay.</p>
<h3>One-time setup</h3>
<ol>
<li>TradingView needs a paid plan for webhooks and <b>two-factor authentication turned on</b>.</li>
<li>Sign up free at <b>ngrok.com</b>. In Terminal: <code>brew install ngrok</code></li>
<li>Copy your authtoken from the ngrok dashboard and run <code>ngrok config add-authtoken &lt;token&gt;</code></li>
<li>In the ngrok dashboard open <b>Domains</b> and copy your free domain.</li>
<li>In {N}: Bots → <b>TradingView alerts setup…</b>, paste the domain and Save.</li>
</ol>
<h3>Each alert</h3>
<ol>
<li>＋ Add bot → Type <b>TradingView alerts</b>.</li>
<li>On TradingView, create or edit the alert. Under Notifications tick <b>Webhook URL</b> and paste the
<b>Webhook URL</b> from the bot's tab (Copy button).</li>
<li>Replace the alert's message with the <b>Alert message</b> from the bot's tab (Copy button).</li>
<li>Enter the alert's expiry date in the bot's Settings, so the app reminds you before it stops.</li>
<li>Press Start on the account you want it to trade.</li>
</ol>
<h3>Stop and target</h3>
<p>Set them in the bot's Settings (stop in ticks, target as a multiple of the stop). If the script plots its own
stop and target, the alert can send their prices instead. For scripts that risk a fixed $ per trade, set
"Script's $ risk" and the stop is worked out from TradingView's size. For an opening range breakout script, also
set "Script's opening range start" (e.g. 15:00) and its length: the bot then checks the range edge and the
breakout candle and uses whichever one fits TradingView's size, which is usually the script's exact stop. The alert
list shows where each stop came from.</p>
<h3>Is it working?</h3>
<p>The bot's tab says whether TradingView can reach the app. It re-checks every 5 minutes and restarts ngrok if
needed. Each alert and what the bot did with it is listed.</p>
<p><b>Don't</b> leave another service (like PickMyTrade) trading the same alert on the same account, or every
signal is taken twice.</p>
"""),

("script", "Your own strategy (Python)", f"""
<h2>Your own strategy (Python)</h2>
<p>Write your strategy as a short Python file and {N} runs it as a bot. Your script only decides <b>when</b> to
buy, sell or close, and where the stop and target go. {N} does everything else: sizing from the bot's risk
settings, max contracts, the daily loss limit, the stop and target orders at Topstep, phone alerts, Performance,
the Chart and Replay.</p>
<h3>Add one</h3>
<ol>
<li>Copy <code>strategies/template.py</code> (in the {N} folder), rename it and change <code>on_bar</code>. Two
examples are there too: <code>ema_cross.py</code> and <code>simple_orb.py</code>.</li>
<li><b>＋ Add bot</b> → <b>Your own script (Python file)</b>, choose the file and the chart timeframe.</li>
<li>Set the bot's risk, test it in its <b>Replay</b> tab on past days, then <b>••• → Test run</b> or
<b>Start</b>.</li>
</ol>
<h3>What a script looks like</h3>
<p><code>class EmaCross(Strategy):<br>
&nbsp;&nbsp;params = {{"fast": 9, "slow": 21}}<br>
&nbsp;&nbsp;def on_bar(self, bar):<br>
&nbsp;&nbsp;&nbsp;&nbsp;fast, slow = self.ema(self.p.fast), self.ema(self.p.slow)<br>
&nbsp;&nbsp;&nbsp;&nbsp;if self.crossed_above(fast, slow):<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;self.buy(stop_ticks=40, target_rr=2)</code></p>
<p>Every entry needs a stop (a price or <code>stop_ticks</code>) and a target (a price, <code>target_ticks</code> or
<code>target_rr</code>, a multiple of the stop). Helpers: <code>sma, ema, rsi, atr, highest, lowest,
crossed_above, crossed_below</code>, plus <code>self.bars</code>, <code>self.closes</code>, <code>self.time</code>
and <code>self.position</code>. The template lists them all.</p>
<h3>Tips</h3>
<ul>
<li>Don't write Python? Give the template to ChatGPT or Claude with your rules (or your Pine Script) and ask for
a {N} strategy. Always check the result in Replay against your TradingView results.</li>
<li>Params can be changed in the bot's Settings tab without editing the file. After editing the file, press
Save in Settings and restart the bot.</li>
<li>If the script has an error, it's shown in Activity and the bot makes no new trades; an open trade keeps its
stop and target at Topstep.</li>
</ul>
"""),
("phone", "Phone alerts (Telegram)", f"""
<h2>Phone alerts (Telegram)</h2>
<p>Get a message when a trade opens or closes, or when something needs attention, and control your bots from
your phone. Free.</p>
<h3>Set up (about 2 minutes)</h3>
<ol>
<li>Install <b>Telegram</b> on your phone and sign up.</li>
<li>In Telegram, search for <b>@BotFather</b>, send <code>/newbot</code>, and choose a name and a username ending in
<i>bot</i>. BotFather replies with a <b>token</b>.</li>
<li>In {N}: Account → <b>Phone alerts (Telegram)…</b> and paste the token.</li>
<li>Open your new bot in Telegram and send it any message, like <i>hi</i>.</li>
<li>Press <b>Find my chat</b>, then <b>Send test</b>, then <b>Save</b>.</li>
</ol>
<h3>What you'll get</h3>
<ul>
<li>Trade opened: bot, account, long or short, size, entry, stop and target.</li>
<li>Trade closed: result, P&amp;L and the account's total for the day.</li>
<li>Problems: rejected order, a trade without a stop that was closed for safety, TradingView can't reach the app,
daily loss limit reached, errors.</li>
</ul>
<h3>Commands you can send</h3>
<table cellpadding="4">
<tr><td><code>/status</code></td><td>What each bot is doing, positions and today's P&amp;L.</td></tr>
<tr><td><code>/stop</code></td><td>Stops every bot. Open trades keep their stop and target at Topstep.</td></tr>
<tr><td><code>/flatten</code></td><td>Closes every bot's open trade at market and stops all bots. Reply
<b>YES</b> within 60 seconds to confirm.</td></tr>
</table>
<p>Only your own chat is listened to, and messages sent while the app was closed are ignored. Commands only work
while the app is open and the computer is on.</p>
<p>The token is stored in your keychain. If it ever leaks, send <code>/revoke</code> to @BotFather and paste the new
one here.</p>
"""),

("safety", "Stopping, flattening and safety", f"""
<h2>Stopping, flattening and safety</h2>
<ul>
<li><b>Stop</b> (on a bot): no new trades. An open trade keeps its stop and target at Topstep.</li>
<li><b>Close now</b> (on a bot's trade): closes that bot's trade at market and cancels its stop and target.</li>
<li><b>Flatten all</b> (top bar, or Bots → Flatten all and stop…): closes every bot's open trade at market, on every
account, and stops all bots. Trades the bots didn't place are left alone.</li>
<li><b>Bots → Stop all bots</b>: stops everything, trades keep their brackets.</li>
</ul>
<h3>Built-in protection</h3>
<ul>
<li>Every entry goes in with its stop and target attached at Topstep, so they work even if the app or computer
goes down.</li>
<li>If a bot's trade is ever found without a stop at Topstep, it is closed for safety.</li>
<li>Real orders are refused until the bracket test has passed.</li>
<li>The daily loss limit blocks new trades and shrinks trades that could breach it.</li>
</ul>
<h3>If the computer sleeps, loses internet or the app closes</h3>
<p>Open trades stay protected by their stop and target at Topstep. No new trades are taken until the app is
running again. When a bot restarts it picks up its own open trade.</p>
<h3>Where to run it</h3>
<p>Run {N} on your own computer. Topstep doesn't allow trading from a VPS, VPN or remote server.</p>
"""),

("performance", "Performance", f"""
<h2>Performance</h2>
<p>The <b>Performance</b> page (second icon on the left) shows your results the way TopstepX does: total P&amp;L, win rate, average win
and loss, profit factor, day win rate, best day's share of profit, drawdown, best and worst trade, weekday
stats, fees, charts, a month calendar and every trade.</p>
<ul>
<li>Pick one account or <b>All accounts</b>, a period, and one bot or all of them.</li>
<li>Numbers come from Topstep's own record of the account's fills, after fees, so they should match TopstepX.</li>
<li>Each trade is tagged with the bot that placed it. Trades from elsewhere show as <i>Manual / other</i>.</li>
<li>Press <b>Refresh</b> to load the latest trades.</li>
</ul>
"""),

("trouble", "Troubleshooting", f"""
<h2>Troubleshooting</h2>
<h3>"Order rejected"</h3>
<p>Usually Auto OCO Brackets is off for that account (see <i>Accounts</i>), the market is closed, or the account
hit a Topstep limit. The Activity log shows Topstep's reason.</p>
<h3>TradingView can't reach the app</h3>
<ul>
<li>Check the bot is running: alerts only arrive while a TradingView alerts bot is started.</li>
<li><i>ERR_NGROK_334</i> or "already online": another copy of ngrok is using your domain. Quit it (in Terminal:
<code>pkill ngrok</code>) and the app starts its own within a minute.</li>
<li>Check the Webhook URL in TradingView matches the bot's tab exactly, ending in <code>/tv</code>.</li>
<li>TradingView only sends webhooks with two-factor authentication on.</li>
</ul>
<h3>An alert was ignored</h3>
<p>The bot's alert list says why: wrong key, a different market, more than 60 seconds old, daily loss limit,
or the bot wasn't running.</p>
<h3>Logged out of the TopstepX website</h3>
<p>Topstep allows one session at a time. The website logs out; the app carries on. Check the Activity log.</p>
<h3>No phone messages</h3>
<p>Open Account → Phone alerts and press <b>Send test</b>. If it fails, the message says why (usually a wrong
token or you haven't messaged your bot yet).</p>
<h3>Still stuck?</h3>
<p>The full log is in the <code>logs</code> folder (<code>orb-bot.log</code>). Send it with a screenshot of the
Activity tab.</p>
"""),

("faq", "FAQ", f"""
<h2>Frequently asked questions</h2>
<h3>Does the computer need to stay on?</h3>
<p>Yes, with the app open, for bots to take trades. Open trades are protected at Topstep if it goes off.</p>
<h3>Can I run it on my phone or a cloud server?</h3>
<p>No. Phones pause background apps, and Topstep doesn't allow trading from a VPS. Use Telegram to keep an eye on
it from your phone.</p>
<h3>Can I use my own strategy?</h3>
<p>Yes. Any TradingView script can trade through a <b>TradingView alerts</b> bot.</p>
<h3>Can I run several bots on one account?</h3>
<p>Yes. Each manages only its own trades, even on the same contract.</p>
<h3>Can I trade several accounts at once?</h3>
<p>Yes. Start the bot on each account with its own risk.</p>
<h3>Will an update reset my settings or TradingView alerts?</h3>
<p>No. Your settings stay in your own files and your alerts live in TradingView. The webhook address stays the
same.</p>
<h3>Why didn't a trade match TradingView exactly?</h3>
<p>Live fills happen at the market price when the order arrives, which can differ by a tick or two from the
price TradingView shows. Paper mode and Replay fill like TradingView's Strategy Tester.</p>
<h3>Does it work with Live Funded accounts?</h3>
<p>No. Topstep's API trades Practice and Combine accounts (and, we expect, Express Funded), not Live Funded.</p>
<h3>Is my login safe?</h3>
<p>Your TopstepX API key and Telegram token are kept in your computer's keychain and are only ever sent to
Topstep and Telegram.</p>
"""),

("updates", "Updating the app", f"""
<h2>Updating the app</h2>
<p>When a new version of {N} is out, a blue bar appears at the top of the window:
<b>"vX is ready"</b> with <b>Update now</b> and <b>Later</b>. The app looks for new versions when it opens and
every few hours. You can also check yourself: <b>Help</b> (bottom of the topic list) → <b>Check for updates</b>.
Your version number is shown just above that button.</p>
<h3>What Update now does</h3>
<ol>
<li>Downloads the new version.</li>
<li>Checks it's a genuine {N} release. Every release is digitally signed, and anything that doesn't match is
refused before a single file changes.</li>
<li>Installs it and restarts the app (about a minute).</li>
</ol>
<p><b>Your settings, bots, trade history and logs are kept.</b> Updates never touch them.</p>
<h3>Bots must be stopped first</h3>
<p>Updating restarts the app, so it won't update while a bot is running. Stop your bots (open trades keep their
stop and target at Topstep), update, then press Start again. A good time is outside your sessions.</p>
<p>If an update can't download or doesn't check out, nothing is changed and you can keep using the version you
have.</p>
"""),

("licence", "Your licence", f"""
<h2>Your licence</h2>
<p>Your {N} subscription comes with a <b>licence key</b> (from your Whop purchase). Paste it in the first time
you open the app.</p>
<h3>One computer per key</h3>
<p>A key works on <b>one computer</b>. To move to a new computer, open Settings → <b>Deactivate this
computer</b> on the old one, then enter your key on the new one. (Lost the old computer? Contact support and
we'll free the key.)</p>
<h3>No logging in every day</h3>
<p>The app checks your subscription quietly in the background about once a day. You never need to log in or
re-enter your key.</p>
<h3>Away or offline</h3>
<ul>
<li>The app keeps working for <b>7 days</b> without internet.</li>
<li>After that it asks you to connect so it can check your subscription, and won't start bots until it can.
Your settings and history are kept.</li>
<li>As soon as you're back online it checks with Whop. If your subscription is active, everything unlocks
straight away, with nothing to enter.</li>
</ul>
<h3>If your subscription ends</h3>
<p>The app shows <b>"Your subscription has ended"</b> with a link to renew on Whop. Once you renew, it unlocks
on the next check. A bot that's in a trade when this happens is never cut off mid-trade: it stops taking new
trades and lets the open one finish on its stop or target.</p>
"""),
]
