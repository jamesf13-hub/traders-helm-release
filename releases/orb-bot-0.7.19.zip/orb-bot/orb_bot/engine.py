"""Runs the strategy against a data source and an order broker (real or simulated).

The engine only ever manages the orders it placed itself, so other bots or manual trades on the same
account (even on the same contract) are left alone. TopstepX's Auto OCO Brackets give every entry its
own stop and target sized to that entry, so when the bot's target fills it closes only the bot's
contracts, and another bot's contracts keep running with their own brackets.
"""
from __future__ import annotations

import csv
import json
import logging
import queue
import threading
import time as _time
from dataclasses import asdict, dataclass, field
from datetime import datetime, time as dtime, timedelta, timezone
from pathlib import Path

from .broker.base import Broker
from .broker.sim import SimBroker
from . import notify
from .config import Config, session_window
from .models import Bar, Side, Signal
from .strategy.orb import NEW_YORK, ORBStrategy, trading_day

log = logging.getLogger(__name__)

WARMUP_HOURS = 26  # covers a full day so every session's range is rebuilt on restart
UNPROTECTED_POLLS_BEFORE_FLATTEN = 2
UNFILLED_ENTRY_TIMEOUT = timedelta(seconds=60)
LEG_WAIT_SECONDS = 4.0
FAST_GRACE_SECONDS = 0.5  # fast bars: wait this long after the close for the last trades to arrive
FAST_CHECK_AFTER = timedelta(seconds=8)  # then compare with TopstepX's bar once it's surely published

# Several bots can run in one app on the same account. Their stop/target legs are told apart by order id:
# one bot places and claims its legs at a time, and a claimed id is never taken by another bot.
_PLACE_LOCK = threading.Lock()
_CLAIMED: set[int] = set()
_LIVE: set["Engine"] = set()


class StopRequested(Exception):
    pass


@dataclass
class BotTrade:
    """A trade this bot opened. `leg_ids` are its own stop and target orders at the broker."""
    session: str
    tag: str
    side: Side
    size: int
    entry_time: datetime  # signal bar open time
    entry: float  # signal close until the real fill price is known
    stop: float
    target: float
    stop_ticks: int
    target_ticks: int
    entry_order: int | None = None
    pre_ids: list[int] = field(default_factory=list)  # working orders that existed before ours
    leg_ids: list[int] = field(default_factory=list)
    filled: bool = False
    placed_at: datetime | None = None  # wall clock, UTC
    entry_balance: float | None = None
    unprotected_polls: int = 0
    exit: float | None = None
    exit_time: datetime | None = None
    reason: str | None = None
    pnl: float | None = None
    signal_price: float | None = None  # price the signal was given at (bar close or alert price)
    signal_at: datetime | None = None  # when the signal happened (bar close or alert arrival), UTC

    def to_json(self) -> dict:
        d = asdict(self)
        d["side"] = self.side.value
        for k in ("entry_time", "placed_at", "exit_time", "signal_at"):
            d[k] = d[k].isoformat() if d[k] else None
        return d

    @classmethod
    def from_json(cls, d: dict) -> "BotTrade":
        d = dict(d)
        d["side"] = Side(d["side"])
        for k in ("entry_time", "placed_at", "exit_time", "signal_at"):
            d[k] = datetime.fromisoformat(d[k]) if d.get(k) else None
        return cls(**d)


class Engine:
    def __init__(self, config: Config, data: Broker, orders: Broker, mode: str):
        assert mode in ("paper", "practice", "replay")
        self.cfg = config
        self.data = data
        self.orders = orders
        self.mode = mode
        self.contract = data.get_contract()
        if config.kind == "script":
            from .scripting import ScriptRunner
            self.strategy = ScriptRunner(config, self.contract)
        else:
            self.strategy = ORBStrategy(config, self.contract)
        self.signal_at: datetime | None = None  # set by a subclass for the next _execute (alert arrival time)
        self.tz = config.timezone
        self.day = None
        self.day_start_balance: float | None = None
        self.in_position = False  # the bot's own trade only
        self.trade: BotTrade | None = None
        self.closed_trades: list[BotTrade] = []
        self.started_at = datetime.now(timezone.utc)  # trades before this come from logs/fills.csv
        self.flatten_deadline: datetime | None = None
        self.last_bar_time: datetime | None = None
        self.last_lag: float | None = None
        self.last_price: float | None = None
        self.account_name: str | None = None
        self.running = False
        self._cached_balance: float | None = None
        account = f"-{config.broker.account_id}" if mode != "replay" and config.broker.account_id else ""
        self.state_path = config.log_dir / f"state-{config.slug}-{mode}{account}.json"
        # Before bots had names the only bot used state-<mode>.json, always on the Practice account.
        self._legacy_state = config.log_dir / f"state-{mode}.json" \
            if mode == "practice" and (config.path is None or config.path.name == "config.toml") \
            and config.broker.account_name.upper().startswith("PRAC") else None
        self._stop = threading.Event()
        self._wake = threading.Event()
        self._commands: queue.Queue[str] = queue.Queue()
        self.stream = None  # TradeStream when fast bars are on
        self._fast_pending: list[Bar] = []
        self.fast_stats = {"live": 0, "fallback": 0, "matched": 0, "differed": 0}

    # --- control from another thread (the app window) -------------------------------------
    def request_stop(self) -> None:
        self._stop.set()
        self._wake.set()

    def request_close(self) -> None:
        self._commands.put("close")
        self._wake.set()

    def request_breakeven(self) -> None:
        self._commands.put("breakeven")
        self._wake.set()

    def _sleep(self, seconds: float) -> None:
        if self._wake.wait(max(seconds, 0)):
            self._wake.clear()
        self._run_commands()
        if self._stop.is_set():
            raise StopRequested

    def _run_commands(self) -> None:
        while True:
            try:
                cmd = self._commands.get_nowait()
            except queue.Empty:
                return
            if cmd == "close":
                if self.trade:
                    log.info("Close now pressed")
                    self._close_own("manual")
                else:
                    log.info("Close now pressed, but the bot has no open trade")
            elif cmd == "breakeven":
                self._move_stop_to_entry()

    def _move_stop_to_entry(self) -> None:
        """Break-even: move the bot's own stop to its entry price. Only once price is past the entry, so the
        stop isn't triggered straight away."""
        t = self.trade
        if not t or not t.filled:
            log.info("Break-even pressed, but the bot has no filled trade")
            return
        self._move_stop(t.entry, "break-even")

    def _move_stop(self, price: float, what: str) -> None:
        """Move the bot's own stop leg at Topstep (break-even button, or a script's move_stop)."""
        t = self.trade
        if not t or not t.filled:
            return
        be = round(price / self.contract.tick_size) * self.contract.tick_size
        last = self.last_price
        if last is None or (last <= be if t.side is Side.BUY else last >= be):
            log.warning("%s not set: price (%s) isn't past %.2f yet, so the stop would fill straight away",
                        what, "unknown" if last is None else f"{last:,.2f}", be)
            return
        if t.stop is not None and (t.stop >= be if t.side is Side.BUY else t.stop <= be):
            log.info("%s: the stop is already at or past %.2f (%.2f)", what, be, t.stop)
            return
        if isinstance(self.orders, SimBroker):
            ok = self.orders.modify_stop(-1, be)
        else:
            orders = self.orders.get_open_orders()
            leg = next((o for o in orders if o.id in t.leg_ids and o.stop_price is not None), None)
            if leg is None:
                log.error("break-even: couldn't find the bot's stop order at Topstep")
                return
            ok = self.orders.modify_stop(leg.id, be)
        if ok:
            log.info("stop moved (%s): %.2f (was %s)", what, be, "–" if t.stop is None else f"{t.stop:,.2f}")
            t.stop = be
            self._save_state()

    # --- balance & daily P&L ------------------------------------------------------------
    def _balance(self) -> float:
        if isinstance(self.orders, SimBroker):
            return self.orders.balance
        if self._cached_balance is None:
            self.refresh_balance()
        return self._cached_balance

    def refresh_balance(self) -> None:
        """Real accounts: one API call per poll, not per bar (rate limits)."""
        acct = self.orders.get_account_state()
        self._cached_balance = acct.balance
        self.account_name = acct.name

    def _roll_day(self, t: datetime) -> None:
        d = trading_day(t)
        if d == self.day:
            return
        self.day = d
        saved = self._load_state()
        # (states saved before v0.7.15 counted from when the bot started, so they're worked out again)
        if self.mode != "replay" and saved.get("day") == d.isoformat() and (
                saved.get("v") == 2 or isinstance(self.orders, SimBroker)):
            self.day_start_balance = saved["start_balance"]
        else:
            # Started part-way through the day (or on a new account): count what the account already made or lost
            # today, from Topstep's own trade list, so the daily figure and loss limit match TopstepX.
            self.day_start_balance = self._balance() - self._realised_today(d)
            self._save_state()

    def _realised_today(self, d) -> float:
        if isinstance(self.orders, SimBroker) or not hasattr(self.orders, "get_fills"):
            return 0.0
        start = datetime.combine(d - timedelta(days=1), dtime(18, 0), tzinfo=NEW_YORK)
        try:
            fills = self.orders.get_fills(start)
        except Exception as e:  # noqa: BLE001 - the figure falls back to "since the bot started"
            log.warning("couldn't read today's trades from Topstep (%s); today's P&L counts from now", e)
            return 0.0
        return sum((f.pnl or 0.0) - f.fees for f in fills if f.time >= start)

    def day_pnl(self) -> float:
        """Whole-account P&L for the trading day (other bots included), like Topstep's own limit."""
        return self._balance() - (self.day_start_balance or 0.0)

    def _load_state(self) -> dict:
        for p in (self.state_path, self._legacy_state):
            if p is None:
                continue
            try:
                return json.loads(p.read_text())
            except (OSError, ValueError):
                continue
        return {}

    def _save_state(self) -> None:
        if self.mode == "replay":
            return
        state = {"v": 2, "day": self.day.isoformat() if self.day else None, "start_balance": self.day_start_balance,
                 "trade": self.trade.to_json() if self.trade else None}
        self.state_path.parent.mkdir(parents=True, exist_ok=True)
        self.state_path.write_text(json.dumps(state))

    # --- per bar ------------------------------------------------------------------------
    def process_bar(self, bar: Bar, trading: bool = True) -> None:
        if isinstance(self.orders, SimBroker):
            self.orders.update(bar)
            self._collect_sim_exits()
        self._roll_day(bar.time)
        script = getattr(self.strategy, "script", None)
        if script is not None:
            script.position = self.trade.side.sign * self.trade.size if self.trade else 0
            script.entry_price = self.trade.entry if self.trade and self.trade.filled else None
            script.live = trading
        signal = self.strategy.on_bar(bar, self._balance(), self.in_position, self.day_pnl())
        self.last_bar_time = bar.time
        if script is not None and self.strategy.want_stop is not None:
            price, self.strategy.want_stop = self.strategy.want_stop, None
            if self.trade and trading:
                if self.last_price is None:
                    self.last_price = bar.close
                self._move_stop(price, "script")
        if script is not None and self.strategy.want_close:
            reason, self.strategy.want_close = self.strategy.want_close, None
            if self.trade and trading:
                log.info("the script closed its trade: %s", reason)
                self._close_own("script exit")
        if signal:
            if trading:
                self._execute(signal, bar)
            else:
                log.info("%s breakout at %s happened before the bot started; not trading it late",
                         signal.session, bar.time.astimezone(self.tz).strftime("%H:%M"))
                self.strategy.mark_session_done(signal.session)
        if trading:
            self.check_flatten(bar.time + timedelta(minutes=self.cfg.strategy.bar_minutes))

    def _collect_sim_exits(self) -> None:
        for st in self.orders.just_closed:
            if self.trade and self.trade.tag == st.tag:
                t = self.trade
                t.exit, t.exit_time, t.pnl = st.exit_price, st.exit_time, st.pnl
                t.reason = t.reason or st.exit_reason
                self._finish(t)
            else:
                self.strategy.on_trade_closed(st.pnl)
        self.orders.just_closed.clear()

    def _execute(self, s: Signal, bar: Bar) -> None:
        tick = self.contract.tick_size
        stop_ticks = round(abs(s.entry_price - s.stop_price) / tick)
        target_ticks = round(abs(s.target_price - s.entry_price) / tick)
        when = bar.time.astimezone(self.tz)
        log.info("SIGNAL %s %s x%d at %s | %s | stop %.2f (%d ticks) target %.2f (%d ticks)",
                 s.session, s.side.value.upper(), s.contracts, when.strftime("%Y-%m-%d %H:%M"), s.reason,
                 s.stop_price, stop_ticks, s.target_price, target_ticks)
        min_ticks = self.cfg.safety.min_bracket_ticks
        if min(stop_ticks, target_ticks) < max(min_ticks, 1):
            log.warning("bracket under %d tick(s), trade skipped", max(min_ticks, 1))
            return
        tag = self._tag(s, when)
        with _PLACE_LOCK:
            pre_ids = [o.id for o in self.orders.get_open_orders()] if self.mode == "practice" else []
            result = self.orders.place_bracket_order(s.side, s.contracts, stop_ticks, target_ticks, tag)
            if not result.ok:
                log.error("ORDER REJECTED: %s", result.error)
                return
            log.info("order placed, id %s", result.order_id)
            t = BotTrade(s.session, tag, s.side, s.contracts, bar.time, s.entry_price, s.stop_price,
                         s.target_price, stop_ticks, target_ticks, entry_order=result.order_id, pre_ids=pre_ids,
                         placed_at=datetime.now(timezone.utc), entry_balance=self._balance(),
                         signal_price=s.entry_price,
                         signal_at=self.signal_at or bar.time + timedelta(minutes=self.cfg.strategy.bar_minutes))
            self.signal_at = None
            if self.mode == "practice" and len(_LIVE) > 1:
                # Another bot in this app may enter at the same moment: claim our legs before it can look.
                deadline = _time.monotonic() + LEG_WAIT_SECONDS
                while _time.monotonic() < deadline and len(t.leg_ids) < 2:
                    self._claim_legs(t, self.orders.get_open_orders())
                    if len(t.leg_ids) < 2:
                        _time.sleep(0.3)
        if isinstance(self.orders, SimBroker) and self.orders.open:
            o = self.orders.open
            t.entry, t.stop, t.target, t.filled = o.entry_price, o.stop_price, o.target_price, True
            self._announce_entry(t)
        self.trade = t
        self.in_position = True
        session = next((c for c in self.cfg.sessions if c.name == s.session), None)
        self.flatten_deadline = None
        if session and session.flatten_at:
            d = datetime.combine(when.date(), session.flatten_at, self.tz)
            self.flatten_deadline = d if d > when else d + timedelta(days=1)
        self._save_state()

    def _tag(self, s: Signal, when: datetime) -> str:
        return f"{self.cfg.slug}-{s.session}-{when.strftime('%Y%m%d%H%M')}"

    def check_flatten(self, now: datetime) -> None:
        if self.trade and self.flatten_deadline and now >= self.flatten_deadline:
            log.info("flatten time %s reached, closing the bot's trade", self.flatten_deadline.strftime("%H:%M"))
            self._close_own("flatten")

    # --- the bot's own trade at the broker ------------------------------------------------
    def _sync_position(self) -> None:
        """Practice: follow the bot's own trade through its fill, its stop/target legs and its exit."""
        t = self.trade
        if self.mode != "practice":
            self.in_position = bool(t)
            return
        if not t:
            self.in_position = False
            return
        self.in_position = True
        orders = self.orders.get_open_orders()
        ids = {o.id for o in orders}
        self._claim_legs(t, orders)
        if not t.filled:
            self._check_entry_fill(t)
        own_open = [i for i in t.leg_ids if i in ids]
        if t.leg_ids and len(own_open) < len(t.leg_ids):  # a leg filled (Auto OCO cancels the other)
            for i in own_open:
                self.orders.cancel_order(i)
            self._finish(t)
            return
        if t.filled and not self.orders.get_positions():  # closed outside the bot (TopstepX window etc.)
            for i in own_open:
                log.info("cancelling leftover order %s", i)
                self.orders.cancel_order(i)
            t.reason = t.reason or "closed outside the bot"
            self._finish(t)
            return
        if not t.filled:
            if t.placed_at and datetime.now(timezone.utc) - t.placed_at > UNFILLED_ENTRY_TIMEOUT:
                log.error("entry order %s never filled; dropping it", t.entry_order)
                self.trade, self.in_position = None, False
                self._save_state()
            return
        has_stop = any(o.id in t.leg_ids and o.stop_price is not None for o in orders)
        self._verify_protection(t, has_stop)

    def _claim_legs(self, t: BotTrade, orders) -> None:
        """Our Auto OCO stop and target: new orders of our size on the other side that no other bot claimed."""
        for o in orders:
            if len(t.leg_ids) >= 2:
                return
            if (o.id not in t.pre_ids and o.id != t.entry_order and o.id not in t.leg_ids and o.id not in _CLAIMED
                    and o.size == t.size and o.side is not t.side
                    and (o.stop_price is not None or o.limit_price is not None)):
                if any(i for i in t.leg_ids if (o.stop_price is not None) == self._is_stop_leg(orders, i)):
                    continue  # already have this kind of leg
                t.leg_ids.append(o.id)
                _CLAIMED.add(o.id)
                if o.stop_price is not None:
                    t.stop = o.stop_price
                if o.limit_price is not None:
                    t.target = o.limit_price

    @staticmethod
    def _is_stop_leg(orders, order_id: int) -> bool:
        o = next((o for o in orders if o.id == order_id), None)
        return o is not None and o.stop_price is not None

    def _check_entry_fill(self, t: BotTrade) -> None:
        """The entry is filled once its own fills show up (or its Auto OCO legs appear)."""
        try:
            fills = [f for f in self.orders.get_fills(t.placed_at - timedelta(minutes=1))
                     if f.order_id == t.entry_order]
        except Exception as e:  # noqa: BLE001
            log.debug("fills unavailable: %s", e)
            fills = []
        if fills:
            size = sum(f.size for f in fills)
            t.entry = sum(f.price * f.size for f in fills) / size
        if fills or t.leg_ids:
            t.filled = True
            log.info("filled %s x%d @ %.2f, stop %.2f, target %.2f", t.side.value, t.size, t.entry, t.stop,
                     t.target)
            self._log_entry_quality(t)
            self._announce_entry(t)
            self._save_state()

    def _verify_protection(self, t: BotTrade, has_stop: bool) -> None:
        """The bot's filled trade must have its own stop at the broker. If not for two checks, close it."""
        if has_stop:
            t.unprotected_polls = 0
            return
        t.unprotected_polls += 1
        log.warning("the bot's trade has no stop order at the broker (check %d)", t.unprotected_polls)
        if t.unprotected_polls >= UNPROTECTED_POLLS_BEFORE_FLATTEN:
            log.critical("UNPROTECTED POSITION: closing the bot's %d contract(s) for safety", t.size)
            self._close_own("unprotected")

    def _close_own(self, reason: str) -> None:
        """Close only the bot's contracts and cancel only its own stop and target."""
        t = self.trade
        if not t:
            return
        t.reason = reason
        if isinstance(self.orders, SimBroker):
            if reason == "manual" and self.last_price is not None:
                self.orders.close_now(self.last_price, datetime.now(timezone.utc), reason)
            else:  # at the last bar's close, like the strategy tester
                self.orders.flatten_all()
            self._collect_sim_exits()
            return
        open_ids = {o.id for o in self.orders.get_open_orders()}
        for i in t.leg_ids:
            if i in open_ids:
                self.orders.cancel_order(i)
        self.orders.close_size(t.side, t.size)
        _time.sleep(1.0)  # let the closing fill land before reading fills
        self._finish(t)

    def _slip_ticks(self, t: BotTrade, planned: float | None, actual: float | None, entering: bool) -> int | None:
        """Ticks the fill was worse (+) or better (-) than planned."""
        if planned is None or actual is None:
            return None
        sign = t.side.sign if entering else -t.side.sign
        return round((actual - planned) * sign / self.contract.tick_size)

    def _log_entry_quality(self, t: BotTrade) -> None:
        if self.mode == "replay" or t.signal_price is None:
            return
        slip = self._slip_ticks(t, t.signal_price, t.entry, True)
        delay = (t.placed_at - t.signal_at).total_seconds() if t.placed_at and t.signal_at else None
        log.info("entry fill: signal price %.2f, order sent %s after the signal, filled %.2f (%s)", t.signal_price,
                 f"{delay:.1f}s" if delay is not None else "?", t.entry,
                 "same price" if not slip else f"{abs(slip)} tick{'s' if abs(slip) != 1 else ''} "
                 f"{'worse' if slip > 0 else 'better'}")

    def _record_fills(self, t: BotTrade) -> None:
        """One row per closed trade in logs/fills.csv: how far each fill was from the price it was meant to get."""
        if self.mode == "replay":
            return
        planned_exit = t.stop if t.reason == "stop" else t.target if t.reason == "target" else None
        row = {
            "date": (t.signal_at or t.entry_time).astimezone(self.tz).strftime("%Y-%m-%d"),
            "bot": self.cfg.bot_name, "account": self.cfg.broker.account_name or "", "mode": self.mode,
            "session": t.session, "side": t.side.value, "size": t.size,
            "signal_time": t.signal_at.astimezone(self.tz).strftime("%H:%M:%S") if t.signal_at else "",
            "signal_price": t.signal_price,
            "order_delay_s": round((t.placed_at - t.signal_at).total_seconds(), 2)
            if t.placed_at and t.signal_at else "",
            "entry_fill": round(t.entry, 2), "entry_slip_ticks": self._slip_ticks(t, t.signal_price, t.entry, True),
            "exit_reason": t.reason or "", "planned_exit": planned_exit if planned_exit is not None else "",
            "exit_fill": t.exit if t.exit is not None else "",
            "exit_slip_ticks": self._slip_ticks(t, planned_exit, t.exit, False), "pnl": t.pnl,
            "entry_order_id": t.entry_order or "",
            "entry_time": t.entry_time.astimezone(self.tz).strftime("%H:%M:%S") if t.entry_time else "",
            "exit_time": t.exit_time.astimezone(self.tz).strftime("%H:%M:%S") if t.exit_time else "",
            "stop": t.stop if t.stop is not None else "", "target": t.target if t.target is not None else "",
        }
        path = self.cfg.log_dir / "fills.csv"
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            new = not path.exists()
            if not new:
                _upgrade_csv(path, list(row))
            with path.open("a", newline="") as f:
                w = csv.DictWriter(f, fieldnames=list(row))
                if new:
                    w.writeheader()
                w.writerow({k: "" if v is None else v for k, v in row.items()})
        except OSError as e:
            log.warning("could not write fills.csv: %s", e)

    def _announce_entry(self, t: BotTrade) -> None:
        notify.send("trade", f"{'🟢 Long' if t.side is Side.BUY else '🔴 Short'} {t.size} {self._where()}\n"
                    f"Entry {t.entry:,.2f} · stop {t.stop:,.2f} · target {t.target:,.2f}", self.mode)

    def _where(self) -> str:
        """"MNQZ6 · ORB M5 · PRAC-V2-…" for phone alerts."""
        parts = [self.contract.name if getattr(self, "contract", None) else "", self.cfg.bot_name,
                 self.account_name or self.cfg.broker.account_name or "",
                 "PAPER" if self.mode == "paper" else ""]
        return " · ".join(p for p in parts if p)

    def _finish(self, t: BotTrade) -> None:
        if self.mode == "practice":
            self._fill_exit_from_broker(t)
        if t.reason is None and t.exit is not None:
            t.reason = "target" if abs(t.exit - t.target) <= abs(t.exit - t.stop) else "stop"
        t.exit_time = t.exit_time or datetime.now(timezone.utc)
        self.strategy.on_trade_closed(t.pnl or 0.0)
        log.info("trade closed (%s): %s x%d, entry %.2f, exit %s, P&L $%.2f", t.reason, t.side.value, t.size,
                 t.entry, f"{t.exit:.2f}" if t.exit is not None else "?", t.pnl or 0.0)
        self.closed_trades.append(t)
        self._record_fills(t)
        pnl = t.pnl or 0.0
        notify.send("trade", f"{'✅' if pnl > 0 else '❌' if pnl < 0 else '➖'} Closed ({t.reason}) {self._where()}\n"
                    f"{'Long' if t.side is Side.BUY else 'Short'} {t.size} · {t.entry:,.2f} → "
                    f"{f'{t.exit:,.2f}' if t.exit is not None else '?'} · P&L {'-' if pnl < 0 else '+'}${abs(pnl):,.2f}"
                    f"\nAccount today: {'-' if self.day_pnl() < 0 else '+'}${abs(self.day_pnl()):,.2f}", self.mode)
        _CLAIMED.difference_update(t.leg_ids)
        self.trade, self.in_position, self.flatten_deadline = None, False, None
        self._save_state()

    def _fill_exit_from_broker(self, t: BotTrade) -> None:
        """Exact exit price and P&L from the bot's own fills; falls back to the balance change."""
        try:
            fills = [f for f in self.orders.get_fills(t.placed_at - timedelta(minutes=1))
                     if f.contract_id == self.contract.id and f.time >= t.placed_at - timedelta(seconds=5)]
        except Exception as e:  # noqa: BLE001 - P&L detail only
            log.warning("could not read fills: %s", e)
            fills = []
        entry = [f for f in fills if f.order_id == t.entry_order]
        closing = [f for f in fills if f.order_id in t.leg_ids]
        if not closing and t.reason in ("manual", "flatten", "unprotected", "closed outside the bot"):
            # the close was its own order: take the opposite-side fills of our size after our entry
            opp = Side.SELL if t.side is Side.BUY else Side.BUY
            closing = [f for f in fills if f.side is opp and f.order_id != t.entry_order
                       and f.order_id not in t.pre_ids][-1:]
        if closing:
            size = sum(f.size for f in closing)
            t.exit = sum(f.price * f.size for f in closing) / size
            point_value = self.contract.tick_value / self.contract.tick_size
            fees = sum(f.fees for f in entry + closing)
            t.pnl = (t.exit - t.entry) * t.side.sign * point_value * t.size - fees
        self.refresh_balance()
        if t.pnl is None and t.entry_balance is not None:
            t.pnl = self._balance() - t.entry_balance

    # --- startup -------------------------------------------------------------------------
    def reconcile(self) -> None:
        """Practice: pick the bot's own trade back up after a restart; leave everything else alone."""
        positions = self.orders.get_positions()
        orders = self.orders.get_open_orders()
        saved = self._load_state().get("trade")
        if saved:
            t = BotTrade.from_json(saved)
            ids = {o.id for o in orders}
            if any(i in ids for i in t.leg_ids) or (not t.leg_ids and positions):
                self.trade, self.in_position = t, True
                _CLAIMED.update(t.leg_ids)
                log.warning("picked up the bot's open trade from before the restart: %s x%d @ %.2f",
                            t.side.value, t.size, t.entry)
                return
            log.info("the bot's last trade closed while it was off")
            self._finish(t)
        if positions or orders:
            log.info("%s has %d position(s) and %d working order(s) the bot didn't open; leaving them alone",
                     self.contract.name, len(positions), len(orders))

    # --- live loop -------------------------------------------------------------------------
    def run_live(self) -> None:
        m = self.cfg.strategy.bar_minutes
        self.running = True
        _LIVE.add(self)
        try:
            if self.mode == "practice":
                self.refresh_balance()
                self.reconcile()
            now = datetime.now(timezone.utc)
            start = now - timedelta(hours=WARMUP_HOURS)
            want = getattr(getattr(self.strategy, "script", None), "warmup_start", None)
            if want is not None and want < start:
                start = want
                log.info("catching up on %d-minute bars since %s", m, want.astimezone(self.tz).strftime("%d %b %H:%M"))
            else:
                log.info("warming up with the last %dh of %d-minute bars", WARMUP_HOURS, m)
            for bar in self.data.get_historical_bars(start, now, m):
                if bar.time + timedelta(minutes=m) <= now:
                    self.process_bar(bar, trading=False)
            log.info("running on %s with %s.", self.contract.name,
                     "REAL ORDERS" if self.mode == "practice" else "paper (simulated) orders")
            while True:
                try:
                    self._wait_for_bar_close(m)
                    self._fetch_closed_bar(m)
                except StopRequested:
                    raise
                except Exception as e:  # keep running through network blips; brackets protect trades
                    log.exception("poll failed: %s", e)
                    self._sleep(5)
        except (KeyboardInterrupt, StopRequested):
            log.info("stopped")
            if self.trade:
                log.warning("the bot's trade is still open; its stop and target stay active at the broker")
        finally:
            self.running = False
            _LIVE.discard(self)

    def _wait_for_bar_close(self, m: int) -> None:
        """Sleep until the current bar closes, doing position checks every poll_seconds meanwhile."""
        now = datetime.now(timezone.utc)
        bar_open = now.replace(second=0, microsecond=0) - timedelta(minutes=now.minute % m)
        close = bar_open + timedelta(minutes=m)
        while (wait := (close - datetime.now(timezone.utc)).total_seconds()) > 0:
            self._sleep(min(wait, self.cfg.broker.poll_seconds))
            if datetime.now(timezone.utc) < close:
                self._housekeeping()

    def _fetch_closed_bar(self, m: int) -> None:
        """Right after a bar closes, ask for it every ~0.5s until it arrives (up to 30s), then act on it."""
        now = datetime.now(timezone.utc)
        expected = now.replace(second=0, microsecond=0) - timedelta(minutes=now.minute % m + m)
        if self.stream is not None and self._fast_bar(expected, m):
            self._housekeeping()
            return
        self._housekeeping()  # an exit in the closing bar frees the strategy to re-enter, like Pine
        for attempt in range(40):
            self._process_new_bars(m)
            if self.last_bar_time and self.last_bar_time >= expected:
                self.last_lag = (datetime.now(timezone.utc) - (expected + timedelta(minutes=m))).total_seconds()
                log.info("bar %s processed %.1fs after close", expected.astimezone(self.tz).strftime("%H:%M"),
                         self.last_lag)
                break
            self._sleep(0.5 if attempt < 10 else 1.5)
        else:
            log.warning("bar ending %s not returned by TopstepX after 30s; will pick it up next bar",
                        (expected + timedelta(minutes=m)).astimezone(self.tz).strftime("%H:%M"))
        self.check_flatten(datetime.now(self.tz))

    def _fast_bar(self, expected: datetime, m: int) -> bool:
        """Act on the bar built from live trades, if the stream saw all of it. False = use TopstepX's bar."""
        close = expected + timedelta(minutes=m)
        wait = (close - datetime.now(timezone.utc)).total_seconds() + FAST_GRACE_SECONDS
        if wait > 0:
            _time.sleep(wait)  # short and fixed; Stop is handled at the next _sleep
        if self.last_bar_time and self.last_bar_time >= expected:
            return True
        if self.last_bar_time and self.last_bar_time < expected - timedelta(minutes=m):
            return False  # a gap before this bar: let TopstepX's bars fill it in order
        bar = self.stream.bar(expected, m)
        if bar is None:
            self.fast_stats["fallback"] += 1
            log.info("live bar %s incomplete (stream not connected for all of it); using TopstepX's bar",
                     expected.astimezone(self.tz).strftime("%H:%M"))
            return False
        # An exit in the closing bar frees the strategy to re-enter, like Pine (quick: positions only).
        if self.mode == "practice" and self.trade:
            self._sync_position()
        self.process_bar(bar)
        self.last_lag = (datetime.now(timezone.utc) - close).total_seconds()
        self.fast_stats["live"] += 1
        self._fast_pending.append(bar)
        log.info("bar %s processed %.1fs after close (live)", expected.astimezone(self.tz).strftime("%H:%M"),
                 self.last_lag)
        self.check_flatten(datetime.now(self.tz))
        return True

    def _check_fast_bars(self) -> None:
        """Compare live bars with TopstepX's official ones and log any difference."""
        now = datetime.now(timezone.utc)
        m = self.cfg.strategy.bar_minutes
        due = [b for b in self._fast_pending if now - (b.time + timedelta(minutes=m)) >= FAST_CHECK_AFTER]
        if not due:
            return
        try:
            official = {b.time: b for b in self.data.get_historical_bars(
                min(b.time for b in due), max(b.time for b in due) + timedelta(minutes=m), m)}
        except Exception as e:  # noqa: BLE001 - try again next poll
            log.debug("could not fetch bars to check live bars: %s", e)
            return
        tick = self.contract.tick_size
        for b in due:
            o = official.get(b.time)
            if o is None and now - b.time < timedelta(minutes=m + 5):
                continue  # not published yet
            self._fast_pending.remove(b)
            if o is None:
                continue
            diffs = [f"{name} {lv:.2f} vs {ov:.2f}" for name, lv, ov in
                     (("open", b.open, o.open), ("high", b.high, o.high), ("low", b.low, o.low),
                      ("close", b.close, o.close)) if abs(lv - ov) >= tick / 2]
            if diffs:
                self.fast_stats["differed"] += 1
                log.warning("live bar %s differed from TopstepX's bar: %s",
                            b.time.astimezone(self.tz).strftime("%H:%M"), ", ".join(diffs))
            else:
                self.fast_stats["matched"] += 1
                log.debug("live bar %s matched TopstepX's bar", b.time.astimezone(self.tz).strftime("%H:%M"))

    def _housekeeping(self) -> None:
        if self.mode == "practice":
            self.refresh_balance()
            self._sync_position()
        if self.trade:
            try:
                self.last_price = self.data.get_last_price()
            except Exception as e:  # noqa: BLE001 - display only
                log.debug("last price unavailable: %s", e)
        if self._fast_pending:
            self._check_fast_bars()
        self.check_flatten(datetime.now(self.tz))

    def _process_new_bars(self, m: int) -> None:
        now = datetime.now(timezone.utc)
        start = (self.last_bar_time or now - timedelta(hours=1)) - timedelta(minutes=m)
        for bar in self.data.get_historical_bars(start, now, m):
            if self.last_bar_time and bar.time <= self.last_bar_time:
                continue
            if bar.time + timedelta(minutes=m) > now:  # still forming
                continue
            # A bar that closed a while ago (the Mac was asleep, or the network was down) still updates the
            # ranges, but a breakout in it isn't taken late at today's price.
            fresh = now - (bar.time + timedelta(minutes=m)) <= timedelta(minutes=m + 1)  # up to one bar late
            if not fresh and not getattr(self, "_late_noted", None) == bar.time.date():
                log.warning("catching up on bars missed while the app wasn't running (Mac asleep or offline); "
                            "signals in them aren't traded late")
                self._late_noted = bar.time.date()
            self.process_bar(bar, trading=fresh)

    def _poll(self, m: int) -> None:
        """One full check: positions, then any newly closed bars (used by tests)."""
        self._housekeeping()
        self._process_new_bars(m)
        self.check_flatten(datetime.now(self.tz))

    # --- what the app window shows -----------------------------------------------------------
    def snapshot(self) -> dict:
        now = datetime.now(self.tz)
        today = trading_day(now)
        closed = [t for t in self.closed_trades if trading_day(t.entry_time) == today]
        earlier = self._earlier_today(today)
        rows = []
        for cfg in self.cfg.sessions:
            st = self.strategy.state[cfg.name]
            start, end = session_window(self.cfg, cfg, now)
            recent = st.lock_time is not None and now - st.lock_time < timedelta(hours=20)
            if st.prev_in_session:
                status = "Building range"
            elif st.locked and recent:
                window_over = bool(cfg.breakout_window_hours) and \
                    now - st.lock_time > timedelta(hours=cfg.breakout_window_hours)
                if self.trade and self.trade.session == cfg.name:
                    status = "In trade"
                elif st.trades >= cfg.max_trades or window_over:
                    status = "Done" if st.trades else "Done, no breakout"
                else:
                    status = "Watching for breakout"
            else:
                status = f"Starts {start.strftime('%H:%M')}"
            if not cfg.enabled:
                status = "Off"
            show_range = st.prev_in_session or (st.locked and recent)
            rows.append({"name": cfg.name, "enabled": cfg.enabled,
                         "window": f"{start.strftime('%H:%M')}-{end.strftime('%H:%M')}",
                         "high": st.high if show_range else None, "low": st.low if show_range else None,
                         "status": status, "pnl": sum(t.pnl or 0 for t in closed if t.session == cfg.name),
                         "trades": sum(1 for t in closed if t.session == cfg.name)})
        trade = None
        if self.trade:
            t = self.trade
            unreal = None
            if self.last_price is not None and t.filled:
                point_value = self.contract.tick_value / self.contract.tick_size
                unreal = (self.last_price - t.entry) * t.side.sign * point_value * t.size
            trade = {"session": t.session, "side": t.side.value, "size": t.size, "entry": t.entry, "stop": t.stop,
                     "target": t.target, "filled": t.filled, "last": self.last_price, "unrealized": unreal,
                     "time": t.entry_time.astimezone(self.tz).strftime("%H:%M"), "at": t.placed_at or t.entry_time}
        balance = day_pnl = None
        if isinstance(self.orders, SimBroker) or self._cached_balance is not None:
            balance = self._balance()
            if self.day_start_balance is not None:
                day_pnl = self.day_pnl()
        return {
            "running": self.running, "mode": self.mode, "contract": self.contract.name,
            "account": self.account_name, "balance": balance, "day_pnl": day_pnl,
            "last_bar": (self.last_bar_time + timedelta(minutes=self.cfg.strategy.bar_minutes)).astimezone(self.tz)
            if self.last_bar_time else None,
            "last_lag": self.last_lag, "sessions": rows, "trade": trade,
            "fast": dict(self.fast_stats, on=self.stream is not None,
                         connected=bool(self.stream and self.stream.healthy)),
            "closed": earlier + [{"session": t.session, "time": t.entry_time.astimezone(self.tz).strftime("%H:%M:%S"),
                                  "out": t.exit_time.astimezone(self.tz).strftime("%H:%M:%S") if t.exit_time else "",
                                  "side": t.side.value, "size": t.size, "entry": t.entry, "exit": t.exit,
                                  "reason": t.reason, "pnl": t.pnl} for t in closed],
        }

    def _earlier_today(self, today) -> list[dict]:
        """Today's trades closed before this run started (from logs/fills.csv), so a restart keeps the list."""
        if self.mode == "replay":
            return []
        if getattr(self, "_earlier", (None,))[0] != today:
            rows: list[dict] = []
            try:
                with (self.cfg.log_dir / "fills.csv").open(newline="") as f:
                    for r in csv.DictReader(f):
                        if (r.get("bot"), r.get("account") or "", r.get("mode")) != \
                                (self.cfg.bot_name, self.cfg.broker.account_name or "", self.mode):
                            continue
                        when = datetime.strptime(f"{r['date']} {r.get('signal_time') or '00:00:00'}",
                                                 "%Y-%m-%d %H:%M:%S").replace(tzinfo=self.tz)
                        if trading_day(when) != today or when >= self.started_at:
                            continue
                        num = lambda k: float(r[k]) if r.get(k) not in (None, "") else None  # noqa: E731
                        rows.append({"session": r.get("session", ""),
                                     "time": r.get("entry_time") or when.strftime("%H:%M:%S"),
                                     "out": r.get("exit_time") or "", "order": r.get("entry_order_id") or "",
                                     "fill_known": bool(r.get("entry_time")),
                                     "side": r.get("side", ""), "size": int(float(r.get("size") or 0)),
                                     "entry": num("entry_fill"), "exit": num("exit_fill"),
                                     "reason": r.get("exit_reason", ""), "pnl": num("pnl")})
            except (OSError, ValueError, KeyError) as e:
                log.debug("earlier trades not loaded: %s", e)
            self._earlier = (today, rows)
            if any(not r["out"] for r in rows) and hasattr(self.data, "get_fills"):
                threading.Thread(target=self._fill_times, args=(rows,), daemon=True).start()
        return self._earlier[1]

    def _fill_times(self, rows: list[dict]) -> None:
        """Older fills.csv rows have no entry/exit times: take them from Topstep's fills (in the background)."""
        from .performance import round_trips
        try:
            trips = round_trips(self.data.get_fills(datetime.now(timezone.utc) - timedelta(days=2)))
        except Exception as e:  # noqa: BLE001 - display only
            log.debug("couldn't look up trade times: %s", e)
            return
        for r in rows:
            oid = int(r["order"]) if str(r["order"]).isdigit() else None
            t = next((t for t in trips if oid in t.order_ids), None) if oid else None
            if t is None:
                continue
            r["out"] = t.exit_time.astimezone(self.tz).strftime("%H:%M:%S")
            if not r["fill_known"]:
                r["time"] = t.entry_time.astimezone(self.tz).strftime("%H:%M:%S")

    # --- replay ------------------------------------------------------------------------------
    def run_replay(self, start: datetime, end: datetime, out_csv: Path) -> list:
        assert isinstance(self.orders, SimBroker)
        bars = self.data.get_historical_bars(start, end, self.cfg.strategy.bar_minutes)
        log.info("replaying %d bars from %s to %s", len(bars), start.date(), end.date())
        for bar in bars:
            self.process_bar(bar)
        trades = self.orders.trades
        write_trades_csv(trades, out_csv, self.tz)
        return trades


def _upgrade_csv(path: Path, fields: list[str]) -> None:
    """Rewrite an older fills.csv under the current header so new columns line up (old rows get blanks)."""
    with path.open(newline="") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames == fields:
            return
        rows = list(reader)
    with path.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") or "" for k in fields})


def write_trades_csv(trades, path: Path, tz) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["session", "entry_time", "side", "size", "entry", "stop", "target", "exit_time", "exit",
                    "reason", "pnl"])
        for t in trades:
            w.writerow([t.tag.split("-")[-2] if t.tag else "",
                        t.entry_time.astimezone(tz).strftime("%Y-%m-%d %H:%M"), t.side.value, t.size,
                        f"{t.entry_price:.2f}", f"{t.stop_price:.2f}", f"{t.target_price:.2f}",
                        t.exit_time.astimezone(tz).strftime("%Y-%m-%d %H:%M") if t.exit_time else "open",
                        f"{t.exit_price:.2f}" if t.exit_price is not None else "", t.exit_reason or "",
                        f"{t.pnl:.2f}"])
