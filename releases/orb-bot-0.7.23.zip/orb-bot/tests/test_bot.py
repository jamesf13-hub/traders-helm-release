"""Tests for the Pine Script port, the TradingView-style fills, and the TopstepX adapter.

Bars are hand-built 15-minute bars in Brisbane time, matching the Pine Script's default settings.
Contract is MNQ: tick 0.25 = $0.50, so 1 point = $2.
"""
from datetime import datetime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

import json
from types import SimpleNamespace
import time

import pytest

from orb_bot.broker.base import Broker
from orb_bot.broker.projectx import ProjectXBroker
from orb_bot.broker.sim import SimBroker
from orb_bot.config import BrokerConfig, load_config, save_broker_setting, save_setting
from orb_bot.engine import Engine
from orb_bot.models import Account, Bar, Contract, Fill, OpenOrder, OrderResult, Position, Side
from orb_bot.strategy.orb import ORBStrategy

ROOT = Path(__file__).resolve().parents[1]
BNE = ZoneInfo("Australia/Brisbane")
MNQ = Contract("CON.F.US.MNQ.Z26", "MNQZ6", 0.25, 0.5)


def B(when, o, h, l, c):
    return Bar(datetime.strptime(when, "%Y-%m-%d %H:%M").replace(tzinfo=BNE), o, h, l, c, 1)


@pytest.fixture(autouse=True)
def fresh_claims():
    from orb_bot import engine
    from orb_bot.broker import projectx
    engine._CLAIMED.clear(); engine._LIVE.clear(); projectx._LOGINS.clear()
    yield


@pytest.fixture
def cfg(tmp_path):
    p = tmp_path / "config.toml"
    p.write_text((ROOT / "config.example.toml").read_text())
    c = load_config(p)
    c.log_dir = tmp_path / "logs"
    c.strategy.bar_minutes = 15  # tests use hand-built 15m bars
    # Tests are written against the Pine Script's own input defaults, not James's live settings.
    pine_defaults = {
        "s1": dict(enabled=False, window_minutes=15, candle_sl_threshold=50, min_close_pct_first=0,
                   min_close_pct_flip=0, breakout_window_hours=2.0, body_filter=False, min_body_pct=50),
        "s2": dict(min_close_pct_first=0, min_close_pct_flip=50, breakout_window_hours=2.0),
        "s3": dict(candle_sl_threshold=50, min_close_pct_first=10, min_close_pct_flip=30, body_filter=False,
                   min_body_pct=60),
    }
    for s in c.sessions:
        for k, v in pine_defaults[s.name].items():
            setattr(s, k, v)
    c.risk.risk_on_starting_balance, c.risk.max_contracts = False, 50
    c.sim.commission_per_side, c.sim.slippage_ticks = 0.0, 0
    c.safety.max_daily_loss = 0
    return c


def session(cfg, name):
    return next(s for s in cfg.sessions if s.name == name)


def only(cfg, name):
    for s in cfg.sessions:
        s.enabled = s.name == name
    return session(cfg, name)


class FakeData(Broker):
    def __init__(self, bars):
        self.bars = bars
    def connect(self): pass
    def get_account_state(self): raise NotImplementedError
    def get_contract(self): return MNQ
    def get_historical_bars(self, start, end, minutes):
        return [b for b in self.bars if start <= b.time < end]
    def place_bracket_order(self, *a, **k): raise NotImplementedError
    def cancel_order(self, i): return True
    def get_positions(self): return []
    def get_open_orders(self): return []
    def flatten_all(self): pass


def replay(cfg, bars, tmp_name="t.csv"):
    sim = SimBroker(MNQ, cfg.sim, starting_balance=cfg.risk.account_size)
    eng = Engine(cfg, FakeData(bars), sim, "replay")
    trades = eng.run_replay(bars[0].time, bars[-1].time + timedelta(minutes=15), cfg.log_dir / tmp_name)
    return trades, eng


# Session 3 defaults: 23:15 AEST, candle SL on, min close 10% first / 30% flip, flip allowed.
S3_DAY = [
    B("2026-10-06 23:00", 20000, 20002, 19998, 20000),   # before the range
    B("2026-10-06 23:15", 20000, 20010, 19990, 20005),   # range bar: 19990 - 20010
    B("2026-10-06 23:30", 20005, 20030, 20004, 20025),   # lock bar + long breakout (57% beyond, candle SL)
    B("2026-10-06 23:45", 20026, 20032, 20020, 20030),   # hits target 20031.25
    B("2026-10-07 00:00", 19995, 19996, 19980, 19985),   # flip short (31% beyond, candle SL -> 19996)
    B("2026-10-07 00:15", 19984, 19997, 19983, 19990),   # stopped at 19996
    B("2026-10-07 00:30", 19990, 20045, 19990, 20040),   # third breakout: no trade, max 2
]


def test_s3_first_trade_flip_and_max_two(cfg):
    only(cfg, "s3")
    trades, _ = replay(cfg, S3_DAY)
    assert len(trades) == 2
    first, flip = trades
    assert (first.side, first.entry_price, first.stop_price, first.target_price) == (Side.BUY, 20025, 20004, 20031.25)
    assert first.entry_time.astimezone(BNE).strftime("%H:%M") == "23:30"
    assert first.size == 11                                   # $500 / (21 pts x $2) = 11.9 -> 11
    assert first.exit_reason == "target" and first.pnl == pytest.approx(25 * 0.5 * 11)
    assert (flip.side, flip.entry_price, flip.stop_price, flip.target_price) == (Side.SELL, 19985, 19996, 19981.75)
    assert flip.size == 22                                    # $501.37 / (11 pts x $2) = 22.8 -> 22
    assert flip.exit_reason == "stop" and flip.exit_price == 19996


def test_min_close_pct_blocks_weak_breakout(cfg):
    only(cfg, "s3")
    bars = S3_DAY[:2] + [B("2026-10-06 23:30", 20000, 20030, 19995, 20011)]  # 1 pt beyond of 35 = 2.9% < 10%
    trades, _ = replay(cfg, bars)
    assert trades == []


def test_range_stop_when_candle_mostly_inside(cfg):
    only(cfg, "s3")
    # candle 19995-20015, only 5 of 20 pts (25%) above range high -> stop stays at range low 19990
    bars = S3_DAY[:2] + [B("2026-10-06 23:30", 19996, 20015, 19995, 20014)]
    trades, _ = replay(cfg, bars)
    assert trades[0].stop_price == 19990


def test_flip_must_be_opposite_direction(cfg):
    only(cfg, "s3")
    bars = S3_DAY[:4] + [B("2026-10-07 00:00", 20030, 20060, 20029, 20055)]  # another long: blocked
    trades, _ = replay(cfg, bars)
    assert len(trades) == 1


def test_no_flip_when_disabled(cfg):
    only(cfg, "s3").allow_flip = False
    trades, _ = replay(cfg, S3_DAY)
    assert len(trades) == 1


def test_breakout_window_is_inclusive_two_hours(cfg):
    only(cfg, "s3")
    quiet = [B(f"2026-10-07 {h:02d}:{m:02d}", 20000, 20005, 19995, 20000)
             for h, m in [(0, 0), (0, 15), (0, 30), (0, 45), (1, 0), (1, 15)]]
    at_limit = B("2026-10-07 01:30", 20000, 20030, 19999, 20025)   # lock 23:30 + 2h -> allowed
    late = B("2026-10-07 01:45", 20000, 20030, 19999, 20025)       # 2h15 -> not allowed
    lock = B("2026-10-06 23:30", 20000, 20005, 19995, 20000)
    assert len(replay(cfg, S3_DAY[:2] + [lock] + quiet + [at_limit])[0]) == 1
    assert len(replay(cfg, S3_DAY[:2] + [lock] + quiet + [late], "t2.csv")[0]) == 0


def test_body_and_exhaustion_filters(cfg):
    s3 = only(cfg, "s3")
    s3.candle_sl = False
    wick = B("2026-10-06 23:30", 20005, 20050, 20004, 20015)  # upper wick 35 > range 20
    assert len(replay(cfg, S3_DAY[:2] + [wick])[0]) == 1
    s3.exhaustion_filter = True
    assert len(replay(cfg, S3_DAY[:2] + [wick], "t2.csv")[0]) == 0
    s3.exhaustion_filter, s3.body_filter = False, True                  # body 10 of 46 = 22% < 60%
    assert len(replay(cfg, S3_DAY[:2] + [wick], "t3.csv")[0]) == 0


def test_session2_uses_brisbane_1500(cfg):
    only(cfg, "s2")
    bars = [B("2026-10-07 15:00", 20000, 20010, 19990, 20000),
            B("2026-10-07 15:15", 20000, 20020, 19999, 20015),
            B("2026-10-07 15:30", 20015, 20040, 20010, 20035)]
    trades, _ = replay(cfg, bars)
    assert len(trades) == 1 and trades[0].stop_price == 19990          # candle SL is off in session 2
    assert trades[0].exit_reason == "target"


def test_same_bar_exit_then_flip_entry(cfg):
    only(cfg, "s3")
    bars = S3_DAY[:3] + [B("2026-10-06 23:45", 20010, 20012, 19970, 19975)]  # stop hit, closes 15 below low
    trades, _ = replay(cfg, bars)
    assert len(trades) == 2 and trades[0].exit_reason == "stop"
    assert trades[1].side is Side.SELL and trades[1].entry_time == trades[0].exit_time


def test_tradingview_intrabar_order_and_gaps(cfg):
    sim = SimBroker(MNQ, cfg.sim)
    def long_at(price):
        sim.open = None
        sim.update(B("2026-10-07 00:00", price, price, price, price))
        sim.place_bracket_order(Side.BUY, 1, 40, 40)   # stop -10, target +10
    long_at(100)
    sim.update(B("2026-10-07 00:15", 101, 111, 89, 100))   # high nearer the open -> target first
    assert sim.trades[-1].exit_reason == "target"
    long_at(100)
    sim.update(B("2026-10-07 00:15", 99, 111, 89, 100))    # low nearer the open -> stop first
    assert sim.trades[-1].exit_reason == "stop"
    long_at(100)
    sim.update(B("2026-10-07 00:15", 85, 86, 80, 84))      # gap through stop fills at the open
    assert sim.trades[-1].exit_price == 85


def test_slippage_like_tradingview(cfg):
    # 1 tick slippage: entry and stop fills are 1 tick worse; stop/target prices stay anchored to the signal close.
    cfg.sim.slippage_ticks = 1
    sim = SimBroker(MNQ, cfg.sim)
    sim.update(B("2026-09-22 15:15", 100, 101, 99, 100))
    assert sim.place_bracket_order(Side.SELL, 1, 8, 4).ok
    t = sim.open
    assert (t.entry_price, t.stop_price, t.target_price) == (99.75, 102.0, 99.0)
    sim.update(B("2026-09-22 15:20", 100, 102.5, 99.5, 102))
    assert (t.exit_price, t.exit_reason) == (102.25, "stop")
    sim.update(B("2026-09-22 15:25", 100, 101, 99, 100))
    assert sim.place_bracket_order(Side.BUY, 1, 8, 4).ok
    t = sim.open
    assert (t.entry_price, t.stop_price, t.target_price) == (100.25, 98.0, 101.0)
    sim.update(B("2026-09-22 15:30", 100, 101.5, 99.5, 101))
    assert (t.exit_price, t.exit_reason) == (101.0, "target")


def test_sizing_and_prop_firm_passer(cfg):
    s = ORBStrategy(cfg, MNQ)
    assert s.qty_for_risk(21, 50000) == 11
    assert s.qty_for_risk(1000, 50000) == 1          # never below 1, like Pine
    assert s.qty_for_risk(0.25, 50000) == 50         # capped at max_contracts
    cfg.risk.risk_on_starting_balance = True
    assert s.qty_for_risk(21, 10) == 11              # uses account_size, not balance
    cfg.risk.prop_firm_passer = True
    assert s.qty_for_risk(21, 0) == 23               # starts HIGH: 2x risk
    s.on_trade_closed(-100)
    assert not s.passer_high and s.qty_for_risk(21, 0) == 11
    for _ in range(5):
        s.on_trade_closed(50)
    assert not s.passer_high
    s.on_trade_closed(0)                             # breakeven counts as a loss in Pine
    assert s.passer_wins_since_loss == 0
    for _ in range(6):
        s.on_trade_closed(50)
    assert s.passer_high


def test_optional_flatten_time(cfg):
    only(cfg, "s3").flatten_at = datetime.strptime("00:30", "%H:%M").time()
    bars = S3_DAY[:3] + [B(f"2026-10-07 00:{m:02d}", 20026, 20028, 20020, 20027) for m in (0, 15, 30)]
    bars.insert(3, B("2026-10-06 23:45", 20026, 20028, 20020, 20027))
    trades, _ = replay(cfg, bars)
    assert trades[0].exit_reason == "flatten"
    assert trades[0].exit_time.astimezone(BNE).strftime("%H:%M") == "00:15"   # bar ending 00:30


def test_safety_daily_loss_blocks_entries(cfg):
    only(cfg, "s3")
    cfg.safety.max_daily_loss = 400
    trades, _ = replay(cfg, S3_DAY[:3] + [B("2026-10-06 23:45", 20010, 20012, 19970, 19975)])
    assert len(trades) == 1   # first trade loses 21 pts x $2 x 11 = $462, so the flip is blocked
    cfg.safety.max_daily_loss = 0
    assert len(replay(cfg, S3_DAY[:3] + [B("2026-10-06 23:45", 20010, 20012, 19970, 19975)], "t2.csv")[0]) == 2


def test_example_config_has_james_tradingview_settings(tmp_path):
    p = tmp_path / "c.toml"
    p.write_text((ROOT / "config.example.toml").read_text())
    c = load_config(p)
    s1, s2, s3 = (session(c, n) for n in ("s1", "s2", "s3"))
    assert c.strategy.bar_minutes == 5 and c.timezone.key == "Australia/Brisbane"
    assert (s1.enabled, s1.start.hour, s1.window_minutes, s1.min_close_pct_first, s1.body_filter, s1.min_body_pct,
            s1.breakout_window_hours) == (True, 11, 30, 80, True, 75, 1.0)
    assert (s2.min_close_pct_first, s2.min_close_pct_flip, s2.breakout_window_hours, s2.candle_sl) == (70, 100, 1.0, False)
    assert (s3.start.minute, s3.candle_sl, s3.candle_sl_threshold, s3.min_close_pct_first, s3.min_close_pct_flip,
            s3.body_filter) == (15, True, 25, 20, 40, True)
    assert c.risk.risk_on_starting_balance and c.risk.max_contracts == 50 and c.sim.commission_per_side == 0.61
    assert c.sim.slippage_ticks == 1

def test_unknown_setting_is_an_error(tmp_path):
    p = tmp_path / "c.toml"
    p.write_text((ROOT / "config.example.toml").read_text().replace("rr_flip = 0.3", "rr_flipp = 0.3", 1))
    with pytest.raises(ValueError, match="rr_flipp"):
        load_config(p)


def test_save_broker_setting(tmp_path):
    p = tmp_path / "c.toml"
    p.write_text((ROOT / "config.example.toml").read_text())
    save_broker_setting(p, "account_id", 777)
    save_broker_setting(p, "bracket_tick_mode", "signed")
    save_broker_setting(p, "bracket_tick_mode", "unsigned")
    c = load_config(p)
    assert c.broker.account_id == 777 and c.broker.bracket_tick_mode == "unsigned"
    assert [s.name for s in c.sessions] == ["s1", "s2", "s3"]


# --- live-mode safety with a stand-in for the real account ----------------------------
class FakeLive(FakeData):
    """A TopstepX account with Auto OCO: each entry gets its own stop and target sized to that entry."""
    def __init__(self, bars, positions=None, orders=None):
        super().__init__(bars)
        self.positions, self.orders, self.cancelled, self.flattened, self.placed = positions or [], orders or [], [], 0, []
        self.fills, self.closed_sizes, self._id = [], [], 100
    def get_account_state(self): return Account(1, "PRAC-TEST", 50000.0, True)
    def get_positions(self): return self.positions
    def get_open_orders(self): return self.orders
    def cancel_order(self, i):
        self.cancelled.append(i); self.orders = [o for o in self.orders if o.id != i]; return True
    def flatten_all(self): self.flattened += 1; self.positions = []; self.orders = []
    def place_bracket_order(self, *a, **k): self.placed.append(a); return OrderResult(True, 1)
    def close_size(self, side, size): self.closed_sizes.append((side, size))
    def get_fills(self, since): return [f for f in self.fills if f.time >= since]
    def get_last_price(self): return None
    # helpers to script what the broker does
    def fill_entry(self, order_id, side, size, price, stop, target):
        now = datetime.now(timezone.utc)
        self.fills.append(Fill(order_id, MNQ.id, side, size, price, None, 0.37 * size, now))
        exit_side = Side.SELL if side is Side.BUY else Side.BUY
        self._id += 2
        self.orders += [OpenOrder(self._id, MNQ.id, exit_side, size, 4, None, stop),
                        OpenOrder(self._id + 1, MNQ.id, exit_side, size, 1, target, None)]
        net = sum(p.size * p.side.sign for p in self.positions) + size * side.sign
        self.positions = [Position(MNQ.id, Side.BUY if net > 0 else Side.SELL, abs(net), price)] if net else []
        return self._id, self._id + 1
    def fill_leg(self, leg_id, other_leg, price):
        leg = next(o for o in self.orders if o.id == leg_id)
        self.orders = [o for o in self.orders if o.id not in (leg_id, other_leg)]   # OCO cancels the other
        self.fills.append(Fill(leg_id, MNQ.id, leg.side, leg.size, price, 1.0, 0.37 * leg.size,
                               datetime.now(timezone.utc)))
        net = sum(p.size * p.side.sign for p in self.positions) + leg.size * leg.side.sign
        self.positions = [Position(MNQ.id, Side.BUY if net > 0 else Side.SELL, abs(net), price)] if net else []


def test_warmup_does_not_trade_missed_breakouts(cfg):
    only(cfg, "s3")
    live = FakeLive(S3_DAY)
    eng = Engine(cfg, live, live, "practice")
    for b in S3_DAY[:3]:
        eng.process_bar(b, trading=False)          # breakout happened while the bot was off
    for b in S3_DAY[3:]:
        eng.process_bar(b, trading=True)
    assert live.placed == []                       # and the flip is not taken either


def test_live_places_bracket_in_ticks(cfg):
    only(cfg, "s3")
    live = FakeLive(S3_DAY)
    eng = Engine(cfg, live, live, "practice")
    for b in S3_DAY[:3]:
        eng.process_bar(b)
    assert live.placed == [(Side.BUY, 11, 84, 25, "orbm5-s3-202610062330")]   # 21 pts = 84 ticks; 6.3 pts -> 25


def _bot_in_trade(cfg, live):
    """Bot places a long x4 on S3 (entry order id 1); returns the engine."""
    only(cfg, "s3")
    cfg.risk.risk_mode, cfg.risk.risk_dollars = "dollars", 4 * 21 * 2   # 21-pt stop -> exactly 4 contracts
    eng = Engine(cfg, live, live, "practice")
    for b in S3_DAY[:3]:
        eng.process_bar(b)
    assert eng.trade and eng.trade.size == 4
    return eng


def test_other_bot_on_same_contract_is_left_alone(cfg):
    # Another bot already holds 2 long with its own stop and target.
    other = [OpenOrder(7, MNQ.id, Side.SELL, 2, 4, None, 19900.0), OpenOrder(8, MNQ.id, Side.SELL, 2, 1, 20100.0, None)]
    live = FakeLive(S3_DAY, positions=[Position(MNQ.id, Side.BUY, 2, 20000.0)], orders=list(other))
    eng = Engine(cfg, live, live, "practice")
    eng.reconcile()
    assert live.cancelled == [] and not eng.in_position          # not adopted, not touched
    eng = _bot_in_trade(cfg, live)
    stop_id, tp_id = live.fill_entry(1, Side.BUY, 4, 20025.25, 20004.25, 20031.50)
    eng._sync_position()
    t = eng.trade
    assert t.filled and t.entry == 20025.25 and sorted(t.leg_ids) == [stop_id, tp_id]
    assert (t.stop, t.target) == (20004.25, 20031.50)
    live.fill_leg(tp_id, stop_id, 20031.50)                     # our target: sells our 4 only
    eng._sync_position()
    assert eng.trade is None and not eng.in_position
    closed = eng.closed_trades[-1]
    assert closed.reason == "target" and closed.exit == 20031.50
    assert closed.pnl == pytest.approx((20031.50 - 20025.25) * 2 * 4 - 0.37 * 8)
    assert live.positions[0].size == 2                           # the other bot's 2 keep running
    assert [o.id for o in live.orders] == [7, 8] and live.cancelled == []


def test_close_now_closes_only_the_bots_contracts(cfg):
    live = FakeLive(S3_DAY, positions=[Position(MNQ.id, Side.BUY, 2, 20000.0)],
                    orders=[OpenOrder(7, MNQ.id, Side.SELL, 2, 4, None, 19900.0)])
    eng = _bot_in_trade(cfg, live)
    stop_id, tp_id = live.fill_entry(1, Side.BUY, 4, 20025.25, 20004.25, 20031.50)
    eng._sync_position()
    eng.request_close()
    with patch_sleep():
        eng._run_commands()
    assert live.closed_sizes == [(Side.BUY, 4)]
    assert sorted(live.cancelled) == [stop_id, tp_id]            # only our own stop and target
    assert eng.trade is None and eng.closed_trades[-1].reason == "manual"


def test_unprotected_trade_is_closed(cfg):
    live = FakeLive(S3_DAY)
    eng = _bot_in_trade(cfg, live)
    live.fills.append(Fill(1, MNQ.id, Side.BUY, 4, 20025.25, None, 0, datetime.now(timezone.utc)))
    live.positions = [Position(MNQ.id, Side.BUY, 4, 20025.25)]
    with patch_sleep():
        eng._sync_position()
        assert live.closed_sizes == []                           # first check: brackets may still be arriving
        eng._sync_position()
    assert live.closed_sizes == [(Side.BUY, 4)] and eng.closed_trades[-1].reason == "unprotected"


def test_restart_picks_up_own_trade_and_ignores_foreign_orders(cfg):
    live = FakeLive(S3_DAY, orders=[OpenOrder(5, MNQ.id, Side.SELL, 1, 4, None, 19950.0)])
    eng = _bot_in_trade(cfg, live)
    stop_id, tp_id = live.fill_entry(1, Side.BUY, 4, 20025.25, 20004.25, 20031.50)
    eng._sync_position()
    eng2 = Engine(cfg, live, live, "practice")
    eng2.reconcile()
    assert eng2.trade and eng2.trade.leg_ids == eng.trade.leg_ids and live.cancelled == []


class patch_sleep:
    def __enter__(self):
        import orb_bot.engine as m
        self.m, self.orig = m, m._time.sleep
        m._time.sleep = lambda s: None
    def __exit__(self, *a):
        self.m._time.sleep = self.orig


# --- TopstepX adapter with a fake HTTP session ----------------------------------------
class FakeResp:
    def __init__(self, data, status=200):
        self._d, self.status_code, self.text = data, status, str(data)
    def json(self):
        return self._d


class FakeSession:
    def __init__(self):
        self.headers, self.calls = {}, []
    def post(self, url, json=None, timeout=None, headers=None):
        path = url.split("topstepx.com")[1]
        self.calls.append((path, json))
        self.auth = (headers or {}).get("Authorization")
        ok = {"success": True, "errorCode": 0, "errorMessage": None}
        if path == "/api/Auth/loginKey":
            return FakeResp({**ok, "token": "T"})
        if path == "/api/Contract/search":
            return FakeResp({**ok, "contracts": [
                {"id": "CON.F.US.MNQ.Z26", "name": "MNQZ6", "tickSize": 0.25, "tickValue": 0.5, "activeContract": True},
                {"id": "CON.F.US.MNQ.H27", "name": "MNQH7", "tickSize": 0.25, "tickValue": 0.5, "activeContract": False}]})
        if path == "/api/History/retrieveBars":
            return FakeResp({**ok, "bars": [
                {"t": "2026-10-06T13:45:00+00:00", "o": 2, "h": 3, "l": 1, "c": 2.5, "v": 9},
                {"t": "2026-10-06T13:30:00+00:00", "o": 1, "h": 2, "l": 0.5, "c": 2, "v": 5}]})
        if path == "/api/Order/place":
            return FakeResp({**ok, "orderId": 42})
        raise AssertionError(path)


def make_px(mode=None):
    b = ProjectXBroker(BrokerConfig(account_id=1, bracket_tick_mode=mode), "u", "k")
    b.session = FakeSession()
    return b


def test_projectx_contract_bars_and_signed_brackets():
    b = make_px("signed")
    b.connect()
    assert b.get_contract().name == "MNQZ6"
    bars = b.get_historical_bars(datetime(2026, 10, 6, 13, tzinfo=timezone.utc),
                                 datetime(2026, 10, 6, 14, tzinfo=timezone.utc), 15)
    assert [x.close for x in bars] == [2, 2.5] and bars[0].time.tzinfo is not None
    assert b.session.calls[-1][1]["unitNumber"] == 15
    assert b.place_bracket_order(Side.BUY, 2, 40, 12).order_id == 42
    body = b.session.calls[-1][1]
    assert body["side"] == 0 and body["type"] == 2 and body["size"] == 2
    assert body["stopLossBracket"] == {"ticks": -40, "type": 4}
    assert body["takeProfitBracket"] == {"ticks": 12, "type": 1}
    b.place_bracket_order(Side.SELL, 1, 40, 12)
    body = b.session.calls[-1][1]
    assert body["side"] == 1 and body["stopLossBracket"]["ticks"] == 40 and body["takeProfitBracket"]["ticks"] == -12


def test_projectx_refuses_orders_before_bracket_test():
    b = make_px(None)
    b.connect()
    r = b.place_bracket_order(Side.BUY, 1, 40, 12)
    assert not r.ok and "bracket-test" in r.error


def test_5m_bars_range_spans_three_candles(cfg):
    only(cfg, "s3").candle_sl = False
    cfg.strategy.bar_minutes = 5
    bars = [B("2026-10-06 23:10", 20000, 20001, 19999, 20000),
            B("2026-10-06 23:15", 20000, 20004, 19996, 20002),
            B("2026-10-06 23:20", 20002, 20010, 20001, 20008),   # range high 20010
            B("2026-10-06 23:25", 20008, 20009, 19990, 19995),   # range low 19990
            B("2026-10-06 23:30", 19995, 20020, 19994, 20015)]   # lock + long breakout
    sim = SimBroker(MNQ, cfg.sim, starting_balance=cfg.risk.account_size)
    trades = Engine(cfg, FakeData(bars), sim, "replay").run_replay(bars[0].time, bars[-1].time + timedelta(minutes=5),
                                                                   cfg.log_dir / "t.csv")
    assert len(trades) == 1 and trades[0].stop_price == 19990 and trades[0].entry_price == 20015


def test_live_loop_acts_within_seconds_of_bar_close(cfg, monkeypatch):
    import orb_bot.engine as engine_mod
    cfg.strategy.bar_minutes = 5
    clock = [datetime(2026, 10, 9, 13, 3, 20, tzinfo=timezone.utc)]   # mid-bar (13:00-13:05 UTC)

    class Clock(datetime):
        @classmethod
        def now(cls, tz=None):
            return clock[0].astimezone(tz) if tz else clock[0]

    def sleep(s):
        clock[0] += timedelta(seconds=s)

    calls = []

    class LaggyData(FakeData):
        # TopstepX publishes the closed bar 1.2s after the close.
        def get_historical_bars(self, start, end, minutes):
            calls.append(clock[0])
            return [b for b in self.bars if start <= b.time < end
                    and b.time + timedelta(minutes=minutes, seconds=1.2) <= clock[0]]

    bars = [Bar(datetime(2026, 10, 9, 12, 55, tzinfo=timezone.utc), 1, 1, 1, 1, 1),
            Bar(datetime(2026, 10, 9, 13, 0, tzinfo=timezone.utc), 1, 1, 1, 1, 1)]
    monkeypatch.setattr(engine_mod, "datetime", Clock)
    eng = Engine(cfg, LaggyData(bars), SimBroker(MNQ, cfg.sim), "paper")
    monkeypatch.setattr(eng, "_sleep", sleep)
    eng.last_bar_time = bars[0].time
    eng._wait_for_bar_close(5)
    assert clock[0] == datetime(2026, 10, 9, 13, 5, tzinfo=timezone.utc)
    assert not calls                                  # no bar requests while waiting
    eng._fetch_closed_bar(5)
    assert eng.last_bar_time == bars[1].time
    assert (clock[0] - datetime(2026, 10, 9, 13, 5, tzinfo=timezone.utc)).total_seconds() <= 1.5
    assert len(calls) <= 4


def test_fixed_dollar_risk(cfg):
    s = ORBStrategy(cfg, MNQ)
    cfg.risk.risk_mode, cfg.risk.risk_dollars = "dollars", 300
    assert s.qty_for_risk(30.0, 123456) == 5          # $300 / (30 pts x $2)
    cfg.risk.max_contracts = 3
    assert s.qty_for_risk(30.0, 123456) == 3


def test_daily_loss_limit_cuts_size_then_blocks(cfg):
    only(cfg, "s3")
    cfg.safety.max_daily_loss = 1000
    s = ORBStrategy(cfg, MNQ)
    # 21-pt stop + 1 tick = $42.50 per contract. Down $800 -> $200 room -> 4 contracts (not 11).
    sig = None
    for b in S3_DAY[:3]:
        sig = s.on_bar(b, 50000, False, day_pnl=-800) or sig
    assert sig and sig.contracts == 4
    s2 = ORBStrategy(cfg, MNQ)
    for b in S3_DAY[:3]:
        assert s2.on_bar(b, 50000, False, day_pnl=-990) is None   # not even 1 contract fits


def test_session_switched_on_mid_session_uses_full_range(cfg):
    s3 = only(cfg, "s3")
    s3.enabled = False
    s = ORBStrategy(cfg, MNQ)
    s.on_bar(S3_DAY[0], 50000, False)
    s.on_bar(S3_DAY[1], 50000, False)                 # range bar seen while switched off
    s3.enabled = True                                 # switched on from the app
    sig = s.on_bar(S3_DAY[2], 50000, False)
    assert sig and sig.side is Side.BUY and sig.stop_price == 20004.0   # candle SL from the full range


def test_save_setting_keeps_comments(tmp_path):
    from orb_bot.config import save_setting
    p = tmp_path / "c.toml"
    p.write_text((ROOT / "config.example.toml").read_text())
    save_setting(p, "sessions.s2", "enabled", False)
    save_setting(p, "risk", "risk_mode", "dollars")
    save_setting(p, "safety", "max_daily_loss", 1000)
    save_setting(p, "sessions.s1", "start", datetime.strptime("10:30", "%H:%M").time())
    c = load_config(p)
    assert not session(c, "s2").enabled and session(c, "s3").enabled
    assert c.risk.risk_mode == "dollars" and c.safety.max_daily_loss == 1000
    assert session(c, "s1").start.strftime("%H:%M") == "10:30"
    assert "# OR start" in p.read_text()


def test_app_window_live_edits_save_to_config(tmp_path, monkeypatch):
    pytest.importorskip("PySide6.QtWidgets", exc_type=ImportError)
    monkeypatch.setenv("QT_QPA_PLATFORM", "offscreen")
    from PySide6.QtCore import Qt
    from PySide6.QtWidgets import QApplication
    from orb_bot.gui import MainWindow
    (tmp_path / "config.toml").write_text((ROOT / "config.example.toml").read_text())
    app = QApplication.instance() or QApplication([])
    w = MainWindow(tmp_path)
    w.main.sessions.item(1, 0).setCheckState(Qt.Unchecked)            # switch S2 off
    w.main.risk_mode.setCurrentIndex(1)                                # fixed $
    w.main.risk_amount.setValue(300); w.main.daily_loss.setValue(800); w.main._risk_changed()
    assert not session(w.cfg, "s2").enabled and w.cfg.risk.risk_dollars == 300
    c = load_config(tmp_path / "config.toml")
    assert not session(c, "s2").enabled and session(c, "s1").enabled
    assert c.risk.risk_mode == "dollars" and c.risk.risk_dollars == 300 and c.safety.max_daily_loss == 800
    w.close()


def test_s3_follows_new_york_time_after_daylight_saving_ends(cfg):
    only(cfg, "s3")
    assert session(cfg, "s3").timezone == "America/New_York"
    # 3 Nov: New York is on EST, so 09:15 NY = 00:15 Brisbane (an hour later than in October).
    later = [Bar(b.time.replace(year=2026, month=11, day=b.time.day - 3) + timedelta(hours=1), b.open, b.high,
                 b.low, b.close, 1) for b in S3_DAY]
    trades, _ = replay(cfg, later)
    assert [t.entry_time.astimezone(BNE).strftime("%d %H:%M") for t in trades] == ["04 00:30", "04 01:00"]
    # On Brisbane time the same bars would start the range an hour early and miss the setup.
    session(cfg, "s3").timezone, session(cfg, "s3").start = "", datetime.strptime("23:15", "%H:%M").time()
    trades, _ = replay(cfg, later, "t2.csv")
    assert [t.entry_time.astimezone(BNE).strftime("%H:%M") for t in trades] != ["00:30", "01:00"]


def test_settings_time_zone_switch_keeps_the_same_moment(tmp_path, monkeypatch):
    pytest.importorskip("PySide6.QtWidgets", exc_type=ImportError)
    monkeypatch.setenv("QT_QPA_PLATFORM", "offscreen")
    from PySide6.QtWidgets import QApplication, QComboBox, QTimeEdit
    from orb_bot.gui import MainWindow
    (tmp_path / "config.toml").write_text((ROOT / "config.example.toml").read_text())
    app = QApplication.instance() or QApplication([])
    w = MainWindow(tmp_path)
    ed = {key: wd for sec, key, wd in w.main.editors if sec == "sessions.s3"}
    assert isinstance(ed["timezone"], QComboBox) and isinstance(ed["start"], QTimeEdit)
    ny = datetime.combine(datetime.now(ZoneInfo("America/New_York")).date(),
                          datetime.strptime("09:15", "%H:%M").time(), ZoneInfo("America/New_York"))
    ed["timezone"].setCurrentIndex(ed["timezone"].findData(""))      # switch to Brisbane
    assert ed["start"].time().toString("HH:mm") == ny.astimezone(BNE).strftime("%H:%M")
    w.main.save_settings()
    s3 = session(load_config(tmp_path / "config.toml"), "s3")
    assert s3.timezone == "" and s3.start.strftime("%H:%M") == ny.astimezone(BNE).strftime("%H:%M")
    w.close()


def test_combine_account_only_after_confirming_it(tmp_path):
    from orb_bot.tools import may_trade, select_account
    p = tmp_path / "config.toml"
    p.write_text((ROOT / "config.example.toml").read_text())
    c = load_config(p)
    prac, combine = Account(11, "PRAC-V2-1", 150000.0, True), Account(22, "50KTC-V2-1", 50000.0, True)
    assert may_trade(c, prac) and not may_trade(c, combine)
    select_account(c, None, 22, "50KTC-V2-1", confirmed=True)
    c = load_config(p)
    assert (c.broker.account_id, c.broker.account_name, c.broker.confirmed_accounts) == (22, "50KTC-V2-1", [22])
    assert may_trade(c, combine) and may_trade(c, prac)


class AutoOCO(FakeLive):
    """Places each entry and fills it at once, with its own stop and target (TopstepX Auto OCO)."""
    def place_bracket_order(self, side, size, stop_ticks, target_ticks, tag=None):
        self.placed.append((side, size, stop_ticks, target_ticks, tag))
        self._id += 10
        oid = self._id
        price = 20025.0
        self.fill_entry(oid, side, size, price, price - stop_ticks * 0.25, price + target_ticks * 0.25)
        return OrderResult(True, oid)


def test_two_bots_same_contract_same_size_each_keep_their_own_legs(cfg, tmp_path):
    from orb_bot import engine as engine_mod
    p2 = tmp_path / "m15.toml"
    p2.write_text((ROOT / "config.example.toml").read_text().replace('name = "ORB M5 O.G"', 'name = "ORB M15"').replace('id = "orbm5"', ''))
    cfg2 = load_config(p2)
    cfg2.log_dir, cfg2.strategy.bar_minutes = tmp_path / "logs", 15
    for c in (cfg, cfg2):
        c.safety.max_daily_loss, c.sim.slippage_ticks = 0, 0
        for s in c.sessions:
            s.enabled, s.min_close_pct_first, s.body_filter = s.name == "s3", 10, False
        c.risk.risk_mode, c.risk.risk_dollars = "dollars", 4 * 21 * 2
    live = AutoOCO(S3_DAY)
    a, b = Engine(cfg, live, live, "practice"), Engine(cfg2, live, live, "practice")
    engine_mod._LIVE.update({a, b})
    for bar in S3_DAY[:3]:
        a.process_bar(bar)
        b.process_bar(bar)
    assert [p[4] for p in live.placed] == ["orbm5-s3-202610062330", "orbm15-s3-202610062330"]
    assert a.trade.size == b.trade.size == 4
    assert set(a.trade.leg_ids).isdisjoint(b.trade.leg_ids) and len(a.trade.leg_ids) == len(b.trade.leg_ids) == 2
    tp_a = next(i for i in a.trade.leg_ids if any(o.id == i and o.limit_price for o in live.orders))
    stop_a = next(i for i in a.trade.leg_ids if i != tp_a)
    live.fill_leg(tp_a, stop_a, 20031.25)                       # M5's target fills
    a._sync_position()
    b._sync_position()
    assert a.trade is None and a.closed_trades[-1].reason == "target"
    assert b.trade is not None and live.positions[0].size == 4   # M15's 4 keep running
    assert all(i in {o.id for o in live.orders} for i in b.trade.leg_ids)


def test_app_add_bot_rename_and_remove(tmp_path, monkeypatch):
    pytest.importorskip("PySide6.QtWidgets", exc_type=ImportError)
    monkeypatch.setenv("QT_QPA_PLATFORM", "offscreen")
    from PySide6.QtWidgets import QApplication, QMessageBox
    from orb_bot import gui
    (tmp_path / "config.toml").write_text((ROOT / "config.example.toml").read_text())
    app = QApplication.instance() or QApplication([])
    shown = []
    monkeypatch.setattr(QMessageBox, "information", staticmethod(lambda p, t, m: shown.append(m)))
    monkeypatch.setattr(QMessageBox, "warning", staticmethod(lambda p, t, m: shown.append(m)))
    monkeypatch.setattr(QMessageBox, "question", staticmethod(lambda *a, **k: QMessageBox.Yes))
    monkeypatch.setattr(gui.AddBotDialog, "exec", lambda self: 1)       # defaults: copy ORB M5, 1 hour, "ORB H1"
    w = gui.MainWindow(tmp_path)
    assert [b.name for b in w.bots] == ["ORB M5 O.G"]
    w.add_bot()
    assert [b.name for b in w.bots] == ["ORB M5 O.G", "ORB H1"]
    h1 = load_config(tmp_path / "bots" / "orbh1.toml")
    assert h1.bot_name == "ORB H1" and h1.strategy.bar_minutes == 60
    assert "S3 range" in shown[-1] and "never build a range" in shown[-1]   # 09:15 / 30 min don't fit 1h bars
    assert w.bots[1].cfg.broker.account_id == w.bots[0].cfg.broker.account_id  # same account as the tab set
    assert w.bots[1].title.text() == "ORB H1" and w.bots[1].sessions.item(0, 1).text() == "S1"
    w.add_bot()                                                               # same name again is refused
    assert len(w.bots) == 2 and "already uses that name" in shown[-1]
    # reopening the app loads both bots
    w2 = gui.MainWindow(tmp_path)
    assert [b.name for b in w2.bots] == ["ORB M5 O.G", "ORB H1"]
    w2.bots[1].remove()
    assert [b.name for b in w2.bots] == ["ORB M5 O.G"] and not (tmp_path / "bots" / "orbh1.toml").exists()
    w.close(); w2.close()


def test_app_bots_keep_running_on_one_account_while_viewing_another(tmp_path, monkeypatch):
    pytest.importorskip("PySide6.QtWidgets", exc_type=ImportError)
    monkeypatch.setenv("QT_QPA_PLATFORM", "offscreen")
    import threading
    from PySide6.QtWidgets import QApplication, QMessageBox
    from orb_bot import gui
    p = tmp_path / "config.toml"
    p.write_text((ROOT / "config.example.toml").read_text())
    save_setting(p, "broker", "account_id", 11)
    save_setting(p, "broker", "account_name", "PRAC-V2-1")
    save_setting(p, "broker", "bracket_tick_mode", "signed")
    app = QApplication.instance() or QApplication([])
    asked = []
    monkeypatch.setattr(QMessageBox, "question", staticmethod(lambda p_, t, m: asked.append(m) or QMessageBox.Yes))
    monkeypatch.setattr(QMessageBox, "warning", staticmethod(lambda *a: None))
    monkeypatch.setattr(QMessageBox, "information", staticmethod(lambda *a: None))
    release = threading.Event()
    ran = []
    monkeypatch.setattr(gui.BotPanel, "_run", lambda self, mode, creds: (ran.append(
        (self.label, mode, self.cfg.broker.account_id, self.cfg.risk.risk_percent)), release.wait(10)))
    w = gui.MainWindow(tmp_path)
    monkeypatch.setattr(w, "_credentials", lambda: ("u", "k"))
    prac = w.main
    prac.mode.setCurrentIndex(1)
    prac.start()
    wait = lambda n: [__import__("time").sleep(0.02) for _ in range(100) if len(ran) < n]  # noqa: E731
    wait(1)
    assert prac.running and ran[-1] == ("ORB M5 O.G @ PRAC…1", "practice", 11, 1.0)

    w.view_account(22, "50KTC-V2-1")                            # look at the Combine: the Practice bot keeps going
    assert prac.running and w.main is not prac and w.main.account_id == 22
    assert w.main.cfg.broker.account_id == 22 and prac.cfg.broker.account_id == 11
    combine = w.main
    combine.risk_amount.setValue(0.5); combine._risk_changed()    # its own risk, saved for that account only
    assert prac.cfg.risk.risk_percent == 1.0
    combine.mode.setCurrentIndex(1)
    combine.start()                                             # not Practice: asks once, then remembers it
    assert "isn't a Practice account" in asked[-1] and combine.running
    wait(2)
    assert ran[-1] == ("ORB M5 O.G @ 50KTC…1", "practice", 22, 0.5)
    assert load_config(p).broker.confirmed_accounts == [22]
    w.refresh()
    assert "2 bots running on 2 accounts" in w.status.text()
    assert not combine.save_btn.isEnabled()                     # strategy settings locked while it runs anywhere

    w.view_account(11, "PRAC-V2-1")                             # back again: same running bot, untouched
    assert w.main is prac and prac.running
    reopened = gui.MainWindow(tmp_path)
    reopened.view_account(22, "50KTC-V2-1")
    assert reopened.main.cfg.risk.risk_percent == 0.5
    reopened.view_account(11, "PRAC-V2-1")
    assert reopened.main.cfg.risk.risk_percent == 1.0
    release.set()
    prac.worker.join(5); combine.worker.join(5)
    w.close(); reopened.close()


def test_bots_share_one_projectx_login():
    a, b = make_px("signed"), make_px("signed")
    a.connect(); b.connect()
    logins = [c for c in a.session.calls + b.session.calls if c[0] == "/api/Auth/loginKey"]
    assert len(logins) == 1                                     # the second bot reuses the first bot's session
    assert b.session.auth == "Bearer T"


def _trade_msg(*trades):
    return {"type": 1, "target": "GatewayTrade", "arguments": [MNQ.id, [
        {"symbolId": "F.US.MNQ", "price": p, "timestamp": ts, "type": 0, "volume": v} for ts, p, v in trades]]}


def test_trade_stream_builds_bars_only_when_it_saw_the_whole_bar():
    from orb_bot.broker.stream import TradeStream
    import time as _t
    s = TradeStream(make_px("signed"), MNQ.id)
    s.connected_since = datetime(2026, 10, 9, 13, 39, 30, tzinfo=timezone.utc)
    s.last_message = _t.monotonic()
    s.handle(_trade_msg(("2026-10-09T13:40:00.1234567Z", 20000.0, 1), ("2026-10-09T13:41:10Z", 20010.25, 2),
                        ("2026-10-09T13:43:59.9Z", 19990.5, 1)))
    s.handle({"type": 1, "target": "GatewayTrade", "arguments": [MNQ.id, {"price": 20004.75, "timestamp":
              "2026-10-09T13:44:59.950Z", "volume": 3}]})                  # a single trade, not a list
    s.handle(_trade_msg(("2026-10-09T13:45:00.01Z", 21000.0, 1)))         # next bar
    t = datetime(2026, 10, 9, 13, 40, tzinfo=timezone.utc)
    b = s.bar(t, 5)
    assert (b.open, b.high, b.low, b.close, b.volume) == (20000.0, 20010.25, 19990.5, 20004.75, 7)
    s.connected_since = datetime(2026, 10, 9, 13, 41, tzinfo=timezone.utc)   # reconnected mid-bar
    assert s.bar(t, 5) is None
    s.connected_since = None
    assert s.bar(t, 5) is None


class FakeStream:
    def __init__(self, bar): self._bar, self.healthy = bar, True
    def bar(self, open_time, minutes): return self._bar if self._bar and self._bar.time == open_time else None


def test_fast_bar_acts_at_close_then_checks_against_topstep(cfg, monkeypatch):
    from orb_bot import engine as engine_mod
    only(cfg, "s3")
    live = FakeLive(S3_DAY)
    eng = Engine(cfg, live, live, "practice")
    for b in S3_DAY[:2]:
        eng.process_bar(b, trading=False)
    signal_bar = S3_DAY[2]                                             # 23:30 breakout bar
    eng.stream = FakeStream(Bar(signal_bar.time, signal_bar.open, signal_bar.high, signal_bar.low,
                                signal_bar.close + 0.25, 1))          # live close one tick off TopstepX's
    monkeypatch.setattr(engine_mod, "FAST_GRACE_SECONDS", 0)
    assert eng._fast_bar(signal_bar.time, 15)
    assert len(live.placed) == 1 and eng.fast_stats["live"] == 1      # traded on the live bar
    monkeypatch.setattr(engine_mod, "FAST_CHECK_AFTER", timedelta(0))
    eng._check_fast_bars()
    assert eng.fast_stats["differed"] == 1 and not eng._fast_pending
    eng.stream = FakeStream(None)                                       # stream missed the next bar
    assert not eng._fast_bar(S3_DAY[3].time, 15) and eng.fast_stats["fallback"] == 1


# --- TradingView alerts bots ------------------------------------------------------------------------------
def _alerts_cfg(tmp_path, **alerts):
    p = tmp_path / "tv.toml"
    body = "\n".join(f"{k} = {json.dumps(v)}" for k, v in alerts.items())
    p.write_text(f'name = "TV NQ"\ntype = "alerts"\n\n[alerts]\nsecret = "s3cret"\nsymbol = "MNQ"\n{body}\n'
                 "[risk]\nmax_contracts = 10\n\n[safety]\nmax_daily_loss = 0\n")
    c = load_config(p)
    c.log_dir = tmp_path / "logs"
    return c


def _tv(**kw):
    from orb_bot.alerts import parse_alert
    return parse_alert(json.dumps({"bot": "tvnq", "key": "s3cret", **kw}))


def test_alert_messages_are_read_in_every_form():
    from orb_bot.alerts import AlertError, parse_alert, same_market
    a = _tv(action="sell", contracts="2", position="short", position_size="2", price="31020.5", ticker="MNQ1!")
    assert (a.action, a.contracts, a.position, a.position_size, a.price) == ("sell", 2, "short", 2, 31020.5)
    pmt = parse_alert('{"bot": "tvnq", "key": "k", "data": "buy", "quantity": "3", "symbol": "MNQZ2025", '
                      '"sl": "30990", "tp": "31050"}')
    assert (pmt.action, pmt.contracts, pmt.stop, pmt.target) == ("buy", 3, 30990, 31050)
    plotted = parse_alert('{"bot": "tvnq", "key": "k", "action": "buy", "stop": "NaN", "target": "31050.25"}')
    assert plotted.stop is None and plotted.target == 31050.25            # no stop plotted yet: use the setting
    unfilled = parse_alert('{"bot": "tvnq", "key": "k", "action": "buy", "stop": "{{plot("Active Stop")}}"}')
    assert unfilled.action == "buy" and unfilled.stop is None
    plain = parse_alert("exit", "tvnq", "k")
    assert (plain.bot, plain.key, plain.action) == ("tvnq", "k", "exit")
    for bad in ('{"bot": "x", "action": "hold"}', "{not json", "maybe"):
        with pytest.raises(AlertError):
            parse_alert(bad)
    assert same_market("CME_MINI:NQZ2025", "MNQ") and same_market("MNQ1!", "MNQ") and not same_market("MGC1!", "MNQ")


def test_alerts_bot_puts_stop_and_target_at_topstep_and_leaves_the_exit_to_them(tmp_path):
    from orb_bot.alerts import AlertEngine
    cfg = _alerts_cfg(tmp_path, stop_ticks=80, target_rr=2.0)
    live = AutoOCO([])
    eng = AlertEngine(cfg, live, live, "practice")
    assert eng.handle(_tv(action="buy", contracts=2, position="long", position_size=2, price=20025)).startswith("bought 2 · stop")
    side, size, stop_ticks, target_ticks, tag = live.placed[-1]
    assert (side, size, stop_ticks, target_ticks) == (Side.BUY, 2, 80, 160) and tag.startswith("tvnq-tv-")
    eng._sync_position()
    tp = next(i for i in eng.trade.leg_ids if any(o.id == i and o.limit_price for o in live.orders))
    live.fill_leg(tp, next(i for i in eng.trade.leg_ids if i != tp), 20065.0)   # Topstep's target fills
    eng._sync_position()
    assert eng.trade is None and eng.closed_trades[-1].reason == "target"
    # the script's own exit alert arrives later and changes nothing
    assert eng.handle(_tv(action="sell", contracts=2, position="flat", position_size=0)).startswith("already flat")
    assert live.closed_sizes == [] and len(live.placed) == 1


def test_alerts_bot_uses_the_scripts_stop_and_target_prices_and_reverses(tmp_path):
    from orb_bot.alerts import AlertEngine
    cfg = _alerts_cfg(tmp_path, sizing="fixed", contracts=3, exit_alerts="close")
    live = AutoOCO([])
    def close_size(side, size):
        live.closed_sizes.append((side, size))
        live.orders = [o for o in live.orders if o.size != size]
        net = sum(p.size * p.side.sign for p in live.positions) - size * side.sign
        live.positions = [Position(MNQ.id, Side.BUY if net > 0 else Side.SELL, abs(net), 0)] if net else []
    live.close_size = close_size
    eng = AlertEngine(cfg, live, live, "practice")
    eng.handle(_tv(action="buy", price=20000, stop=19990, target=20030))          # indicator-style "buy"
    assert live.placed[-1][:4] == (Side.BUY, 3, 40, 120)
    eng._sync_position()
    assert eng.handle(_tv(action="sell", price=20010)).startswith("closed 3, sold 3 · stop")      # reversal
    assert live.closed_sizes == [(Side.BUY, 3)] and live.placed[-1][:2] == (Side.SELL, 3)
    eng._sync_position()
    assert eng.handle(_tv(action="exit")) == "closed 3"                            # close if still open
    assert eng.handle(_tv(action="buy", ticker="MGC1!", price=2400)).startswith("ignored")


def test_alerts_bot_follows_tradingview_sizes_and_the_daily_loss_limit(tmp_path):
    from orb_bot.alerts import AlertEngine
    cfg = _alerts_cfg(tmp_path, multiplier=2.0, stop_ticks=100, exit_alerts="close")
    cfg.safety.max_daily_loss = 500
    live = AutoOCO([])
    eng = AlertEngine(cfg, live, live, "practice")
    eng.refresh_balance(); eng._roll_day(datetime.now(timezone.utc))
    # 2 x 2 = 4 contracts wanted, but a 100-tick stop costs $50 each: 4 x 50 = $200 fits in $500
    assert eng.handle(_tv(action="sell", contracts=2, price=20000)).startswith("sold 4 ")
    eng._sync_position()
    eng.handle(_tv(action="buy", contracts=2, price=20000))                       # strategy order: back to flat
    assert eng.tv_pos == 0 and eng.trade is None
    eng.day_start_balance = 50000 + 400                                             # down $400 today
    assert eng.handle(_tv(action="buy", contracts=2, price=20000)).startswith("bought 2 ")   # cut so a stop stays inside


def test_alerts_bot_works_out_a_missing_stop_from_the_scripts_risk(tmp_path):
    from orb_bot.alerts import AlertEngine
    cfg = _alerts_cfg(tmp_path, script_risk=500.0, target_rr=0.3)
    live = AutoOCO([])
    eng = AlertEngine(cfg, live, live, "practice")
    # no plotted stop: the script's stop is between $500/6 and $500/5 a contract; the middle, $91.67, is 183 ticks,
    # target 0.3 x 183 = 55
    res = eng.handle(_tv(action="buy", contracts=5, position="long", position_size=5, price=20000, stop="NaN"))
    assert live.placed[-1][:4] == (Side.BUY, 5, 183, 55) and "script risk" in res
    eng._sync_position()
    eng.handle(_tv(action="sell", contracts=5, position="flat", position_size=0))
    # a plotted stop still wins
    live2 = AutoOCO([])
    (tmp_path / "b").mkdir()
    eng2 = AlertEngine(_alerts_cfg(tmp_path / "b", script_risk=500.0, target_rr=0.3), live2, live2, "practice")
    assert "from the alert" in eng2.handle(_tv(action="sell", contracts=5, position="short", position_size=5,
                                                price=20000, stop=20010))
    assert live2.placed[-1][:4] == (Side.SELL, 5, 40, 12)


def test_alerts_bot_paper_mode_fills_at_alert_prices(tmp_path):
    from orb_bot.alerts import AlertEngine
    cfg = _alerts_cfg(tmp_path, stop_ticks=40, target_rr=1.0)
    cfg.sim.slippage_ticks = 0
    data = FakeData([])
    data.get_last_price = lambda: None
    sim = SimBroker(MNQ, cfg.sim, starting_balance=150000)
    eng = AlertEngine(cfg, data, sim, "paper")
    eng.handle(_tv(action="buy", contracts=1, price=20000))
    assert sim.open and (sim.open.stop_price, sim.open.target_price) == (19990, 20010)
    data.get_last_price = lambda: 20011.0
    eng._housekeeping()                                                             # price passed the target
    assert eng.trade is None and eng.closed_trades[-1].pnl == 20.0 and sim.balance == 150020
    import csv
    rows = list(csv.DictReader((cfg.log_dir / "fills.csv").open()))               # fill quality record
    assert len(rows) == 1 and rows[0]["signal_price"] == "20000.0" and rows[0]["entry_slip_ticks"] == "0"
    assert rows[0]["exit_reason"] == "target" and rows[0]["exit_slip_ticks"] == "0" and rows[0]["mode"] == "paper"


def test_webhook_needs_the_right_key_and_a_running_bot(tmp_path):
    from orb_bot import webhook
    from orb_bot.alerts import AlertEngine
    cfg = _alerts_cfg(tmp_path)
    live = AutoOCO([])
    eng = AlertEngine(cfg, live, live, "practice")
    msg = json.dumps({"bot": "tvnq", "key": "s3cret", "action": "buy", "price": 20000})
    assert webhook.dispatch(msg)[0] == 404                                          # not running
    webhook.register(eng)
    try:
        assert webhook.dispatch(msg.replace("s3cret", "guess"))[0] == 403
        assert webhook.dispatch(msg) == (200, "ok: 1 account(s)")
        assert webhook.dispatch(msg) == (200, "duplicate ignored")
        assert webhook.dispatch("buy", "/tv/tvnq/s3cret?x=1")[0] == 200            # plain text, key in the URL
        assert eng.alerts.qsize() == 2
    finally:
        webhook.unregister(eng)
        webhook._recent.clear()


def test_webhook_server_answers_over_http(tmp_path):
    import urllib.request
    from orb_bot.webhook import WebhookServer
    srv = WebhookServer(0, "james.ngrok-free.app", start_ngrok=False)
    srv.start()
    try:
        port = srv.httpd.server_address[1]
        assert srv.address == "https://james.ngrok-free.app/tv"
        req = urllib.request.Request(f"http://127.0.0.1:{port}/tv", data=b'{"bot":"nobody","action":"buy"}')
        with pytest.raises(urllib.error.HTTPError) as e:
            urllib.request.urlopen(req, timeout=5)
        assert e.value.code == 404
    finally:
        srv.stop()


def test_app_adds_a_tradingview_alerts_bot(tmp_path, monkeypatch):
    pytest.importorskip("PySide6.QtWidgets", exc_type=ImportError)
    monkeypatch.setenv("QT_QPA_PLATFORM", "offscreen")
    from PySide6.QtWidgets import QApplication, QMessageBox
    from orb_bot import gui
    (tmp_path / "config.toml").write_text((ROOT / "config.example.toml").read_text())
    app = QApplication.instance() or QApplication([])
    shown = []
    monkeypatch.setattr(QMessageBox, "information", staticmethod(lambda p, t, m: shown.append(m)))
    monkeypatch.setattr(QMessageBox, "warning", staticmethod(lambda p, t, m: shown.append(m)))
    def pick_alerts(self):
        self.kind.setCurrentIndex(1)
        return 1
    monkeypatch.setattr(gui.AddBotDialog, "exec", pick_alerts)
    w = gui.MainWindow(tmp_path)
    w.add_bot()
    tv = w.bots[-1]
    assert tv.name == "TV alerts" and tv.is_alerts and tv.cfg.alerts.secret
    assert f'"key": "{tv.cfg.alerts.secret}"' in tv.alert_message() and '"bot": "tvalerts"' in tv.alert_message()
    tv.risk_mode.setCurrentIndex(1); tv.risk_amount.setValue(2); tv._risk_changed()  # fixed 2 contracts
    assert load_config(tmp_path / "bots" / "tvalerts.toml").alerts.contracts == 2
    w.set_webhook("https://james.ngrok-free.app/tv", 8799, False)
    assert tv.al_url.text().startswith("https://james.ngrok-free.app/tv\n")
    assert tv.al_url.text().endswith(f"https://james.ngrok-free.app/tv/tvalerts/{tv.cfg.alerts.secret}")
    assert load_config(tmp_path / "config.toml").webhook.public_url == "james.ngrok-free.app"
    # reminder before the TradingView alert expires
    today = datetime.now(tv.cfg.timezone).date()
    assert tv.expiry_status() is None                                               # not set
    tv.cfg.alerts.alert_expires = (today + timedelta(days=30)).strftime("%d/%m/%Y")
    assert tv.expiry_status()[1] == "ok" and "30 days" in tv.expiry_status()[0]
    tv.cfg.alerts.alert_expires = (today + timedelta(days=2)).isoformat()
    assert tv.expiry_status()[1] == "warn"
    tv.cfg.alerts.alert_expires = (today - timedelta(days=1)).isoformat()
    assert tv.expiry_status()[1] == "error" and "expired" in tv.expiry_status()[0]
    monkeypatch.setattr(gui, "notify", lambda t, m: shown.append(m))
    w._expiry_reminders(); w._expiry_reminders()                                     # once a day per bot
    assert sum("expired" in m for m in shown) == 1
    w.close()


def test_webhook_restarts_a_dead_ngrok_and_checks_it_can_be_reached(tmp_path, monkeypatch):
    from orb_bot import webhook
    fake = tmp_path / "ngrok"
    fake.write_text("#!/bin/sh\necho 'lvl=info msg=\"started tunnel\"'\n")  # starts, then dies straight away
    fake.chmod(0o755)
    monkeypatch.setattr(webhook, "find_ngrok", lambda: str(fake))
    monkeypatch.setattr(webhook, "NGROK_RETRY_SECONDS", 0.0)
    answers = []
    monkeypatch.setattr(webhook.WebhookServer, "self_test",
                        lambda self, quiet=False: (answers.append(quiet), setattr(self, "reachable", True))[1] or True)
    w = webhook.WebhookServer(0, "example.ngrok-free.dev", True)
    w.start()
    try:
        first = w.ngrok
        first.wait(5)
        w._last_ngrok_start -= 1
        w.tick()                                   # dead tunnel: started again
        assert w.ngrok is not first
        w._next_test = 0
        w.ngrok.wait(5)
        w.start_ngrok = False                      # now just the periodic check
        w.tick()
        for _ in range(50):
            if answers:
                break
            time.sleep(0.05)
        assert w.reachable is True
    finally:
        w.stop()


# --- performance ---------------------------------------------------------------------------------------
def _f(oid, side, size, price, pnl, minute, fees=0.37):
    return Fill(oid, MNQ.id, side, size, price, pnl, fees,
                datetime(2026, 10, 9, 23, 0, tzinfo=timezone.utc) + timedelta(minutes=minute))


def test_performance_groups_fills_into_round_trips_like_topstepx():
    from orb_bot import performance as pf
    fills = [
        _f(1, Side.BUY, 4, 20000.0, None, 0), _f(2, Side.SELL, 2, 20010.0, 40.0, 5),   # long 4, scale out
        _f(3, Side.SELL, 2, 20005.0, 20.0, 9),                                          # flat: trade 1
        _f(4, Side.SELL, 3, 20000.0, None, 20), _f(5, Side.BUY, 5, 20004.0, -24.0, 30),  # short 3, flip long 2
        _f(6, Side.SELL, 2, 20010.0, 24.0, 40),                                         # flat: trade 3
    ]
    trips = pf.round_trips(fills, "PRAC")
    assert [(t.side, t.size) for t in trips] == [(Side.BUY, 4), (Side.SELL, 3), (Side.BUY, 2)]
    t1, t2, t3 = trips
    assert t1.entry_price == 20000.0 and t1.exit_price == 20007.5 and t1.pnl == 60.0
    assert t1.duration == timedelta(minutes=9) and t1.order_ids == {1, 2, 3}
    assert t2.pnl == -24.0 and t2.exit_price == 20004.0 and round(t2.fees, 3) == round(0.37 + 0.37 * 3 / 5, 3)
    assert t3.entry_price == 20004.0 and t3.pnl == 24.0
    assert round(sum(t.fees for t in trips), 6) == round(0.37 * 6, 6)                # every fee counted once


def test_performance_labels_bots_and_works_out_the_stats(tmp_path):
    from orb_bot import performance as pf
    fills = [_f(11, Side.BUY, 2, 20000.0, None, 0, 0), _f(12, Side.SELL, 2, 20020.0, 80.0, 10, 0),
             _f(21, Side.SELL, 1, 20030.0, None, 60 * 24, 0), _f(22, Side.BUY, 1, 20050.0, -40.0, 60 * 24 + 3, 0),
             _f(31, Side.BUY, 1, 20000.0, None, 60 * 48, 0), _f(32, Side.SELL, 1, 20015.0, 30.0, 60 * 48 + 1, 0)]
    trips = pf.round_trips(fills, "PRAC")
    rows = [{"bot": "ORB", "account": "PRAC", "mode": "practice", "entry_order_id": "11"},
            {"bot": "TV alerts", "account": "PRAC", "mode": "practice", "entry_order_id": "", "side": "sell",
             "size": "1", "entry_fill": "20030.0", "date": "2026-10-11"},           # older row: matched on price
            {"bot": "ORB", "account": "PRAC", "mode": "paper", "entry_order_id": "31"}]  # paper: never matches
    path = tmp_path / "fills.csv"
    import csv
    with path.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["bot", "account", "mode", "entry_order_id", "side", "size", "entry_fill",
                                          "date"])
        w.writeheader(); w.writerows(rows)
    pf.label_bots(trips, pf.read_bot_log(path), BNE)
    assert [t.bot for t in trips] == ["ORB", "TV alerts", pf.MANUAL]
    s = pf.summarise(trips, BNE)
    assert (s.trades, s.wins, s.losses, s.net) == (3, 2, 1, 70.0)
    assert s.profit_factor == 110 / 40 and s.win_loss_ratio == 55 / 40 and s.max_drawdown == -40.0
    assert s.best.bot == "ORB" and s.worst.bot == "TV alerts" and s.day_win_rate == 2 / 3
    assert round(s.best_day_share, 4) == round(80 / 70, 4) and [g.name for g in s.bots][0] == "ORB"
    assert s.curve[-1][1] == 70.0 and len(s.curve) == 3
    only_orb = pf.filter_trips(trips, BNE, bot="ORB")
    assert len(only_orb) == 1
    from datetime import date
    assert pf.period_range("Last week", date(2026, 10, 11)) == (date(2026, 9, 28), date(2026, 10, 4))
    assert pf.period_range("Last month", date(2026, 10, 11)) == (date(2026, 9, 1), date(2026, 9, 30))


def test_fills_csv_gains_the_entry_order_column_without_losing_old_rows(tmp_path):
    import csv
    from orb_bot.engine import _upgrade_csv
    path = tmp_path / "fills.csv"
    path.write_text("date,bot,pnl\n2026-10-09,ORB,12.5\n")
    _upgrade_csv(path, ["date", "bot", "pnl", "entry_order_id"])
    rows = list(csv.DictReader(path.open()))
    assert rows == [{"date": "2026-10-09", "bot": "ORB", "pnl": "12.5", "entry_order_id": ""}]


def test_performance_window_shows_an_accounts_trades(tmp_path, monkeypatch):
    pytest.importorskip("PySide6.QtWidgets", exc_type=ImportError)
    monkeypatch.setenv("QT_QPA_PLATFORM", "offscreen")
    from PySide6.QtWidgets import QApplication
    from orb_bot.perf_view import PerformanceWindow
    app = QApplication.instance() or QApplication([])
    now = datetime.now(timezone.utc).replace(microsecond=0) - timedelta(hours=1)
    fills = {1: [Fill(1, MNQ.id, Side.BUY, 2, 20000.0, None, 0.5, now),
                 Fill(2, MNQ.id, Side.SELL, 2, 20010.0, 40.0, 0.5, now + timedelta(minutes=4))],
             2: [Fill(3, MNQ.id, Side.SELL, 1, 20000.0, None, 0.0, now),
                 Fill(4, MNQ.id, Side.BUY, 1, 20005.0, -10.0, 0.0, now + timedelta(minutes=1))]}
    w = PerformanceWindow(lambda: [(1, "PRAC-A"), (2, "50KTC-B")], lambda a, since: fills[a],
                          lambda fn, cb: cb(fn(), None), tmp_path / "fills.csv", BNE, account_id=1)
    w.period.setCurrentText("Today"); w._period_changed()
    assert w.tiles["net"].value.text() == "$39.00" and w.tiles["win"].value.text() == "100.0%"
    assert w.trades_table.rowCount() == 1 and w.trades_table.item(0, 1).text() == "Manual / other"
    w.account.setCurrentIndex(w.account.findText("All accounts")); w.load()
    assert w.tiles["trades"].value.text() == "2" and w.tiles["net"].value.text() == "$29.00"
    assert w.by_bot.rowCount() == 1
    w.close()


# --- phone alerts (Telegram) ----------------------------------------------------------------------------
@pytest.fixture
def phone():
    from orb_bot import notify
    sent = []
    n = notify.Notifier("tok", "42", trades=True, problems=True, paper=True,
                        sender=lambda token, chat, text: sent.append(text))
    old = notify.current()
    notify.configure(n)
    yield n, sent
    notify.configure(old)


def test_phone_alerts_follow_the_switches_and_never_repeat_a_problem(phone):
    from orb_bot import notify
    n, sent = phone
    assert n.send("trade", "t1") and n.send("problem", "p1") and not n.send("problem", "p1")  # repeat held back
    n.paper = False
    assert not n.send("trade", "paper trade", mode="paper") and n.send("trade", "real", mode="practice")
    assert not n.send("trade", "replay", mode="replay")
    n.trades = False
    assert not n.send("trade", "off") and n.send("problem", "p2")
    n.flush()
    assert sent == ["t1", "p1", "real", "p2"]
    assert not notify.Notifier(None, "42").send("trade", "no token")
    logging_ = __import__("logging")
    h = notify.ProblemHandler()
    rec = logging_.LogRecord("orb_bot", logging_.ERROR, "", 0, "ORDER REJECTED: %s", ("no margin",), None)
    rec.bot = "[TV NQ] "
    h.emit(rec)
    n.flush()
    assert "[TV NQ]" in sent[-1] and "ORDER REJECTED: no margin" in sent[-1]


def test_phone_alerts_on_trade_open_and_close(tmp_path, phone):
    from orb_bot.alerts import AlertEngine
    n, sent = phone
    cfg = _alerts_cfg(tmp_path, stop_ticks=40, target_rr=1.0)
    cfg.sim.slippage_ticks = 0
    data = FakeData([])
    data.get_last_price = lambda: None
    sim = SimBroker(MNQ, cfg.sim, starting_balance=150000)
    eng = AlertEngine(cfg, data, sim, "paper")
    eng.handle(_tv(action="buy", contracts=1, price=20000))
    data.get_last_price = lambda: 20011.0
    eng._housekeeping()
    n.flush()
    opened = [m for m in sent if m.startswith("🟢 Long 1")]
    closed = [m for m in sent if m.startswith("✅ Closed (target)")]
    assert opened and "stop 19,990.00" in opened[0] and "TV NQ" in opened[0] and "PAPER" in opened[0]
    assert closed and "P&L +$20.00" in closed[0]


def test_telegram_commands_only_from_your_chat_and_flatten_needs_yes():
    from orb_bot import notify
    got = []
    msgs = [{"update_id": 7, "message": {"chat": {"id": 42}, "text": "/flatten"}}]          # sent before start
    fetches = []

    def fetch(offset, wait):
        fetches.append(offset)
        return msgs if offset == -1 else []
    lst = notify.CommandListener("tok", "42", got.append, fetch=fetch)
    lst._skip_old()
    assert lst.offset == 8 and got == []                                              # old /flatten ignored
    m = lambda text, chat=42: {"update_id": 9, "message": {"chat": {"id": chat}, "text": text}}
    assert lst.handle(m("/stop", chat=999)) is None and got == []                     # a stranger
    assert lst.handle(m("/status")) == "status"
    assert lst.handle(m("yes")) == "help"                                             # nothing to confirm
    assert lst.handle(m("/flatten")) == "confirm_flatten"
    assert lst.handle(m("YES")) == "flatten"
    assert lst.handle(m("/flatten")) == "confirm_flatten" and lst.handle(m("no")) == "help"
    assert lst.handle(m("yes")) == "help"                                             # "no" cancelled it
    assert lst.handle(m("/stop@my_orb_bot")) == "stop"
    assert got == ["status", "help", "confirm_flatten", "flatten", "confirm_flatten", "help", "help", "stop"]


def test_app_flatten_all_closes_only_bot_trades_and_stops_every_bot(tmp_path, monkeypatch, phone):
    pytest.importorskip("PySide6.QtWidgets", exc_type=ImportError)
    monkeypatch.setenv("QT_QPA_PLATFORM", "offscreen")
    from PySide6.QtWidgets import QApplication
    from orb_bot import gui
    (tmp_path / "config.toml").write_text((ROOT / "config.example.toml").read_text())
    app = QApplication.instance() or QApplication([])
    n, sent = phone
    w = gui.MainWindow(tmp_path)
    from orb_bot import notify
    notify.configure(n)                                                # the window set up its own (no token)
    calls = []

    class FakeEngine:
        mode = "practice"
        def __init__(self, trade): self.trade = trade
        def request_close(self): calls.append("close")
        def request_stop(self): calls.append("stop")
        def snapshot(self): return {"day_pnl": -120.5}
    trade = type("T", (), {"side": Side.BUY, "size": 3, "entry": 20000.0})()
    p = w.main
    p.engine = FakeEngine(trade)
    monkeypatch.setattr(type(p), "running", property(lambda self: self.engine is not None))
    w.remote("status")
    w.remote("confirm_flatten")
    w.remote("flatten")
    n.flush()
    assert calls == ["close", "stop"]
    assert "long 3 @ 20,000.00" in sent[0] and "account today -$120.50" in sent[0]
    assert "buy 3" in sent[1] and "YES" in sent[1] and "closing 1 trade" in sent[2]
    p.engine = None
    w.close()


def test_help_window_has_every_topic_and_search(tmp_path, monkeypatch):
    pytest.importorskip("PySide6.QtWidgets", exc_type=ImportError)
    monkeypatch.setenv("QT_QPA_PLATFORM", "offscreen")
    from PySide6.QtWidgets import QApplication
    from orb_bot import gui
    from orb_bot.help_content import TOPICS
    (tmp_path / "config.toml").write_text((ROOT / "config.example.toml").read_text())
    app = QApplication.instance() or QApplication([])
    w = gui.MainWindow(tmp_path)
    w.open_help("phone")
    h = w.help_window
    assert h.topics.count() == len(TOPICS) and "BotFather" in h.page.toPlainText()
    h.search.setText("ngrok")
    shown = [h.topics.item(i).text() for i in range(h.topics.count()) if not h.topics.item(i).isHidden()]
    assert "TradingView alerts" in shown and "Performance" not in shown
    h.close(); w.close()


def test_logo_icon_and_make_app(tmp_path, monkeypatch):
    pytest.importorskip("PySide6.QtWidgets", exc_type=ImportError)
    monkeypatch.setenv("QT_QPA_PLATFORM", "offscreen")
    from PySide6.QtWidgets import QApplication
    from orb_bot import cli, theme
    app = QApplication.instance() or QApplication([])
    theme.apply(app)
    img = theme.logo_pixmap(24).toImage()
    assert img.width() == 48 and img.pixelColor(24, 4).alpha() > 0  # the top handle is drawn
    assert not theme.app_icon().isNull()
    assert theme.WORDMARK_FONT in theme.QFontDatabase.families()
    assert "HELM" in theme.wordmark_html() and theme.ACCENT in theme.wordmark_html()
    # make-app puts the icon in the bundle and names it in Info.plist
    monkeypatch.setattr(cli.Path, "home", lambda: tmp_path)
    exe = tmp_path / "bin" / "orb-bot-gui"
    exe.parent.mkdir()
    exe.write_text("")
    monkeypatch.setattr(cli.sys, "executable", str(exe.parent / "python"))
    (tmp_path / "Applications" / "ORB Bot.app" / "Contents").mkdir(parents=True)  # from an older version
    cli.cmd_make_app(None, tmp_path)
    assert not (tmp_path / "Applications" / "ORB Bot.app").exists()
    bundle = tmp_path / "Applications" / f"{cli.APP_NAME}.app" / "Contents"
    assert (bundle / "Resources" / "AppIcon.icns").stat().st_size > 1000
    assert "<key>CFBundleIconFile</key><string>AppIcon</string>" in (bundle / "Info.plist").read_text()


def test_alert_keeps_the_stop_and_target_as_sent():
    from orb_bot.alerts import parse_alert
    a = parse_alert('{"bot": "tv", "action": "sell", "contracts": "6", "position": "short", "stop": "NaN", '
                    '"target": "31210.75"}')
    assert a.stop is None and a.target == 31210.75
    assert a.sent_levels == "stop='NaN' target='31210.75'"


def test_alerts_bot_finds_the_scripts_stop_at_the_range_or_the_breakout_candle(tmp_path, monkeypatch):
    from orb_bot import alerts
    from orb_bot.alerts import AlertEngine
    from orb_bot.models import Bar
    monkeypatch.setattr(alerts, "MAX_ALERT_AGE", 1e9)  # the alert is dated 12 Oct 15:40

    def run(range_high, candle_high, sub):
        d = tmp_path / sub
        d.mkdir()
        cfg = _alerts_cfg(d, script_risk=500.0, target_rr=0.3, range_start="15:00", range_minutes=15)
        tz = cfg.timezone
        day = datetime(2026, 10, 12, tzinfo=tz)
        bars = [Bar(day.replace(hour=15, minute=mi), 31230, 31240, 31220, 31230) for mi in range(0, 35, 5)]
        bars[1] = Bar(bars[1].time, 31230, range_high, 31220, 31235)            # 15:05, inside the range
        bars.append(Bar(day.replace(hour=15, minute=35), 31238, candle_high, 31221, 31222.25))  # breakout candle
        live = AutoOCO(bars)
        eng = AlertEngine(cfg, live, live, "practice")
        a = _tv(action="sell", contracts=6, position="short", position_size=6, price=31222.25, stop="null")
        a.received = day.replace(hour=15, minute=40, second=1)
        return eng.handle(a), live.placed[-1][:4]

    # 12 Oct: 6 contracts at $500 means a 35.7-41.7 pt stop. The range high (37.25 pts) fits, the candle doesn't.
    res, placed = run(31259.5, 31240, "a")
    assert "range high" in res and placed == (Side.SELL, 6, 149, 45)
    # a big breakout candle: its high fits and the range high is too far away
    res, placed = run(31300, 31261, "b")
    assert "breakout candle high" in res and placed[2] == 155
    # both fit: can't tell, so the middle of the window (38.7 pts = 155 ticks)
    res, placed = run(31259.5, 31261, "c")
    assert "script risk" in res and placed[2] == 155


def test_start_is_real_orders_and_test_run_is_paper_once(tmp_path, monkeypatch):
    pytest.importorskip("PySide6.QtWidgets", exc_type=ImportError)
    monkeypatch.setenv("QT_QPA_PLATFORM", "offscreen")
    from PySide6.QtWidgets import QApplication
    from orb_bot import gui
    (tmp_path / "config.toml").write_text((ROOT / "config.example.toml").read_text())
    app = QApplication.instance() or QApplication([])
    w = gui.MainWindow(tmp_path)
    p = w.main
    assert p.mode.currentIndex() == 1 and p.mode.isHidden()          # Start = real orders, no switch shown
    seen = []
    monkeypatch.setattr(p, "start", lambda confirmed=False: seen.append(p.mode.currentIndex()))
    p.test_run()
    assert seen == [0] and p.mode.currentIndex() == 1                # paper for that run only
    w.close()


def test_todays_trades_survive_a_restart(tmp_path):
    from orb_bot.alerts import AlertEngine
    cfg = _alerts_cfg(tmp_path, script_risk=500.0, target_rr=0.3)
    live = AutoOCO([])
    eng = AlertEngine(cfg, live, live, "practice")
    now = datetime.now(cfg.timezone) - timedelta(minutes=1)
    (cfg.log_dir).mkdir(parents=True, exist_ok=True)
    head = "date,bot,account,mode,session,side,size,signal_time,entry_fill,exit_reason,exit_fill,pnl\n"
    rows = [f"{now:%Y-%m-%d},{cfg.bot_name},,practice,TV,sell,6,{now:%H:%M:%S},31221.25,target,31208.75,145.68",
            f"{now:%Y-%m-%d},{cfg.bot_name},,paper,TV,buy,1,{now:%H:%M:%S},1,stop,0,-1",       # a test run: not shown
            f"{now:%Y-%m-%d},Other bot,,practice,TV,buy,1,{now:%H:%M:%S},1,stop,0,-1"]          # another bot
    (cfg.log_dir / "fills.csv").write_text(head + "\n".join(rows) + "\n")
    closed = eng.snapshot()["closed"]
    assert len(closed) == 1 and closed[0]["pnl"] == 145.68 and closed[0]["side"] == "sell"
    assert closed[0]["time"] == f"{now:%H:%M:%S}"
    # older rows have no fill times: they're taken from Topstep's fills by entry order id
    t_in = (now - timedelta(seconds=30)).astimezone(timezone.utc)
    eng._fill_times_from = None
    rows = [dict(closed[0], order="77", fill_known=False, out="")]
    eng.data = type("D", (), {"get_fills": lambda self, since: [
        Fill(77, "C", Side.SELL, 6, 31221.25, None, 2.2, t_in),
        Fill(78, "C", Side.BUY, 6, 31208.75, 150.0, 2.2, t_in + timedelta(minutes=2, seconds=5))]})()
    eng._fill_times(rows)
    assert rows[0]["time"] == t_in.astimezone(cfg.timezone).strftime("%H:%M:%S")
    assert rows[0]["out"] == (t_in + timedelta(minutes=2, seconds=5)).astimezone(cfg.timezone).strftime("%H:%M:%S")


def test_todays_trades_table_shows_in_and_out_times(tmp_path):
    from orb_bot import gui
    from PySide6.QtWidgets import QApplication
    (tmp_path / "config.toml").write_text((ROOT / "config.example.toml").read_text())
    app = QApplication.instance() or QApplication([])  # noqa: F841
    w = gui.MainWindow(tmp_path)
    w._fill_trades([{"bot": "TV alerts", "session": "tv", "time": "15:40:03", "out": "15:41:57", "side": "sell",
                     "size": 6, "entry": 31221.25, "exit": 31208.75, "reason": "target", "pnl": 145.68}])
    heads = [w.trades.horizontalHeaderItem(i).text() for i in range(w.trades.columnCount())]
    assert heads == ["BOT", "IN", "OUT", "SIDE", "SIZE", "ENTRY", "EXIT", "P&L"]
    row = [w.trades.item(0, i).text() for i in range(8)]
    assert row[:3] == ["TV alerts", "15:40:03", "15:41:57"] and row[7] == "+$145.68"


def test_chart_marks_entries_and_exits_on_their_bars():
    from zoneinfo import ZoneInfo
    from orb_bot.chart_view import bars_json, trade_markers
    from orb_bot.models import Bar
    from orb_bot.performance import RoundTrip
    tz = ZoneInfo("Australia/Brisbane")
    t0 = datetime(2026, 10, 12, 5, 30, tzinfo=timezone.utc)                    # 15:30 Brisbane
    bars = [Bar(t0 + timedelta(minutes=5 * i), 1, 2, 0, 1) for i in range(4)]
    assert bars_json(bars, tz)[0]["time"] == int(t0.timestamp()) + 10 * 3600   # axis reads Brisbane time
    trip = RoundTrip("A", "C", Side.SELL, 6, t0 + timedelta(minutes=10, seconds=3), t0 + timedelta(minutes=13),
                     31222, 31209.5, 150.0, 4.32, bot="TV alerts")
    m = trade_markers([trip], bars, tz, 5)
    assert [x["shape"] for x in m] == ["arrowDown", "circle"]
    assert m[0]["text"] == "Short 6 · TV alerts" and m[1]["text"] == "+$145.68"
    assert m[0]["time"] == m[1]["time"] == bars_json(bars, tz)[2]["time"]


def _script_cfg(tmp_path, script: str, minutes: int = 5):
    (tmp_path / "strategies").mkdir(exist_ok=True)
    (tmp_path / "strategies" / "mine.py").write_text(script)
    (tmp_path / "bots").mkdir(exist_ok=True)
    p = tmp_path / "bots" / "mine.toml"
    p.write_text('name = "Mine"\ntype = "script"\n\n[script]\nfile = "strategies/mine.py"\n\n'
                 f'[strategy]\nbar_minutes = {minutes}\n\n[risk]\nrisk_mode = "dollars"\nrisk_dollars = 200\n'
                 'max_contracts = 10\n\n[safety]\nmax_daily_loss = 0\n')
    c = load_config(p)
    c.log_dir = tmp_path / "logs"
    return c


def test_script_bot_trades_what_the_script_says_sized_by_the_app(tmp_path):
    from orb_bot.engine import Engine
    from orb_bot.models import Bar
    script = '''
from orb_bot.scripting import Strategy

class Up(Strategy):
    name = "Up"
    params = {"n": 3, "stop_ticks": 40}
    def on_bar(self, bar):
        if len(self.bars) >= self.p.n and self.position == 0 and all(
                b.close > b.open for b in self.bars[-self.p.n:]):
            self.buy(stop_ticks=self.p.stop_ticks, target_rr=2, reason="3 up bars")
'''
    cfg = _script_cfg(tmp_path, script)
    live = AutoOCO([])
    eng = Engine(cfg, live, live, "practice")
    t0 = datetime(2026, 10, 12, 0, 0, tzinfo=timezone.utc)
    for i in range(3):
        eng.process_bar(Bar(t0 + timedelta(minutes=5 * i), 100 + i, 102 + i, 99 + i, 101 + i))
    # $200 risk / (40 ticks x $0.50) = 10 contracts; target 2 x 40 = 80 ticks
    assert live.placed[-1][:4] == (Side.BUY, 10, 40, 80)


def test_script_errors_dont_stop_the_bot_and_params_can_be_changed(tmp_path):
    from orb_bot.models import Bar
    from orb_bot.scripting import ScriptRunner, load_strategy
    script = '''
from orb_bot.scripting import Strategy

class Boom(Strategy):
    params = {"fast": 9}
    def on_bar(self, bar):
        raise ValueError("oops")
'''
    cfg = _script_cfg(tmp_path, script)
    st = load_strategy(cfg.script_path(), {"fast": "12"})
    assert st.p.fast == 12
    from orb_bot.models import Contract
    r = ScriptRunner(cfg, Contract("C", "MNQZ6", 0.25, 0.5))
    bar = Bar(datetime(2026, 10, 12, tzinfo=timezone.utc), 1, 2, 0, 1)
    assert r.on_bar(bar, 50000, False) is None and r.errors == 1


def test_example_strategies_load_and_indicators_match_tradingview_style():
    from orb_bot.scripting import Strategy, load_strategy
    for f in ("template.py", "ema_cross.py", "simple_orb.py"):
        load_strategy(ROOT / "strategies" / f)
    s = Strategy()
    vals = [1, 2, 3, 4, 5, 6]
    assert s.sma(3, vals)[-1] == 5 and s.ema(3, vals)[2] == 2 and s.ema(3, vals)[3] == 3
    assert s.crossed_above([1, 3], [2, 2]) and not s.crossed_above([3, 4], 2)
    assert s.rsi(3, [1, 2, 3, 4])[-1] == 100.0


def test_left_bar_switches_pages_inside_the_main_window(tmp_path, monkeypatch):
    from orb_bot import gui
    from PySide6.QtWidgets import QApplication
    (tmp_path / "config.toml").write_text((ROOT / "config.example.toml").read_text())
    app = QApplication.instance() or QApplication([])  # noqa: F841
    w = gui.MainWindow(tmp_path)
    w._perf_fetch = lambda aid, since: []
    assert w.pages.currentIndex() == 0 and w.nav_buttons["chart"].isChecked()
    w.show_page("settings")
    assert w.pages.currentIndex() == 3 and w.nav_buttons["settings"].isChecked()
    w.open_help("tv")
    assert w.pages.currentIndex() == 4 and not w.help_window.isWindow()
    w.show_page("bots")  # My bots: every bot, click one for its details and code
    assert w.pages.currentWidget() is w.bots_page and w.bots_page.table.rowCount() == 1
    w.bots_page.pick_bot.emit(0)
    assert "class" in w.bots_page.d_code.toPlainText() and w.bots_page.d_title.text() == w.bots[0].name
    started = []
    monkeypatch.setattr(gui.BotPanel, "start", lambda self, confirmed=False: started.append(self.account_id))
    w._deploy(777)  # Deploy to another account: its bots are made, and that copy is started (Start asks first)
    assert started == [777] and 777 in w.views and w.view_id is None
    w.bots_page.open_bot.emit(0)  # Open on chart
    assert w.pages.currentIndex() == 0 and w.bot_tabs.currentWidget() is w.bots[0]
    w.show_page("chart")
    assert w.pages.currentIndex() == 0


def test_upl_moves_with_each_trade_on_every_position():
    from types import SimpleNamespace
    from orb_bot.live_pnl import OpenPnL
    from orb_bot.models import Contract, Fill, Position, Side
    mnq, mgc = Contract("MNQ", "MNQZ6", 0.25, 0.5), Contract("MGC", "MGCZ6", 0.1, 1.0)
    streams = {"MNQ": SimpleNamespace(last_price=None), "MGC": SimpleNamespace(last_price=None)}

    class FakeBroker:
        account_id = None
        def get_all_positions(self):
            return [Position("MNQ", Side.SELL, 6, 31221.25), Position("MGC", Side.BUY, 2, 4198.5)]
        def contract_by_id(self, cid):
            return {"MNQ": mnq, "MGC": mgc}[cid]
        def last_price_of(self, cid):
            return {"MNQ": 31220.0, "MGC": 4198.0}[cid]
        def get_fills(self, since):
            now = datetime.now(timezone.utc)
            return [Fill(1, "MNQ", Side.BUY, 2, 1.0, None, 1.0, now),          # London entry
                    Fill(2, "MNQ", Side.SELL, 2, 1.0, -250.0, 1.0, now),       # and its stop
                    Fill(3, "MNQ", Side.SELL, 1, 1.0, 999.0, 0.5, since - timedelta(hours=1))]  # yesterday

    w = OpenPnL(lambda: FakeBroker(), lambda b, cid: streams[cid])
    w.account_id = 1
    assert w.value() is None and w.realised is None  # not checked yet
    w.check()
    assert w.value() == pytest.approx(6 * 1.25 * 2 + 2 * -0.5 * 10)   # 1-minute closes until the stream trades
    streams["MNQ"].last_price = 31208.75          # every trade moves it
    assert w.value() == pytest.approx(6 * 12.5 * 2 - 10)
    assert w.realised == pytest.approx(-252.0)    # RP&L with no bot running: today's closed trades less fees


def test_trading_day_starts_at_6pm_new_york():
    from orb_bot.live_pnl import trading_day_start
    ny = ZoneInfo("America/New_York")
    assert trading_day_start(datetime(2026, 10, 16, 3, 0, tzinfo=ny)) == datetime(2026, 10, 15, 18, 0, tzinfo=ny)
    assert trading_day_start(datetime(2026, 10, 16, 19, 0, tzinfo=ny)) == datetime(2026, 10, 16, 18, 0, tzinfo=ny)


def test_divider_sizes_are_remembered(tmp_path):
    from orb_bot import gui
    from PySide6.QtWidgets import QApplication
    (tmp_path / "config.toml").write_text((ROOT / "config.example.toml").read_text())
    app = QApplication.instance() or QApplication([])  # noqa: F841
    w = gui.MainWindow(tmp_path)
    n = w.split.count()
    w._save_ui_state(split=[100 + i for i in range(n)])
    w2 = gui.MainWindow(tmp_path)
    w2.resize(1200, 900)
    w2._size_split()
    assert w2._ui_state()["split"] == [100 + i for i in range(n)]
    assert sum(w2.split.sizes()) > 0


def test_daily_balances_work_back_from_todays_balance():
    from datetime import date
    from zoneinfo import ZoneInfo
    from orb_bot import performance as pf
    tz = ZoneInfo("Australia/Brisbane")
    # 10-11am Brisbane: inside that day's Topstep trading day (which starts 5pm Chicago = 8 or 9am Brisbane)
    mk = lambda d, net: pf.RoundTrip("A", "C", Side.BUY, 1, datetime(2026, 10, d, 10, tzinfo=tz),  # noqa: E731
                                     datetime(2026, 10, d, 11, tzinfo=tz), 1.0, 2.0, net, 0.0)
    trips = [mk(6, 100.0), mk(8, -50.0), mk(9, 25.0)]
    out = dict(pf.daily_balances(trips, tz, 1000.0, date(2026, 10, 5), date(2026, 10, 12), date(2026, 10, 12)))
    assert out[date(2026, 10, 12)] == 1000.0 and out[date(2026, 10, 9)] == 1000.0
    assert out[date(2026, 10, 8)] == 975.0 and out[date(2026, 10, 6)] == 1025.0 and out[date(2026, 10, 5)] == 925.0
    assert date(2026, 10, 10) not in out                       # weekends without trades are skipped


def test_performance_page_can_hide_any_figure_and_remembers(tmp_path):
    from orb_bot.perf_view import PerformanceWindow
    from PySide6.QtWidgets import QApplication
    app = QApplication.instance() or QApplication([])  # noqa: F841
    run = lambda fn, cb: cb(fn(), None)  # noqa: E731
    lay = tmp_path / "layout.json"
    w = PerformanceWindow(lambda: [(1, "PRAC")], lambda a, s: [], run, tmp_path / "fills.csv",
                          ZoneInfo("Australia/Brisbane"), 1, layout_file=lay)
    w._toggle("dur", False)
    w._toggle("calendar", False)
    assert w.tiles["dur"].isHidden() and w.calendar.isHidden()
    w2 = PerformanceWindow(lambda: [(1, "PRAC")], lambda a, s: [], run, tmp_path / "fills.csv",
                           ZoneInfo("Australia/Brisbane"), 1, layout_file=lay)
    assert w2.hidden == {"dur", "calendar"} and w2.tiles["dur"].isHidden() and not w2.tiles["net"].isHidden()


def test_trade_details_show_the_bots_plan_and_r():
    from zoneinfo import ZoneInfo
    from orb_bot import performance as pf
    from orb_bot.trade_view import facts
    tz = ZoneInfo("Australia/Brisbane")
    f1 = Fill(1, "CON.F.US.MNQ.Z26", Side.SELL, 6, 31221.25, None, 2.22, datetime(2026, 10, 12, 5, 40, 6, tzinfo=timezone.utc))
    f2 = Fill(2, "CON.F.US.MNQ.Z26", Side.BUY, 6, 31208.75, 150.0, 2.22, datetime(2026, 10, 12, 5, 42, tzinfo=timezone.utc))
    t = pf.round_trips([f1, f2], "PRAC")[0]
    assert t.fills == [f1, f2]
    t.log = {"stop": "31263.0", "target": "31208.75", "exit_reason": "target"}
    got = {k: v for k, v, _c in facts(t, tz)}
    assert got["Market"] == "MNQ · Micro Nasdaq  (MNQ Z26)" and got["Closed by"] == "Target"
    assert got["Planned stop"].startswith("31,263.00") and got["Result in R"].startswith("+0.29 R")


def test_chart_falls_back_to_the_app_drawn_chart_and_remembers(tmp_path):
    from orb_bot import chart_view, gui
    from PySide6.QtWidgets import QApplication
    (tmp_path / "config.toml").write_text((ROOT / "config.example.toml").read_text())
    app = QApplication.instance() or QApplication([])  # noqa: F841
    w = gui.MainWindow(tmp_path)
    if w.chart.native is None:
        w.chart.tries = 3
        w.chart._page_ready(False)                 # the Mac stopped the web chart three times
    assert w.chart.native is not None and w.chart.view is None and chart_view.USE_NATIVE
    assert w._ui_state().get("native_chart") is True
    n = w.chart.native
    n.setBars([{"time": 1760000000 + 300 * i, "open": 1.0, "high": 2.0, "low": 0.5, "close": 1.5} for i in range(50)])
    n.updateBar({"time": 1760000000 + 300 * 50, "open": 1.5, "high": 2.5, "low": 1.0, "close": 2.0})
    n.setMarkers([{"time": 1760000000, "position": "belowBar", "shape": "arrowUp", "color": "#fff", "text": "x"}])
    n.setLines([{"price": 1.2, "color": "#f00", "title": "stop"}])
    n.resize(800, 400)
    n.grab()                                       # draws without errors
    assert len(n.bars) == 51
    w2 = gui.MainWindow(tmp_path)
    assert w2.chart.native is not None             # next launch goes straight to the app-drawn chart


def test_clicking_a_day_opens_its_trades(tmp_path, monkeypatch):
    from datetime import date
    from orb_bot import perf_view
    from orb_bot.perf_view import PerformanceWindow
    from PySide6.QtWidgets import QApplication, QDialog
    app = QApplication.instance() or QApplication([])  # noqa: F841
    tz = ZoneInfo("Australia/Brisbane")
    t0 = datetime.now(timezone.utc).replace(microsecond=0) - timedelta(minutes=30)
    fills = [Fill(1, "C", Side.SELL, 2, 100.0, None, 1.0, t0), Fill(2, "C", Side.BUY, 2, 99.0, 4.0, 1.0, t0 + timedelta(minutes=5)),
             Fill(3, "C", Side.BUY, 1, 99.0, None, 1.0, t0 + timedelta(minutes=10)),
             Fill(4, "C", Side.SELL, 1, 98.0, -2.0, 1.0, t0 + timedelta(minutes=12))]
    w = PerformanceWindow(lambda: [(1, "PRAC")], lambda a, s: fills, lambda fn, cb: cb(fn(), None),
                          tmp_path / "fills.csv", tz, 1)
    opened, listed = [], []
    monkeypatch.setattr(w, "_open", lambda t: opened.append(t))
    monkeypatch.setattr(QDialog, "exec", lambda self: listed.append(self.windowTitle()))
    from orb_bot.performance import trading_day
    day = trading_day(t0 + timedelta(minutes=12))  # Topstep's trading day (from 5pm Chicago), not the Brisbane date
    w.calendar.day_clicked.emit(day)              # two trades that day: a list to pick from
    assert len(listed) == 1 and not opened
    w.trips = w.trips[:1]
    w.balance.day_clicked.emit(day)               # one trade: its details open straight away
    assert len(opened) == 1
    # All time starts the balance chart the day before the first trade, not a year earlier
    w.balance_fn = lambda a: 50000.0
    w.period.setCurrentText("All time")
    assert day - timedelta(days=1) <= w._balances()[0][0] <= day


def test_native_chart_zooms_smoothly_around_the_mouse(monkeypatch):
    pytest.importorskip("PySide6.QtWidgets", exc_type=ImportError)
    monkeypatch.setenv("QT_QPA_PLATFORM", "offscreen")
    from PySide6.QtCore import QPoint, QPointF, Qt
    from PySide6.QtGui import QWheelEvent
    from PySide6.QtWidgets import QApplication
    from orb_bot.native_chart import AXIS_W, NativeChart
    app = QApplication.instance() or QApplication([])  # noqa: F841
    c = NativeChart()
    c.resize(800 + AXIS_W, 400)
    c.setBars([{"time": 1_800_000_000 + 300 * i, "open": 100 + i, "high": 101 + i, "low": 99 + i, "close": 100.5 + i}
               for i in range(500)])
    c.visible, c.right = 100.0, 0.0

    def under(x):  # the bar index drawn at x
        return len(c.bars) - 1 - c.right - (800 - x) / c._step()

    def wheel(dx, dy, x=200):
        c.wheelEvent(QWheelEvent(QPointF(x, 100), QPointF(x, 100), QPoint(dx, dy), QPoint(dx * 4, dy * 4),
                                 Qt.NoButton, Qt.NoModifier, Qt.NoScrollPhase, False))

    before = under(200)
    wheel(0, 4)  # one small trackpad scroll: a small zoom in, not a 15% jump
    assert 95 < c.visible < 100
    assert abs(under(200) - before) < 0.01  # the candle under the mouse stays put
    r = c.right
    wheel(-40, 0)  # a sideways swipe pans
    assert c.right != r
    c.paintEvent(None)  # draws without error, price scale remembered for gliding
    assert c._yr is not None
    lo, hi = c._yr
    c._scale_price(0.5)  # pinching the price axis stretches the prices
    assert abs((c.y_manual[1] - c.y_manual[0]) - (hi - lo) / 2) < 1e-6
    c.mouseDoubleClickEvent(None)  # double-click: back to fitting the candles
    assert c.y_manual is None
    c.right, c.y_manual = 200.0, (1.0, 2.0)
    c.goLive()  # Refresh: back to the latest candle and fitted prices
    assert c.right < 0 and c.y_manual is None


def test_chart_timeframes_and_markets():
    from orb_bot.broker.projectx import _bar_unit, _is_month
    from orb_bot.chart_view import DAYS, MARKETS, TIMEFRAMES
    assert all(m in DAYS for m, _ in TIMEFRAMES) and "MGC" in MARKETS and "ES" in MARKETS
    assert _bar_unit(5) == {"unit": 2, "unitNumber": 5} and _bar_unit(240) == {"unit": 3, "unitNumber": 4}
    assert _bar_unit(1440) == {"unit": 4, "unitNumber": 1} and _bar_unit(10080) == {"unit": 5, "unitNumber": 1}
    assert _is_month("Z6") and _is_month("H27") and not _is_month("LZ6")  # "SI" doesn't match "SILZ6"


def test_all_bots_tab_lists_every_bot():
    pytest.importorskip("PySide6.QtWidgets", exc_type=ImportError)
    from PySide6.QtWidgets import QApplication
    from orb_bot.overview import AllBots, bot_row
    app = QApplication.instance() or QApplication([])  # noqa: F841
    snap = {"mode": "practice", "trade": {"side": "sell", "size": 6, "entry": 31221.25, "filled": True,
                                          "unrealized": -42.5},
            "closed": [{"pnl": 145.68}, {"pnl": -20.0}]}
    r = bot_row("TV ORB", "TV alerts", "MNQ", True, snap)
    assert r["position"] == "Short 6 @ 31,221.25" and r["upl"] == -42.5 and r["trades"] == 2
    assert abs(r["pnl"] - 125.68) < 1e-9 and r["status"] == "Running"
    stopped = bot_row("ORB M5", "ORB", "MNQ", False, None)
    assert stopped["status"] == "Stopped" and stopped["pnl"] is None
    w = AllBots()
    picked = []
    w.pick_bot.connect(picked.append)
    w.set_rows([r, stopped])
    assert w.table.rowCount() == 3 and w.table.item(2, 0).text() == "Total"  # a total row under the bots
    w.table.cellClicked.emit(1, 0)
    w.table.cellClicked.emit(2, 0)  # the total row opens nothing
    assert picked == [1]
    w.show_detail(1, {"title": "ORB M5", "facts": [("Type", "ORB")], "code_title": "Python code", "code": "x = 1"})
    w._copy()
    assert QApplication.clipboard().text() == "x = 1" and w.d_copy.text() == "Copied"


def test_performance_matches_topstepx_trade_list():
    """14 Oct 2026 on the 50K Combine: TopstepX listed three trades; two MNQ shorts overlapped (two entries,
    then two exits), and a trade before 8am Brisbane belongs to the previous Topstep day."""
    from datetime import date
    from zoneinfo import ZoneInfo
    from orb_bot import performance as pf
    tz = ZoneInfo("Australia/Brisbane")
    at = lambda h, m, s, d=14: datetime(2026, 10, d, h, m, s, tzinfo=tz)  # noqa: E731
    fee = lambda n, ex: ex + 0.25 * n  # noqa: E731 - exchange fee + TopstepX commission per fill
    fills = [Fill(1, "MNQ", Side.BUY, 1, 30768.75, None, fee(1, 0.37), at(0, 45, 2)),
             Fill(2, "MNQ", Side.SELL, 1, 30738.25, -61.0, fee(1, 0.37), at(2, 15, 2)),
             Fill(10, "MGC", Side.SELL, 3, 4181.2, None, fee(3, 2.13), at(15, 30, 5)),
             Fill(11, "MGC", Side.BUY, 3, 4176.6, 138.0, fee(3, 2.13), at(15, 53, 55)),
             Fill(20, "MNQ", Side.SELL, 2, 30762.0, None, fee(2, 0.72), at(15, 55, 2)),
             Fill(21, "MNQ", Side.SELL, 2, 30754.5, None, fee(2, 0.72), at(16, 0, 1)),
             Fill(22, "MNQ", Side.BUY, 2, 30732.0, 120.0, fee(2, 0.72), at(16, 4, 28)),
             Fill(23, "MNQ", Side.BUY, 2, 30719.0, 142.0, fee(2, 0.72), at(16, 5, 0))]
    trips = pf.round_trips(fills)
    today = [t for t in trips if pf.trade_day(t) == date(2026, 10, 14)]
    assert len(today) == 3 and pf.trade_day(trips[0]) == date(2026, 10, 13)  # the 00:45 trade is 13 Oct's
    got = sorted((t.size, t.entry_price, t.exit_price, round(t.pnl, 2)) for t in today)
    assert got == [(2, 30754.5, 30719.0, 142.0), (2, 30762.0, 30732.0, 120.0), (3, 4181.2, 4176.6, 138.0)]
    assert round(sum(t.net for t in today), 2) == 389.36  # TopstepX's RP&L for the day


def test_updates_only_install_signed_releases(tmp_path):
    import hashlib
    import io
    import zipfile
    from types import SimpleNamespace
    from orb_bot import ed25519, updater
    secret = bytes(range(32))
    pub = ed25519.public_key(secret)
    old_key = updater.PUBLIC_KEY
    updater.PUBLIC_KEY = pub
    try:
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as z:
            z.writestr("orb-bot/orb_bot/new.py", "x = 2\n")
            z.writestr("orb-bot/config.toml", "should not replace\n")
            z.writestr("orb-bot/bots/mine.toml", "should not replace\n")
        data = buf.getvalue()
        sha = hashlib.sha256(data).hexdigest()
        man = {"version": "9.9.9", "url": "https://x/r.zip", "sha256": sha,
               "signature": ed25519.sign(secret, updater.signed_message("9.9.9", sha)).hex()}
        get = lambda u: SimpleNamespace(raise_for_status=lambda: None, json=lambda: man, content=data)  # noqa: E731
        rel = updater.check("https://x/latest.json", "0.7.13", get)
        assert rel and rel.version == "9.9.9"
        assert updater.check("https://x/latest.json", "9.9.9", get) is None  # already up to date
        (tmp_path / "config.toml").write_text("mine\n")
        (tmp_path / "strategies").mkdir()
        (tmp_path / "strategies" / "agent_orb.py").write_text("old\n")  # renamed in v0.7.21
        written = updater.install(updater.download(rel, get), tmp_path)
        assert not (tmp_path / "strategies" / "agent_orb.py").exists()
        assert written == ["orb_bot/new.py"] and (tmp_path / "config.toml").read_text() == "mine\n"
        assert not (tmp_path / "bots").exists()
        forged = dict(man, version="9.9.10")  # signature no longer matches
        with pytest.raises(updater.UpdateError):
            updater.parse_manifest(forged)
        bad = SimpleNamespace(raise_for_status=lambda: None, json=lambda: man, content=data + b"x")
        with pytest.raises(updater.UpdateError):
            updater.download(rel, lambda u: bad)  # changed download
        evil = io.BytesIO()
        with zipfile.ZipFile(evil, "w") as z:
            z.writestr("orb-bot/../../escape.py", "x")
        with pytest.raises(updater.UpdateError):
            updater.install(evil.getvalue(), tmp_path)
        assert updater.version_tuple("0.7.10") > updater.version_tuple("0.7.9")
    finally:
        updater.PUBLIC_KEY = old_key


def test_window_fits_half_a_screen_and_chart_shows_the_spinning_wheel_while_loading(tmp_path):
    from orb_bot import gui
    from PySide6.QtWidgets import QApplication
    (tmp_path / "config.toml").write_text((ROOT / "config.example.toml").read_text())
    app = QApplication.instance() or QApplication([])
    w = gui.MainWindow(tmp_path)
    w.show()
    app.processEvents()
    w._build_performance()
    for page in ("chart", "bots", "performance", "settings", "help"):
        w.show_page(page)
        app.processEvents()
        assert w.minimumSizeHint().width() <= 700, page  # two apps side by side on a laptop
    w.resize(680, 700)
    app.processEvents()
    assert w.width() <= 700
    w.show_page("chart")
    app.processEvents()
    c = w.chart
    c.ready, c.bars = True, []
    c.account.addItem("PRAC", 1)
    c.account.setCurrentIndex(c.account.count() - 1)
    jobs = []
    c.run = lambda fn, cb: jobs.append(cb)
    c.load(full=True)
    assert c.spinner.isVisible() and c.spinner.solid    # nothing to show yet: the wheel turns
    c.spinner._tick()
    c.spinner.grab()
    jobs[0](None, RuntimeError("offline"))
    assert not c.spinner.isVisible()
    w.close()


def test_todays_pnl_counts_trades_made_before_the_bot_started(cfg, tmp_path):
    """Deployed mid-day: RP&L and the daily loss limit include the account's earlier trades (as TopstepX does)."""
    import json as _json
    from dataclasses import replace
    cfg = replace(cfg, log_dir=tmp_path)
    live = FakeLive(S3_DAY)
    now = datetime.now(timezone.utc)
    live.fills = [Fill(1, MNQ.id, Side.SELL, 2, 100.0, None, 1.22, now - timedelta(minutes=30)),
                  Fill(2, MNQ.id, Side.BUY, 2, 90.0, 400.0, 1.22, now - timedelta(minutes=20)),
                  Fill(3, MNQ.id, Side.SELL, 1, 90.0, -50.0, 0.61, now - timedelta(days=3))]   # an earlier day
    eng = Engine(cfg, live, live, "practice")
    eng._roll_day(now)
    assert abs(eng.day_pnl() - (400.0 - 2.44)) < 1e-6
    # a state saved by an older version (counted from the start) is worked out again
    eng.state_path.write_text(_json.dumps({"day": eng.day.isoformat(), "start_balance": 50000.0, "trade": None}))
    eng2 = Engine(cfg, live, live, "practice")
    eng2._roll_day(now)
    assert abs(eng2.day_pnl() - 397.56) < 1e-6


def test_chart_shows_trades_and_opening_ranges_like_tradingview():
    from orb_bot.chart_view import range_boxes, trade_boxes
    from orb_bot.native_chart import NativeChart
    from orb_bot.chart_view import bars_json
    from orb_bot.performance import round_trips
    from PySide6.QtWidgets import QApplication
    app = QApplication.instance() or QApplication([])  # noqa: F841
    tz = ZoneInfo("Australia/Brisbane")
    t0 = datetime(2026, 10, 14, 5, 0, tzinfo=timezone.utc)   # 15:00 Brisbane
    bars = [Bar(t0 + timedelta(minutes=5 * i), 100 + i, 105 + i, 95 + i, 101 + i) for i in range(30)]
    fills = [Fill(1, "C", Side.SELL, 2, 110.0, None, 1.0, t0 + timedelta(minutes=55, seconds=2)),
             Fill(2, "C", Side.BUY, 2, 104.0, 24.0, 1.0, t0 + timedelta(minutes=64, seconds=28))]
    trips = round_trips(fills)
    trips[0].bot, trips[0].log = "ORB M5", {"stop": "114.5", "target": "104"}
    boxes = trade_boxes(trips, bars, tz)
    assert boxes[0]["entry"] == 110.0 and boxes[0]["stop"] == 114.5 and boxes[0]["target"] == 104.0
    assert boxes[0]["t1"] - boxes[0]["t0"] == 9 * 60 + 26          # exact fill times, not candle starts
    assert boxes[0]["text"] == "−2 ORB M5 Short" and boxes[0]["result"] == "+$22.00"
    start = t0
    r = range_boxes([("ORB M5 S1", start, start + timedelta(minutes=15), None)], bars, tz)
    assert r[0]["high"] == 107 and r[0]["low"] == 95                 # the three candles 15:00-15:10
    assert r[0]["t2"] - r[0]["t1"] == 10 * 5 * 60                     # lines run on 10 candles
    n = NativeChart()
    n.resize(900, 500)
    n.setBars(bars_json(bars, tz))
    n.setTrades(boxes)
    n.setRanges(r)
    n.grab()                                                          # draws without errors


def test_chart_draws_the_open_trade_live():
    from orb_bot.chart_view import open_boxes
    tz = ZoneInfo("Australia/Brisbane")
    t0 = datetime(2026, 10, 14, 5, 0, tzinfo=timezone.utc)
    bars = [Bar(t0 + timedelta(minutes=5 * i), 100, 105, 95, 101) for i in range(12)]
    live = [{"side": "sell", "size": 2, "entry": 110.0, "stop": 114.5, "target": 104.0, "last": 108.0,
             "unrealized": 4.0, "at": t0 + timedelta(minutes=31), "bot": "ORB M5"}]
    b = open_boxes(live, bars, tz)[0]
    assert b["open"] and b["stop"] == 114.5 and b["target"] == 104.0
    assert b["t1"] - b["t0"] == 60 * 60 - 31 * 60                  # runs to the end of the current candle
    assert b["result"] == "+$4.00 open" and b["text"] == "−2 ORB M5 Short"


def test_break_even_moves_only_the_bots_stop_once_price_is_past_the_entry(cfg):
    live = FakeLive(S3_DAY, orders=[OpenOrder(7, MNQ.id, Side.SELL, 2, 4, None, 19900.0)])
    moved = []
    live.modify_stop = lambda oid, price: moved.append((oid, price)) or True
    eng = _bot_in_trade(cfg, live)
    stop_id, _tp = live.fill_entry(1, Side.BUY, 4, 20025.25, 20004.25, 20031.50)
    eng._sync_position()
    eng.last_price = 20020.0                                        # still below the entry: refused
    eng.request_breakeven()
    with patch_sleep():
        eng._run_commands()
    assert moved == []
    eng.last_price = 20028.0                                        # past the entry: stop goes to the entry
    eng.request_breakeven()
    with patch_sleep():
        eng._run_commands()
    assert moved == [(stop_id, 20025.25)] and eng.trade.stop == 20025.25   # the other bot's stop (7) untouched


def test_bars_missed_while_the_mac_slept_are_not_traded_late(cfg):
    only(cfg, "s3")
    live = FakeLive(S3_DAY)
    eng = Engine(cfg, live, live, "practice")
    eng.last_bar_time = S3_DAY[0].time
    eng._process_new_bars(15)                       # woke up long after the breakout bar
    assert live.placed == []
    assert eng.last_bar_time == S3_DAY[-1].time    # the ranges still caught up


def test_performance_shows_and_filters_by_market(tmp_path):
    from orb_bot import performance as pf
    from orb_bot.perf_view import PerformanceWindow
    from PySide6.QtWidgets import QApplication
    app = QApplication.instance() or QApplication([])  # noqa: F841
    t0 = datetime.now(timezone.utc).replace(microsecond=0) - timedelta(hours=1)
    nq, gc = "CON.F.US.MNQ.Z26", "CON.F.US.MGC.Z26"
    fills = [Fill(1, nq, Side.SELL, 2, 100.0, None, 0.0, t0), Fill(2, nq, Side.BUY, 2, 99.0, 4.0, 0.0, t0 + timedelta(minutes=1)),
             Fill(3, gc, Side.BUY, 1, 50.0, None, 0.0, t0 + timedelta(minutes=2)),
             Fill(4, gc, Side.SELL, 1, 49.0, -10.0, 0.0, t0 + timedelta(minutes=3))]
    assert pf.market_label("MGC") == "MGC · Micro Gold" and pf.round_trips(fills[:2])[0].points == 1.0
    w = PerformanceWindow(lambda: [(1, "PRAC")], lambda a, s: fills, lambda fn, cb: cb(fn(), None),
                          tmp_path / "fills.csv", ZoneInfo("Australia/Brisbane"), 1)
    w.period.setCurrentText("Today"); w._period_changed()
    assert w.by_market.rowCount() == 2 and {w.trades_table.item(r, 2).text() for r in range(2)} == {"MNQ", "MGC"}
    w.market.setCurrentIndex(w.market.findData("MGC")); w.render()
    assert w.trades_table.rowCount() == 1 and w.tiles["net"].value.text() == "-$10.00"


def _orb_1m_day(tmp_path, monkeypatch, day):
    """Replays one New York day through the ORB 1M bot from the history it had the day
    before, with the app's own engine and simulated Topstep fills."""
    import gzip
    from orb_bot import orb_1m
    from orb_bot.engine import Engine
    from orb_bot.models import Bar
    data = json.loads(gzip.open(ROOT / "tests" / "data" / f"orb-1m-{day}.json.gz", "rt").read())
    monkeypatch.setattr(orb_1m, "bundled_state", lambda: data["state"])
    cfg = _script_cfg(tmp_path, (ROOT / "strategies" / "orb_1m.py").read_text(), minutes=1)
    cfg.risk.risk_dollars, cfg.risk.max_contracts = 535.0, 2  # the risk box at ORB 1M's own numbers
    cfg.sim.commission_per_side, cfg.sim.slippage_ticks = 0.0, 1
    bars = [Bar(datetime.strptime(t, "%Y-%m-%d %H:%M").replace(tzinfo=timezone.utc), o, h, l, c, v)
            for t, o, h, l, c, v in data["bars"]]
    sim = SimBroker(MNQ, cfg.sim, starting_balance=50_000)
    eng = Engine(cfg, FakeData(bars), sim, "replay")
    trades = eng.run_replay(bars[0].time, bars[-1].time + timedelta(minutes=1), cfg.log_dir / "t.csv")
    saved = json.loads((cfg.log_dir / "orb-1m-state.json").read_text())
    assert saved["cash_date"] == day  # the day's history was kept for tomorrow
    return trades


def test_orb_1m_matches_ninjatrader_short_to_target_14_oct(tmp_path, monkeypatch):
    # NinjaTrader: short 1 @ 30488.50 at 10:00 ET, target 30188.50
    (t,) = _orb_1m_day(tmp_path, monkeypatch, "2026-10-14")
    assert t.side is Side.SELL and t.size == 1
    assert abs(t.entry_price - 30488.5) <= 1 and abs(t.exit_price - 30188.5) <= 1


def test_orb_1m_matches_ninjatrader_long_closed_at_1600_7_oct(tmp_path, monkeypatch):
    # NinjaTrader: long 2 @ 31288.75, closed at 16:00 ET at 31395.75
    (t,) = _orb_1m_day(tmp_path, monkeypatch, "2026-10-07")
    assert t.side is Side.BUY and t.size == 2
    assert abs(t.entry_price - 31288.75) <= 2 and abs(t.exit_price - 31395.75) <= 2
    assert t.exit_time.astimezone(ZoneInfo("America/New_York")).strftime("%H:%M") in ("15:59", "16:00", "16:01")


def test_port_in_use_says_whether_its_another_copy_of_the_app(tmp_path):
    import socket
    from orb_bot.webhook import WebhookServer
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0)); port = s.getsockname()[1]
    first = WebhookServer(port, start_ngrok=False); first.start()
    try:
        assert WebhookServer(port, start_ngrok=False).port_owner() == "app"
    finally:
        first.stop()
    assert WebhookServer(port, start_ngrok=False).port_owner() == "other"


def test_orb_5m_asia_matches_the_12_oct_trade(tmp_path):
    # ORB 5M (ASIA, $500, 0.3R) live on 12 Oct: short 6 at ~31222 on the 01:35 bar (filled 01:40 NY), target ~31211, stop 31260
    import gzip
    from orb_bot.engine import Engine
    from orb_bot.models import Bar
    data = json.loads(gzip.open(ROOT / "tests" / "data" / "orb-5m-2026-10-12.json.gz", "rt").read())
    cfg = _script_cfg(tmp_path, (ROOT / "strategies" / "orb_5m.py").read_text(), minutes=5)
    cfg.script.params = {"london": True, "ny_am": False, "risk_dollars": 500, "max_contracts": 20}
    cfg.risk.risk_dollars, cfg.risk.max_contracts = 500.0, 20
    cfg.sim.commission_per_side, cfg.sim.slippage_ticks = 0.0, 0
    bars = [Bar(datetime.strptime(t, "%Y-%m-%d %H:%M").replace(tzinfo=timezone.utc), o, h, l, c, v)
            for t, o, h, l, c, v in data]
    sim = SimBroker(MNQ, cfg.sim, starting_balance=50_000)
    eng = Engine(cfg, FakeData(bars), sim, "replay")
    trades = eng.run_replay(bars[0].time, bars[-1].time + timedelta(minutes=5), cfg.log_dir / "t.csv")
    (t,) = trades
    ny = ZoneInfo("America/New_York")
    assert t.side is Side.SELL and t.size == 6 and t.entry_time.astimezone(ny).strftime("%H:%M") == "01:35"  # the signal bar; fills at its 01:40 close
    assert abs(t.entry_price - 31222.25) <= 0.5 and t.stop_price == 31260.0 and t.exit_reason == "target"


def test_orb_5m_london_and_ny_am_switch_on_and_off_per_account_while_running(tmp_path):
    import gzip
    import shutil
    from PySide6.QtWidgets import QApplication
    from orb_bot import gui
    from orb_bot.engine import Engine
    from orb_bot.models import Bar
    data = json.loads(gzip.open(ROOT / "tests" / "data" / "orb-5m-2026-10-12.json.gz", "rt").read())
    bars = [Bar(datetime.strptime(t, "%Y-%m-%d %H:%M").replace(tzinfo=timezone.utc), o, h, l, c, v)
            for t, o, h, l, c, v in data]
    cfg = _script_cfg(tmp_path, (ROOT / "strategies" / "orb_5m.py").read_text(), minutes=5)
    cfg.script.params = {"london": False, "risk_dollars": 500, "max_contracts": 20}
    cfg.risk.risk_dollars, cfg.risk.max_contracts = 500.0, 20
    eng = Engine(cfg, FakeData(bars), SimBroker(MNQ, cfg.sim, starting_balance=50_000), "replay")
    assert eng.run_replay(bars[0].time, bars[-1].time + timedelta(minutes=5), cfg.log_dir / "t.csv") == []  # London off

    root = tmp_path / "app"
    (root / "strategies").mkdir(parents=True)
    (root / "bots").mkdir()
    (root / "config.toml").write_text((ROOT / "config.example.toml").read_text())
    shutil.copy(ROOT / "strategies" / "orb_5m.py", root / "strategies" / "orb_5m.py")
    (root / "bots" / "orb5m.toml").write_text('name = "ORB 5M"\ntype = "script"\n\n[script]\nfile = "strategies/orb_5m.py"\n'
                                              '\n[strategy]\nbar_minutes = 5\n')
    app = QApplication.instance() or QApplication([])  # noqa: F841
    w = gui.MainWindow(root)
    p = next(b for b in w.bots if b.name == "ORB 5M")
    p.account_id = 7
    assert set(p.switch_boxes) == {"london", "ny_am"} and p.switch_boxes["london"].text() == "London"
    running = SimpleNamespace(p=SimpleNamespace(london=True), params={"london": True})
    p.engine = SimpleNamespace(strategy=SimpleNamespace(script=running))
    p.switch_boxes["london"].setChecked(False)
    assert running.p.london is False                                   # the running bot sees it at once
    assert load_config(root / "bots" / "orb5m.toml").script.params == {}  # other accounts keep theirs
    from orb_bot.config import for_account
    assert for_account(load_config(root / "bots" / "orb5m.toml"), BrokerConfig(), 7).script.params["london"] is False


def test_orb_5m_second_trade_waits_for_the_bar_after_the_first_closes(tmp_path):
    # 23 Feb 2024 in James's TradingView list: long stopped out in the 09:55 bar, the short came from the 10:05 bar
    import gzip
    from orb_bot.engine import Engine
    from orb_bot.models import Bar
    data = json.loads(gzip.open(ROOT / "tests" / "data" / "orb-5m-2024-02-23.json.gz", "rt").read())
    cfg = _script_cfg(tmp_path, (ROOT / "strategies" / "orb_5m.py").read_text(), minutes=5)
    cfg.script.params = {"london": False, "ny_am": True, "risk_dollars": 500, "max_contracts": 20}
    cfg.risk.risk_dollars, cfg.risk.max_contracts = 500.0, 20
    cfg.sim.commission_per_side, cfg.sim.slippage_ticks = 0.0, 0
    bars = [Bar(datetime.strptime(t, "%Y-%m-%d %H:%M").replace(tzinfo=timezone.utc), o, h, l, c, v)
            for t, o, h, l, c, v in data]
    sim = SimBroker(MNQ, cfg.sim, starting_balance=50_000)
    eng = Engine(cfg, FakeData(bars), sim, "replay")
    trades = eng.run_replay(bars[0].time, bars[-1].time + timedelta(minutes=5), cfg.log_dir / "t.csv")
    ny = ZoneInfo("America/New_York")
    assert [(t.side, t.size, t.entry_time.astimezone(ny).strftime("%H:%M")) for t in trades] == [
        (Side.BUY, 6, "09:30"), (Side.SELL, 12, "10:05")]


def test_bots_added_before_the_rename_find_orb_1m_and_its_history(tmp_path):
    import shutil
    from orb_bot.scripting import ScriptRunner
    from orb_bot.orb_1m import bundled_state
    cfg = _script_cfg(tmp_path, "")
    (tmp_path / "bots" / "old.toml").write_text('name = "ORB 1M"\ntype = "script"\n\n[script]\nfile = "strategies/agent_orb.py"\n\n'
                                              '[strategy]\nbar_minutes = 1\n')
    old = load_config(tmp_path / "bots" / "old.toml")
    assert old.script.file == "strategies/orb_1m.py"
    shutil.copy(ROOT / "strategies" / "orb_1m.py", tmp_path / "strategies" / "orb_1m.py")
    old.log_dir = tmp_path / "logs"
    old.log_dir.mkdir()
    state = dict(bundled_state(), cash_date="2099-01-01")
    (old.log_dir / "agent-orb-state.json").write_text(json.dumps(state))  # saved by v0.7.20
    r = ScriptRunner(old, MNQ)
    assert r.script.name == "ORB 1M" and str(r.script.core.cash_date) == "2099-01-01"


def test_packaged_app_hides_the_built_in_bots_code(tmp_path, monkeypatch):
    from PySide6.QtWidgets import QApplication
    from orb_bot import gui, licence
    (tmp_path / "config.toml").write_text((ROOT / "config.example.toml").read_text())
    app = QApplication.instance() or QApplication([])  # noqa: F841
    w = gui.MainWindow(tmp_path)
    assert "def " in w._bot_detail(w.bots[0])["code"]  # James's own copy shows it
    monkeypatch.setattr(licence, "ENFORCE", True)
    assert "isn't shown" in w._bot_detail(w.bots[0])["code"]
    assert {"orb_1m.py", "orb_5m.py"} <= gui.BUILT_IN_SCRIPTS


def test_original_orb_bot_becomes_orb_m5_og_keeping_its_orders_and_state(tmp_path):
    from orb_bot.config import rename_original_orb
    p = tmp_path / "config.toml"
    p.write_text((ROOT / "config.example.toml").read_text().replace('name = "ORB M5 O.G"', 'name = "ORB M5"')
                 .replace('id = "orbm5"', ''))
    assert rename_original_orb(p)
    c = load_config(p)
    assert c.bot_name == "ORB M5 O.G" and c.slug == "orbm5"  # same order tags and state file as before
    assert not rename_original_orb(p)
    save_top_setting = __import__("orb_bot.config", fromlist=["x"]).save_top_setting
    save_top_setting(p, "name", "ORB M5")  # renamed back by hand: left alone
    assert not rename_original_orb(p) and load_config(p).bot_name == "ORB M5"


def test_orb_1m_starts_at_its_own_risk_and_follows_the_risk_box(tmp_path):
    import tomllib
    from orb_bot import gui
    from orb_bot.scripting import load_strategy
    sec = tomllib.loads(gui._script_risk_section(load_strategy(ROOT / "strategies" / "orb_1m.py").params))["risk"]
    assert sec == {"risk_mode": "dollars", "risk_dollars": 535, "max_contracts": 2}
    script = '''
from orb_bot.scripting import Strategy

class Sizer(Strategy):
    params = {"risk_dollars": 535.0, "max_contracts": 2}
    def on_bar(self, bar):
        self.seen = (self.p.risk_dollars, self.p.max_contracts)
'''
    from orb_bot.scripting import ScriptRunner
    cfg = _script_cfg(tmp_path, script)
    cfg.risk.risk_mode, cfg.risk.risk_dollars, cfg.risk.max_contracts = "dollars", 545.0, 2
    r = ScriptRunner(cfg, MNQ)
    bar = Bar(datetime(2026, 10, 16, 14, 0, tzinfo=timezone.utc), 1, 2, 0.5, 1.5, 10)
    r.on_bar(bar, 50_000, False)
    assert r.script.seen == (545.0, 2)
    cfg.risk.max_contracts = 3            # changed in the risk box while running
    r.on_bar(bar, 50_000, False)
    assert r.script.seen == (545.0, 3)
    cfg.risk.risk_mode = "percent"         # % of balance: the script keeps its own risk
    r.script.params["risk_dollars"] = r.script.p.risk_dollars = 535.0
    r.on_bar(bar, 50_000, False)
    assert r.script.seen[0] == 535.0


def test_script_bot_trades_its_own_contract(tmp_path):
    from orb_bot.config import BrokerConfig, for_account
    script = '''
from orb_bot.scripting import Strategy

class Gold(Strategy):
    name = "Gold"
    symbol = "MGC"
    def on_bar(self, bar):
        pass
'''
    cfg = _script_cfg(tmp_path, script)
    assert for_account(cfg, BrokerConfig(symbol="MNQ"), 1).broker.symbol == "MGC"  # the script's own contract
    cfg.script.symbol = "GC"
    assert for_account(cfg, BrokerConfig(symbol="MNQ"), 1).broker.symbol == "GC"  # the bot's setting wins
    (tmp_path / "p").mkdir()
    plain = _script_cfg(tmp_path / "p", script.replace('    symbol = "MGC"\n', ""))
    assert for_account(plain, BrokerConfig(symbol="MNQ"), 1).broker.symbol == "MNQ"


def test_orb_1m_moves_its_history_onto_the_new_contract_at_a_roll(tmp_path, monkeypatch):
    from orb_bot import orb_1m
    from orb_bot.models import Bar
    from orb_bot.scripting import ScriptRunner, load_strategy
    state = orb_1m.bundled_state()
    monkeypatch.setattr(orb_1m, "bundled_state", lambda: state)
    cfg = _script_cfg(tmp_path, (ROOT / "strategies" / "orb_1m.py").read_text(), minutes=1)
    t = datetime.now(timezone.utc).replace(second=0, microsecond=0) - timedelta(hours=1)
    prices = {"CON.F.US.MNQ.Z26": 30000.0, "CON.F.US.MNQ.H27": 30296.75}
    bars_of = lambda cid, s, e, m: [Bar(t, 0, 0, 0, prices[cid], 1)]  # noqa: E731
    h7 = Contract("CON.F.US.MNQ.H27", "MNQH7", 0.25, 0.5)
    run = ScriptRunner(cfg, h7, bars_of=bars_of)
    assert run.script.core.close_hist == [c + 296.75 for c in state["close_hist"]]
    run.script._save_state(run.script.core)
    saved = json.loads((cfg.log_dir / "orb-1m-state.json").read_text())
    assert saved["contract_id"] == "CON.F.US.MNQ.H27"
    # the same contract again: nothing moves
    same = ScriptRunner(cfg, MNQ, bars_of=bars_of)
    assert same.script.core.close_hist == state["close_hist"]


def test_lapsed_licence_blocks_new_trades_only(tmp_path, monkeypatch):
    from orb_bot import engine as eng, licence
    from orb_bot.engine import Engine
    from orb_bot.models import Bar
    assert licence.Licence(tmp_path / "licence.json").may_trade()  # not enforced in this copy
    script = '''
from orb_bot.scripting import Strategy

class Up(Strategy):
    name = "Up"
    def on_bar(self, bar):
        if self.position == 0:
            self.buy(stop_ticks=40, target_rr=2)
'''
    cfg = _script_cfg(tmp_path, script)
    live = AutoOCO([])
    e = Engine(cfg, live, live, "practice")
    monkeypatch.setattr(eng, "ENTRY_GATE", lambda: False)
    t0 = datetime(2026, 10, 12, 0, 0, tzinfo=timezone.utc)
    e.process_bar(Bar(t0, 100, 102, 99, 101))
    assert live.placed == []
    monkeypatch.setattr(eng, "ENTRY_GATE", lambda: True)
    e.process_bar(Bar(t0 + timedelta(minutes=5), 100, 102, 99, 101))
    assert len(live.placed) == 1


def test_packaged_app_asks_for_a_licence_before_start(tmp_path, monkeypatch):
    from PySide6.QtWidgets import QApplication, QMessageBox
    from orb_bot import gui, licence
    monkeypatch.setattr(licence, "ENFORCE", True)
    (tmp_path / "config.toml").write_text((ROOT / "config.example.toml").read_text())
    app = QApplication.instance() or QApplication([])
    shown = []
    monkeypatch.setattr(QMessageBox, "information", staticmethod(lambda p, t, m: shown.append(m)))
    w = gui.MainWindow(tmp_path)
    assert w.licence_status.text() == "Enter your licence key to start trading."
    p = w.bots[0]
    p.account_id = 1
    p.start()
    assert not p.running and "licence key" in shown[-1]
