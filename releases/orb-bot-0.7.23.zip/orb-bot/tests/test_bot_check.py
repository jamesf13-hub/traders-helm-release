"""Monthly bot check: matching live trades to the replay, each check's verdict, saved reports and the banners."""
from datetime import date, datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

import pytest

from orb_bot import bot_check as bc
from orb_bot.bot_stats import StatTrade

NY = ZoneInfo("America/New_York")
ROOT = Path(__file__).resolve().parents[1]


def T(day, hh, mm, side, net, size=4, acct="PRAC", fees=5.0, risk=500.0, month=9):
    a = datetime(2026, month, day, hh, mm, tzinfo=NY)
    return StatTrade(a, a + timedelta(minutes=20), side, size, net, "", risk, fees, acct)


def test_match_per_account_and_idle_days():
    replay = [T(1, 9, 35, 1, 100), T(2, 9, 40, -1, -50), T(3, 9, 35, 1, 80), T(4, 9, 50, 1, 60)]
    live = [T(1, 9, 40, 1, 95), T(2, 9, 45, -1, -60), T(1, 9, 41, 1, 90, acct="COMBINE"),  # 2nd account: day 1 only
            T(3, 11, 0, -1, 30)]                                                           # the replay didn't take
    pairs, extra, missed, idle = bc.match(live, replay, 5)
    assert len(pairs) == 3 and len(extra) == 1
    assert [t.entry_time.day for t in missed] == [3]          # PRAC traded on the 3rd but not this one
    assert idle == {date(2026, 9, 4), date(2026, 9, 2), date(2026, 9, 3)}  # COMBINE / PRAC days with no trades


def test_report_good_and_bad():
    replay = [T(d, 9, 35, 1 if d % 2 else -1, 120 if d % 4 else -480) for d in range(1, 29)]
    live = [T(r.entry_time.day, 9, 40, r.side, r.net - 2) for r in replay]
    backtest = [T(1 + i % 28, 9, 35, 1, (120 if i % 4 else -480) + 10 * (i // 28) - 60, month=1 + i // 28)
                for i in range(28 * 12)]  # a year of months, some better and some worse than this one
    for t in backtest:
        t.entry_time = t.entry_time.replace(year=2025)
        t.exit_time = t.exit_time.replace(year=2025)
    rows = [{"date": f"2026-09-{d:02d}", "entry_slip_ticks": "1", "exit_slip_ticks": "1", "exit_reason": "stop"}
            for d in range(1, 29)]
    rep = bc.run("ORB 5M", "2026-09", live, replay, rows, backtest, 5)
    names = {c.name: c for c in rep.checks}
    assert names["Trades match the replay"].status == bc.GOOD and names["Trades match the replay"].value == "100%"
    assert names["Fills vs the replay"].status == bc.GOOD
    assert names["Slippage"].status == bc.GOOD
    assert names["Win rate"].status == bc.GOOD
    assert rep.status == bc.GOOD and rep.verdict == "On track" and not rep.flagged

    # half the trades missing, fills 4 ticks worse a contract, slipping 3 ticks, every trade a loser
    live = [T(r.entry_time.day, 9, 40, r.side, -8 * 4 - 200) for r in replay[::2]]
    rows = [dict(r, entry_slip_ticks="3", exit_slip_ticks="3") for r in rows]
    rep = bc.run("ORB 5M", "2026-09", live, replay, rows, backtest, 5)
    names = {c.name: c for c in rep.checks}
    assert names["Trades match the replay"].status == bc.WATCH  # the ones taken all ended differently
    assert names["Days not running"].status == bc.WATCH and names["Days not running"].value == "14 days"
    assert names["Fills vs the replay"].status == bc.BAD
    assert names["Slippage"].status == bc.BAD and names["Win rate"].status == bc.BAD
    assert rep.status == bc.BAD and "Needs a look" in rep.summary()


def test_no_replay_or_backtest_is_info():
    live = [T(1, 9, 40, 1, 50)]
    rep = bc.run("ORB M5 O.G", "2026-09", live, None, [], [], 5)
    assert all(c.status in (bc.INFO, bc.GOOD) for c in rep.checks)
    assert rep.checks[0].value == "not run"


def test_saved_reports_round_trip(tmp_path):
    rep = bc.Report("ORB 1M", "2026-09", "2026-10-01 08:00", 20, [bc.Check("Win rate", bc.WATCH, "40%", "low")])
    bc.save(tmp_path, "orb1m", rep)
    back = bc.load(tmp_path, "orb1m", "2026-09")
    assert back == rep and back.status == bc.WATCH and back.flagged
    assert bc.load(tmp_path, "orb1m", "2026-08") is None
    assert bc.month_range("2026-02") == (date(2026, 2, 1), date(2026, 2, 28))
    assert bc.previous_month(date(2026, 1, 3)) == "2025-12"


def test_review_banner_until_keep_running(tmp_path, monkeypatch):
    pytest.importorskip("PySide6.QtWidgets", exc_type=ImportError)
    monkeypatch.setenv("QT_QPA_PLATFORM", "offscreen")
    from PySide6.QtWidgets import QApplication
    from orb_bot import gui
    (tmp_path / "config.toml").write_text((ROOT / "config.example.toml").read_text())
    QApplication.instance() or QApplication([])
    w = gui.MainWindow(tmp_path)
    p = w.bots[0]
    month = bc.previous_month(datetime.now(w.main_cfg.timezone).date())
    bc.save(w.check_dir, p.cfg.slug, bc.Report(p.name, month, "x", 12, [bc.Check("Slippage", bc.BAD, "+3", "d")]))
    w._refresh_reviews()
    assert not p.review_banner.isHidden() and "Needs a look" in p.review_banner.text.text()
    assert w.bots_page.reviews.count() == 1
    w._keep_bot(p)
    assert p.review_banner.isHidden() and w.bots_page.reviews.count() == 0
    assert bc.load(w.check_dir, p.cfg.slug, month).reviewed
