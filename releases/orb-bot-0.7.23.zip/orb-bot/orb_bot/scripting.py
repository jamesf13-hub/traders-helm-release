"""Your own strategy in Python: the script decides when to trade, the app does everything else.

A script is one .py file with a class based on `Strategy`. The app calls its `on_bar` once per closed bar with the
bar just finished; the script answers with `self.buy(...)`, `self.sell(...)` or `self.close()` (or nothing).
Sizing (risk % or $, max contracts), the daily loss limit, Topstep brackets, phone alerts, Performance, the Chart
and Replay all come from the app, the same as for the built-in bots. See strategies/template.py.

    from orb_bot.scripting import Strategy

    class EmaCross(Strategy):
        name = "EMA cross"
        params = {"fast": 9, "slow": 21, "stop_ticks": 40, "target_rr": 2.0}

        def on_bar(self, bar):
            fast, slow = self.ema(self.p.fast), self.ema(self.p.slow)
            if self.crossed_above(fast, slow):
                self.buy(stop_ticks=self.p.stop_ticks, target_rr=self.p.target_rr, reason="fast EMA crossed up")
"""
from __future__ import annotations

import importlib.util
import logging
import sys
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from types import SimpleNamespace

from .models import Bar, Side, Signal
from .strategy.orb import ORBStrategy

log = logging.getLogger(__name__)

HISTORY = 2000  # bars kept for the script (about 7 days of 5-minute bars)


class ScriptError(RuntimeError):
    pass


@dataclass
class Order:
    side: Side | None  # None = close the open trade
    stop: float | None = None
    target: float | None = None
    stop_ticks: float | None = None
    target_ticks: float | None = None
    target_rr: float | None = None
    reason: str = ""
    contracts: int | None = None  # the script's own size (still capped by max contracts and the daily loss limit)


class Strategy:
    """Base class for your strategy. Override `on_bar`; optionally `on_start`.

    Inside on_bar you have:
      self.bars      every closed bar so far, oldest first (self.bars[-1] is the one just closed)
      self.opens / highs / lows / closes / volumes   the same as lists of numbers
      self.time      the bar's close time in the app's time zone (a datetime: .hour, .minute, .weekday())
      self.position  your bot's open trade: +size long, -size short, 0 flat
      self.trades_closed  how many of your trades have closed since the bot started
    A script that sizes its own trades can name its params risk_dollars and max_contracts: they then follow
    the bot's risk box ("$ per trade" and Max contracts), per account and straight away.
      self.p         your params (self.p.fast), after any changes in the bot's settings file
      self.tick      the contract's tick size (0.25 for MNQ / NQ)
    and helpers sma, ema, rsi, atr, highest, lowest, crossed_above, crossed_below.
    """

    name = "My strategy"
    params: dict = {}
    bar_minutes: int | None = None  # set to require a chart timeframe, e.g. 1 for one-minute bars
    symbol: str | None = None  # the contract it trades, e.g. "MGC" (blank = the app's main contract)
    # on/off params shown as switches on the bot's screen, e.g. {"london": "London"}: each account has its own,
    # and flipping one changes self.p straight away, even while the bot runs
    switches: dict = {}
    history = HISTORY  # bars kept in self.bars

    def __init__(self):
        self.bars: list[Bar] = []
        self.position = 0
        self.tick = 0.25
        self.tz = None
        self.p = SimpleNamespace(**self.params)
        self.live = False  # False while the app catches up on past bars (orders are ignored then)
        self.entry_price: float | None = None  # your open trade's fill price at Topstep, once known
        self.trades_closed = 0  # goes up as each trade closes (catches a trade opened and closed within one bar)
        self.data_dir = None  # a folder the script may keep its own files in (the app's logs folder)
        self.warmup_start: datetime | None = None  # set in on_start to get past bars from further back
        self.contract_id = ""  # Topstep's id of the contract traded, e.g. "CON.F.US.MNQ.Z26"
        self.contract_name = ""  # e.g. "MNQZ6"
        self._bars_of = None
        self._order: Order | None = None
        self._move_stop: float | None = None
        self._series: dict = {}

    # --- override these --------------------------------------------------------------------
    def on_start(self) -> None:
        """Called once before the first bar."""

    def on_bar(self, bar: Bar) -> None:
        """Called once per closed bar. Call self.buy / self.sell / self.close to trade."""
        raise NotImplementedError

    # --- orders ------------------------------------------------------------------------------
    def buy(self, stop: float | None = None, target: float | None = None, *, stop_ticks: float | None = None,
            target_ticks: float | None = None, target_rr: float | None = None, reason: str = "",
            contracts: int | None = None) -> None:
        """Go long at the next price. Give the stop as a price or in ticks, and the target as a price, in ticks
        or as a multiple of the stop (target_rr=2 = twice the stop distance). contracts= sets the size yourself
        (the bot's max contracts and daily loss limit still apply); without it the bot's risk settings size it."""
        self._order = Order(Side.BUY, stop, target, stop_ticks, target_ticks, target_rr, reason, contracts)

    def sell(self, stop: float | None = None, target: float | None = None, *, stop_ticks: float | None = None,
             target_ticks: float | None = None, target_rr: float | None = None, reason: str = "",
             contracts: int | None = None) -> None:
        """Go short. Same arguments as buy."""
        self._order = Order(Side.SELL, stop, target, stop_ticks, target_ticks, target_rr, reason, contracts)

    def bars_of(self, contract_id: str, start: datetime, end: datetime, minutes: int = 1) -> list[Bar]:
        """Past bars of any contract by Topstep id (e.g. the previous quarter's at a roll); [] if unavailable."""
        if self._bars_of is None:
            return []
        try:
            return list(self._bars_of(contract_id, start, end, minutes))
        except Exception as e:  # noqa: BLE001
            log.warning("bars for %s unavailable: %s", contract_id, e)
            return []

    def move_stop(self, price: float) -> None:
        """Move your open trade's stop at Topstep to this price (e.g. break-even)."""
        self._move_stop = price

    def close(self, reason: str = "script exit") -> None:
        """Close your open trade at market (its stop and target are cancelled)."""
        self._order = Order(None, reason=reason)

    # --- data -----------------------------------------------------------------------------------
    @property
    def opens(self) -> list[float]:
        return [b.open for b in self.bars]

    @property
    def highs(self) -> list[float]:
        return [b.high for b in self.bars]

    @property
    def lows(self) -> list[float]:
        return [b.low for b in self.bars]

    @property
    def closes(self) -> list[float]:
        return [b.close for b in self.bars]

    @property
    def volumes(self) -> list[float]:
        return [b.volume for b in self.bars]

    @property
    def time(self) -> datetime | None:
        """The close time of the bar just finished, in the app's time zone."""
        return self._close_time

    _close_time: datetime | None = None

    # --- indicators: each returns a list as long as the input (None until there's enough data) -------
    def sma(self, n: int, src: list[float] | None = None) -> list[float | None]:
        src = self.closes if src is None else src
        out: list[float | None] = []
        total = 0.0
        for i, v in enumerate(src):
            total += v
            if i >= n:
                total -= src[i - n]
            out.append(total / n if i >= n - 1 else None)
        return out

    def ema(self, n: int, src: list[float] | None = None) -> list[float | None]:
        """Like TradingView's ta.ema: starts from the SMA of the first n values."""
        src = self.closes if src is None else src
        out: list[float | None] = []
        k, prev = 2 / (n + 1), None
        for i, v in enumerate(src):
            if i < n - 1:
                out.append(None)
                continue
            prev = sum(src[:n]) / n if prev is None else v * k + prev * (1 - k)
            out.append(prev)
        return out

    def rsi(self, n: int = 14, src: list[float] | None = None) -> list[float | None]:
        """Like TradingView's ta.rsi (Wilder's smoothing)."""
        src = self.closes if src is None else src
        out: list[float | None] = [None]
        up = down = None
        for i in range(1, len(src)):
            ch = src[i] - src[i - 1]
            g, lo = max(ch, 0.0), max(-ch, 0.0)
            if i < n:
                out.append(None)
                continue
            if up is None:
                gains = [max(src[j] - src[j - 1], 0.0) for j in range(1, n + 1)]
                losses = [max(src[j - 1] - src[j], 0.0) for j in range(1, n + 1)]
                up, down = sum(gains) / n, sum(losses) / n
            else:
                up, down = (up * (n - 1) + g) / n, (down * (n - 1) + lo) / n
            out.append(100.0 if down == 0 else 100 - 100 / (1 + up / down))
        return out

    def atr(self, n: int = 14) -> list[float | None]:
        """Average true range (Wilder's smoothing, like ta.atr)."""
        trs = []
        for i, b in enumerate(self.bars):
            prev = self.bars[i - 1].close if i else b.close
            trs.append(max(b.high - b.low, abs(b.high - prev), abs(b.low - prev)))
        out: list[float | None] = []
        val = None
        for i, tr in enumerate(trs):
            if i < n - 1:
                out.append(None)
                continue
            val = sum(trs[:n]) / n if val is None else (val * (n - 1) + tr) / n
            out.append(val)
        return out

    def highest(self, n: int, src: list[float] | None = None) -> float:
        """Highest value of the last n (highs by default), including the bar just closed."""
        src = self.highs if src is None else src
        return max(src[-n:])

    def lowest(self, n: int, src: list[float] | None = None) -> float:
        src = self.lows if src is None else src
        return min(src[-n:])

    @staticmethod
    def crossed_above(a: list, b: list | float) -> bool:
        """True on the bar where a moved from at/below b to above it."""
        b0, b1 = (b, b) if isinstance(b, (int, float)) else (b[-2] if len(b) > 1 else None, b[-1])
        if len(a) < 2 or None in (a[-2], a[-1], b0, b1):
            return False
        return a[-2] <= b0 and a[-1] > b1

    @staticmethod
    def crossed_below(a: list, b: list | float) -> bool:
        b0, b1 = (b, b) if isinstance(b, (int, float)) else (b[-2] if len(b) > 1 else None, b[-1])
        if len(a) < 2 or None in (a[-2], a[-1], b0, b1):
            return False
        return a[-2] >= b0 and a[-1] < b1


def load_strategy(path: Path, overrides: dict | None = None) -> Strategy:
    """Load the Strategy class from a script file and make one with the bot's params."""
    path = Path(path)
    if not path.exists():
        raise ScriptError(f"script not found: {path}")
    mod_name = f"th_script_{abs(hash(str(path.resolve())))}"
    spec = importlib.util.spec_from_file_location(mod_name, path)
    module = importlib.util.module_from_spec(spec)
    try:
        sys.modules[mod_name] = module
        spec.loader.exec_module(module)
    except Exception as e:  # noqa: BLE001 - the user's code
        raise ScriptError(f"{path.name} has an error: {type(e).__name__}: {e}") from e
    classes = [c for c in vars(module).values()
               if isinstance(c, type) and issubclass(c, Strategy) and c is not Strategy and c.__module__ == mod_name]
    if len(classes) != 1:
        raise ScriptError(f"{path.name} needs exactly one class based on Strategy (found {len(classes)})")
    cls = classes[0]
    params = dict(cls.params)
    for k, v in (overrides or {}).items():
        if k not in params:
            log.warning("%s: setting %r isn't one of the script's params; ignored", path.name, k)
            continue
        params[k] = type(params[k])(v) if params[k] is not None and not isinstance(params[k], bool) else v
    s = cls()
    s.params = params
    s.p = SimpleNamespace(**params)
    return s


@dataclass
class ScriptRunner(ORBStrategy):
    """Plugs a user's script into the engine in place of the ORB strategy. Sizing, the daily loss limit and the
    safety switches are the ORB strategy's own, so a script bot is sized and limited exactly like the others."""
    script: Strategy | None = None
    errors: int = 0
    want_close: str | None = None
    want_stop: float | None = None
    state: dict = field(default_factory=dict)
    bars_of: object = None  # (contract_id, start, end, minutes) -> bars, from the engine's data source

    def __post_init__(self):
        if self.script is None:
            self.script = load_strategy(self.config.script_path(), self.config.script.params)
        self.script.tick = self.contract.tick_size
        self.script.contract_id, self.script.contract_name = self.contract.id, self.contract.name
        self.script._bars_of = self.bars_of
        self.script.tz = self.config.timezone
        self.script.data_dir = self.config.log_dir
        self.label = self.config.bot_name
        need = self.script.bar_minutes
        if need and need != self.config.strategy.bar_minutes:
            raise ScriptError(f"{self.script.name} needs {need}-minute bars; this bot is set to "
                              f"{self.config.strategy.bar_minutes}-minute bars")
        try:
            self.script.on_start()
        except Exception as e:  # noqa: BLE001
            raise ScriptError(f"on_start failed: {type(e).__name__}: {e}") from e

    def mark_session_done(self, name: str) -> None:
        pass  # a signal from the warm-up bars: nothing to remember

    def _follow_risk_box(self) -> None:
        s, r = self.script, self.config.risk
        if "risk_dollars" in s.params and r.risk_mode == "dollars":
            s.p.risk_dollars = s.params["risk_dollars"] = float(r.risk_dollars)
            if "max_contracts" in s.params:
                s.p.max_contracts = s.params["max_contracts"] = int(r.max_contracts)

    def on_trade_closed(self, pnl: float) -> None:
        super().on_trade_closed(pnl)
        self.script.trades_closed += 1

    def on_bar(self, bar: Bar, equity: float, in_position: bool, day_pnl: float = 0.0) -> Signal | None:
        from datetime import timedelta
        s = self.script
        s.bars.append(bar)
        del s.bars[:-s.history]
        if not in_position:
            s.position = 0  # the engine sets it while a trade is open
        s._close_time = (bar.time + timedelta(minutes=self.config.strategy.bar_minutes)).astimezone(
            self.config.timezone)
        s._order = None
        s._move_stop = None
        self._follow_risk_box()
        try:
            s.on_bar(bar)
            self.errors = 0
        except Exception as e:  # noqa: BLE001 - a script bug must never take the app down
            self.errors += 1
            log.error("%s: script error on the %s bar: %s: %s%s", self.label, s._close_time.strftime("%H:%M"),
                      type(e).__name__, e, " (no new trades until it runs cleanly)" if self.errors == 1 else "")
            return None
        if s._move_stop is not None and in_position:
            self.want_stop = s._move_stop
        o = s._order
        if o is None:
            return None
        if o.side is None:
            if in_position:
                self.want_close = o.reason or "script exit"
            return None
        if in_position:
            return None
        return self._signal(o, bar, equity, day_pnl)

    def _signal(self, o: Order, bar: Bar, equity: float, day_pnl: float) -> Signal | None:
        tick, price, long = self.contract.tick_size, bar.close, o.side is Side.BUY
        sign = 1 if long else -1
        if o.stop is not None:
            dist = (price - o.stop) * sign
        elif o.stop_ticks:
            dist = o.stop_ticks * tick
        else:
            log.warning("%s: %s without a stop; skipped (give stop= or stop_ticks=)", self.label, o.side.value)
            return None
        if dist <= 0:
            log.warning("%s: stop %s is on the wrong side of %.2f for a %s; skipped", self.label, o.stop, price,
                        o.side.value)
            return None
        if o.target is not None:
            tdist = (o.target - price) * sign
        elif o.target_ticks:
            tdist = o.target_ticks * tick
        elif o.target_rr:
            tdist = dist * o.target_rr
        else:
            log.warning("%s: %s without a target; skipped (give target=, target_ticks= or target_rr=)",
                        self.label, o.side.value)
            return None
        if tdist <= 0:
            log.warning("%s: target is on the wrong side of %.2f; skipped", self.label, price)
            return None
        block = self._safety_block(day_pnl)
        if block:
            log.info("%s: %s; no new trades", self.label, block)
            return None
        qty = min(o.contracts, self.config.risk.max_contracts) if o.contracts else self.qty_for_risk(dist, equity)
        qty = self._cap_for_daily_loss(self.label, qty, dist, day_pnl)
        if qty < 1:
            return None
        rnd = lambda v: round(v / tick) * tick  # noqa: E731
        return Signal(self.label, o.side, price, rnd(price - sign * dist), rnd(price + sign * tdist), qty,
                      o.reason or f"{self.script.name} {'buy' if long else 'sell'}")

