"""Monthly bot check: is a bot still doing what it should? For one month it compares the bot's real trades at
Topstep with a replay of the same month (did it take the trades it should have, and get similar fills) and with
its backtest (are the results inside the normal range), and looks at slippage, drawdown and costs.

Each check comes out good / watch / bad (or info when there isn't enough to judge), and the worst one is the verdict.
The app runs it for every bot that traded, at the start of each month (reports in logs/bot-checks/), and it can
be run for any month from My bots → a bot → Monthly check."""
from __future__ import annotations

import json
import logging
import math
from dataclasses import asdict, dataclass, field
from datetime import date, datetime, timedelta
from pathlib import Path

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import QComboBox, QFrame, QGridLayout, QHBoxLayout, QLabel, QPushButton, QVBoxLayout

from . import theme
from .bot_stats import StatTrade

log = logging.getLogger(__name__)

GOOD, WATCH, BAD, INFO = "good", "watch", "bad", "info"
RANK = {INFO: 0, GOOD: 1, WATCH: 2, BAD: 3}
VERDICT = {GOOD: "On track", WATCH: "Keep an eye on it", BAD: "Needs a look", INFO: "Not enough to judge"}
ASSUMED_SLIP = 1.0  # ticks the backtests and replays allow on entries and stop exits
MIN_TRADES = 8  # fewer live trades than this in a month: results aren't judged


@dataclass
class Check:
    name: str
    status: str
    value: str
    detail: str


@dataclass
class Report:
    bot: str
    month: str  # "2026-09"
    made: str  # when the check ran
    trades: int
    checks: list[Check] = field(default_factory=list)
    reviewed: str = ""  # when the user pressed "Keep running" on it

    @property
    def status(self) -> str:
        judged = [c.status for c in self.checks if c.status != INFO]
        return max(judged, key=RANK.get) if judged else INFO

    @property
    def verdict(self) -> str:
        return VERDICT[self.status]

    def summary(self) -> str:
        """One message for Telegram and the Activity log."""
        lines = [f"{self.bot}, {month_label(self.month)}: {self.verdict} ({self.trades} trades)"]
        for c in self.checks:
            if c.status in (WATCH, BAD):
                lines.append(f"• {c.name}: {c.value}. {c.detail}")
        return "\n".join(lines)

    def to_json(self) -> dict:
        return asdict(self)

    @classmethod
    def from_json(cls, d: dict) -> "Report":
        return cls(d["bot"], d["month"], d.get("made", ""), d.get("trades", 0), [Check(**c) for c in d.get("checks", [])],
                   d.get("reviewed", ""))

    @property
    def flagged(self) -> list[Check]:
        return [c for c in self.checks if c.status in (WATCH, BAD)]


def month_label(month: str) -> str:
    return datetime.strptime(month, "%Y-%m").strftime("%B %Y")


def month_range(month: str) -> tuple[date, date]:
    """First and last day of "YYYY-MM"."""
    start = datetime.strptime(month, "%Y-%m").date()
    nxt = (start.replace(day=28) + timedelta(days=4)).replace(day=1)
    return start, nxt - timedelta(days=1)


def previous_month(today: date) -> str:
    return (today.replace(day=1) - timedelta(days=1)).strftime("%Y-%m")


def _in(trades: list[StatTrade], start: date, end: date) -> list[StatTrade]:
    return [t for t in trades if start <= t.entry_time.date() <= end]


def _pct(v: float) -> str:
    return f"{v * 100:.0f}%"


def _money(v: float) -> str:
    return ("+" if v > 0 else "-" if v < 0 else "") + f"${abs(v):,.0f}"


# --- the checks ---------------------------------------------------------------------------------------------
def match(live: list[StatTrade], replay: list[StatTrade], bar_minutes: int):
    """Pairs each live trade with the replay trade it should be: same side, entered within about two bars (the
    replay times a trade at its signal bar's open, a live one at its fill). Done per account, since a bot running
    on two accounts takes each replay trade twice. Returns (pairs, live only, replay only, days not running)."""
    tol = timedelta(minutes=2 * bar_minutes + 1)
    pairs, extra, missed = [], [], []
    idle_days: set[date] = set()
    for acct in sorted({t.account for t in live}):
        mine = sorted((t for t in live if t.account == acct), key=lambda t: t.entry_time)
        days = {t.entry_time.date() for t in mine}
        pool = sorted(replay, key=lambda t: t.entry_time)
        used = set()
        for t in mine:
            best = None
            for i, r in enumerate(pool):
                if i in used or r.side != t.side:
                    continue
                gap = abs(t.entry_time - r.entry_time)
                if gap <= tol and (best is None or gap < best[1]):
                    best = (i, gap)
            if best:
                used.add(best[0])
                pairs.append((t, pool[best[0]]))
            else:
                extra.append(t)
        for i, r in enumerate(pool):
            if i in used:
                continue
            if r.entry_time.date() in days:
                missed.append(r)
            else:  # no trades at all from this bot that day on this account: it most likely wasn't running
                idle_days.add(r.entry_time.date())
    return pairs, extra, missed, idle_days


def _when(t: StatTrade) -> str:
    return f"{t.entry_time:%a %d %b %H:%M} {'long' if t.side > 0 else 'short'}"


def check_tracking(live, replay, bar_minutes) -> list[Check]:
    if replay is None:
        return [Check("Trades match the replay", INFO, "not run",
                      "The replay needs Topstep's bars for the month (log in, and the month must still be in "
                      "Topstep's history).")]
    pairs, extra, missed, idle = match(live, replay, bar_minutes)
    expected = len(pairs) + len(missed)
    rate = len(pairs) / (expected + len(extra)) if expected + len(extra) else 1.0
    status = GOOD if rate >= 0.95 else WATCH if rate >= 0.8 else BAD
    bits = [f"{len(pairs)} of {expected} replay trades taken"]
    if missed:
        bits.append("missed " + ", ".join(_when(t) for t in missed[:3]) + (" …" if len(missed) > 3 else ""))
    if extra:
        bits.append(f"{len(extra)} the replay didn't take (" + ", ".join(_when(t) for t in extra[:3])
                    + (" …" if len(extra) > 3 else "") + ")")
    same = sum((a.net > 0) == (b.net > 0) for a, b in pairs)
    if pairs:
        bits.append(f"{same} of {len(pairs)} ended the same way (win or loss)")
        if same / len(pairs) < 0.9:
            status = max(status, WATCH, key=RANK.get)
    out = [Check("Trades match the replay", status, _pct(rate), "; ".join(bits) + ".")]
    if idle:
        out.append(Check("Days not running", WATCH if len(idle) >= 3 else INFO, f"{len(idle)} day{'s' if len(idle) != 1 else ''}",
                         "The replay traded on " + ", ".join(f"{d:%d %b}" for d in sorted(idle)[:6])
                         + (" …" if len(idle) > 6 else "") + " but the bot didn't trade at all those days "
                         "(app closed, bot stopped or the Mac asleep?). Not counted above; if it was running, look at its "
                         "Activity for those days."))
    if pairs:
        # per contract, so different sizes on different accounts compare fairly
        gap = sum(a.net / max(a.size, 1) - b.net / max(b.size, 1) for a, b in pairs) / len(pairs)
        ticks = gap / 0.5  # MNQ: $0.50 a tick
        status = GOOD if ticks >= -1 else WATCH if ticks >= -3 else BAD
        out.append(Check("Fills vs the replay", status, f"{'-' if gap < 0 else '+'}${abs(gap):,.2f} a contract",
                         f"On the same trades, live made ${abs(gap):,.2f} per contract per trade "
                         f"{'less' if gap < 0 else 'more'} than the replay (about {abs(ticks):.1f} ticks on MNQ), "
                         "fees included."))
    return out


def check_slippage(rows: list[dict]) -> Check:
    def avg(key, only_stops=False):
        vals = []
        for r in rows:
            if only_stops and r.get("exit_reason") not in ("stop", "close", "flatten", "eod"):
                continue
            try:
                vals.append(float(r.get(key) or "nan"))
            except ValueError:
                continue
        vals = [v for v in vals if v == v]
        return (sum(vals) / len(vals), len(vals)) if vals else (None, 0)
    entry, n_in = avg("entry_slip_ticks")
    exit_, n_out = avg("exit_slip_ticks", only_stops=True)
    if entry is None and exit_ is None:
        return Check("Slippage", INFO, "–", "No fills logged for this bot this month (logs/fills.csv).")
    worst = max(v for v in (entry, exit_) if v is not None)
    status = GOOD if worst <= ASSUMED_SLIP + 0.25 else WATCH if worst <= 2 else BAD
    parts = []
    if entry is not None:
        parts.append(f"entries {entry:+.1f} ticks ({n_in})")
    if exit_ is not None:
        parts.append(f"stop and market exits {exit_:+.1f} ({n_out})")
    return Check("Slippage", status, f"{worst:+.1f} ticks",
                 f"Average fill against the price planned: {', '.join(parts)}. The backtest allows "
                 f"{ASSUMED_SLIP:g} tick; more than that comes straight off the results.")


def check_results(live: list[StatTrade], backtest: list[StatTrade], end: date, k: float = 1.0) -> list[Check]:
    """k: the bot's risk per trade / the backtest's, so a bot run at $250 is judged against a $500 backtest fairly."""
    if not backtest:
        return [Check("Results vs the backtest", INFO, "no backtest",
                      "This bot has no backtest to compare with; the replay check above covers it.")]
    if len(live) < MIN_TRADES:
        return [Check("Results vs the backtest", INFO, f"{len(live)} trades",
                      f"Too few trades this month to judge (needs {MIN_TRADES}).")]
    hist = [t for t in backtest if end - timedelta(days=3 * 365) <= t.exit_time.date() <= end]
    hist = hist or backtest
    months: dict[str, float] = {}
    for t in hist:
        key = f"{t.exit_time:%Y-%m}"
        months[key] = months.get(key, 0.0) + t.net * k
    net = sum(t.net for t in live)
    below = sum(v < net for v in months.values()) / len(months)
    status = GOOD if below >= 0.2 else WATCH if below >= 0.05 else BAD
    out = [Check("Month's P&L vs the backtest", status, _money(net),
                 f"Better than {below * 100:.0f}% of the last {len(months)} backtest months"
                 + (f" (scaled to your risk, ×{k:.2f})" if abs(k - 1) > 0.05 else "") + ".")]
    p = sum(t.net > 0 for t in hist) / len(hist)
    n = len(live)
    wr = sum(t.net > 0 for t in live) / n
    sd = math.sqrt(p * (1 - p) / n)
    lo, hi = max(0.0, p - 1.5 * sd), min(1.0, p + 1.5 * sd)
    z = (wr - p) / sd if sd else 0.0
    status = GOOD if z >= -1.5 else WATCH if z >= -2.5 else BAD
    out.append(Check("Win rate", status, _pct(wr),
                     f"The backtest wins {_pct(p)}; with {n} trades anything from {_pct(lo)} to {_pct(hi)} is normal."))
    return out


def check_drawdown(live_all: list[StatTrade], backtest: list[StatTrade], end: date, k: float = 1.0) -> Check:
    """The deepest dip in the bot's live record so far, against the worst the backtest had in three years."""
    run = peak = dd = 0.0
    for t in sorted(live_all, key=lambda t: t.exit_time):
        if t.exit_time.date() > end:
            break
        run += t.net
        peak = max(peak, run)
        dd = min(dd, run - peak)
    if not backtest:
        return Check("Drawdown", INFO, _money(dd), "Deepest dip in the live record so far (no backtest to compare).")
    hist = [t for t in backtest if end - timedelta(days=3 * 365) <= t.exit_time.date() <= end] or backtest
    run = peak = worst = 0.0
    for t in sorted(hist, key=lambda t: t.exit_time):
        run += t.net * k
        peak = max(peak, run)
        worst = min(worst, run - peak)
    share = dd / worst if worst else 0.0
    status = GOOD if share < 0.5 else WATCH if share < 1 else BAD
    return Check("Drawdown", status, _money(dd),
                 f"Deepest dip in the live record so far; the backtest's worst in three years was {_money(worst)}"
                 f" ({share * 100:.0f}% of it used).")


def check_costs(live: list[StatTrade]) -> Check:
    fees = sum(t.fees for t in live)
    gross = sum(t.net + t.fees for t in live)
    contracts = sum(t.size for t in live)
    risk = [t.risk / t.size for t in live if t.risk and t.size]
    stop = f"; average stop {sum(risk) / len(risk) / 2:.0f} points (MNQ)" if risk else ""
    if not live:
        return Check("Costs", INFO, "–", "No trades.")
    per = f"{contracts / len(live):.1f} contracts a trade"
    if gross <= 0:
        return Check("Costs", INFO, f"${fees:,.0f} fees",
                     f"Fees ${fees:,.0f} on {contracts} contracts ({per}{stop}); no profit before fees to "
                     "compare them with.")
    share = fees / gross
    status = GOOD if share < 0.3 else WATCH if share < 0.6 else BAD
    return Check("Costs", status, f"{share * 100:.0f}% of profit",
                 f"Fees ${fees:,.0f} took {share * 100:.0f}% of the {_money(gross)} made before fees ({per}{stop}). "
                 "Smaller stops mean more contracts, and more fees, for the same risk.")


def run(bot: str, month: str, live_all: list[StatTrade], replay: list[StatTrade] | None, fill_rows: list[dict],
        backtest: list[StatTrade], bar_minutes: int, now: datetime | None = None, scale: float = 1.0) -> Report:
    start, end = month_range(month)
    live = _in(live_all, start, end)
    rows = [r for r in fill_rows if (r.get("date") or "")[:7] == month]
    rep = Report(bot, month, (now or datetime.now()).strftime("%Y-%m-%d %H:%M"), len(live))
    if not live and not replay:
        rep.checks.append(Check("Trades", INFO, "none", "No trades by this bot this month, live or in the replay."))
        return rep
    rep.checks += check_tracking(live, replay if replay is None else _in(replay, start, end), bar_minutes)
    rep.checks.append(check_slippage(rows))
    rep.checks += check_results(live, backtest, end, scale)
    rep.checks.append(check_drawdown(live_all, backtest, end, scale))
    rep.checks.append(check_costs(live))
    return rep


# --- saved reports ------------------------------------------------------------------------------------------
def report_path(folder: Path, slug: str, month: str) -> Path:
    return folder / f"{slug}-{month}.json"


def save(folder: Path, slug: str, rep: Report) -> None:
    try:
        folder.mkdir(parents=True, exist_ok=True)
        report_path(folder, slug, rep.month).write_text(json.dumps(rep.to_json(), indent=1), encoding="utf-8")
    except OSError as e:
        log.warning("could not save the bot check: %s", e)


def load(folder: Path, slug: str, month: str) -> Report | None:
    try:
        return Report.from_json(json.loads(report_path(folder, slug, month).read_text(encoding="utf-8")))
    except (OSError, ValueError, KeyError, TypeError):
        return None


# --- the panel on My bots -----------------------------------------------------------------------------------
COLOURS = {GOOD: theme.UP, WATCH: theme.WARN, BAD: theme.DOWN, INFO: theme.TEXT_3}


class BotCheckPanel(QFrame):
    run_check = Signal(str)  # "YYYY-MM"
    month_changed = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("box")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(16, 14, 16, 16)
        lay.setSpacing(10)
        head = QHBoxLayout()
        t = QLabel("MONTHLY CHECK")
        t.setObjectName("statTitle")
        head.addWidget(t)
        head.addSpacing(12)
        self.month = QComboBox()
        self.month.currentIndexChanged.connect(lambda _i: self.month.currentData()
                                               and self.month_changed.emit(self.month.currentData()))
        head.addWidget(self.month)
        head.addSpacing(12)
        self.verdict = QLabel("")
        self.verdict.setObjectName("pill")
        head.addWidget(self.verdict)
        head.addSpacing(10)
        self.made = QLabel("")
        self.made.setObjectName("muted")
        head.addWidget(self.made)
        head.addStretch(1)
        self.button = QPushButton("Run check")
        self.button.clicked.connect(lambda: self.month.currentData() and self.run_check.emit(self.month.currentData()))
        head.addWidget(self.button)
        lay.addLayout(head)
        self.intro = QLabel("Checks the bot's real trades for the month against a replay of the same month (did it "
                            "take the trades it should, with similar fills) and against its backtest (are the "
                            "results in the normal range). Runs by itself at the start of each month.")
        self.intro.setObjectName("muted")
        self.intro.setWordWrap(True)
        lay.addWidget(self.intro)
        self.grid = QGridLayout()
        self.grid.setHorizontalSpacing(14)
        self.grid.setVerticalSpacing(9)
        self.grid.setColumnStretch(3, 1)
        lay.addLayout(self.grid)
        self.set_months(date.today())
        self.show_report(None)

    def set_months(self, today: date, back: int = 12) -> None:
        self.month.blockSignals(True)
        self.month.clear()
        d = today.replace(day=1)
        self.month.addItem(f"{d:%B %Y} so far", f"{d:%Y-%m}")
        for _ in range(back):
            d = (d - timedelta(days=1)).replace(day=1)
            self.month.addItem(f"{d:%B %Y}", f"{d:%Y-%m}")
        self.month.setCurrentIndex(1)
        self.month.blockSignals(False)

    def set_busy(self, busy: bool, text: str = "") -> None:
        self.button.setEnabled(not busy)
        self.button.setText("Checking…" if busy else "Run check")
        if text:
            self.made.setText(text)

    def show_report(self, rep: Report | None) -> None:
        while self.grid.count():
            w = self.grid.takeAt(0).widget()
            if w:
                w.deleteLater()
        if rep is None:
            self.verdict.hide()
            self.made.setText("Not checked yet")
            return
        c = COLOURS[rep.status]
        self.verdict.setText(rep.verdict)
        self.verdict.setStyleSheet(f"QLabel {{ color: {c}; border: 1px solid {c}; border-radius: 10px; "
                                   "padding: 2px 10px; font-weight: 600; }")
        self.verdict.show()
        self.made.setText(f"{rep.trades} live trades · checked {rep.made}")
        for r, ch in enumerate(rep.checks):
            dot = QLabel("●")
            dot.setStyleSheet(f"color: {COLOURS[ch.status]}; font-size: 14px;")
            name = QLabel(ch.name)
            name.setStyleSheet("font-weight: 600;")
            val = QLabel(ch.value)
            val.setStyleSheet(f"color: {COLOURS[ch.status] if ch.status != INFO else theme.TEXT_2};"
                              " font-weight: 600;")
            detail = QLabel(ch.detail)
            detail.setObjectName("muted")
            detail.setWordWrap(True)
            for col, w in enumerate((dot, name, val, detail)):
                self.grid.addWidget(w, r, col, Qt.AlignTop)


class ReviewBanner(QFrame):
    """The monthly check waiting on the user: shown on the bot's own tab and at the top of My bots until they
    press Keep running (or stop the bot)."""
    review = Signal()
    keep = Signal()
    stop = Signal()

    def __init__(self, parent=None, compact: bool = False):
        super().__init__(parent)
        self.setObjectName("reviewBanner")
        lay = QHBoxLayout(self)
        lay.setContentsMargins(14, 10, 12, 10)
        lay.setSpacing(10)
        self.dot = QLabel("●")
        self.text = QLabel()
        self.text.setWordWrap(True)
        self.text.setTextFormat(Qt.RichText)
        lay.addWidget(self.dot, 0, Qt.AlignTop)
        lay.addWidget(self.text, 1)
        self.review_btn = QPushButton("Review")
        self.review_btn.clicked.connect(self.review.emit)
        self.stop_btn = QPushButton("Stop bot")
        self.stop_btn.setObjectName("stop")
        self.stop_btn.clicked.connect(self.stop.emit)
        self.keep_btn = QPushButton("Keep running")
        self.keep_btn.setObjectName("start")
        self.keep_btn.setToolTip("You've looked at this month's check: hide it until next month's")
        self.keep_btn.clicked.connect(self.keep.emit)
        for b in (self.review_btn, self.stop_btn, self.keep_btn):
            b.setCursor(Qt.PointingHandCursor)
            lay.addWidget(b, 0, Qt.AlignVCenter)
        self.compact = compact
        self.report: Report | None = None
        self.hide()

    def show_for(self, rep: Report | None, running: bool = True) -> None:
        self.report = rep
        if rep is None or rep.reviewed:
            self.hide()
            return
        c = COLOURS[rep.status]
        flagged = rep.flagged
        if flagged:
            what = ", ".join(f.name.lower() for f in flagged[:3]) + (f" and {len(flagged) - 3} more"
                                                                    if len(flagged) > 3 else "")
            line = f"{len(flagged)} thing{'s' if len(flagged) != 1 else ''} to look at: {what}."
        else:
            line = "Everything looks as it should."
        self.text.setText(f"<b>{rep.bot}</b> · {month_label(rep.month)} check: "
                          f"<b style='color:{c}'>{rep.verdict}</b><br>"
                          f"<span style='color:{theme.TEXT_2}'>{line} Review it, then press Keep running.</span>")
        self.dot.setStyleSheet(f"color: {c}; font-size: 15px;")
        self.setStyleSheet(f"QFrame#reviewBanner {{ background: {theme.TILE_BG}; border: 1px solid {c}; "
                           "border-radius: 10px; }")
        self.stop_btn.setVisible(running and rep.status == BAD)
        self.show()
