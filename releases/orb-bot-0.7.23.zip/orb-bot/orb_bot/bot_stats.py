"""Bot stats: one bot's record at a glance (win rate, profit factor, drawdown, streaks, sessions, months),
from its real trades at Topstep or from a backtest over a chosen date range."""
from __future__ import annotations

import calendar
import json
import logging
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (QButtonGroup, QComboBox, QFrame, QGridLayout, QHBoxLayout, QLabel, QPushButton,
                               QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget)

from . import theme
from .perf_view import Chart, Tile, _fill, _table, money, pct

log = logging.getLogger(__name__)
BACKTESTS = Path(__file__).parent / "assets" / "backtests"
SESSION_NAMES = {"ASIA": "London", "NYAM": "NY AM"}  # ORB 5M's internal session names
NY = ZoneInfo("America/New_York")
# Script bots log their own name as the session: for these, the session comes from the entry time (New York)
SESSION_BY_TIME = {"orb_5m": lambda ny: "London" if ny.hour < 8 else "NY AM"}
OLD_NAMES = {"ORB M5 O.G": ("ORB M5",)}  # trades logged before a bot was renamed
PERIODS = [("All", None), ("Last 30 days", 30), ("Last 90 days", 90), ("Last 12 months", 365), ("This year", "ytd")]


@dataclass
class StatTrade:
    """One closed trade, whatever it came from (Topstep fills, a replay or a backtest)."""
    entry_time: datetime
    exit_time: datetime
    side: int  # +1 long, -1 short
    size: int
    net: float  # $ after fees
    session: str = ""
    risk: float | None = None  # $ at risk at entry, for R multiples
    fees: float = 0.0  # $ fees in `net` (live trades only)
    account: str = ""


@dataclass
class Group:
    name: str
    trades: int = 0
    wins: int = 0
    gross_win: float = 0.0
    gross_loss: float = 0.0
    net: float = 0.0

    def add(self, n: float) -> None:
        self.trades += 1
        self.net += n
        if n > 0:
            self.wins += 1
            self.gross_win += n
        elif n < 0:
            self.gross_loss += n

    @property
    def win_rate(self) -> float | None:
        return self.wins / self.trades if self.trades else None

    @property
    def profit_factor(self) -> float | None:
        return self.gross_win / -self.gross_loss if self.gross_loss else None


@dataclass
class Stats:
    trades: int = 0
    wins: int = 0
    losses: int = 0
    net: float = 0.0
    gross_win: float = 0.0
    gross_loss: float = 0.0
    max_drawdown: float = 0.0  # negative or 0
    drawdown_date: date | None = None
    best: float | None = None
    worst: float | None = None
    win_streak: int = 0
    loss_streak: int = 0
    first: date | None = None
    last: date | None = None
    avg_r: float | None = None
    curve: list[tuple[date, float]] = field(default_factory=list)
    sessions: list[Group] = field(default_factory=list)
    sides: list[Group] = field(default_factory=list)
    months: dict[tuple[int, int], float] = field(default_factory=dict)

    @property
    def win_rate(self) -> float | None:
        return self.wins / self.trades if self.trades else None

    @property
    def profit_factor(self) -> float | None:
        return self.gross_win / -self.gross_loss if self.gross_loss else None

    @property
    def avg_win(self) -> float | None:
        return self.gross_win / self.wins if self.wins else None

    @property
    def avg_loss(self) -> float | None:
        return self.gross_loss / self.losses if self.losses else None

    @property
    def payoff(self) -> float | None:
        return self.avg_win / -self.avg_loss if self.avg_win is not None and self.avg_loss else None

    @property
    def expectancy(self) -> float | None:
        return self.net / self.trades if self.trades else None

    @property
    def recovery(self) -> float | None:
        return self.net / -self.max_drawdown if self.max_drawdown else None

    @property
    def per_week(self) -> float | None:
        if not self.first or not self.last:
            return None
        weeks = max(1.0, ((self.last - self.first).days + 1) / 7)
        return self.trades / weeks


def compute(trades: list[StatTrade]) -> Stats:
    s = Stats()
    trades = sorted(trades, key=lambda t: t.exit_time)
    peak = running = 0.0
    streak = 0
    sessions: dict[str, Group] = {}
    sides = {1: Group("Long"), -1: Group("Short")}
    rs = []
    for t in trades:
        n = t.net
        d = t.exit_time.date()
        s.trades += 1
        running += n
        if running > peak:
            peak = running
        if running - peak < s.max_drawdown:
            s.max_drawdown, s.drawdown_date = running - peak, d
        if n > 0:
            s.wins += 1
            s.gross_win += n
            streak = streak + 1 if streak > 0 else 1
        elif n < 0:
            s.losses += 1
            s.gross_loss += n
            streak = streak - 1 if streak < 0 else -1
        s.win_streak, s.loss_streak = max(s.win_streak, streak), max(s.loss_streak, -streak)
        s.best = n if s.best is None else max(s.best, n)
        s.worst = n if s.worst is None else min(s.worst, n)
        if t.session:
            sessions.setdefault(t.session, Group(t.session)).add(n)
        sides[1 if t.side > 0 else -1].add(n)
        key = (d.year, d.month)
        s.months[key] = s.months.get(key, 0.0) + n
        if t.risk:
            rs.append(n / t.risk)
        if s.curve and s.curve[-1][0] == d:
            s.curve[-1] = (d, running)
        else:
            s.curve.append((d, running))
    s.net = running
    if trades:
        s.first, s.last = trades[0].entry_time.date(), trades[-1].exit_time.date()
    s.avg_r = sum(rs) / len(rs) if rs else None
    s.sessions = sorted(sessions.values(), key=lambda g: g.name)
    s.sides = [g for g in sides.values() if g.trades]
    return s


def backtest_risk(script_file: str) -> float | None:
    """The $ risk per trade the bundled backtest was run at."""
    try:
        return float(json.loads((BACKTESTS / (Path(script_file).stem + ".json")).read_text(encoding="utf-8"))["risk"])
    except (OSError, ValueError, KeyError, TypeError):
        return None


def bundled_backtest(script_file: str) -> tuple[list[StatTrade], str]:
    """The backtest that ships with a built-in bot (assets/backtests/<script>.json), and a line saying what it is."""
    path = BACKTESTS / (Path(script_file).stem + ".json")
    if not path.exists():
        return [], ""
    try:
        doc = json.loads(path.read_text(encoding="utf-8"))
        trades = [StatTrade(datetime.fromisoformat(a), datetime.fromisoformat(b), side, size, net, sess, risk)
                  for a, b, side, size, net, sess, risk in doc["trades"]]
    except (OSError, ValueError, KeyError, TypeError) as e:
        log.warning("could not read %s: %s", path, e)
        return [], ""
    return trades, (f"Backtest of {doc['bot']} with {doc['settings']}, on {doc['data']}, after {doc['fees']}. "
                    "Past results, not a promise of future ones.")


def _session(raw: str | None, bot: str, script: str, entry: datetime) -> str:
    by_time = SESSION_BY_TIME.get(Path(script).stem if script else "")
    if by_time:
        return by_time(entry.astimezone(NY))
    raw = raw or ""
    return "" if raw == bot else SESSION_NAMES.get(raw, raw)


def from_round_trips(trips, bot: str, tz, script: str = "") -> list[StatTrade]:
    """This bot's real trades at Topstep (Performance's round trips, already labelled from logs/fills.csv)."""
    names = {bot, *OLD_NAMES.get(bot, ())}
    out = []
    for t in trips:
        if t.bot not in names:
            continue
        row = t.log or {}
        sess = _session(row.get("session"), bot, script, t.entry_time)
        risk = None
        try:
            stop = float(row.get("stop") or "nan")
            if stop == stop and t.points:
                risk = abs(t.entry_price - stop) * t.size * abs(t.pnl / (t.points * t.size))
        except (ValueError, ZeroDivisionError):
            pass
        side = 1 if t.side.value == "buy" else -1
        out.append(StatTrade(t.entry_time.astimezone(tz), t.exit_time.astimezone(tz), side, t.size, t.net, sess,
                             risk or None, t.fees, t.account))
    return out


def from_replay(trades, tz, bot: str = "", script: str = "") -> list[StatTrade]:
    """A replay's closed trades (BotTrade)."""
    return [StatTrade(t.entry_time.astimezone(tz), t.exit_time.astimezone(tz), 1 if t.side.value == "buy" else -1,
                      t.size, t.pnl, _session(t.session, bot, script, t.entry_time))
            for t in trades if t.exit_time and t.pnl is not None]


def in_period(trades: list[StatTrade], period, today: date) -> list[StatTrade]:
    if period is None:
        return trades
    if isinstance(period, tuple):  # ("year", 2025)
        return [t for t in trades if t.exit_time.year == period[1]]
    start = date(today.year, 1, 1) if period == "ytd" else today - timedelta(days=int(period))
    return [t for t in trades if t.exit_time.date() >= start]


def _short(v: float) -> str:
    """A month cell: +2.3k, -950."""
    return f"{v / 1000:+.1f}k" if abs(v) >= 1000 else f"{v:+.0f}"


def _whole(v: float | None) -> str:
    return "–" if v is None else ("+" if v > 0 else "-" if v < 0 else "") + f"${abs(v):,.0f}"


def _ratio(v: float | None) -> str:
    return "–" if v is None else f"{v:.2f}"


def _colour(v: float | None) -> str | None:
    if not v:
        return None
    return theme.UP if v > 0 else theme.DOWN


class BotStatsPanel(QFrame):
    """The panel on the My bots page. Shows one bot's Live (real trades) or Backtest stats."""
    source_changed = Signal(str)  # "live" or "backtest"
    run_backtest = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("box")
        self._trades: dict[str, list[StatTrade]] = {"live": [], "backtest": []}
        self._can_run = True
        self._notes: dict[str, str] = {"live": "", "backtest": ""}
        self.source = "live"
        lay = QVBoxLayout(self)
        lay.setContentsMargins(16, 14, 16, 16)
        lay.setSpacing(12)

        head = QHBoxLayout()
        title = QLabel("BOT STATS")
        title.setObjectName("statTitle")
        head.addWidget(title)
        head.addSpacing(12)
        seg = QFrame()
        seg.setObjectName("seg")
        sl = QHBoxLayout(seg)
        sl.setContentsMargins(2, 2, 2, 2)
        sl.setSpacing(2)
        self.seg = QButtonGroup(self)
        self.seg.setExclusive(True)
        for key, label in (("live", "Live trades"), ("backtest", "Backtest")):
            b = QPushButton(label)
            b.setCheckable(True)
            b.setChecked(key == "live")
            b.clicked.connect(lambda _c=False, k=key: self.set_source(k))
            self.seg.addButton(b)
            sl.addWidget(b)
        head.addWidget(seg)
        head.addSpacing(12)
        self.period = QComboBox()
        for label, v in PERIODS:
            self.period.addItem(label, v)
        self.period.currentIndexChanged.connect(lambda _i: self._render())
        head.addWidget(self.period)
        head.addSpacing(10)
        self.range = QLabel("")
        self.range.setObjectName("muted")
        head.addWidget(self.range)
        head.addStretch(1)
        self.run = QPushButton("Run backtest…")
        self.run.clicked.connect(self.run_backtest.emit)
        head.addWidget(self.run)
        lay.addLayout(head)

        self.note = QLabel("")
        self.note.setObjectName("muted")
        self.note.setWordWrap(True)
        lay.addWidget(self.note)

        tiles = QGridLayout()
        tiles.setHorizontalSpacing(10)
        tiles.setVerticalSpacing(10)
        names = ["Net P&L", "Win rate", "Profit factor", "Trades",
                 "Avg win / avg loss", "Expectancy", "Max drawdown", "Streaks"]
        self.tiles = {n: Tile(n) for n in names}
        for tile in self.tiles.values():
            tile.setMinimumHeight(84)  # the page scrolls: don't let the code box squeeze the figures
        for i, n in enumerate(names):
            tiles.addWidget(self.tiles[n], i // 4, i % 4)
        lay.addLayout(tiles)

        ch = QLabel("RUNNING P&L")
        ch.setObjectName("statTitle")
        lay.addWidget(ch)
        self.chart = Chart("curve")
        self.chart.setMinimumHeight(230)
        lay.addWidget(self.chart)

        low = QHBoxLayout()
        low.setSpacing(12)
        left = QVBoxLayout()
        left.setSpacing(6)
        t1 = QLabel("BY SESSION AND SIDE")
        t1.setObjectName("statTitle")
        left.addWidget(t1)
        self.groups = _table(["", "TRADES", "WIN RATE", "PF", "NET"])
        left.addWidget(self.groups)
        left.addStretch(1)
        right = QVBoxLayout()
        right.setSpacing(6)
        t2 = QLabel("MONTHS")
        t2.setObjectName("statTitle")
        right.addWidget(t2)
        self.months = QTableWidget(0, 14)
        self.months.setHorizontalHeaderLabels([""] + [calendar.month_abbr[m].upper() for m in range(1, 13)] + ["YEAR"])
        self.months.verticalHeader().setVisible(False)
        self.months.setShowGrid(False)
        self.months.setFocusPolicy(Qt.NoFocus)
        self.months.setSelectionMode(QTableWidget.NoSelection)
        self.months.setEditTriggers(QTableWidget.NoEditTriggers)
        hh = self.months.horizontalHeader()
        hh.setDefaultAlignment(Qt.AlignRight | Qt.AlignVCenter)
        hh.setSectionResizeMode(hh.ResizeMode.Stretch)
        hh.setSectionResizeMode(0, hh.ResizeMode.ResizeToContents)
        hh.setSectionResizeMode(13, hh.ResizeMode.ResizeToContents)
        self.months.setStyleSheet("QTableWidget { font-size: 12px; } QHeaderView::section { font-size: 10.5px; }")
        right.addWidget(self.months)
        right.addStretch(1)
        low.addLayout(left, 4)
        low.addLayout(right, 7)
        lay.addLayout(low)
        self._render()

    # --- data -------------------------------------------------------------------------------------
    def set_trades(self, source: str, trades: list[StatTrade], note: str = "") -> None:
        self._trades[source] = trades
        self._notes[source] = note
        if source == self.source:
            self._periods()
            self._render()

    def set_can_run(self, can: bool, why: str = "") -> None:
        """Run backtest… is only for bots the app can replay (not TradingView alerts bots)."""
        self._can_run = can
        self.run.setToolTip("" if can else why)
        self.run.setVisible(self.source == "backtest" and can)

    def set_busy(self, busy: bool) -> None:
        self.run.setEnabled(not busy)
        self.run.setText("Running…" if busy else "Run backtest…")

    def period_range(self, today: date) -> tuple[date, date]:
        """The dates a backtest run covers: the chosen period (All = the last 90 days)."""
        v = self.period.currentData()
        if isinstance(v, tuple):
            return date(v[1], 1, 1), min(date(v[1], 12, 31), today)
        if v == "ytd":
            return date(today.year, 1, 1), today
        return today - timedelta(days=int(v or 90)), today

    def _periods(self) -> None:
        """The period list: the fixed ones, then each year the trades cover."""
        keep = self.period.currentText()
        years = sorted({t.exit_time.year for t in self._trades[self.source]}, reverse=True)
        self.period.blockSignals(True)
        self.period.clear()
        for label, v in PERIODS:
            self.period.addItem(label, v)
        for y in years:
            self.period.addItem(str(y), ("year", y))
        self.period.setCurrentIndex(max(self.period.findText(keep), 0))
        self.period.blockSignals(False)

    def set_source(self, source: str) -> None:
        self.source = source
        for b in self.seg.buttons():
            b.setChecked(b.text().lower().startswith(source[:4]))
        self._periods()
        self._render()
        self.source_changed.emit(source)

    # --- drawing ----------------------------------------------------------------------------------
    def _render(self) -> None:
        self.run.setVisible(self.source == "backtest" and self._can_run)
        trades = in_period(self._trades[self.source], self.period.currentData(), date.today())
        s = compute(trades)
        self.note.setText(self._notes[self.source])
        self.note.setVisible(bool(self._notes[self.source]))
        if s.first:
            self.range.setText(f"{s.first:%d %b %Y} – {s.last:%d %b %Y}  ·  {s.trades:,} trades"
                               + (f"  ·  {s.per_week:.1f} a week" if s.per_week else ""))
        else:
            self.range.setText("No trades yet" if self.source == "live" else "No backtest yet")
        t = self.tiles
        t["Net P&L"].set(money(s.net, True), f"best {money(s.best, True)} · worst {money(s.worst)}" if s.trades else "",
                         _colour(s.net))
        t["Win rate"].set(pct(s.win_rate), f"{s.wins} won · {s.losses} lost" if s.trades else "")
        pf = s.profit_factor
        t["Profit factor"].set(_ratio(pf), "gross won ÷ gross lost", None if pf is None else
                               (theme.UP if pf >= 1 else theme.DOWN))
        t["Trades"].set(f"{s.trades:,}", "" if s.per_week is None else f"{s.per_week:.1f} a week")
        t["Avg win / avg loss"].set(f"{money(s.avg_win)} / {money(s.avg_loss)}" if s.trades else "–",
                                    f"payoff {_ratio(s.payoff)}" if s.payoff else "")
        t["Expectancy"].set(money(s.expectancy, True), "per trade" + (f" · {s.avg_r:+.2f} R" if s.avg_r is not None else ""),
                            _colour(s.expectancy))
        t["Max drawdown"].set(money(s.max_drawdown), (f"{s.drawdown_date:%d %b %Y}" if s.drawdown_date else "")
                              + (f" · recovery {s.recovery:.1f}" if s.recovery and s.net > 0 else ""), theme.DOWN if s.max_drawdown else None)
        t["Streaks"].set(f"{s.win_streak} / {s.loss_streak}" if s.trades else "–",
                         "most wins / losses in a row" if s.trades else "")
        self.chart.set_points(s.curve)
        rows = []
        for g in [*(s.sessions if len(s.sessions) > 1 else []), *s.sides]:  # one session = the total, so skip it
            rows.append([(g.name, None), (f"{g.trades:,}", theme.TEXT_2), (pct(g.win_rate), None),
                         (_ratio(g.profit_factor), None), (_whole(g.net), _colour(g.net))])
        _fill(self.groups, rows)
        years = sorted({y for y, _ in s.months}, reverse=True)
        self.months.setRowCount(len(years))
        for r, y in enumerate(years):
            cells = [str(y)] + [s.months.get((y, m)) for m in range(1, 13)]
            total = sum(v for (yy, _), v in s.months.items() if yy == y)
            for c, v in enumerate(cells + [total]):
                if c == 0:
                    it = QTableWidgetItem(v)
                    it.setForeground(QColor(theme.TEXT_2))
                else:
                    it = QTableWidgetItem("" if v is None else _short(v))
                    it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                    if v is not None:
                        it.setForeground(QColor(_colour(v) or theme.TEXT_2))
                        if c == 13:
                            f = it.font()
                            f.setBold(True)
                            it.setFont(f)
                self.months.setItem(r, c, it)
            self.months.setRowHeight(r, 30)
        self.months.setFixedHeight(self.months.horizontalHeader().height() + 30 * len(years) + 6)
