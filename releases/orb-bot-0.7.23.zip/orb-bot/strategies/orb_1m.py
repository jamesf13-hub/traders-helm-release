"""ORB 1M: opening range breakout on one-minute bars. For James's own use only.

Runs on MNQ one-minute bars (New York times):
  - Opening range 09:30-09:45. Breakouts are checked on 15-minute closes from 10:00 to 15:45.
  - The breakout candle must be solid and touch the level 3+ times; then the direction can flip (prior day
    against it by 3%+, or the 15 most similar past days say the fade wins), with short waits before entering.
  - Stop 1.25 x the range (2-100 points), target 3R (1.25R on big-range days). At 1.25R in profit the stop
    moves to break-even (0.75R -> +0.1R against the 20-day trend). 15:30: out unless 0-1R up. 16:00: flat.
  - $535 risk, 2 contracts max (1 on big-range or against-trend days). The bot's own max contracts and daily
    loss limit still apply on top.

Everything the strategy remembers between days (ranges, closes, the similar-days model's past trades) starts
from history built from 2020-2026 one-minute data and is kept in logs/orb-1m-state.json after each day.
If the app is closed for a while it catches up on Topstep's bars when started (no late trades).

The logic itself is in orb_bot/orb_1m.py.
"""
import json
import logging
from datetime import datetime, time, timedelta, timezone

from orb_bot import orb_1m as ao
from orb_bot.scripting import Strategy

log = logging.getLogger("orb_1m")
STATE_FILE = "orb-1m-state.json"
OLD_STATE_FILE = "agent-orb-state.json"  # its name before v0.7.21
BUNDLED_CONTRACT = "CON.F.US.MNQ.Z26"  # the bundled history is on the December 2026 contract's prices


class Orb1M(Strategy):
    name = "ORB 1M"
    symbol = "MNQ"
    bar_minutes = 1
    history = 30
    params = {"risk_dollars": 535.0, "max_contracts": 2}

    def on_start(self):
        settings = ao.Settings(fixed_risk=float(self.p.risk_dollars), max_contracts=int(self.p.max_contracts))
        self.core = ao.Orb1M(settings, log=log.info, hooks=self)
        state = self._newest_state()
        self.core.load_state(state)
        self.core.on_day_done = self._save_state
        was = state.get("contract_id") or BUNDLED_CONTRACT
        self._contract = self.contract_id or was
        if self.contract_id and was != self.contract_id:
            self._roll(was, self.contract_id)
        # carry on from the evening after the last day it knows (17:00 New York)
        self.resume = datetime.combine(self.core.cash_date, time(17, 0), ao.NEW_YORK).astimezone(timezone.utc)
        self.warmup_start = self.resume
        log.info("ORB 1M: history up to %s (%d past days in the model)", self.core.cash_date, len(self.core.rows))

    # --- the app calls this every closed one-minute bar ------------------------------------------
    def on_bar(self, bar):
        open_utc = bar.time.astimezone(timezone.utc)
        if open_utc < self.resume:
            return  # already in the saved history
        open_et = bar.time.astimezone(ao.NEW_YORK).replace(tzinfo=None)
        core = self.core
        core.live = self.live
        core.s.fixed_risk, core.s.max_contracts = float(self.p.risk_dollars), int(self.p.max_contracts)
        t = core.pos
        if t is not None and not t.real and self.live and self.position * t.side > 0:
            t.real = True  # the app restarted mid-trade: the bot's trade at Topstep is this one
        if t is not None and t.real and self.entry_price and not getattr(t, "synced", False):
            # NinjaTrader measures the stop, target and R from the real fill price
            t.entry = self.entry_price
            t.stop = ao.round_tick(t.entry - t.side * t.stop_ticks * ao.TICK)
            t.target = ao.round_tick(t.entry + t.side * t.target_ticks * ao.TICK)
            t.synced = True
        core.on_bar(ao.Bar(open_utc.replace(tzinfo=None), open_et, ao.cash_date_of(open_et),
                           bar.open, bar.high, bar.low, bar.close, bar.volume))
        if not self.live:
            return
        if core.pos is not None and core.pos.real and self.position == 0 and core.pending_entry is None:
            core.close_pos(bar.close, open_et, "closed at Topstep")  # its stop or target filled there
        close_min = open_et.hour * 60 + open_et.minute + 1
        if self.position != 0 and core.pos is None and close_min >= ao.CASH_CLOSE:
            self.close("16:00 ET close")  # never hold past the cash close

    # --- hooks the strategy core calls on live bars ---------------------------------------------
    def enter(self, t) -> bool:
        why = f"ORB 1M {t.source} / {t.path}"
        order = self.buy if t.side == 1 else self.sell
        order(stop_ticks=t.stop_ticks, target_ticks=t.target_ticks, contracts=t.qty, reason=why)
        return True

    def move_stop(self, price, t=None):  # also the kit's own move_stop
        super().move_stop(price)

    def exit(self, reason: str) -> None:
        self.close(reason)

    # --- saved state ------------------------------------------------------------------------------
    def _newest_state(self) -> dict:
        bundled = ao.bundled_state()
        saved = None
        if self.data_dir is not None:
            for name in (STATE_FILE, OLD_STATE_FILE):
                try:
                    saved = json.loads((self.data_dir / name).read_text())
                    break
                except (OSError, ValueError):
                    saved = None
        if saved and saved.get("cash_date") and saved["cash_date"] >= bundled["cash_date"]:
            return saved
        return bundled

    def _roll(self, old: str, new: str) -> None:
        """New quarter's contract: like NinjaTrader's back-adjusted chart, move the remembered closes by the gap
        between the two contracts (measured on the latest minute both traded in the last few days)."""
        end = datetime.now(timezone.utc)
        start = end - timedelta(days=5)
        a = {b.time: b.close for b in self.bars_of(old, start, end, 1)}
        b = {b.time: b.close for b in self.bars_of(new, start, end, 1)}
        common = sorted(set(a) & set(b))
        if not common:
            log.warning("ORB 1M: new contract %s, but the gap to %s couldn't be measured; its 20-day trend uses "
                        "unadjusted closes until the history catches up", new, old)
            return
        gap = round((b[common[-1]] - a[common[-1]]) / ao.TICK) * ao.TICK
        self.core.shift_prices(gap)
        log.info("ORB 1M: rolled from %s to %s; past closes moved by %+.2f points", old, new, gap)

    def _save_state(self, core) -> None:
        if self.data_dir is None:
            return
        try:
            self.data_dir.mkdir(parents=True, exist_ok=True)
            tmp = self.data_dir / (STATE_FILE + ".tmp")
            tmp.write_text(json.dumps({**core.to_state(), "contract_id": self._contract}))
            tmp.replace(self.data_dir / STATE_FILE)
        except OSError as e:
            log.warning("ORB 1M: couldn't save its history (%s)", e)
