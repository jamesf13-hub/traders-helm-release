"""Trading performance, worked out the way TopstepX does it: from the account's own fills at Topstep.

Fills are grouped into round trips (flat to flat on one contract). Each round trip is matched to the bot
that opened it using logs/fills.csv (the bot's entry order id, or for older rows its side, size and entry
price). Pure functions, so the Performance window and the tests share them."""
from __future__ import annotations

import csv
import logging
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

from .models import Fill, Side
from .strategy.orb import trading_day

log = logging.getLogger(__name__)

MANUAL = "Manual / other"
PERIODS = ["Today", "This week", "Last week", "This month", "Last month", "Last 30 days", "All time"]
WEEKDAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]


@dataclass
class RoundTrip:
    account: str
    contract: str
    side: Side  # the opening side: BUY = long
    size: int  # largest position held
    entry_time: datetime
    exit_time: datetime
    entry_price: float  # average
    exit_price: float  # average
    pnl: float  # before fees
    fees: float
    order_ids: set[int] = field(default_factory=set)
    bot: str = MANUAL
    fills: list = field(default_factory=list)  # Topstep's fills that made up the trade
    log: dict | None = None  # the bot's own row in logs/fills.csv (signal, planned stop/target), if any

    @property
    def net(self) -> float:
        return self.pnl - self.fees

    @property
    def duration(self) -> timedelta:
        return self.exit_time - self.entry_time


def round_trips(fills: list[Fill], account: str = "") -> list[RoundTrip]:
    """One trade per entry order, the way TopstepX lists them. Each order that opens or adds to a position is
    its own trade; closing fills are matched to the open ones first in, first out. So two bots in the same
    contract at once (or one adding to a position) show as separate trades, each with its own entry and exit.
    A fill that flips the position closes what's open and opens a new trade with the rest of its size."""
    trips: list[RoundTrip] = []
    by_contract: dict[str, list[Fill]] = {}
    for f in sorted(fills, key=lambda f: f.time):
        by_contract.setdefault(f.contract_id, []).append(f)
    for contract, cf in by_contract.items():
        lots: list[dict] = []  # open trades, oldest first
        for f in cf:
            sign = f.side.sign
            open_sign = lots[0]["side"].sign if lots else 0
            qty = f.size
            if lots and sign != open_sign:  # closing (part of) the open trades, oldest first
                matched = []
                for lot in lots:
                    if not qty:
                        break
                    q = min(qty, lot["left"])
                    if q:
                        matched.append((lot, q))
                        qty -= q
                closed_q = f.size - qty
                # Topstep gives one P&L per closing fill; share it out by each trade's points made
                pts = [(f.price - lot["in_v"] / lot["in_q"]) * open_sign * q for lot, q in matched]
                total_pts = sum(pts)
                for (lot, q), p_ in zip(matched, pts):
                    if f.pnl is None:
                        part = 0.0
                    elif total_pts:
                        part = f.pnl * p_ / total_pts
                    else:
                        part = f.pnl * q / closed_q
                    lot["left"] -= q
                    lot["out_q"] += q
                    lot["out_v"] += q * f.price
                    lot["pnl"] += part
                    lot["fees"] += f.fees * q / f.size
                    lot["ids"].add(f.order_id)
                    lot["fills"].append(f)
                    lot["t1"] = f.time
                for lot in [x for x in lots if not x["left"]]:
                    lots.remove(lot)
                    trips.append(RoundTrip(account, contract, lot["side"], lot["in_q"], lot["t0"], lot["t1"],
                                           lot["in_v"] / lot["in_q"], lot["out_v"] / lot["out_q"], lot["pnl"],
                                           lot["fees"], lot["ids"], fills=lot["fills"]))
                if not qty:
                    continue
            # opening or adding: the same order's fills make one trade
            fee = f.fees * qty / f.size
            lot = next((x for x in lots if x["order"] == f.order_id and not x["out_q"]), None)
            if lot is None:
                lot = {"order": f.order_id, "side": f.side, "t0": f.time, "t1": f.time, "in_q": 0, "in_v": 0.0,
                       "left": 0, "out_q": 0, "out_v": 0.0, "pnl": 0.0, "fees": 0.0, "ids": {f.order_id},
                       "fills": []}
                lots.append(lot)
            lot["in_q"] += qty
            lot["in_v"] += qty * f.price
            lot["left"] += qty
            lot["fees"] += fee
            if f not in lot["fills"]:
                lot["fills"].append(f)
    trips.sort(key=lambda t: t.entry_time)
    return trips


def trade_day(t: RoundTrip) -> date:
    """The Topstep trading day a trade belongs to (by its exit): a new day starts at 5pm Chicago time,
    so the Performance days match TopstepX's."""
    return trading_day(t.exit_time)


# --- which bot opened each trade ----------------------------------------------------------------------
def read_bot_log(path: Path) -> list[dict]:
    if not path.exists():
        return []
    try:
        with path.open(newline="") as f:
            return [r for r in csv.DictReader(f) if r.get("mode") != "paper"]
    except OSError as e:
        log.warning("could not read %s: %s", path, e)
        return []


def label_bots(trips: list[RoundTrip], rows: list[dict], tz: ZoneInfo, tick: float = 0.25) -> None:
    """Set each trade's bot from logs/fills.csv. Unmatched trades stay "Manual / other"."""
    by_order = {}
    loose = []
    for r in rows:
        oid = (r.get("entry_order_id") or "").strip()
        if oid.isdigit():
            by_order[int(oid)] = r
        else:
            loose.append(r)
    for t in trips:
        hit = next((by_order[i] for i in t.order_ids if i in by_order), None)
        if hit is None:
            side = t.side.value
            day = t.entry_time.astimezone(tz).date().isoformat()
            for r in loose:
                try:
                    fill = float(r.get("entry_fill") or "nan")
                    size = int(float(r.get("size") or 0))
                except ValueError:
                    continue
                if (r.get("account") == t.account and r.get("side") == side and r.get("date") == day
                        and size == t.size and abs(fill - t.entry_price) < tick / 2):
                    hit = r
                    loose.remove(r)
                    break
        if hit:
            t.bot, t.log = hit["bot"], hit


def daily_balances(trips: list[RoundTrip], tz: ZoneInfo, balance: float, start: date, end: date,
                   today: date) -> list[tuple[date, float]]:
    """End-of-day balance for each weekday from start to end, worked back from today's balance: a day's
    close is today's balance minus every trade's net P&L closed after that day. Pass all of the account's
    trades (not one bot's)."""
    later: dict[date, float] = {}
    for t in trips:
        d = trade_day(t)
        later[d] = later.get(d, 0.0) + t.net
    out = []
    d = start
    while d <= min(end, today):
        if d.weekday() < 5 or later.get(d):
            out.append((d, balance - sum(v for k, v in later.items() if k > d)))
        d += timedelta(days=1)
    return out


# --- filtering ---------------------------------------------------------------------------------------
def period_range(period: str, today: date) -> tuple[date | None, date | None]:
    monday = today - timedelta(days=today.weekday())
    first = today.replace(day=1)
    if period == "Today":
        return today, today
    if period == "This week":
        return monday, today
    if period == "Last week":
        return monday - timedelta(days=7), monday - timedelta(days=1)
    if period == "This month":
        return first, today
    if period == "Last month":
        last = first - timedelta(days=1)
        return last.replace(day=1), last
    if period == "Last 30 days":
        return today - timedelta(days=29), today
    return None, None


def filter_trips(trips: list[RoundTrip], tz: ZoneInfo, start: date | None = None, end: date | None = None,
                 bot: str = "") -> list[RoundTrip]:
    out = []
    for t in trips:
        d = trade_day(t)
        if (start is None or d >= start) and (end is None or d <= end) and (not bot or t.bot == bot):
            out.append(t)
    return out


# --- the numbers -------------------------------------------------------------------------------------
@dataclass
class Group:
    name: str
    trades: int = 0
    wins: int = 0
    net: float = 0.0

    @property
    def win_rate(self) -> float | None:
        return self.wins / self.trades if self.trades else None


@dataclass
class Summary:
    trades: int = 0
    wins: int = 0
    losses: int = 0
    longs: int = 0
    contracts: int = 0
    net: float = 0.0
    fees: float = 0.0
    gross_win: float = 0.0
    gross_loss: float = 0.0  # negative
    max_drawdown: float = 0.0  # from the highest point of the running total; negative or 0
    best: RoundTrip | None = None
    worst: RoundTrip | None = None
    avg_duration: timedelta | None = None
    avg_win_duration: timedelta | None = None
    avg_loss_duration: timedelta | None = None
    curve: list[tuple[date, float]] = field(default_factory=list)  # running total at the end of each day
    days: dict[date, Group] = field(default_factory=dict)
    weekdays: list[Group] = field(default_factory=list)  # Monday first, only days that traded
    bots: list[Group] = field(default_factory=list)

    @property
    def win_rate(self) -> float | None:
        return self.wins / self.trades if self.trades else None

    @property
    def profit_factor(self) -> float | None:
        return self.gross_win / -self.gross_loss if self.gross_loss else None

    @property
    def avg_win(self) -> float | None:
        return self.gross_win / self.wins if self.wins else None

    @property
    def avg_loss(self) -> float | None:
        return self.gross_loss / self.losses if self.losses else None

    @property
    def win_loss_ratio(self) -> float | None:
        aw, al = self.avg_win, self.avg_loss
        return aw / -al if aw is not None and al else None

    @property
    def day_win_rate(self) -> float | None:
        traded = [g for g in self.days.values() if g.trades]
        return sum(g.net > 0 for g in traded) / len(traded) if traded else None

    @property
    def best_day(self) -> tuple[date, float] | None:
        if not self.days:
            return None
        d, g = max(self.days.items(), key=lambda kv: kv[1].net)
        return d, g.net

    @property
    def worst_day(self) -> tuple[date, float] | None:
        if not self.days:
            return None
        d, g = min(self.days.items(), key=lambda kv: kv[1].net)
        return d, g.net

    @property
    def best_day_share(self) -> float | None:
        """Best day as a share of total profit (Topstep's consistency figure)."""
        b = self.best_day
        return b[1] / self.net if b and self.net > 0 and b[1] > 0 else None


def _avg_td(items: list[timedelta]) -> timedelta | None:
    return sum(items, timedelta()) / len(items) if items else None


def summarise(trips: list[RoundTrip], tz: ZoneInfo) -> Summary:
    s = Summary(trades=len(trips))
    trips = sorted(trips, key=lambda t: t.exit_time)
    peak = running = 0.0
    bots: dict[str, Group] = {}
    weekdays: dict[int, Group] = {}
    for t in trips:
        n = t.net
        d = trade_day(t)
        running += n
        peak = max(peak, running)
        s.max_drawdown = min(s.max_drawdown, running - peak)
        s.fees += t.fees
        s.contracts += t.size
        s.longs += t.side is Side.BUY
        if n > 0:
            s.wins += 1
            s.gross_win += n
        elif n < 0:
            s.losses += 1
            s.gross_loss += n
        if s.best is None or n > s.best.net:
            s.best = t
        if s.worst is None or n < s.worst.net:
            s.worst = t
        for g in (s.days.setdefault(d, Group(d.isoformat())), bots.setdefault(t.bot, Group(t.bot)),
                  weekdays.setdefault(d.weekday(), Group(WEEKDAYS[d.weekday()]))):
            g.trades += 1
            g.wins += n > 0
            g.net += n
        if s.curve and s.curve[-1][0] == d:
            s.curve[-1] = (d, running)
        else:
            s.curve.append((d, running))
    s.net = running
    s.avg_duration = _avg_td([t.duration for t in trips])
    s.avg_win_duration = _avg_td([t.duration for t in trips if t.net > 0])
    s.avg_loss_duration = _avg_td([t.duration for t in trips if t.net < 0])
    s.weekdays = [weekdays[k] for k in sorted(weekdays)]
    s.bots = sorted(bots.values(), key=lambda g: g.net, reverse=True)
    return s


def fmt_duration(td: timedelta | None) -> str:
    if td is None:
        return "–"
    secs = int(td.total_seconds())
    h, rem = divmod(secs, 3600)
    m, sec = divmod(rem, 60)
    if h:
        return f"{h}h {m}m"
    return f"{m}m {sec:02d}s" if m else f"{sec}s"
